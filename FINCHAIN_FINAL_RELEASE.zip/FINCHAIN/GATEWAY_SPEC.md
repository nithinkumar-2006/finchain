# Gateway simulator specification

The private FastAPI gateway owns a separate PostgreSQL database and service credential. It accepts only BPI sandbox INR and FUNDING, TRANSFER or REDEMPTION operations. Its request contains operation UUID, network, currency, amount, kind and scenario. It never contacts a bank or holds money.

SUCCESS returns SUCCEEDED; FAILURE returns FAILED; UNKNOWN initially returns UNKNOWN and resolves to SUCCEEDED after the configured 15-second simulator interval. Operation UUID plus request digest is durable. An altered request for an existing UUID fails. Terminal evidence is stored in a statement and authenticated with HMAC-SHA256 over canonical JSON.

The BPI worker verifies the evidence signature, operation, network, currency, amount and environment. Repeated evidence cannot double-post. A contradictory terminal response is audited/quarantined rather than reversing an already applied result. Timeout or unavailable gateway does not imply failure and does not make pending value spendable.

A legally permitted integration later needs a separately reviewed adapter, regulated partner contract, custody/settlement model, signed callbacks, reconciliation files, chargeback/return behavior, privacy and incident procedures. That adapter is not implemented or authorized by this sandbox. The current user-facing balances have no cash value.
