# Blockchain implementation specification

Separate network IDs default to `finchain-bpi-sandbox-1` and `finchain-fincoin-sandbox-1`. SHA-256, Ed25519 and RFC 8785 JSON canonicalization are supplied by established libraries. Financial numbers are canonical integer strings. UUID references, domain, sandbox environment, timestamps, expiry, nonce, fee and signing-key reference are bound into user instructions.

Payload digest is SHA-256 of `FINCHAIN:PAYLOAD:v1:` plus canonical payload bytes. Ed25519 signs that digest as a raw message. Transaction hash is SHA-256 of `FINCHAIN:TX:v1:` plus digest bytes and signature bytes. The journal commitment is SHA-256 of byte `03`, random 32-byte salt and SHA-256 of canonical journal lines. Salts remain encrypted privately.

Merkle leaves hash byte `00` plus transaction hash and journal commitment; branches hash byte `01` plus child hashes; the empty root hashes byte `02`. Block hashes bind `FINCHAIN:BLOCK:v1:` to canonical headers. Each committed financial event currently occupies one block. Genesis height zero is empty and commits network policy. FINCOIN's initial issuance is a subsequent journaled event.

Replay validation checks signatures, hashes, links, network/policy binding, wallet key/nonce progression, journal commitments, per-asset conservation, projected balances and head. Public proofs attest inclusion in this operator's chain, not external settlement or regulatory validity. Neither private identity data nor wallet addresses/amounts are exported to the explorer.

System-operation identifiers, journal identifiers, account identifiers and signing timestamps are stable across transaction retries. A test simulates failure after durable signer acceptance and verifies recovery without duplicate funding.
