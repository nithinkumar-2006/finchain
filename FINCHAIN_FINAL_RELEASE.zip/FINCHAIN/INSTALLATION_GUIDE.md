# Installation guide

Prerequisites: Python 3.12, Docker Engine/Desktop with Compose v2, and enough memory for PostgreSQL, two domain workers, signer services and the web build. Node 22 and pnpm are needed only for host-based frontend development. Docker is not bundled.

Extract the release into a writable folder. From that folder:

```powershell
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r services/platform/requirements.lock
.venv\Scripts\python.exe scripts/configure_sandbox.py
docker compose -f compose.json config --quiet
docker compose -f compose.json up --build -d
docker compose -f compose.json ps
```

On Linux/macOS, replace `.venv\Scripts\python.exe` with `.venv/bin/python`.

Configuration creates random credentials, independent signer masters and a 30-day localhost certificate under `.secrets`. It refuses to overwrite an existing secret directory. Preserve this directory and the PostgreSQL volume together; replacing signer or encryption keys makes existing records unusable. Do not upload either directory.

Open `https://localhost:8443`, register, and use the verification link in the local inbox at `http://localhost:8025`. The browser will warn about the self-signed development certificate. Trust only your locally generated certificate for this localhost sandbox.

Optional demo accounts:

```powershell
docker compose -f compose.json --profile demo run --rm seed-demo
```

Read `.secrets/demo/credentials.json` locally. Merchant/admin users must enroll an authenticator through Account security before protected actions. No published default password exists. Use `docker compose -f compose.json stop` to stop without deleting data. Do not use volume deletion as a repair step.

Docker launch is supplied but not execution-verified on the delivery machine. If a service fails, inspect its safe logs and the migration exit status before trying financial actions.
