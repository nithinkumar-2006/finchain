# Production gate checklist

All items below require evidence and accountable owners before handling real value:

- Establish legally permitted roles, partner arrangements, custody boundaries, customer disclosures and operating jurisdiction. Obtain qualified legal/compliance review; this repository is not authorization.
- Complete full-container acceptance, browser financial journeys, concurrency/load tests, independent security assessment and remediation.
- Replace sandbox signer masters with reviewed managed key/HSM custody and exact Ed25519 interoperability; establish dual control, recovery and key rotation.
- Replace simulated gateway/market/execution/fulfillment with explicitly approved adapters; build reconciliations, returns, dispute and outage procedures.
- Pin/scan signed images and dependencies; configure secrets manager, workload identity, TLS/mTLS, environment isolation, least-privilege operators and resource limits.
- Prove restore and failover without double posting; verify authoritative checkpoints and anti-rollback controls. Export append-only audit evidence to an independent retention system.
- Add monitoring for queue age, gateway unknowns, writer epochs, signer failures, chain replay, proof projection lag, stock expiry and webhook retries. Define on-call and incident responsibilities.
- Validate privacy retention/deletion, access requests, encryption rotation, data residency and administrator review workflows.
- Complete MFA recovery, hardware-backed privileged access and access recertification. Remove demo users, inbox and all test credentials.
- Independently validate monetary limits, risk policy, user-facing disclosures, accessibility, provider requirements and deployment acceptance.

None of these checklist items is implicitly satisfied by a passing unit test or the name of the final ZIP.
