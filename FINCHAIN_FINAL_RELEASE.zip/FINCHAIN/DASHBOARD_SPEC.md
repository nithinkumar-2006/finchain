# FINCHAIN — Consumer Dashboard and BPI Screens

Role 2 · Version 1.0 · Routes: [PAGE_MAP.md](PAGE_MAP.md). Visual tokens: [DESIGN_SYSTEM.md](DESIGN_SYSTEM.md).

## 1. Dashboard C-01

Purpose: understand spendable BPI value, pay or receive quickly, and track unresolved activity. Page heading “Dashboard”; subheading “BPI Payments · Sandbox”. Date-range controls apply only to activity metrics, not the current available balance. Desktop content follows this arrangement:

```text
240 px sidebar | 64 px header: BPI context, help, profile
               | Dashboard                    Period / Updated at
               | [Available BPI balance — 8 columns] [Quick actions — 4]
               | [Sent — 4] [Received — 4] [Monthly spend — 4]
               | [Recent transactions — 8] [Receive QR / address — 4]
               | [Spend history — 8]       [Security / network — 4]
```

Balance card: large `₹1,000.00` followed immediately by “Simulated INR”; below, Reserved and Incoming pending. No FINCOIN number in this card or its tooltip. Primary Pay and secondary Receive can live inside the card; Quick actions contains named recent recipients (private, permission-scoped), Scan QR and sandbox funding. Do not repeat the same primary Pay button in three cards.

| Widget | Definition / source | Interaction / exceptional state |
|---|---|---|
| Available BPI Balance | Authoritative available = settled minus active holds | Open Wallet; unknown shows “Balance unavailable”, not ₹0 |
| Reserved | Active holds, not an additional asset | Explain that reserved value cannot be reused; open pending outgoing activity |
| Incoming pending | Pending recipient credits, excluded from available | Open pending incoming activity |
| Total Sent | Sum of completed outgoing ordinary payments in selected period, excluding refunds/funding/redemption | Link filtered history; explicit gross figure |
| Total Received | Sum of completed incoming ordinary payments in period, excluding refunds/funding/redemption | Link filtered history; no pending credits counted |
| Monthly Spend | Completed outgoing P2P/P2B payments during current selected month, excluding funding/redemption/refunds | Label gross spending; returns before completion excluded, refunds reported separately |
| Recent Transactions | Latest 5 authorized activity records, all current states | Transaction ID link → same private receipt; View all |
| Quick Pay | Private recent counterparties or scan entry | Prefill recipient only; amount/review still required |
| Receive Money / QR | Own address/request actions | Default compact address card; Generate request opens amount/expiry step |
| Wallet Address | Masked middle display, full copy/reveal | “Copied BPI sandbox address”; never copy truncated text |
| Security Alerts | Actual unresolved security notices | Open relevant Security step; missing service is not “All secure” |
| Network Status | Separate BPI chain and simulated settlement health with update time | Click details; FINCOIN incident does not mark BPI down |

Metric calculations are backend aggregate UX-E06 contracts over the full authorized dataset, not sums of the visible first page. Bound period in the chosen display zone; show the zone and exact start/end in metric info. Personal dashboard defaults to current calendar month, display zone Asia/Kolkata on first use, user-adjustable. Figures in wireframes/fixtures are illustrative, never runtime fallback data.

First use: “Your BPI wallet is ready” with `₹0.00 · Simulated INR`, Add test funds and Receive. Empty history says “No BPI payments yet”. A missing wallet is a creation state, not a zero balance. Section failures isolate the affected panel; if available balance cannot be verified, disable authorization while keeping history/help accessible. No investment upsell blocks any BPI task.

## 2. Pay entry C-02

Desktop: 7-column form and 5-column explanation/recent recipients; max form width 640 px. Mobile: single column, source above recipient, inline keyboard and review action above safe area. Heading “Pay with BPI”; always visible sandbox badge.

| Field | Control / behavior | Validation |
|---|---|---|
| Source | Own consumer wallet; authorized merchant source only in merchant context | Current ownership/role, available funds, active account |
| Recipient | BPI Address / Username label; paste/scan plus exact alias lookup only with E01 | Validate prefix/checksum/network, then resolve; no partial global search |
| Resolved recipient | Name/merchant display label, type and full selectable address | Sender confirms intended party; “Sandbox merchant profile” is not legal verification |
| Amount | Decimal input, fixed INR suffix; 2 fractional digits | Positive, within available balance/limits; reject excess decimals |
| Currency | Read-only “INR — simulated” | No FINCOIN or FX dropdown |
| Payment Note | Optional 140-character plain text only when E02 exists | Private participant metadata; no sensitive data prompt |
| Payment Type | Read-only P2P/P2B/B2P/B2B plus plain-language explanation | Derived from verified source/recipient, not editable |

P2P/P2B appear in a personal source context. B2P/B2B require merchant role/source context and may produce an approval proposal, not immediate personal signing. A user-facing format aid never overrides the server. Differentiate invalid address, unsupported network, unresolved recipient and permission restrictions without leaking another account's private existence.

Review is disabled until local required fields pass, but the server performs authoritative checks. Pressing Review creates a stable draft and resolves final details. Errors preserve valid inputs. Insufficient funds offers Deposit — sandbox or Edit amount; never Buy FINCOIN. A second in-progress outgoing authorization shows “Another payment is being processed from this wallet” with its status link, rather than exposing nonce jargon.

## 3. Review, checks and result C-03/C-04

Review screen shows source, verified recipient, full address, exact amount, network fee `₹0.00`, total, currency, derived payment type, optional private note, expiry and simulation disclosure. Leading amount is 32–40 px; recipient is next in hierarchy. Edit returns to entry and invalidates existing confirmation. Primary “Confirm simulated ₹500.00 payment”; secondary Edit/Cancel before submit.

If pre-confirmation risk context is available, place a safe advisory after recipient and before action. State that final checks occur after authorization. MFA is a distinct challenge retaining a summary of exactly what is being authorized. Staff/merchant approval flow identifies maker/checker and pending approval status.

Result uses a status headline, short explanation, current milestone, transaction reference and persistent details. “Transaction successful” only after the authoritative completed state, with subtitle “Simulated settlement completed”. For pending: “Recorded on BPI — settlement pending” and “The recipient cannot use this amount yet.” For unknown: “Settlement being checked” and “You do not need to send this payment again.” Use the canonical matrix in USER_FLOWS for all alternatives.

Receipt data: transaction ID, sender, receiver, amount, currency, payment type, requested/submitted/completed timestamps when available, network fee, overall status, blockchain status, block number, safe risk status, simulated settlement status, and linked return/refund IDs. Missing block number before inclusion displays “Not included yet”. Risk status is “Checks completed”, “Review required”, “Blocked” or “Unavailable” from authorized data; internal score is absent.

Primary receipt action View transaction; secondary View in Explorer opens only the public commitment/proof with no personal data. Copy reference and Print/save receipt are available; print carries sandbox, status and timestamps. Sharing a private receipt URL does not grant access. Never export a pending receipt with a “Paid” watermark. No confetti or investment messaging.

## 4. Scan C-05 and public request REQ-01

Scan page asks for camera access only after user action, shows an accessible scan guide plus Paste link/address and optional local image decoding. No scan sound/haptic requirement. Validate QR destination and network; ignore arbitrary executable URLs. A wrong-domain FINCOIN QR explains that BPI requires a BPI request/address; it does not convert or redirect a financial action automatically.

REQ-01 presents recipient display name, BPI sandbox identifier, amount/currency, request purpose if safely permitted, expiry and current request state. It contains no recipient balance/contact information. OPEN offers Sign in to pay/Review payment; CLAIMED, PAID, EXPIRED and CANCELED have status-specific explanations with no Pay button. After login or app resume, resolve again before review. If amount is fixed, the payer cannot edit it.

## 5. Receive C-06 and request details C-07

Desktop split: 5-column QR/address identity card, 7-column request builder/list. Show user's chosen display name, complete BPI address in expandable/selectable form, Copy Address, Request Amount, expiry and Generate Payment Request. Generated request card shows actual QR, exact amount, request ID, expiry and “FINCHAIN sandbox request”. Use solid white QR background, dark modules and quiet zone; never render a fake placeholder QR that appears scannable.

Show Share Payment Link only after a real request exists. Native share is invoked by explicit action, with clipboard/manual fallback. QR generation errors preserve amount/expiry and never expose a partially generated link. Address-only QR is labeled “Address only — enter amount when paying”. Choosing a requested amount produces a single-use server request, not merely text embedded in a QR.

Request details list OPEN/CLAIMED/PAID/EXPIRED/CANCELED, copy/share/download actions if eligible, permitted cancellation and linked payment for the owner. A paid/claimed request cannot be regenerated in place to accept a second payment. Expired request action “Create new request” creates a new ID. Merchant-specific static/dynamic QR behavior is in MERCHANT_UI_SPEC.

## 6. Transactions C-08 and private detail C-09

Filters: All, Sent, Received, Merchant, Refunds, Pending, Failed, Flagged. Also date range and permitted type/status filters. Implement chips as named filters rather than mutually inconsistent tabs: direction/type filters combine with status, and Reset clears them. Pending includes authorized/review/reserved/settlement-pending/unknown. Failed includes rejected/returned, with their distinct labels; canceled/expired remain selectable in status filtering. Flagged means a user-visible review marker, not every internal risk event.

Table columns: Transaction ID, Type, Counterparty, Amount, Date, Status, Risk Level. Direction appears with text/icon and signed display amount; refunds link their original. Risk Level is the safe LOW/MEDIUM/HIGH/CRITICAL classification when permitted, otherwise “Not shared” or “Unavailable” as appropriate; never infer it from payment success. Show `—` when assessment did not occur. Amounts right-aligned; all statuses include text.

Click reference opens C-09 full receipt, same data contract as C-04. Desktop may offer a detail preview drawer with Open full receipt; mobile uses the full page. Pagination is cursor-based; preserve filters on Back. Empty entire history says “No transactions yet”; no matches says “No transactions match these filters” with Clear filters. Failed load retains filters and Retry; it must not render an empty result. Export must respect scope and format safety and be labeled with period/time zone.

## 7. Wallet C-10–C-13

Wallet displays available BPI balance first, then settled/reserved/incoming pending definitions. Show BPI address, sandbox gateway card, recent wallet activity including funding/redemption, and Deposit — sandbox / Withdraw — sandbox / Transfer. Linked Settlement Gateway card reads “FINCHAIN gateway simulator”; status has update time, no bank logo or account number.

Deposit C-11: amount, cap information from server, source “Test funding”, clear no-real-money explanation, review, Submit sandbox deposit, operation progress and final credited result only after verified funding success. Unknown says “Funding result is being checked”; balance does not increase optimistically.

Withdraw C-12: available amount, fixed destination “Sandbox redemption simulator”, zero fee if applicable, total and explanation “This reduces test balance; no money is sent to a bank.” Review/authorize through the redemption contract, track pending/unknown/success/return. No bank details, cards or FINCOIN source. Do not treat redemption as an ordinary recipient payment in spending metrics.

Private address C-13: full own BPI address, domain/network, wallet status, key-custody explanation and scoped activity link. It remains authenticated and is not a public explorer address page. Never show private key, seed phrase or another address's full history. Exact private view rules are in EXPLORER_UI_SPEC.

## 8. Commerce C-14–C-19

Category grid includes Mobile Recharge, Utilities, Shopping, Travel, Subscriptions and Services. Use neutral category icons, not unlicensed partner marks. Cards show title, category, sample status, actual catalog price and availability; never invent purchasability. Baseline demo catalog can contain sample shopping/service items. Unsupported categories show “No sandbox items available” and explain that live recharge, bill payment, booking and recurring subscriptions are not connected. No Pay bill/Book flight/Activate subscription action is enabled in this release.

| Screen | Content and action | Exceptional behavior |
|---|---|---|
| C-14 Catalog | Categories, sample product cards, clear sandbox badge | Empty catalog explains no items; service error shows retry |
| C-15 Category | Category name, availability, scoped filters | Unsupported real-world integration has explanatory empty state |
| C-16 Product | Image/description, merchant, unit price, stock and “Sample item” notice | Out-of-stock disables Add with explanation; no invented delivery estimate |
| C-17 Cart | Quantity controls, remove, subtotal; server recalculation | Price/stock changes are highlighted before checkout |
| C-18 Checkout | Item summary, merchant, exact server total, BPI source, request expiry, Review payment | Insufficient funds offers sandbox funding; no FINCOIN checkout; changed total requires review |
| C-19 Order | Order state, items, BPI receipt link, fulfillment/review/refund timeline | Chain-only confirmation remains payment pending; late paid inventory expiry becomes review |

A recurring-service concept may be described publicly as future scope; one-time sample items must explicitly say they create no recurring charge. Checkout uses the shared BPI review and status components. On failure after payment, preserve the order/payment links rather than emptying the cart and making the user start again. Fulfillment is controlled by authoritative settlement/order events, never a local successful animation.

## 9. Security C-20–C-23 and settings C-24

Security overview: MFA enrollment status, recent account/security events, active sessions, password/recovery actions and signing-custody explanation. Do not use a fabricated “100% secure” score. MFA enrollment confirms a challenge before Enabled appears. Recovery codes require recent auth, appear only once, and regeneration explains that previous codes cease to work. Sessions show device description, last seen, current-session indicator and Revoke action; do not reveal unnecessary IP precision to shared screens.

Settings: display name, locale/time zone, dark appearance status, notifications supported by actual channels, opt-in username if E01/E07 implemented, accessibility preferences and account closure request. Display-name changes never rewrite historical signed transaction data. Unknown save result says “Checking whether changes were saved”; refetch before claiming success. Closing an account explains access removal and retained immutable records according to published policy; no promise of deleting blocks.

## 10. Consumer acceptance

At 320/390/768/1,024/1,440 px, complete pay and QR flows without hidden disclosures or horizontal page scroll. Verify all defined state variants, long addresses/names, zero and maximum supported amounts, status unavailable, pending settlement, returned payment, held funds, unavailable risk service, no camera, clipboard failure, expired login and a wrong-domain recipient. BPI Pay remains usable when the FINCOIN API is unavailable.
