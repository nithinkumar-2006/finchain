# API reference

These contracts are exported from the implemented FastAPI routes. Internal signer, gateway and identity introspection endpoints are intentionally excluded.

## Browser authentication

Use same-origin HTTPS cookies. Bootstrap `GET /v1/identity/csrf`, then send the returned token in `X-CSRF-Token` together with the CSRF cookie and exact Origin on mutations. The session cookie is HttpOnly. Never store JWTs or refresh credentials in browser storage. Financial writes require an `Idempotency-Key` UUID; reuse the same key and unchanged body when retrying an uncertain response. A new key is a new instruction.

Amounts/quantities are integer decimal strings, INR/SIM_INR minor units and FNC atoms. Most responses carry sandbox/domain labels. 201 creates a reviewable object; 202 means queued, never final settlement. 401 indicates identity failure, 403 scope/CSRF/MFA denial, 404 scoped not-found, 409 state or idempotency conflict, 422 invalid input, 429 throttling, and 503 unavailable dependency. Read existing receipts after a lost response.

Merchant API routes require a scoped Bearer API key and do not accept cookie authentication as a substitute. They cannot spend money. Their CSRF exemption is limited to those Bearer-only routes.

## Request example

```json
{"sender_wallet_id":"<owned UUID>","receiver_address":"<BPI sandbox address>","amount_minor":"50000"}
```

POST this to `/v1/bpi/payment-drafts`, review the response, then POST its exact `payload_digest` to `/v1/bpi/payment-drafts/{payment_id}/authorizations`. Poll the payment receipt until its independent chain and settlement states reach the expected terminal state.

## Implemented endpoints

| Method | Path |
|---|---|
| GET | `/v1/identity/audit-logs` |
| GET | `/v1/identity/csrf` |
| POST | `/v1/identity/email-verification/confirm` |
| POST | `/v1/identity/email-verification/requests` |
| POST | `/v1/identity/forgot-password` |
| POST | `/v1/identity/logout` |
| GET | `/v1/identity/me` |
| POST | `/v1/identity/mfa/enrollments` |
| POST | `/v1/identity/mfa/verifications` |
| POST | `/v1/identity/recovery` |
| POST | `/v1/identity/registrations` |
| POST | `/v1/identity/reset-password` |
| GET | `/v1/identity/sessions` |
| POST | `/v1/identity/sessions` |
| POST | `/v1/identity/sessions/refresh` |
| DELETE | `/v1/identity/sessions/{session_id}` |
| GET | `/v1/explorer/{domain}/blocks` |
| GET | `/v1/explorer/{domain}/blocks/{reference}` |
| GET | `/v1/explorer/{domain}/network` |
| GET | `/v1/explorer/{domain}/transactions` |
| GET | `/v1/explorer/{domain}/transactions/{transaction_hash}` |
| POST | `/v1/bpi/admin/actions` |
| GET | `/v1/bpi/admin/overview` |
| GET | `/v1/bpi/admin/risk-reviews` |
| GET | `/v1/bpi/commerce/orders` |
| POST | `/v1/bpi/commerce/orders` |
| GET | `/v1/bpi/commerce/products` |
| GET | `/v1/bpi/dashboard` |
| POST | `/v1/bpi/merchant-api/payment-requests` |
| GET | `/v1/bpi/merchant-api/payments` |
| GET | `/v1/bpi/merchants` |
| POST | `/v1/bpi/merchants` |
| POST | `/v1/bpi/merchants/{merchant_id}/api-keys` |
| DELETE | `/v1/bpi/merchants/{merchant_id}/api-keys/{key_id}` |
| GET | `/v1/bpi/merchants/{merchant_id}/integrations` |
| POST | `/v1/bpi/merchants/{merchant_id}/invoices` |
| POST | `/v1/bpi/merchants/{merchant_id}/memberships` |
| POST | `/v1/bpi/merchants/{merchant_id}/products` |
| GET | `/v1/bpi/merchants/{merchant_id}/report` |
| POST | `/v1/bpi/merchants/{merchant_id}/webhooks` |
| GET | `/v1/bpi/notifications` |
| POST | `/v1/bpi/notifications/{notification_id}/read` |
| GET | `/v1/bpi/operations/{operation_id}` |
| POST | `/v1/bpi/payment-drafts` |
| POST | `/v1/bpi/payment-drafts/{payment_id}/authorizations` |
| POST | `/v1/bpi/payment-requests` |
| GET | `/v1/bpi/payment-requests/{token}` |
| GET | `/v1/bpi/payments` |
| GET | `/v1/bpi/payments/{payment_id}` |
| POST | `/v1/bpi/payouts/{payment_id}/approvals` |
| POST | `/v1/bpi/redemption-drafts` |
| POST | `/v1/bpi/sandbox/funding` |
| GET | `/v1/bpi/settlements` |
| GET | `/v1/bpi/wallets` |
| POST | `/v1/bpi/wallets` |
| POST | `/v1/fincoin/admin/actions` |
| GET | `/v1/fincoin/admin/overview` |
| GET | `/v1/fincoin/market` |
| GET | `/v1/fincoin/operations/{operation_id}` |
| GET | `/v1/fincoin/orders` |
| GET | `/v1/fincoin/portfolio` |
| POST | `/v1/fincoin/quotes` |
| POST | `/v1/fincoin/quotes/{quote_id}/authorizations` |
| POST | `/v1/fincoin/sandbox/grants` |
| POST | `/v1/fincoin/transfer-drafts` |
| POST | `/v1/fincoin/transfer-drafts/{transfer_id}/authorizations` |
| GET | `/v1/fincoin/transfers` |
| GET | `/v1/fincoin/wallets` |
| POST | `/v1/fincoin/wallets` |

## Machine-readable contracts

- [Identity](docs/openapi/identity.json)
- [BPI](docs/openapi/bpi.json)
- [FINCOIN](docs/openapi/fincoin.json)
- [Public explorer](docs/openapi/explorer.json)

Scope enforcement is implemented in service code; OpenAPI alone is not an authorization policy. Consult AUTH_SPEC, MERCHANT_SPEC and ADMIN_SPEC.
