# Local development

Install packages in a virtual environment:

```text
python -m pip install -r services/platform/requirements.lock
python -m pip install --no-deps -e services/identity -e services/platform
python -m pytest services/identity/tests services/platform/tests -q
```

Without explicit disposable PostgreSQL URLs, the 20 PostgreSQL tests skip; that is not a full database verification. Set `IDENTITY_TEST_DATABASE_URL`, `BPI_TEST_DATABASE_URL` and `FINCOIN_TEST_DATABASE_URL` to separately migrated databases whose names end in `_test`. Never point test jobs at operational data. Apply identity Alembic and platform SQL migrations before testing.

For the web client, enter `apps/web`, run `pnpm install --frozen-lockfile`, `pnpm build`, and `pnpm dev`. A frontend-only preview deliberately returns a 503 for `/v1/*`. It does not supply fake financial values. Use the HTTPS Compose reverse proxy for integrated account/payment workflows.

Browser checks: `pnpm exec playwright install chromium`, then `pnpm test`. The test server uses loopback port 3101. For an already-running test server, set `PLAYWRIGHT_EXTERNAL_SERVER=1`. The browser suite checks real public-page rendering and outage behavior; it is not a complete browser-to-PostgreSQL payment certification.

The workspace-specific `scripts/check_local_postgres.py`, `check_platform_postgres.py` and `run_regression.py` expect an optional local test cluster on port 55432 with a password file under `.tooling`. Neither that cluster nor its credentials is included in the release.

Service modules are run with `uvicorn <module>:create_app --factory`; financial workers use `python -m finchain_platform.worker`. Supply only the environment/credentials assigned to that service by the generated configuration. Do not run a bootstrap writer alongside an operational writer. Seed provisioning queues commands and does not post financial journals directly.

