"""Run identity PostgreSQL checks against the workspace's disposable local cluster."""
import os
import subprocess
import sys
from pathlib import Path
import psycopg
from psycopg import sql

ROOT = Path(__file__).resolve().parents[1]
password = (ROOT / ".tooling/pg-password.txt").read_text().strip()
connection = dict(host="127.0.0.1", port=55432, user="finchain_local", password=password)
with psycopg.connect(**connection, dbname="postgres", autocommit=True) as db:
    for name in ("identity_test", "bpi_test", "fincoin_test", "gateway_test", "signer_test", "public_bpi_test", "public_fincoin_test"):
        if not db.execute("SELECT 1 FROM pg_database WHERE datname=%s", (name,)).fetchone():
            db.execute(sql.SQL("CREATE DATABASE {}").format(sql.Identifier(name)))
url = f"postgresql+psycopg://finchain_local:{password}@127.0.0.1:55432/identity_test"
env = {**os.environ, "IDENTITY_DATABASE_URL": url, "IDENTITY_TEST_DATABASE_URL": url}
subprocess.run([sys.executable, "-m", "alembic", "upgrade", "head"], cwd=ROOT / "services/identity", env=env, check=True)
with psycopg.connect(**connection, dbname="identity_test") as db:
    db.execute((ROOT / "services/identity/deploy/roles.sql").read_text())
subprocess.run([sys.executable, "-m", "pytest", "services/identity/tests/test_postgres.py", "-q"], cwd=ROOT, env=env, check=True)
