"""Final local regression against the disposable workspace PostgreSQL cluster."""
import os
import subprocess
import sys
from pathlib import Path

root=Path(__file__).resolve().parents[1]
password=(root/'.tooling/pg-password.txt').read_text().strip()
base=f'postgresql+psycopg://finchain_local:{password}@127.0.0.1:55432/'
env={**os.environ,'IDENTITY_TEST_DATABASE_URL':base+'identity_test','BPI_TEST_DATABASE_URL':base+'bpi_test','FINCOIN_TEST_DATABASE_URL':base+'fincoin_test'}
result=subprocess.run([sys.executable,'-m','pytest','services/identity/tests','services/platform/tests','-q','--junitxml=.tooling/regression.xml'],cwd=root,env=env)
raise SystemExit(result.returncode)
