"""Build and verify the distributable without credentials, caches or synced sources."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / 'FINCHAIN_FINAL_RELEASE.zip'
EXCLUDED = {'.git', '.secrets', '.tooling', '.venv', 'node_modules', '.next', '__pycache__', '.pytest_cache', 'test-results', 'playwright-report'}

def allowed(path):
    rel = path.relative_to(ROOT)
    return not any(p in EXCLUDED or p.endswith('.egg-info') for p in rel.parts) and path.suffix not in {'.pyc', '.pyo', '.tsbuildinfo', '.zip', '.db', '.sqlite', '.pem', '.key'} and path.name not in {'write_release_docs.py', '.env', '.env.local'}

files = [p for p in ROOT.glob('*.md') if p.name != 'AGENTS.md']
files += [ROOT / p for p in ('.gitignore', '.dockerignore', 'compose.json')]
for folder in ('apps', 'services', 'deploy', 'scripts', 'docs', '.github'):
    for base, dirs, names in __import__('os').walk(ROOT / folder):
        dirs[:] = [d for d in dirs if d not in EXCLUDED and not d.endswith('.egg-info')]
        files.extend(Path(base) / n for n in names if allowed(Path(base) / n))
files = sorted(set(files))
entries = {p.relative_to(ROOT).as_posix(): p.read_bytes() for p in files}
assert all(not n.startswith(('sources/', '.secrets/', '.tooling/')) for n in entries)
assert all(b'-----BEGIN PRIVATE KEY-----\nM' not in data for data in entries.values())
manifest = {'release': 'FINCHAIN sandbox 2026-09-18', 'files': [{'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in entries.items()]}
with zipfile.ZipFile(DEST, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in entries.items():
        archive.writestr('FINCHAIN/' + name, data)
    archive.writestr('FINCHAIN/MANIFEST.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(DEST) as archive:
    assert archive.testzip() is None
    for item in manifest['files']:
        assert hashlib.sha256(archive.read('FINCHAIN/' + item['path'])).hexdigest() == item['sha256']
checksum = hashlib.sha256(DEST.read_bytes()).hexdigest()
DEST.with_suffix('.zip.sha256').write_text(checksum + '  ' + DEST.name + '\n', encoding='ascii')
print(json.dumps({'archive': str(DEST), 'files': len(entries) + 1, 'bytes': DEST.stat().st_size, 'sha256': checksum, 'verified': True}))
