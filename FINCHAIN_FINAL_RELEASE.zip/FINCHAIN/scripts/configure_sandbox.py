"""Generate local-only credentials and a Docker Compose stack. Never overwrites secrets."""
import base64
import ipaddress
import json
import secrets
from datetime import datetime, timedelta, timezone
from pathlib import Path
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID

ROOT = Path(__file__).resolve().parents[1]
PRIVATE = ROOT / ".secrets"
if PRIVATE.exists():
    raise SystemExit(".secrets already exists; preserve it. Use the existing configuration or a new workspace.")
PRIVATE.mkdir(mode=0o700)
files = {}


def secret(name, data):
    path = PRIVATE / name
    path.write_bytes(data if isinstance(data, bytes) else data.encode())
    # The enclosing directory is owner-only; bind-mounted secret files must be readable
    # by each container's non-root UID. Each service receives only its listed files.
    path.chmod(0o444)
    files[name] = {"file": "./.secrets/" + name}
    return "/run/secrets/" + name


def random_key(name, raw=False):
    return secret(name, secrets.token_bytes(32) if raw else base64.b64encode(secrets.token_bytes(32)))


def env_file(name, values):
    (PRIVATE / (name + ".env")).write_text("".join(f"{k}={v}\n" for k,v in values.items()), encoding="utf-8")
    (PRIVATE / (name + ".env")).chmod(0o600)
    return "./.secrets/" + name + ".env"


admin_password = secrets.token_urlsafe(32)
secret("postgres-password", admin_password)
key = rsa.generate_private_key(public_exponent=65537, key_size=3072)
secret("identity-signing.pem", key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
for name in ("identity-encryption", "identity-lookup", "bpi-encryption", "fincoin-encryption", "bpi-service", "fincoin-service", "bpi-signer-service", "fincoin-signer-service", "gateway-service"):
    random_key(name)
for name in ("bpi-signer-master", "fincoin-signer-master", "gateway-signing"):
    random_key(name, raw=True)
tls = rsa.generate_private_key(public_exponent=65537, key_size=3072)
subject = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "localhost")])
cert = x509.CertificateBuilder().subject_name(subject).issuer_name(subject).public_key(tls.public_key()).serial_number(x509.random_serial_number()).not_valid_before(datetime.now(timezone.utc)-timedelta(minutes=1)).not_valid_after(datetime.now(timezone.utc)+timedelta(days=30)).add_extension(x509.SubjectAlternativeName([x509.DNSName("localhost"),x509.IPAddress(ipaddress.ip_address("127.0.0.1"))]),critical=False).sign(tls, hashes.SHA256())
secret("tls.key", tls.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
secret("tls.crt", cert.public_bytes(serialization.Encoding.PEM))

database_users = {
    "identity": {"identity_api":"finchain_identity_runtime", "identity_mail":"finchain_identity_runtime"},
    "bpi": {"bpi_api":"finchain_bpi_api", "bpi_writer":"finchain_bpi_writer", "bpi_projection":"finchain_bpi_projection"},
    "fincoin": {"fincoin_api":"finchain_fincoin_api", "fincoin_writer":"finchain_fincoin_writer", "fincoin_projection":"finchain_fincoin_projection"},
    "signer_bpi": {"signer_bpi":"owner"}, "signer_fincoin": {"signer_fincoin":"owner"}, "gateway": {"gateway":"owner"},
    "public_bpi": {"public_bpi_projector":"owner", "public_bpi_reader":"reader"},
    "public_fincoin": {"public_fincoin_projector":"owner", "public_fincoin_reader":"reader"},
}
urls, owners, migrations, sql = {}, {}, [], []
for name, users in database_users.items():
    database = "finchain_"+name
    owners[name] = f"postgresql+psycopg://postgres:{admin_password}@postgres:5432/{database}"
    sql += [f"CREATE DATABASE {database};", f"REVOKE ALL ON DATABASE {database} FROM PUBLIC;"]
    for user in users:
        password = secrets.token_urlsafe(32)
        sql += [f"CREATE ROLE {user} LOGIN PASSWORD '{password}';", f"GRANT CONNECT ON DATABASE {database} TO {user};"]
        urls[user] = f"postgresql+psycopg://{user}:{password}@postgres:5432/{database}"
    kind = "public" if name.startswith("public_") else "signer" if name.startswith("signer_") else name
    migrations.append({"url": owners[name], "kind": kind, "users": users})
secret("init.sql", "\n".join(sql))
secret("migrations.json", json.dumps(migrations))

services = {}
healthy = {"postgres":{"condition":"service_healthy"}}
migrated = {"migrate":{"condition":"service_completed_successfully"}}
build = {"context":".","dockerfile":"services/platform/Dockerfile"}


def app(name, env, command=None, mounted=(), networks=("identity",), dependencies=None):
    service = {"build":build, "env_file":[env_file(name,env)], "networks":list(networks),
               "secrets":list(mounted), "depends_on":dependencies or migrated, "restart":"unless-stopped",
               "read_only":True, "tmpfs":["/tmp"], "security_opt":["no-new-privileges:true"], "cap_drop":["ALL"]}
    if command:
        service["command"] = command
    services[name] = service
    return service


def api(module):
    return ["uvicorn",module+":create_app","--factory","--host","0.0.0.0","--port","8000","--no-access-log","--no-proxy-headers"]


services["postgres"] = {"image":"postgres:17", "environment":{"POSTGRES_PASSWORD_FILE":"/run/secrets/postgres-password"},"secrets":["postgres-password"], "volumes":["postgres_data:/var/lib/postgresql/data","./.secrets/init.sql:/docker-entrypoint-initdb.d/001-init.sql:ro"],"networks":["identity","bpi","fincoin","public","migration"],"healthcheck":{"test":["CMD-SHELL","pg_isready -U postgres"],"interval":"3s","timeout":"3s","retries":30},"restart":"unless-stopped"}
services["migrate"] = {"build":build,"command":["python","/srv/deploy/migrate_all.py"],"secrets":["migrations.json"],"depends_on":healthy,"networks":["migration"],"restart":"no"}
identity_env = {"FINCHAIN_MODE":"sandbox","IDENTITY_DATABASE_URL":urls["identity_api"],"IDENTITY_ORIGIN":"https://localhost:8443","IDENTITY_ISSUER":"https://localhost:8443/v1/identity","IDENTITY_SIGNING_KEY_FILE":"/run/secrets/identity-signing.pem","IDENTITY_ENCRYPTION_KEY_FILE":"/run/secrets/identity-encryption","IDENTITY_LOOKUP_KEY_FILE":"/run/secrets/identity-lookup","IDENTITY_BPI_SERVICE_KEY_FILE":"/run/secrets/bpi-service","IDENTITY_FINCOIN_SERVICE_KEY_FILE":"/run/secrets/fincoin-service"}
identity_secrets = ["identity-signing.pem","identity-encryption","identity-lookup","bpi-service","fincoin-service"]
app("identity",identity_env,api("finchain_identity.app"),identity_secrets)
app("email-worker",{**identity_env,"IDENTITY_DATABASE_URL":urls["identity_mail"]},["python","-m","finchain_identity.email_worker"],identity_secrets)
services["mailpit"] = {"image":"axllent/mailpit:latest","networks":["identity"],"ports":["127.0.0.1:8025:8025"],"restart":"unless-stopped"}
for domain in ("bpi","fincoin"):
    network = "finchain-"+domain+"-sandbox-1"
    signer_name = domain+"-signer"
    signer_env = {"FINCHAIN_MODE":"sandbox","NETWORK_ID":network,"SIGNER_DATABASE_URL":urls["signer_"+domain],"SIGNER_MASTER_KEY_FILE":"/run/secrets/"+domain+"-signer-master","SIGNER_SERVICE_KEY_FILE":"/run/secrets/"+domain+"-signer-service"}
    app(signer_name,signer_env,api("finchain_platform.signer_api"),[domain+"-signer-master",domain+"-signer-service"],networks=[domain])
    services[domain+"-redis"] = {"image":"redis:7-alpine","command":["redis-server","--save","","--appendonly","no"],"networks":[domain],"restart":"unless-stopped"}
    common = {"FINCHAIN_MODE":"sandbox","FINCHAIN_DOMAIN":domain.upper(),"NETWORK_ID":network,"FINCHAIN_ORIGIN":"https://localhost:8443","DOMAIN_ENCRYPTION_KEY_FILE":"/run/secrets/"+domain+"-encryption","IDENTITY_INTERNAL_URL":"http://identity:8000","SERVICE_SECRET_FILE":"/run/secrets/"+domain+"-service"}
    signing = {"SIGNER_URL":"http://"+signer_name+":8000","SIGNER_SERVICE_KEY_FILE":"/run/secrets/"+domain+"-signer-service"}
    private = [domain+"-encryption",domain+"-service"]
    init = app(domain+"-bootstrap",{**common,**signing,"DOMAIN_DATABASE_URL":owners[domain],"SERVICE_ROLE":"bootstrap"},["python","/srv/deploy/bootstrap.py"],private+[domain+"-signer-service"],networks=[domain],dependencies={**migrated,signer_name:{"condition":"service_started"}})
    init["restart"]="on-failure"
    deps={domain+"-bootstrap":{"condition":"service_completed_successfully"},"identity":{"condition":"service_started"}}
    app(domain+"-api",{**common,"DOMAIN_DATABASE_URL":urls[domain+"_api"],"SERVICE_ROLE":"api","REDIS_URL":"redis://"+domain+"-redis:6379/0"},None,private,networks=[domain,"identity","edge"],dependencies={**deps,domain+"-redis":{"condition":"service_started"}})
    worker_env = {**common,**signing,"DOMAIN_DATABASE_URL":urls[domain+"_writer"],"SERVICE_ROLE":"ledger"}
    worker_keys=private+[domain+"-signer-service"]
    if domain=="bpi":
        worker_env.update({"GATEWAY_URL":"http://gateway:8000","GATEWAY_SERVICE_KEY_FILE":"/run/secrets/gateway-service","GATEWAY_SIGNING_KEY_FILE":"/run/secrets/gateway-signing"})
        worker_keys += ["gateway-service","gateway-signing"]
    app(domain+"-worker",worker_env,["python","-m","finchain_platform.worker"],worker_keys,networks=[domain,"identity"],dependencies=deps)
    app(domain+"-projector",{"PROJECTION_SOURCE_DATABASE_URL":urls[domain+"_projection"],"PROJECTION_DATABASE_URL":urls["public_"+domain+"_projector"]},["python","-m","finchain_platform.explorer"],networks=[domain,"public"],dependencies=deps)
app("gateway",{"GATEWAY_MODE":"simulated","NETWORK_ID":"finchain-bpi-sandbox-1","GATEWAY_DATABASE_URL":urls["gateway"],"GATEWAY_SERVICE_KEY_FILE":"/run/secrets/gateway-service","GATEWAY_SIGNING_KEY_FILE":"/run/secrets/gateway-signing"},api("finchain_platform.gateway"),["gateway-service","gateway-signing"],networks=["bpi"])
app("explorer",{"EXPLORER_BPI_DATABASE_URL":urls["public_bpi_reader"],"EXPLORER_FINCOIN_DATABASE_URL":urls["public_fincoin_reader"]},api("finchain_platform.explorer"),networks=["public","edge"])
services["web"] = {"build":{"context":"./apps/web"},"networks":["edge"],"restart":"unless-stopped","read_only":True,"tmpfs":["/tmp","/app/.next/cache"],"security_opt":["no-new-privileges:true"]}
services["nginx"] = {"image":"nginx:stable-alpine","ports":["127.0.0.1:8443:8443"],"volumes":["./deploy/nginx.conf:/etc/nginx/nginx.conf:ro"],"secrets":["tls.key","tls.crt"],"networks":["edge","identity"],"depends_on":["web","identity","bpi-api","fincoin-api","explorer"],"restart":"unless-stopped"}
(PRIVATE / "demo").mkdir(mode=0o700)
services["seed-demo"] = {"build":build,"user":"0:0","profiles":["demo"],"command":["python","/srv/deploy/seed_demo.py"],"secrets":list(files),"volumes":["./.secrets:/run/config:ro","./.secrets/demo:/demo"],"networks":["identity","bpi","fincoin","migration"],"depends_on":["bpi-worker","fincoin-worker","identity"],"restart":"no"}
compose={"name":"finchain-sandbox","services":services,"secrets":files,"volumes":{"postgres_data":{}},"networks":{name:{"internal":name!="edge"} for name in ("identity","bpi","fincoin","public","migration","edge")}}
(ROOT / "compose.json").write_text(json.dumps(compose,indent=2)+"\n",encoding="utf-8")
print("Created local secrets and compose.json. Start with: docker compose -f compose.json up --build -d")
print("App: https://localhost:8443 | local test inbox: http://localhost:8025")
print("The generated certificate is self-signed and valid for 30 days. Never publish this local configuration.")
