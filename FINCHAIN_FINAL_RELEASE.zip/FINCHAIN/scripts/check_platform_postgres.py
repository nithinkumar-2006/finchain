import importlib.util
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
password = (ROOT / ".tooling/pg-password.txt").read_text().strip()
base = f"postgresql+psycopg://finchain_local:{password}@127.0.0.1:55432/"
env = dict(os.environ)
for name in ("bpi", "fincoin", "gateway", "signer", "public_bpi", "public_fincoin"):
    kind = "public" if name.startswith("public_") else name
    url = base + name + "_test"
    run_env = {**env, "MIGRATION_DATABASE_URL": url, "FINCHAIN_DOMAIN": kind.upper()}
    subprocess.run([sys.executable, "services/platform/migrate.py", kind], cwd=ROOT, env=run_env, check=True)
    if kind in {"bpi", "fincoin"}:
        subprocess.run([sys.executable, "services/platform/deploy_roles.py"], cwd=ROOT, env=run_env, check=True)
env["BPI_TEST_DATABASE_URL"] = base + "bpi_test"
env["FINCOIN_TEST_DATABASE_URL"] = base + "fincoin_test"
subprocess.run([sys.executable, "-m", "pytest", "services/platform/tests/test_postgres_ledger.py", "-q"], cwd=ROOT, env=env, check=True)
