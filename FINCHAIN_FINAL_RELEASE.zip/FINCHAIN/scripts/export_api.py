"""Export current public OpenAPI contracts without credentials or live data."""
import json
import secrets
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization
from finchain_identity.app import create_app as identity_app
from finchain_identity.config import Settings
from finchain_platform.api import create_app
from finchain_platform.config import DomainSettings
from finchain_platform.bpi import BPI
from finchain_platform.fincoin import FINCOIN
from finchain_platform.explorer import create_app as explorer_app

root=Path(__file__).resolve().parents[1]
directory=root/'docs/openapi';directory.mkdir(parents=True,exist_ok=True)
key=rsa.generate_private_key(public_exponent=65537,key_size=3072).private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption())
apps={'identity':identity_app(Settings('sqlite://',key,secrets.token_bytes(32),secrets.token_bytes(32),test_mode=True)), 'explorer':explorer_app({'bpi':'sqlite://','fincoin':'sqlite://'})}
for domain,cls in (('BPI',BPI),('FINCOIN',FINCOIN)):
    settings=DomainSettings(domain,'sqlite://',secrets.token_bytes(32),test_mode=True)
    apps[domain.lower()]=create_app(settings,cls(settings),identity=object())
lines=['# API reference','','These contracts are exported from the implemented FastAPI routes. Internal signer, gateway and identity introspection endpoints are intentionally excluded.','','## Browser authentication','','Use same-origin HTTPS cookies. Bootstrap `GET /v1/identity/csrf`, then send the returned token in `X-CSRF-Token` together with the CSRF cookie and exact Origin on mutations. The session cookie is HttpOnly. Never store JWTs or refresh credentials in browser storage. Financial writes require an `Idempotency-Key` UUID; reuse the same key and unchanged body when retrying an uncertain response. A new key is a new instruction.','','Amounts/quantities are integer decimal strings, INR/SIM_INR minor units and FNC atoms. Most responses carry sandbox/domain labels. 201 creates a reviewable object; 202 means queued, never final settlement. 401 indicates identity failure, 403 scope/CSRF/MFA denial, 404 scoped not-found, 409 state or idempotency conflict, 422 invalid input, 429 throttling, and 503 unavailable dependency. Read existing receipts after a lost response.','','Merchant API routes require a scoped Bearer API key and do not accept cookie authentication as a substitute. They cannot spend money. Their CSRF exemption is limited to those Bearer-only routes.','','## Request example','','```json','{"sender_wallet_id":"<owned UUID>","receiver_address":"<BPI sandbox address>","amount_minor":"50000"}','```','','POST this to `/v1/bpi/payment-drafts`, review the response, then POST its exact `payload_digest` to `/v1/bpi/payment-drafts/{payment_id}/authorizations`. Poll the payment receipt until its independent chain and settlement states reach the expected terminal state.','','## Implemented endpoints','','| Method | Path |','|---|---|']
for name,app in apps.items():
    schema=app.openapi()
    schema['paths']={path:methods for path,methods in schema['paths'].items() if path.startswith('/v1/')}
    schema['servers']=[{'url':'https://localhost:8443','description':'Local sandbox; generated certificate required'}]
    (directory/(name+'.json')).write_text(json.dumps(schema,indent=2)+'\n',encoding='utf-8')
    for path,methods in sorted(schema['paths'].items()):
        for method in methods:
            if method in {'get','post','delete','put','patch'}: lines.append(f'| {method.upper()} | `{path}` |')
lines+=['','## Machine-readable contracts','','- [Identity](docs/openapi/identity.json)','- [BPI](docs/openapi/bpi.json)','- [FINCOIN](docs/openapi/fincoin.json)','- [Public explorer](docs/openapi/explorer.json)','','Scope enforcement is implemented in service code; OpenAPI alone is not an authorization policy. Consult AUTH_SPEC, MERCHANT_SPEC and ADMIN_SPEC.']
(root/'API_REFERENCE.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print('Exported four public API contracts')
