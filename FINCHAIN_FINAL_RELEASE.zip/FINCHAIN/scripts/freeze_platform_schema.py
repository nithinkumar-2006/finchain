"""Development-only generator. Released migrations are frozen SQL, never live ORM metadata."""
from pathlib import Path
from sqlalchemy.schema import CreateTable, CreateIndex
from sqlalchemy.dialects.postgresql import dialect
from finchain_platform.storage import Base, COMMON_TABLES
from finchain_platform.bpi_models import BPI_TABLES
from finchain_platform.fincoin_models import FINCOIN_TABLES
from finchain_platform.gateway import GatewayBase
from finchain_platform.signer_api import SignerBase
from finchain_platform.explorer import PublicBase

root = Path(__file__).resolve().parents[1] / "services/platform/migrations"
root.mkdir(exist_ok=True)
if any(root.glob("*_0001.sql")):
    raise SystemExit("Initial snapshots already exist. Add a new forward migration; never rewrite an applied snapshot.")
for name, metadata, allowed in (
    ("bpi", Base.metadata, set(COMMON_TABLES) | {t.key for t in BPI_TABLES}),
    ("fincoin", Base.metadata, set(COMMON_TABLES) | {t.key for t in FINCOIN_TABLES}),
    ("gateway", GatewayBase.metadata, None), ("signer", SignerBase.metadata, None),
    ("public", PublicBase.metadata, None),
):
    tables = [t for t in metadata.sorted_tables if allowed is None or t.key in allowed]
    schemas = sorted({t.schema for t in tables if t.schema})
    statements = [f'CREATE SCHEMA IF NOT EXISTS "{s}";' for s in schemas]
    for table in tables:
        statements.append(str(CreateTable(table).compile(dialect=dialect())) + ";")
        statements.extend(str(CreateIndex(index).compile(dialect=dialect())) + ";" for index in sorted(table.indexes, key=lambda i: i.name))
    (root / f"{name}_0001.sql").write_text("-- Immutable initial schema snapshot; apply with migrate.py.\n" + "\n".join(statements), encoding="utf-8")
