# FINCHAIN — Page and Navigation Map

Role 2 · Version 1.0 · Parent: [UI_UX_SPEC.md](UI_UX_SPEC.md).

## 1. Route hierarchy

Paths are frontend routes, not a claim that matching backend endpoints already exist. Parameter IDs are scoped by the server. A route can be directly entered only after the same authorization as navigation entry. Preserve safe internal return paths through login; never allow external redirect destinations.

```text
Public
  /                                      Landing
  /about                                 About FINCHAIN
  /bpi-network                           BPI Network
  /fincoin                               FINCOIN public overview
  /security                              Public security explanation
  /merchants                             Merchant Solutions
  /developers                            Developer documentation
  /contact                               Contact
  /disclosures                           Sandbox / data-use information
  /login, /register, /recover             Identity entry
  /auth/mfa                              Authentication challenge
  /request/:token                        Resolve BPI payment request
  /explorer/:domain                      Public Explorer
    /blocks                              Block list
    /blocks/:height                      Block details
    /transactions                        Public commitment list
    /transactions/:hash                  Public transaction proof
    /network                             Network statistics
    /address-privacy                     Explanation, no address lookup
Consumer BPI
  /app/dashboard                         BPI overview
  /app/pay                               Entry
    /review/:draftId                     Review and authorize
    /status/:paymentId                   Progress and receipt
    /scan                                QR scan/manual fallback
  /app/receive                            Receive and request builder
    /requests/:requestId                 Request status/share
  /app/transactions                       History
    /:paymentId                          Private receipt
  /app/wallet                             Wallet
    /deposit                             Sandbox funding
    /withdraw                            Sandbox redemption
    /address                             Private address details
  /app/commerce                           Category/catalog
    /:category                           Category results
    /products/:productId                 Product details
    /cart                                Cart
    /checkout/:orderId                   Review/request/payment
    /orders/:orderId                     Order and receipt
  /app/security                           Account security
    /mfa, /sessions, /recovery-codes      Security subpages
  /app/settings                           Profile/preferences
FINCOIN (optional independent enrollment)
  /app/fincoin                            Overview / enrollment
    /trade                               Buy/sell
    /orders/:orderId                     Simulated order result
    /portfolio                           Holdings, P&L and lots
    /wallet                              FNC and SIM_INR wallet
    /transfer                            FNC test transfer
    /receive                             Test receive instructions
    /transactions/:transactionId         Private test-asset receipt
Merchant (organization scope required)
  /merchant/onboarding                    Sandbox organization setup
  /merchant/:orgId/overview                Overview
    /payments, /payments/:paymentId      Payment list / receipt
    /customers, /customers/:customerId   Scoped relationship summary
    /qr                                  Static/dynamic requests
    /invoices, /invoices/:invoiceId       Invoice list / create / details
    /settlement, /settlement/:operationId Settlement list / evidence
    /refunds, /refunds/:refundId          Refunds and creation/review
    /analytics                           Reports
    /api                                 Sandbox credentials
    /webhooks, /webhooks/:endpointId      Endpoint setup and delivery log
    /settings                            Organization/outlet/team
    /payouts, /payouts/:payoutId          Maker/checker and batch details
    /catalog                             Products/inventory/orders workspace
Admin (staff, MFA, selected domain)
  /admin/:domain/overview                  Domain overview
    /users, /users/:subjectId             Scoped users
    /merchants, /merchants/:orgId         BPI merchant oversight
    /payments, /payments/:paymentId      BPI payment investigation
    /fraud, /fraud/:caseId               Risk queues/cases
    /settlements, /settlements/:caseId   BPI reconciliation
    /blockchain, /blockchain/:height     Private operational chain view
    /validators                          Authorized producer/key governance
    /fincoin                             FINCOIN operations, only FINCOIN domain
    /audit-logs                          Audit search/details
    /system-health                       Health, pauses, incidents
    /corrections/:proposalId              Governed correction / approval detail
```

## 2. Screen index and access

| IDs | Pages | Access / source readiness | Specification |
|---|---|---|---|
| PUB-01–PUB-07 | Landing, About, BPI, FINCOIN, Security, Merchants, Developers | Public static; dynamic excerpts A/E | UI_UX_SPEC |
| PUB-08 | Explorer entry | Public; A/E | EXPLORER_UI_SPEC |
| PUB-09 | Contact | Public; E03 | UI_UX_SPEC |
| PUB-10–PUB-13 | Login, Register, Disclosures, Recovery | Public identity A; published policies E03 | UI_UX_SPEC / USER_FLOWS |
| AUTH-01 | MFA challenge | Bound identity challenge; A | USER_FLOWS |
| REQ-01 | Public request resolver | Opaque token, limited safe information; A | DASHBOARD_SPEC |
| C-01 | Dashboard | Consumer wallet scope; A/E06 | DASHBOARD_SPEC |
| C-02–C-05 | Pay entry, review, result, QR scan | Sender ownership; A, optional E01/E02/E08 | DASHBOARD_SPEC / USER_FLOWS |
| C-06–C-07 | Receive, request details | Self/payee scope; A | DASHBOARD_SPEC |
| C-08–C-09 | History, private receipt | Participant scope; A | DASHBOARD_SPEC |
| C-10–C-13 | Wallet, deposit, withdrawal, private address | Owner; A/E07 | DASHBOARD_SPEC / EXPLORER_UI_SPEC |
| C-14–C-19 | Catalog, category, product, cart, checkout, order | Public sample catalog or signed-in buyer; A/E07 | DASHBOARD_SPEC |
| C-20–C-23 | Account security, MFA, sessions, recovery codes | Self with fresh auth for mutations; A | DASHBOARD_SPEC |
| C-24 | Settings | Self; E07 | DASHBOARD_SPEC |
| F-01–F-08 | Overview, trade, order, portfolio, wallet, transfer, receive, receipt | Optional FINCOIN enrollment; A/E04 | FINCOIN_UI_SPEC |
| M-00 | Merchant onboarding | Authenticated applicant; A/E07 | MERCHANT_UI_SPEC |
| M-01–M-07 | Overview, payments, customers, QR, invoices, settlement, refunds | Scoped merchant roles; A/E06/E07 | MERCHANT_UI_SPEC |
| M-08–M-11 | Analytics, API, Webhooks, Settings | Role-specific; A/E05/E06/E07 | MERCHANT_UI_SPEC |
| M-12–M-13 | Payouts, Catalog | Maker/checker/catalog scopes; A/E07 | MERCHANT_UI_SPEC |
| X-01–X-07 | Explorer home, blocks, transactions, transaction details, block details, address privacy, network | Public redacted data; A/E06 | EXPLORER_UI_SPEC |
| A-01–A-11 | Admin pages in sidebar order below | Explicit domain staff scope + MFA; A/E09 | ADMIN_UI_SPEC |
| A-12 | Governed correction / approval detail | Scoped proposer/checker/auditor; A/E09 | ADMIN_UI_SPEC |
| SYS-01–SYS-04 | Not found, access denied, service unavailable, session expired | Sanitized global states | USER_FLOWS / COMPONENT_LIBRARY |

Create/list/detail modes inside merchant and admin page families are subviews with deep links, not separate information hierarchies. Examples: creating an invoice uses `/merchant/:orgId/invoices?mode=create`; detail uses the ID route. Do not nest `/commerce/:category` so broadly that it captures reserved `cart`, `products`, `checkout` or `orders` routes.

## 3. Navigation hierarchy

**Consumer sidebar, in order:** Dashboard · Pay · Receive · Transactions · Wallet · Commerce · separator · FINCOIN · separator · Security · Settings. FINCOIN is explicitly labeled “Simulator” in its destination header. Pay is a route, not an always-submitting floating control. Wallet → Deposit/Withdraw/Address; Transactions → receipt; Commerce → category/product/cart/checkout/order.

**FINCOIN sidebar:** Overview · Buy / Sell · Portfolio · Wallet · Transfer · Receive · Back to BPI. Shared account Security/Settings live in the profile menu. The mint BPI balance card never appears in this shell. A context label says “FINCOIN Simulator · Test network”.

**Merchant sidebar, in order:** Overview · Payments · Customers · QR · Invoices · Settlement · Refunds · Analytics · API · Webhooks · Settings. Payouts is a Settlement subitem and contextual action; Catalog is a Settings/commerce-management subitem with Overview shortcut. Role restrictions hide unauthorized navigation and provide safe access-denied states for direct URLs.

**Admin sidebar:** Overview · Users · Merchants · Payments · Fraud · Settlements · Blockchain · Validators · FINCOIN · Audit Logs · System Health. Selected domain controls visibility. In FINCOIN scope, BPI-only Merchants/Payments/Settlements are replaced by an explanation on direct entry, not a query of BPI data. The FINCOIN item is a domain-switch entry for staff with FINCOIN scope; otherwise absent. A-01 through A-11 follow this list order; A-12 is a shared correction/approval detail reached from relevant case pages.

**Consumer mobile bottom bar:** Home · Pay · Receive · Activity · More. More opens a labeled menu containing Wallet, Commerce, FINCOIN, Security and Settings. FINCOIN mobile replaces these with Overview · Trade · Portfolio · Wallet · More; More contains Transfer, Receive, Security and Back to BPI. Merchant mobile: Overview · Payments · QR · Settlement · More. Admin uses a compact header and drawer, never a consumer Pay button.

## 4. Navigation behavior

An organization/domain switch clears previous scoped data before fetching the new scope, closes detail overlays, and warns before discarding unsubmitted form changes. It never silently changes the source of an in-progress payment. Switching does not send money or enroll in FINCOIN. Reset query caches and SSE subscriptions on scope change and logout.

Breadcrumbs show shell → section → short reference. Receipt URLs from payment progress and history resolve the same resource. Browser Back preserves entered draft fields where safe; it cannot return a submitted payment to editable draft state. Success screens offer View transaction, Back to dashboard and an explicit new action; no automatic second payment or timed redirect.

Filters/time range may appear in URL state, but never notes, addresses, email, secrets or full financial payloads. Use session-safe state for nonsensitive drafts; clear after sign-out/expiry. Copy/share controls name whether the target is a public request link, public proof, or private receipt. A private receipt link requires participant access; copying it never grants that access.
