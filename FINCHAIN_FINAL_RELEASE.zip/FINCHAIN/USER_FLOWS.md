# FINCHAIN — User Flows and Journey Maps

Role 2 · Version 1.0 · State authority: [BPI architecture](BPI_ARCHITECTURE.md); screen details: [DASHBOARD_SPEC.md](DASHBOARD_SPEC.md).

## 1. Journey map

| Journey / person | Discover | Prepare | Commit | Understand outcome | Recover / return |
|---|---|---|---|---|---|
| New consumer | Landing → Register; learns value is simulated | Create BPI wallet, add capped test funds | Authorize first payment | Distinguish recorded from settled | View same payment after timeout; never pay twice to check |
| Returning payer | Dashboard → Pay/scan | Confirm recipient, amount and available balance | Confirm exact payment, complete step-up if required | Progress with chain and settlement separately | Continue tracking unknown result or create fresh draft after terminal rejection |
| Recipient | Receive → request | Set amount and expiry, share link | Payer authorizes; recipient does not sign incoming payment | Pending amount first, available only after settlement | Expired request regeneration; claimed request never accepts a second payer |
| Merchant cashier | Organization/outlet context → QR | Create invoice/request | Customer pays | Wait for authoritative paid receipt before fulfilling | View pending status or hand off to finance |
| Merchant finance | Settlement → payout/refund | Check available funds, remaining refundable amount, approval policy | Independent checker approves exact details | Child-level payout status and settlement evidence | Resolve returned or unknown operations without creating duplicates |
| FINCOIN learner | FINCOIN overview → optional enrollment | Read separate SIM_INR wallet and synthetic price | Confirm time-limited simulated quote | Filled order and updated holding; P&L freshness | Refresh expired quote, track same queued order, inspect simulated losses |
| Risk reviewer | Domain Fraud queue | Read evidence and safe/private reason scopes | Record review decision, never spend as user | User may need fresh authorization | Escalate or reject; no risk override by consumer |
| Auditor/developer | Explorer/Developers | Choose network and hash/height | Verify/read evidence | Understand proof scope and privacy | Correct wrong network or inspect signed evidence error |

Design intent: reduce uncertainty at Prepare and Understand outcome. Do not reduce deliberate confirmation effort by hiding amount, fee or recipient; reduce effort by retaining valid entries and explaining the next safe action.

## 2. Registration, login and optional enrollment

Public page → Register → minimal profile and credentials → read sandbox context/published policies → create identity → create BPI wallet → Dashboard. If a verification step is configured, show an actual pending challenge rather than a fake inbox confirmation. The absence of a message provider makes that method unavailable and must have a configured alternative before launch.

Login → generic credential verification → MFA challenge if required → validated return route. A deep-linked payment request resolves again after login to confirm it is still open. FINCOIN enrollment is separate: disclose test assets, synthetic prices and independent credits → create FINCOIN wallet → optional test grant → simulator. Declining FINCOIN returns to BPI without impairing payment access.

Expired session before authorization: save only safe draft references, sign in, refetch exact draft and recipient, then review again. Expired session after submission: authenticate and open the existing operation; never auto-submit the last form. Staff/merchant approvers without MFA enter enrollment before sensitive permissions become usable.

## 3. BPI entry-to-settlement flow

```mermaid
flowchart TD
    E[Enter recipient and amount] --> V[Resolve recipient and validate fields]
    V --> R[Review source, recipient, amount, fee and sandbox context]
    R --> P[Safe preliminary context if available]
    P --> C[Confirm exact payment and step-up if required]
    C --> S[Server signs authorized intent]
    S --> K[Authoritative risk checks]
    K -->|Allow| Q[Reserve and submit to BPI]
    K -->|Review| W[Verification or review required]
    K -->|Deny| D[Payment not submitted]
    W -->|Approved with fresh authorization| S
    Q --> B[Recorded on BPI]
    B --> T[Simulated settlement pending]
    T -->|Verified success| OK[Transaction successful]
    T -->|Uncertain| U[Settlement being checked]
    T -->|Definitive failure plus return applied| F[Payment returned]
    U -->|Verified success| OK
    U -->|Verified failure plus return applied| F
```

The brief's Review → Risk → Confirm ordering is represented by safe preliminary context before confirmation, if implemented. The authoritative risk decision is after signing. UI progress must not claim that risk passed before it did. Do not expose service names, nonce handling or signing payload internals during the normal user flow.

Entry: choose permitted source context, paste/scan BPI recipient or exact supported alias, type amount, INR fixed, optional supported private note. Review: resolved recipient name/type/address, source wallet, amount, network fee ₹0.00, total, type and sandbox label. Confirm button: “Confirm simulated ₹500.00 payment”. Confirmation creates/uses a one-time authorization; changes to amount/payee/source invalidate review and approvals.

During submission, show an indeterminate progress indicator with the current actual milestone. Preserve the payment ID and status route before navigating. At chain confirmation, step label reads “Recorded on BPI” and the overall title remains “Settlement pending”. Only settlement completion produces the successful receipt.

## 4. Canonical payment status presentation

| Backend business state | Main label / tone | Explanation | Allowed next action |
|---|---|---|---|
| `DRAFT` | Review payment / neutral | No payment has been submitted | Edit, authorize, leave draft |
| `AUTHORIZED` | Checking payment / info | Your authorization was received; checks are in progress | View status; no repeat Confirm |
| `RISK_REVIEW` | Verification or review required / warning | Describe server-provided safe reason and required path | Continue verification only if allowed; view case/cancel if permitted |
| `RESERVED` | Submitting to BPI / info | Amount is reserved and not available for another payment | View status; request cancellation only when capability says eligible |
| `SETTLEMENT_PENDING` | Settlement pending / info | Recorded on BPI. The recipient cannot use this amount yet | Track payment; no resend/refund CTA |
| `SETTLEMENT_UNKNOWN` | Settlement being checked / warning | We have not confirmed the settlement result. Keep this reference; no need to send again | Refresh same status, contact support with reference |
| `COMPLETED` | Transaction successful / success | Simulated settlement completed | View receipt, public proof, start a separate new payment |
| `RETURNED` | Payment returned / neutral with return icon | Settlement did not complete; the amount was returned to your BPI balance | View linked return; new payment only as a separate deliberate action |
| `REJECTED` | Payment not submitted / danger | Safe reason; no transfer was included | Correct issue/create fresh draft where permitted |
| `EXPIRED` | Payment authorization expired / neutral | No transfer was included; review a new draft | Create/review fresh draft |
| `CANCELED` | Payment canceled / neutral | No transfer was included | Return to dashboard |

If a pre-inclusion hold release is not yet confirmed, do not promise that funds are already available. Use “Checking reserved balance” and fetch authoritative wallet state. A transport error with no authoritative state is “Status unavailable”, never `REJECTED`. If APIs return an impossible state combination, show “Payment status is being checked”, preserve the reference and report telemetry; do not choose the most optimistic badge.

Chain panel independently shows Not submitted / Queued / Confirmed / Not included; settlement panel shows Not started / Pending / Being checked / Succeeded / Failed. Consumers see friendly labels, advanced details may include raw status codes for support. A returned payment still has a confirmed original chain entry.

## 5. Risk and security warning UX

Severity labels LOW, MEDIUM, HIGH and CRITICAL exist in the design. They are supplied as safe display classifications by the server; the frontend never derives thresholds from a numeric score. Internal `ALLOW/REVIEW/DENY`, severity and `allowed_actions` are separate. If classification is missing, show “Assessment unavailable”; do not assume LOW.

| Severity | Safe presentation | Action policy |
|---|---|---|
| LOW | “Routine checks completed” only after an actual decision | Continue normal lifecycle, no safety guarantee |
| MEDIUM | “Please verify this payment” with contextual explanation | Step-up only when server permits; otherwise review queue |
| HIGH | “Additional review required” or “High risk payment” in detail | Continue with verification only if allowed; no “Proceed anyway” |
| CRITICAL | “This payment is blocked” | Cancel/return, report concern, contact support; no bypass |

Example high-risk safe copy: “This payment needs an additional check. You are paying a new recipient, the amount is different from your recent activity, and this device is new to your account.” Show only reasons actually returned and approved for disclosure. Do not reveal detection thresholds, IP addresses, internal rule IDs or another user's data. An administrator may see richer evidence under a separate permission.

Actions “Continue with verification”, “Cancel” and “Report” are independently enabled from server capabilities. Report opens a scoped case with the payment reference, never a public accusation. Cancel is a request and can lose a race with inclusion; show the resulting authoritative status. No countdown pressure, flashing red screen, warning siren or language implying criminal guilt.

## 6. Request and QR journey

Receive → select own wallet → enter amount/expiry → Generate request → show server-issued signed link and QR → copy/share at user action. A static address QR is clearly “Address only”; a payment-request QR contains a request token, amount and expiry retrieved from server. Merchant static QR resolves a merchant profile and creates a fresh request after amount entry.

Payer scans → permission request only after Scan action → validate FINCHAIN sandbox destination → resolve request → show recipient/amount → login if needed → resolve again → review and authorize. Camera denied/unavailable offers Paste link/address and image selection if supported. An imported image is decoded locally where possible; no photo upload without an explicit supported data policy.

Request states: OPEN permits payment; CLAIMED says “A payment is already being processed”; PAID says “Request paid”; EXPIRED/CANCELED block payment and direct recipient to generate a new request. Two scans cannot lead to duplicate successful claims. Sharing a QR does not mark it paid.

## 7. Commerce journey

Category → sample item detail → cart → checkout with server total → BPI review → authorization → chain recorded → settlement → order receipt. Checkout source is BPI only. Inventory/payment-request references persist across reload. Do not mark the order paid from a browser redirect or a chain proof.

If inventory expires before settlement completes, continue tracking the existing payment; no second checkout. Late settlement produces “Payment completed — order needs review”, with an explicit fulfillment/refund case. Explain that a refund, if initiated, follows its own progress. Real recharge/utility/travel/subscription fulfillment is unavailable unless a future integration is actually approved and implemented.

## 8. Merchant approval and refund journey

Finance maker → choose source/outlet and recipient → review amount/purpose → submit proposal → checker sees exact details and maker identity → approve with MFA → BPI flow. Maker cannot approve their own proposal where separation is required. Editing invalidates approvals. Batch details show each child; a partial batch is never shown as wholly successful.

Refund → open completed original receipt → enter up-to-remaining amount/reason → verify source available funds → review/approval → submit linked refund → track settlement. Pending refunds reserve the remaining refundable amount. Insufficient funds does not offer FINCOIN conversion. Unknown settlement does not expose Retry refund as a new operation.

## 9. FINCOIN journey

Optional enrollment → independent wallet/test credit → Trade → Buy/Sell and FNC quantity → request quote → review synthetic price, fee, total/net and expiry → explicit simulation authorization → order submitted → filled or authoritative terminal alternative → portfolio refresh. No fiat gateway or BPI state appears in this path.

When a 15-second quote expires during reading/MFA, retain quantity and side and offer “Get a new quote”. Show changed price/fee before new authorization; never auto-confirm. After an order was submitted, fetch that order's status before offering another. A filled order can precede analytics: show “Trade filled; portfolio updating” and retain source/freshness labels.

## 10. Global recovery and feedback matrix

| Condition | User message / behavior | Recovery |
|---|---|---|
| First page load | Shape-matched skeleton, section-level busy state | Replace only when response resolves |
| Slow read (>10 s) | “This is taking longer than expected” | Retry read; retain known data with timestamp |
| Offline before submission | “Connect to continue” | Preserve safe draft fields, no automatic submission on reconnect |
| Timeout after financial submit | “Checking whether your request was received” | Reuse original operation/key/status lookup |
| Stale quote/draft | “Review a fresh quote/payment” | New authorization required |
| Rate limit | “Please wait before trying again” plus server retry time | Disable retry until eligible; no exponential UI loops |
| Missing/inaccessible resource | Generic unavailable page | Back to relevant list; no tenant-existence leak |
| Clipboard/share unsupported | Selectable text and manual-copy instructions | Never claim copied/shared if action failed |
| Domain unavailable | Domain-specific banner | Other domain remains accessible; no cross-domain fallback |
| Empty data | Specific explanation, meaningful permitted action | Never render zeros for an unavailable service |

## 11. Acceptance scenarios for the frontend engineer

Script journeys for first-time BPI-only registration; ₹500 Alice→Bob success, pending, unknown and returned; duplicate click/reload/back; new-device review; CRITICAL denial; two QR claims; merchant checker separation; partial refunds; a batch with mixed child outcomes; FINCOIN buy/sell/loss/expired quote; transfer with a wrong-domain address; private receipt opened by another user; public explorer unknown hash; MFA recovery; and service outage with no fake fallback data. Check actual backend status, accessible announcements and precise amounts at each step.
