import { defineConfig, devices } from '@playwright/test';
export default defineConfig({
  testDir: './tests', timeout: 30000, fullyParallel: false, workers: 1,
  use: { baseURL: process.env.FINCHAIN_WEB_TEST_URL || 'http://127.0.0.1:3101', trace: 'retain-on-failure' },
  projects: [{ name: 'chromium', use: { ...devices['Desktop Chrome'] } }],
  webServer: process.env.PLAYWRIGHT_EXTERNAL_SERVER ? undefined : { command: 'node node_modules/next/dist/bin/next start --hostname 127.0.0.1 --port 3101', url: 'http://127.0.0.1:3101', reuseExistingServer: true, timeout: 60000 },
  reporter: [['list'], ['html', { open: 'never' }]],
});
