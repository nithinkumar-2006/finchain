import { test, expect } from '@playwright/test';

test('landing exposes separate domains and real navigation', async ({ page }) => {
  const errors: string[] = [];
  page.on('pageerror', e => errors.push(e.message));
  await page.goto('/');
  await expect(page.getByRole('heading', { name: /Payments with purpose/ })).toBeVisible();
  await expect(page.getByText('Software sandbox · Simulated value · No FINCOIN needed to pay')).toBeVisible();
  await page.getByRole('link', { name: 'Explore BPI', exact: true }).click();
  await expect(page).toHaveURL(/bpi-network$/);
  await expect(page.locator('h1')).toBeVisible();
  expect(errors).toEqual([]);
});

for (const width of [320, 390, 768, 1440]) {
  test(`public layout fits ${width}px and mobile navigation works`, async ({ page }) => {
    await page.setViewportSize({ width, height: 900 });
    await page.goto('/');
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
    if (width < 960) {
      await page.getByRole('button', { name: 'Toggle navigation' }).click();
      await page.getByRole('navigation', { name: 'Main navigation' }).getByRole('link', { name: 'FINCOIN', exact: true }).click();
      await expect(page).toHaveURL(/fincoin$/);
    }
  });
}

test('forms use password input, allow paste, and do not invent success when service is down', async ({ page }) => {
  await page.goto('/register');
  await page.getByLabel('Email address').fill('alice@example.com');
  const password = page.getByLabel('Password', { exact: true });
  await expect(password).toHaveAttribute('type', 'password');
  await password.fill('correct long test password 123');
  await page.getByRole('button', { name: 'Create account', exact: true }).click();
  await expect(page.getByRole('alert')).toBeVisible();
  await expect(page.getByText('Request accepted.', { exact: false })).not.toBeVisible();
});

test('unavailable private data stays an explicit error', async ({ page }) => {
  await page.goto('/app/dashboard');
  await expect(page.getByRole('link', { name: 'Sign in to continue' })).toBeVisible();
  await expect(page.getByText('AVAILABLE BPI BALANCE', { exact: true })).not.toBeVisible();
});

test('keyboard skip link reaches main content', async ({ page }) => {
  await page.goto('/');
  await page.keyboard.press('Tab');
  await expect(page.getByRole('link', { name: /Skip/ })).toBeFocused();
  await page.keyboard.press('Enter');
  await expect(page).toHaveURL(/#main$/);
});

test('production scripts use a per-request CSP nonce', async ({page})=>{
  const first=await page.goto('/');
  const policy=first!.headers()['content-security-policy'];
  expect(policy).toContain("'strict-dynamic'");
  expect(policy.split(';').find(part=>part.includes('script-src'))).not.toContain('unsafe-inline');
  const second=await page.reload();
  expect(second!.headers()['content-security-policy']).not.toBe(policy);
});
