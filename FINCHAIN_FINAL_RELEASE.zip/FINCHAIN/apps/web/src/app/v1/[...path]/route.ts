// Deployment routes /v1 directly through Nginx. A frontend-only preview must fail explicitly.
function unavailable() { return Response.json({code:'SERVICE_NOT_CONNECTED'}, {status:503,headers:{'Cache-Control':'no-store'}}); }
export const GET = unavailable;
export const POST = unavailable;
export const DELETE = unavailable;
