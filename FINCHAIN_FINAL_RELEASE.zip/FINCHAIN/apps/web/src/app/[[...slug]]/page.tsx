import FinchainApp from '@/components/FinchainApp';
export default async function Page({ params }: { params: Promise<{ slug?: string[] }> }) {
  const { slug = [] } = await params;
  return <FinchainApp path={'/' + slug.join('/')} />;
}
