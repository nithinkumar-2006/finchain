'use client';
import { useEffect, useState, useId, cloneElement, isValidElement, type ReactNode, type ReactElement } from 'react';
import Link from 'next/link';
import { ArrowUpRight, Copy, Check, AlertCircle, RefreshCw } from 'lucide-react';
import { api, explain } from '@/lib/api';

export function useResource<T = any>(path: string | null, interval = 0) {
  const [data, setData] = useState<T | null>(null), [error, setError] = useState(''), [loading, setLoading] = useState(true), [version, setVersion] = useState(0);
  useEffect(() => {
    let active = true;
    setData(null); setError(''); setLoading(true);
    const load = async () => {
      if (!path) { setLoading(false); return; }
      try { const value = await api<T>(path); if (active) { setData(value); setError(''); } }
      catch (e) { if (active) setError(explain(e)); }
      finally { if (active) setLoading(false); }
    };
    void load(); const timer = interval ? setInterval(load, interval) : null;
    return () => { active = false; if (timer) clearInterval(timer); };
  }, [path, interval, version]);
  return { data, error, loading, reload: () => setVersion(v => v + 1) };
}
export function Button({ children, href, secondary = false, ...props }: React.ButtonHTMLAttributes<HTMLButtonElement> & { children: ReactNode; href?: string; secondary?: boolean }) {
  const className = `button ${secondary ? 'secondary' : ''} ${props.className || ''}`;
  return href ? <Link href={href} className={className}>{children}</Link> : <button {...props} className={className}>{children}</button>;
}
export function Card({ children, className = '' }: { children: ReactNode; className?: string }) { return <section className={`card ${className}`}>{children}</section>; }
export function Badge({ children, tone = '' }: { children: ReactNode; tone?: string }) { return <span className={`badge ${tone}`}>{children}</span>; }
export function ErrorBox({ message, retry }: { message: string; retry?: () => void }) { return <div className="error-box" role="alert"><AlertCircle size={20}/><div>{message}{retry && <button className="text-button" onClick={retry}><RefreshCw size={14}/> Retry</button>}</div></div>; }
export function Loading() { return <div className="skeleton" role="status" aria-label="Loading data"><div/><div/><div/></div>; }
export function Empty({ title, children }: { title: string; children?: ReactNode }) { return <div className="empty"><h3>{title}</h3><p>{children}</p></div>; }
export function PageTitle({ eyebrow = 'BPI PAYMENTS · SANDBOX', title, children, action }: { eyebrow?: string; title: string; children?: ReactNode; action?: ReactNode }) { return <div className="page-title"><div><p className="eyebrow">{eyebrow}</p><h1>{title}</h1>{children && <p className="muted">{children}</p>}</div>{action}</div>; }
export function CopyButton({ value, label = 'Copy' }: { value: string; label?: string }) { const [copied, setCopied] = useState(false), [error,setError] = useState(false); return <><button className="text-button" onClick={async()=>{try {await navigator.clipboard.writeText(value);setCopied(true);setTimeout(()=>setCopied(false),2000);} catch {setError(true);}}}>{copied ? <Check size={16}/> : <Copy size={16}/>} {copied ? 'Copied' : label}</button>{error && <p>Select and copy this value: <code>{value}</code></p>}</>; }
export function Field({ label, children, help }: { label: string; children: ReactNode; help?: string }) { const id=useId(); return <div className="field"><label htmlFor={id}>{label}</label>{isValidElement(children)?cloneElement(children as ReactElement<{id:string;'aria-describedby'?:string}>,{id,'aria-describedby':help?id+'-help':undefined}):children}{help && <small id={id+'-help'}>{help}</small>}</div>; }
export function Fact({ label, value }: { label: string; value: ReactNode }) { return <div className="fact"><span>{label}</span><strong>{value}</strong></div>; }
export function ArrowLink({ href, children }: { href: string; children: ReactNode }) { return <Link className="arrow-link" href={href}>{children}<ArrowUpRight size={16}/></Link>; }
