export type Json = Record<string, any>;
let csrf: string | null = null;
let refreshPending: Promise<void> | null = null;
export class ApiError extends Error { constructor(public code: string, public status: number) { super(code); } }
export async function getCsrf() {
  if (!csrf) {
    const response = await fetch('/v1/identity/csrf', { credentials: 'same-origin', cache: 'no-store' });
    if (!response.ok) throw new ApiError('IDENTITY_UNAVAILABLE', response.status);
    let result;
    try { result = await response.json(); } catch { throw new ApiError('INVALID_SERVER_RESPONSE', response.status); }
    if (typeof result.csrf_token !== 'string' || result.csrf_token.length !== 43) throw new ApiError('INVALID_SERVER_RESPONSE', response.status);
    csrf = result.csrf_token;
  }
  return csrf!;
}
export function clearAuth() { csrf = null; }
export async function api<T = Json>(path: string, method = 'GET', body?: Json, idempotencyKey?: string, retry = true): Promise<T> {
  const headers: Record<string, string> = {};
  if (method !== 'GET') {
    headers['Content-Type'] = 'application/json';
    headers['X-CSRF-Token'] = await getCsrf();
    if (!path.startsWith('/v1/identity/')) headers['Idempotency-Key'] = idempotencyKey || crypto.randomUUID();
  }
  let response: Response;
  try { response = await fetch(path, { method, headers, body: method === 'GET' ? undefined : JSON.stringify(body || {}), credentials: 'same-origin', cache: 'no-store' }); }
  catch { throw new ApiError('CONNECTION_UNAVAILABLE', 0); }
  let result: Json = {};
  if (response.status !== 204) {
    try { result = await response.json(); } catch { throw new ApiError('INVALID_SERVER_RESPONSE', response.status); }
    if (!result || typeof result !== 'object' || Array.isArray(result)) throw new ApiError('INVALID_SERVER_RESPONSE', response.status);
  }
  if (!response.ok) {
    if (response.status === 401 && result.code === 'ACCESS_EXPIRED' && retry && !path.includes('/sessions/refresh')) {
      if (!refreshPending) refreshPending = api('/v1/identity/sessions/refresh', 'POST', {}, undefined, false).then(() => {}).finally(() => { refreshPending = null; });
      await refreshPending;
      return api<T>(path, method, body, idempotencyKey, false);
    }
    throw new ApiError(result.code || 'REQUEST_FAILED', response.status);
  }
  if (result.csrf_token) csrf = result.csrf_token;
  return result as T;
}
export function units(raw: string, decimals = 2): string {
  if (!/^(0|[1-9]\d*)(\.\d+)?$/.test(raw)) throw new Error('Enter a positive amount using digits and a decimal point.');
  const [whole, part = ''] = raw.split('.');
  if (part.length > decimals) throw new Error(`Use at most ${decimals} decimal places.`);
  const amount = BigInt(whole) * 10n ** BigInt(decimals) + BigInt((part + '0'.repeat(decimals)).slice(0, decimals));
  if (amount <= 0n) throw new Error('Enter an amount greater than zero.');
  return amount.toString();
}
export function amount(raw: string | null | undefined, decimals = 2, symbol = '₹'): string {
  if (raw == null) return '—';
  const value = BigInt(raw), sign = value < 0n ? '−' : '', absolute = value < 0n ? -value : value;
  const scale = 10n ** BigInt(decimals);
  const whole = (absolute / scale).toLocaleString('en-IN');
  const fraction = (absolute % scale).toString().padStart(decimals, '0');
  return `${sign}${symbol}${whole}${decimals ? '.' + fraction : ''}`;
}
const messages: Record<string, string> = {
  INVALID_SERVER_RESPONSE: 'The service returned an invalid response. Your data could not be loaded. Please try again later.',
  INVALID_CREDENTIALS: 'Check your email, password and authenticator code. Your email must be verified before you sign in.',
  CONNECTION_UNAVAILABLE: 'The service could not be reached. Your payment outcome is not known; check its existing reference before trying again.',
  INSUFFICIENT_BALANCE: 'There is not enough available simulated balance for this action.',
  INDEPENDENT_APPROVAL_REQUIRED: 'A different authorized merchant checker must approve this exact payment first.',
  MFA_REQUIRED: 'Sign in with your authenticator to continue.', DOMAIN_STAFF_MFA_REQUIRED: 'This page requires a role for this domain and a recent MFA sign-in.',
  SYNTHETIC_FEED_STALE: 'The synthetic price feed is unavailable or stale. Trading will resume when fresh data arrives.',
  RATE_LIMITED: 'Too many requests. Please wait a minute and try again.',
  IDENTITY_UNAVAILABLE: 'Account services are unavailable. Try again shortly.', DATABASE_UNAVAILABLE: 'This service is unavailable. Your information has not been replaced with demo values.',
};
export function explain(error: unknown): string { return error instanceof ApiError ? messages[error.code] || error.code.toLowerCase().replaceAll('_', ' ') : error instanceof Error ? error.message : 'The request could not be completed.'; }
