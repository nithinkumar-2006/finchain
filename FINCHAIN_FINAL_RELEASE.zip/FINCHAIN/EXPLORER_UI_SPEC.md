# FINCHAIN — Explorer Interface Specification

Role 2 · Version 1.0 · Public view is a redacted proof explorer, not a wallet surveillance tool.

## 1. Privacy and proof model

Role 1's public projection exposes block headers, transaction hashes, salted journal commitments and proof data. It exposes no customer addresses, balances, amounts, payment type, risk score, contact data, legal names or private settlement evidence. The new request for Address Details is implemented as an authenticated private wallet screen plus a public explanation page; it does not loosen this boundary.

Public copy: “Explore signed sandbox blocks and transaction inclusion proofs. Payment details remain private.” Persistent selected domain and network/epoch appear beside search. No API request from the public explorer may fetch private records then hide fields visually. Public pages must be safe even when users inspect page source/network responses or copy a proof URL.

## 2. Explorer Home X-01

Header: Explorer, BPI / FINCOIN segmented domain selector, Sandbox/network ID and freshness. Search accepts exact transaction hash, block hash or block height; placeholder “Transaction hash, block hash or block height”. An address input receives a privacy explanation without echoing it into public analytics or shareable URL. Do not offer autocomplete from private records.

Desktop: summary metric row → 6-column Latest Blocks / 6-column Latest Transactions → network/trust explanation. Mobile: search and domain selector → metrics → blocks → transactions. Public latest transactions are opaque commitments, not sender/receiver/amount rows.

| Requested widget | Definition / display |
|---|---|
| Latest Blocks | Last 5 committed headers by height, selected network; height, time, event count, hash |
| Latest Transactions | Last 5 included transaction hashes with block height/index and commitment link |
| Total Transactions | Number of included chain events, not count of completed user payments; exclude genesis metadata |
| Average Block Time | Mean interval between up to latest 100 non-genesis committed blocks; show sample size/window |
| Active Validators | Label “Authorized block producer”; configured active producer count with telemetry status, not fake multi-validator count |
| Network Status | Serving/current data, no recent activity, stale, degraded or unavailable from timestamped health, not block age alone |

BPI transfer and later settlement generate separate events, so chain events must not be labeled payment volume. With fewer than two eligible blocks, average time is “Not enough blocks”. An idle network produces no empty blocks: old head time alone does not prove outage. Authorized producer count is distinct from heartbeat activity and from optional verifying followers.

## 3. Blocks X-02 and Block Details X-05

Blocks list columns: Height, Hash, Time (UTC), Included events, Producer key reference. Cursor pagination preserves network and range; sorting defaults newest first. Each Height links to details. Large height/hash strings remain selectable/copyable without wrapping the whole page horizontally.

Block details layout: heading “Block 42” with network; summary grid for height, timestamp, count and producer; expandable Verification section with block hash, previous hash, Merkle root, validator key ID, signature, protocol version and writer epoch; ordered included-event table. Previous/Next navigation bounds at genesis/head and never crosses network epoch.

Genesis detail identifies height 0 and registry purpose, not a ordinary payment. Empty blocks have an explicit event count if the protocol ever supplies them; current baseline creates no empty operational blocks. A missing height/hash gives “Block not found on this network” with domain selector/search. Do not redirect to another network automatically.

## 4. Transactions X-03 and Transaction Details X-04

Public transaction list: transaction hash, block height, index, block time and “Included” status. No sender/receiver columns, BPI amount, business status, risk level or merchant name. Filters are hash/height/time/network only. The word Transaction refers to a chain event here; a caption explains that one payment can have multiple events.

Detail: full transaction hash, journal commitment, inclusion block/hash/time, index, Merkle root, proof path, public validator signature/key reference. Main statement “Included in sandbox block …” does not say paid, safe, bank settled or successful trade. Expandable “What this proof shows” explains membership under the trusted producer; it does not prove private financial details or legal settlement.

If a future in-browser Verify action is implemented, show its actual verification result with explicit scope: “Inclusion proof matches this block header” and separately “Header signature matches the trusted network key” when checked. Never display Verified before code runs or when required genesis/key history is unavailable. An unimplemented verifier offers read/download proof only. Failed proof validation produces “Proof could not be verified”, retains original references and provides report/help; do not substitute a green check because an API returned 200.

Download/copy includes only allowlisted public proof material and selected network ID. An authorized user's View in Explorer action opens this same redacted record; public visitors do not gain the private receipt through that link.

## 5. Address Details X-06 / private C-13

Public route `/explorer/:domain/address-privacy` explains: “Wallet addresses and activity are private in this sandbox explorer. Sign in to view wallets you are authorized to access.” It has no address search box, address list or address existence probe. Do not create `/explorer/.../address/:address` responses exposing even activity counts.

Private address detail lives under the authenticated product wallet: BPI C-13 or FINCOIN F-05/F-07. Show own authorized address, domain/network, wallet status, copy/select and scoped history link. BPI may show its own available/reserved/pending balances; FINCOIN may show its own test assets. Private address content uses the application shell and no public share preview. Another user's private deep link returns a generic unavailable/access response without revealing their identity.

This meets the useful Address Details journey while preserving Role 1 privacy. A future proposal for public pseudonymous addresses requires a new architecture/privacy decision; a name-free blockchain address can still reveal private activity through linkage.

## 6. Network Statistics X-07

Display selected domain/network genesis/epoch, current committed height, included-event count, average block interval/window, producer public key/rotation history when publicly available, and follower information only if actually published. Throughput metric, if added, is included events divided by a stated observed window, never advertised maximum capacity.

Trust model panel: “One authorized block producer. Optional followers verify records. This prototype is not a permissionless network.” Use real registry counts, no sample animated validators. Producer key rotation public history must follow trusted chain records; private staff identities and internal network endpoints remain hidden.

Statistics read model is UX-E06. Minimal existing block/proof endpoints cannot produce arbitrary global metrics from their first page. If aggregate data is absent, show Unavailable or omit optional graph with reason. Do not infer gateway settlement status from block metrics or expose private operations telemetry in the public page.

## 7. States and accessibility

Loading shows nonnumeric skeletons; no fake block progression. Empty new epoch says “No transactions yet” and shows available genesis. Unknown hash says “No matching public record on this network”; some records may still be pending/private, so this is not proof of payment failure. Service unavailable preserves the chosen network/search locally without recording sensitive input. Stale data labels timestamp and avoids an “Operational” badge based solely on cached success.

Long hashes wrap in details with copy, while compact rows show clearly shortened references. Keyboard users can open rows, move between block pages and read verification data without hover. Public proof tables support screen-reader labels and text exports. Mobile summaries use cards; full proof paths use bounded wrapping/expanders rather than horizontal page overflow.

## 8. Privacy acceptance

Inspect public JSON, rendered content, metadata, exports, error messages, logs and social previews for names, email/phone, addresses, balances, amounts, risk signals and settlement evidence. Test BPI and FINCOIN networks, empty genesis, unknown hashes, malformed input, invalid proof, stale/no-activity distinction and a private receipt opened without permission. Public explorer success means a public proof rendered correctly; it never implies a payment completed.
