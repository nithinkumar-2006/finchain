# Deployment guide

The generated Compose stack is a local sandbox. It contains PostgreSQL with separate databases and login roles; identity API and local email worker; BPI/FINCOIN APIs, Redis instances, workers, signers, bootstrap jobs and proof projectors; a gateway simulator; a public explorer; Next.js; Nginx; and a local email inbox. Only Nginx 8443 and the local inbox 8025 bind host ports, both on loopback.

Startup order is PostgreSQL readiness → forward migrations and role grants → private signers → genesis initialization → financial APIs/workers/projectors. Nginx routes identity and domain requests directly to their APIs. The public explorer has public projection credentials only. The migration and bootstrap jobs have temporary broad authority and must not become internet-facing runtime services.

Run `docker compose -f compose.json config --quiet`, then build/start. Check completed migration/bootstrap jobs and service logs. Open a fresh account, verify email in Mailpit, create a wallet, request test funding, execute a payment and inspect settlement, receipt and public proof. Run FINCOIN separately. Exercise failure and unknown gateway scenarios. Full-stack execution remains a release acceptance gate on a Docker-enabled host.

Images use major/moving tags in this sandbox. Before a shared environment, resolve and pin image digests, scan dependencies, establish signed image provenance and set resource limits. Application Python dependencies and frontend packages have lock files; this does not replace vulnerability scanning.

Back up each PostgreSQL database plus encrypted secret/key material under separate access controls. Restore into an isolated environment and replay journals/chain before accepting traffic. Never repair balances with SQL updates or delete audit rows. A failed migration rolls back; applied SQL checksums must match. Corrections require a new forward migration and tested recovery plan.

Cloud readiness means services have explicit boundaries and container definitions. This delivery has not provisioned a cloud account, DNS, certificate authority, managed key service or live gateway.
