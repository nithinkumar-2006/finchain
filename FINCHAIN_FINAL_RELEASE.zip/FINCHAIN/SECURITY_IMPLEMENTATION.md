# FINCHAIN Security Implementation

Status: sandbox implementation v0.1, 2026-09-14. Read [AUTH_SPEC](AUTH_SPEC.md) for API/credential contracts and [SECURITY_HANDOFF](SECURITY_HANDOFF.md) for execution and remaining gates. No claim of perfect security or completed production certification is made.

## Implementation map

| File | Responsibility |
|---|---|
| `services/identity/finchain_identity/config.py` | Fail-fast PostgreSQL, HTTPS origin, key-separation and lifetime configuration |
| `crypto.py` | Argon2id, AES-GCM, blind indexes, token verifiers, pinned JWT verification, TOTP and audit hashes |
| `models.py` | PostgreSQL identity schema; UUID primary keys, UTC timestamps, constraints and FK integrity |
| `service.py` | Transactional identity workflows, locks, refresh lineage, lockouts, live authorization and audit |
| `app.py` | Strict schemas, endpoint wiring, opaque cookies, CSRF/Origin boundary, CORS, body cap and headers |
| `operator.py` | Offline audited role provisioning, using separately controlled operator credentials |
| `migrations/versions/0001_identity.py` | First migration with frozen schema snapshot and append-only audit trigger |
| `deploy/roles.sql` | Runtime/operator separation and role-grant RLS |
| `tests/` | HTTP abuse/security tests and opt-in PostgreSQL concurrency/permission tests |

## Defense coverage and practical limits

| Concern | Implemented control | Limit / integration obligation |
|---|---|---|
| Password disclosure | Argon2id; no reversible passwords; dummy verification for absent users | Hardware benchmarking and breached-password screening remain |
| JWT substitution | RS256 only, fixed issuer/audience/kid/type, required typed claims, server-only storage | One active key; coordinated rotation until a reviewed public-key ring exists |
| Refresh replay | Atomic lineage and family revocation under PostgreSQL locks | SQLite tests cannot validate cross-process locking |
| Stale authority | Live user status, session revocation, credential epoch and role reads | Domain operation authorization still belongs in domain services |
| Credential stuffing | PostgreSQL counters per peer/route and account; five failed logins cause 15-minute lock | Fixed-window throttles are not volumetric DDoS defense; lockouts can cause denial of service |
| Suspicious login | Version-one deterministic change signal from HMAC of peer address and bounded User-Agent; private audit event | No geolocation, impossible-travel claim, alert worker or ML risk engine; first login establishes baseline |
| CSRF | Exact Origin, double-submit CSRF, server session binding for authenticated writes | Same-origin XSS can still act as a user |
| CORS | One exact configured HTTPS origin; credentials permitted only there; bounded methods/headers | CORS is a browser policy, not an authorization boundary |
| Injection | SQLAlchemy bound parameters, typed UUID paths, strict Pydantic bodies and unknown-field rejection | Future SQL must use bound parameters; identifiers cannot be sourced from requests |
| XSS | JSON-only responses, no reflected validation input, no HTML interpolation, nosniff and CSP | Future Next.js pages need escaping, safe rendering and their own nonce-based CSP |
| Request abuse | 8 KiB body cap, input lengths, rate limits and bounded query output | Add edge connection/concurrency limits and trusted proxy configuration |
| Audit reliability | Auth mutation and chained audit commit together; missing audit stream fails closed | Global stream lock bounds throughput; external checkpoints/export are not implemented |
| Storage leakage | Encrypted email/MFA/bridge tokens/outbox, HMAC lookup and network signals | App process/key compromise can decrypt its data; use managed keys before deployment |

Default rate is 60 requests per minute for each peer/route bucket, plus account buckets on login, registration and recovery. MFA enrollment/confirmation share five attempts per browser session per minute, and enrollment expires in five minutes. Existing-account failures also update a locked user row; attempts during a lock do not extend the lock. There is no Redis dependency: PostgreSQL is the durable limiter for this foundation. Add Redis only as an additional fast rejection layer, preserving correctness and a fail-closed policy if the authoritative limiter is unavailable.

The shipped server ignores forwarded headers. Behind the provided proxy example, all requests therefore share the proxy's peer bucket; account limits still apply. Before shared testing at scale, add a reviewed trusted-proxy topology that strips client-supplied forwarding headers and accepts only the actual proxy network. Do not simply enable trust for every proxy address. Logging raw IP/user-agent is unnecessary for the implemented signal.

All API responses passing the HTTP boundary receive no-store, nosniff, frame denial, restrictive API CSP, no-referrer, limited Permissions-Policy and HSTS. The API CSP is deliberately unsuitable for serving a frontend page; Next.js requires its own policy. TLS termination, encrypted database transport/storage/backups and private network access remain infrastructure responsibilities. The application is not an HTTPS terminator.

## Database scope and migrations

Use one independent `identity_db` with schema `auth`. Implemented tables: users, password_credentials, role_grants, sessions, refresh_tokens, web_sessions, identity_challenges, email_outbox, mfa_factors, rate_buckets, audit_streams, audit_logs. Every table has a UUID primary identifier and created_at. All temporal columns are timezone-aware in PostgreSQL; the SQLite test adapter restores UTC on reads. User updates also maintain updated_at; other lifecycle changes use explicit monotonic times/counters.

This is a **subset and explicit refinement** of [DATA_DICTIONARY](DATA_DICTIONARY.md), not an implementation of its complete schema:

* `sessions.id` itself is the refresh-family identifier, avoiding a second equivalent family UUID. Its opaque browser digest lives only in web_sessions.
* Temporary lockouts use `locked_until` plus failure count, rather than changing the permanent account status to LOCKED. DISABLED/DELETED remain authentication denials. No hard-delete endpoint exists.
* `identity_challenges`, `role_grants`, `email_outbox` and `rate_buckets` are necessary new identity tables.
* One TOTP factor per user is implemented. WebAuthn fields, recovery_codes, profiles, durable device records, generic row versions, subject-event outbox/inbox and deletion workflows remain future migrations. The HMAC network/agent signal does not pretend to implement trusted-device enrollment.
* Digests are 64-character hexadecimal SHA-256/HMAC values instead of binary 32-byte fields; they carry the same digest bits. Ciphertexts use binary version-1 AES-GCM envelopes. No blockchain/public export contains these tables.
* Identity audit is a minimal typed chain with subject and optional operator UUID, action/result, time, sequence, correlation and hashes. It intentionally has no arbitrary metadata/request-body field.

UUIDs are generated in application/migration code; raw SQL inserts must supply them. Unique email/token digests, role uniqueness, refresh root/child uniqueness, same-session parent FK and active-factor ownership are enforced by the schema. No cascade deletion erases session/audit history. Indexes cover user lookup, FK-oriented history and token lookup. Runtime is never the table owner or a superuser.

Migration 0001 loads a frozen snapshot; future model edits cannot silently change this revision. Run migrations once with the migration owner, not at API startup. Offline SQL preview is included and generated successfully. Apply `deploy/roles.sql` separately as DBA, then use a login inheriting only finchain_identity_runtime. Operator credentials inherit only their dedicated capability. RLS prevents runtime from inserting privileged role grants, and the audit trigger rejects row update/delete. No runtime DELETE/TRUNCATE/schema CREATE permissions are granted. Privileged database owners can still bypass protections; external evidence is required to detect an owner-level rewrite.

Future revisions use expand → bounded backfill → validation → switch → contract. Do not rewrite encrypted fields without original associated-data context. Before renaming columns, preserve the encryption context or re-encrypt in a reviewed migration. Destructive downgrade is disabled; recover into an isolated backup or forward-fix. Test restore plus session invalidation after restoring older state, since an old backup can resurrect previously revoked sessions/challenges.

## Transaction and failure semantics

User-specific changes serialize on the user row, then session/factor/challenge rows, then the audit stream. Refresh additionally reloads the bridge row after acquiring locks. Rate updates commit in a separate short transaction before expensive credential work. Registration uses a unique blind index and INSERT ON CONFLICT to avoid a duplicate-account race. No external network action occurs inside an identity transaction.

The application `Denied` exception deliberately commits controlled failure mutations: login failure counters, MFA failure audit, refresh-family revocation and authorization audit must survive a 4xx response. Other exceptions roll back the business transaction. This exception type must never be raised halfway through an otherwise successful partial operation in future code. Database errors return 503 without SQL/parameter details. Sensitive success paths cannot succeed if their audit write fails; rollback is tested.

Recovery token consumption and reset/revocation are atomic. For an ambiguous reset response, do not automatically replay user commands with a new token; the existing one is either consumed or still usable, and the user can attempt the new password or request recovery again. No business action is retried with fresh identifiers behind the user's back.

## Secret handling and key management

**Wallet private keys never enter this service and must never be logged anywhere in FINCHAIN.** There are no wallet-key inputs, fields or signer methods. Unknown `wallet_private_key` input is rejected without echoing its value, including in tests. Do not add request/response body, cookie, Authorization, token, TOTP secret or private-key logging. Uvicorn access logging is disabled in the container; the Nginx example disables identity access logs. Exception monitoring must disable local-variable/body capture. A safe event allowlist is stronger than attempting to redact arbitrary dictionaries after collection.

Sandbox configuration reads an RSA PKCS8 signing key and separate base64-encoded 32-byte encryption/lookup keys from mounted files. There are no default secret values and no real secret files in the deliverable. The encryption version byte identifies the one configured AES-256-GCM key; a fresh 96-bit random nonce is generated per write. Associated data binds table, row UUID and field within this isolated database. Deployment keys must be unique per service/environment. There is no implemented managed-key adapter, automatic envelope-DEK rotation or dual blind-index rotation; plan those before retaining real personal data.

For production identity JWT signing, recommend an asymmetric AWS KMS RSA SIGN_VERIFY key with a reviewed RS256 signing adapter. AWS documents supported RSA signing specifications in its [key-spec reference](https://docs.aws.amazon.com/kms/latest/developerguide/symm-asymm-choose-key-spec.html). The current Python file-key adapter does not call KMS. Use a separate symmetric KMS key for envelope encryption and restricted secret management for lookup-key material; separate identities and audit policies for signing versus decrypting.

For BPI and FINCOIN wallet/validator signing, choose separate private signer services backed by an HSM that demonstrably supports the exact protocol algorithm and required throughput. Verify hardware, mechanism and region support for Ed25519 before procurement; never assume a vault storing an encrypted key performs the signature inside hardware. If a chosen KMS lacks the required mechanism, choose a compatible HSM or review the protocol change explicitly. Do not share JWT, wallet, validator, callback or audit-checkpoint keys. Rotation must preserve public verification history and bind wallet keys to the correct network and effective block height.

Audit hashes require independently controlled signed checkpoints to detect rewriting by a privileged owner. Export/alert infrastructure, retention automation, cryptographic erasure and a restore drill are handoff work, not implemented assurances.
