# FINCHAIN — FINCOIN Architecture

Status: sandbox/test-ledger architecture v1.0. This product is independent of [BPI](BPI_ARCHITECTURE.md).

## 1. Scope and isolation

FINCOIN provides an independent wallet, test-asset transfers, simulated buy/sell, holdings, FIFO P&L and synthetic market charts. It has its own chain, database, API audience, signer, administrators, workers and secrets. The quote asset `SIM_INR` is fictitious, nonredeemable simulator credit. It is not the BPI wallet's simulated INR balance and cannot be transferred to or from BPI.

No external exchange, actual security, real-money deposit, real custody, public token sale, price guarantee, yield or return promise is part of this release. Buying creates a simulated fill against a simulator account. Screens must say “Simulated trade” and identify generated price data. A FINCOIN wallet is optional for every BPI user.

## 2. Asset registry and supply

| Asset | Precision | Sandbox issuance |
|---|---|---|
| `FINCOIN` | 8 decimal places; 1 coin = 100000000 atoms | Genesis issues exactly 1000000 test coins (100000000000000 atoms) to simulator inventory |
| `SIM_INR` | 2 decimal places | Simulator begins with 100000000 minor units; faucet may issue explicitly logged credits under caps |

FINCOIN has no post-genesis minting in this epoch. Test grants transfer from existing simulator inventory; transfers and fills preserve issued supply. SIM_INR faucet defaults to 1000000 minor units per subject per day, enforced durably; it credits user liability against an issuance contra account and records a system chain transaction. Limits and values are demonstration choices, not tokenomics or a real valuation. Reset requires a new network epoch, never hidden edits to history.

Each asset has credit-normal holder accounts (user, simulator inventory, fee treasury) and a debit-normal issuance contra account. Total holder balances equal issued supply for that asset. These are quantity subledgers, not a claim of real-world financial liabilities. The fee treasury and simulator accounts cannot go negative. FINCOIN assets do not collateralize BPI obligations.

## 3. Wallet and transfer

Wallets expose available and reserved atomic units by asset; all amounts are strings. FINCOIN test transfers between user wallets use chain-specific signed payloads, recipient verification, nonce, expiry, permissions, and exact available-balance checks. FINCOIN uses one active outgoing nonce claim per wallet, like BPI, in a separate namespace. Transfers commit journal and chain together, and become `CONFIRMED` without any fiat settlement stage.

Test transfer fee starts at zero. No bridging, mainnet withdrawal, smart-contract deployment, margin, leverage, derivatives, staking or lending. Withdrawal buttons must not imply external redeemability. A supply view reconciles genesis, grants and holdings using the authoritative ledger.

## 4. Market feed and quote contract

Use a seeded synthetic feed with deterministic ticks, source ID, sequence, timestamp and network epoch. Prices are positive integer SIM_INR minor units **per whole FINCOIN**. Default tick interval is one second; reject new quotes when the latest tick is older than ten seconds. Use the server clock for expiry, not browser time.

A quote binds `quote_id`, subject/wallet, side, FINCOIN quantity atoms, unit price, gross minor units, fee minor units, total/net minor units, feed sequence, created time, expiry, network, and `source: "synthetic"`. Quote lifetime defaults to 15 seconds. It is all-or-nothing and subject to inventory checks at execution; it does not reserve liquidity. The user signs the exact quote terms. Never silently reprice an expired quote.

Initial fee: 10 basis points of rounded gross, rounded upward to the next minor unit; visible before authorization. Fee configuration is versioned and fixed in the quote. Let quantity be `q`, price `p`, and `S = 100000000`:

```text
buy_gross_minor  = ceil(q * p / S)
sell_gross_minor = floor(q * p / S)
fee_minor       = ceil(gross_minor * 10 / 10000)
buy_total_minor = buy_gross_minor + fee_minor
sell_net_minor  = sell_gross_minor - fee_minor
```

Reject zero gross or nonpositive sell net. Use arbitrary-precision integer intermediates; no IEEE float calculations. Display rounded estimates only from the server-computed quote. Any future spread is an explicit quote term, not a hidden difference introduced during fill.

## 5. Atomic execution and accounting

Order states: `CREATED → AUTHORIZED → QUEUED → FILLED`; alternatives are `REJECTED`, `EXPIRED`, `CANCELED` before fill. A cancellation and fill race on the same locked order row. One quote can fill once; a quote belongs to its requesting subject. No partial fills in v1.

The ledger locks order, user accounts, simulator inventory, fee treasury and nonce state in stable order. Revalidate quote expiry, current account permissions and funds. The following entries, fill, transaction/block, nonce consumption and outbox event commit in one domain database transaction:

| Side | Asset | Debit | Credit |
|---|---|---|---|
| Buy | SIM_INR | User: gross + fee | Simulator: gross; fee treasury: fee |
| Buy | FINCOIN | Simulator: quantity | User: quantity |
| Sell | FINCOIN | User: quantity | Simulator: quantity |
| Sell | SIM_INR | Simulator: gross | User: net; fee treasury: fee |

Journals balance independently by asset; do not subtract coin quantities from currency amounts. Both sides are full-value legs in one operation. Simulator must have FINCOIN inventory for buys and gross SIM_INR for sells. Reject exhausted inventory without partial effects. There is no BPI funding fallback.

Fills are immutable with `order_id`, quote digest, quantity, price, gross, fees, net/total, feed sequence and chain hash. Duplicate commands return the original fill. Outbox delivery is at least once, projection effects idempotent.

## 6. Portfolio and P&L

Use FIFO cost lots for reproducible simulation analytics. A buy opens a lot with quantity `q` and SIM_INR cost `buy_total_minor`, including buy fee. A sell disposes oldest available lots by chain order and computes realized P&L as `sell_net_minor - allocated_cost_minor`.

For partial lot disposal, allocate `floor(remaining_cost * disposed_quantity / remaining_quantity)`; the final disposal receives all remaining cost. This preserves total cost exactly. Store allocation evidence and rebuild from fills/transfers in `(block_height, tx_index)` order. No double-counting when events replay.

Example: buy 2 FINCOIN at SIM_INR 100 each; gross 20000 minor units, fee 20, total cost 20020. Sell 1 at SIM_INR 120; gross 12000, fee 12, net 11988; allocated FIFO cost 10010; realized P&L is 1978 minor units (SIM_INR 19.78).

Portfolio market value uses `floor(total_atoms * current_price_minor / 100000000)`. Unrealized P&L equals marked value minus remaining known cost; identify it as excluding future sell fees. Show realized and unrealized separately and include valuation time/feed sequence. Stale or absent prices disable fresh valuation and new quotes; do not silently use zero prices.

Internal test transfers carry lot quantity/cost evidence to the recipient for this simulator's analytics, without realizing a sale. Sender basis is removed using FIFO and transferred cost lots preserve total basis. This is a simulation convention, not tax advice. Test grants use `basis_status: "grant"` and zero acquisition spend; report grant-derived gains separately from purchased-lot P&L. Cost basis imported without evidence is unknown; suppress affected P&L rather than inventing zero cost. Deposits of SIM_INR are cash flows, not profits. Do not display return percentages without a defined denominator and method; v1 reports absolute P&L only.

## 7. Charts and dashboards

Build OHLC candles from synthetic ticks in UTC buckets, with explicit gaps and deterministic opening/closing sequence selection. Distinguish price-feed ticks from simulator trade volume; never invent external market volume. Provide price chart, holdings allocation, balance history, realized P&L and unrealized P&L. The UI displays source, timestamp, simulation label and stale-data state beside values.

Query read models with pagination and bounded time ranges. Order/transaction detail reads authoritative fill status; portfolio projections expose `as_of_block_height` and `as_of_time`. A replay rebuild must equal incremental analytics exactly.

## 8. Controls and acceptance

Enforce quote ownership, idempotency, nonce replay protection, faucet limits, account freezes, order velocity and domain-specific administrative permissions. Pause new quotes/orders separately from read access and processing already committed events. Correction trades require linked compensating commands and approval; no editing fill price after execution.

Test supply conservation, fractional quantity rounding, final lot remainder, fees, empty inventory, stale feed, simultaneous sells, duplicate fills, quote expiry while queued, cancellation races, transfers of mixed-basis lots, grant separation and full projection replay. Execute the complete simulator with BPI services and gateway disabled, and verify FINCOIN credentials cannot read BPI balances or sign BPI transactions.
