# FINCHAIN — FINCOIN Interface Specification

Role 2 · Version 1.0 · Product label: **FINCOIN Simulator** · Display ticker: **FNC**.

## 1. Domain identity and scope

FINCOIN is optional and separate from BPI. The internal asset code remains `FINCOIN`; `FNC` is the display ticker, with eight decimal places. Quotes, fees and simulated market value use `SIM_INR`, displayed literally as `SIM_INR 120.00`, never as an unqualified rupee balance. BPI funds cannot buy FNC, fund quote credits or cover a test transfer fee.

Persistent explanatory copy: **“FINCOIN is a digital asset and is separate from BPI payment balances.”** Follow with **“Digital assets involve risk. Market value may rise or fall.”** Nearby context: “This simulator uses test assets and synthetic prices. No real trade is executed.” Keep these on public FINCOIN, simulator enrollment and trade review, with a compact always-visible simulator/source label elsewhere.

The shell uses violet accents and text “FINCOIN Simulator · Test network”. Navigation: Overview, Buy / Sell, Portfolio, Wallet, Transfer, Receive; Back to BPI is a separate navigation link. It is never a funding action. A user without a FINCOIN wallet sees optional enrollment and a usable Back to BPI action, not a blocked general account.

## 2. Overview F-01

Desktop layout: title/ticker and simulation label; four market summary metrics; 8-column price chart plus 4-column trade-action/holding summary; lower portfolio summary and recent simulated activity. Primary action Buy — simulation; Sell, Transfer and Receive are secondary and depend on enrollment/balance/availability.

```text
FINCOIN Simulator        FNC                         Synthetic data / updated at
[Current price] [24H change] [Simulated supply valuation] [Simulator volume]
[Price chart, time range, source — 8 cols]  [Your FNC holding — 4 cols]
[OHLC / accessible table toggle]           [Buy / Sell / Transfer / Receive]
[Portfolio and cost-basis summary]         [Recent test transactions]
```

When no wallet exists, market information may remain readable but trading actions route to enrollment. Do not seed personal holdings automatically for appearance. Test credits/grants require a deliberate, capped server operation with an actual receipt.

## 3. Market metric definitions — UX-E04

Role 1 already defines synthetic prices/candles. These derived read-only metrics extend that contract and must be implemented explicitly before displaying values. Aggregations use the complete synthetic dataset, a shared as-of time and server-specified source/network, not browser guesses from a visible chart window.

| Requested metric | Display label and definition | Missing/edge case |
|---|---|---|
| Current Price | “Synthetic price”; latest valid tick in SIM_INR per 1 FNC | Older than 10 seconds: show retained price as stale, block new quotes |
| 24H Change | “24h synthetic change”; `(latest price / price at or immediately before t−24h − 1) × 100` | Reference tick must be within 10 seconds of target; otherwise “Not enough price history” |
| Market Cap | “Simulated supply valuation”; latest synthetic unit price × issued FNC supply from same epoch | Explain this is all issued test supply, not real market capitalization or circulating valuation; absent supply/price → unavailable |
| Volume | “24h simulator volume”; sum filled FNC quantity and gross SIM_INR consideration in `(t−24h,t]`, each fill once | Tick count is not volume; transfers/grants excluded; genuine no fills → 0 |
| Active supply | Issued quantity (initial epoch 1,000,000 FNC), from ledger registry | Never hard-code this as a live metric or infer circulating supply |

Market cap terminology may appear in the metric explanation because it was requested; the visible label must retain simulated-supply context. Never imply a real exchange listing, external liquidity, market dominance or guaranteed redemption. No market capitalization figure enters a user's spendable total.

Chart default 24h; available 1h/24h/7d/30d/All where data exists. Default line; optional OHLC view only from actual synthetic candle data. Gaps remain gaps. A textual summary and data table show source, selected window, open/high/low/close and timestamps. Show `+`/`−` for change and a neutral flat state. No default positive trend or “top gainer” treatment.

## 4. Buy / Sell F-02

Desktop split: market/quote context 7 columns, transaction form 5; mobile form above chart. Controls: Buy/Sell segmented selector, quantity in FNC with up to eight decimals, available asset/credit balance, Request quote. Quantity-first v1 avoids inventing an exact spend-to-quantity calculation. Display estimated value only as an estimate until a server quote exists.

Quote review shows side, exact FNC quantity, price per coin, gross SIM_INR, fee, total to pay or net to receive, source “Synthetic feed”, quote expiry and explicit simulation context. Fee is backend-calculated under Role 1's 10-basis-point rule and rounding; the UI never recomputes a competing rounded total. Primary button includes direction and quantity: “Buy 2 FNC — simulation” / “Sell 1 FNC — simulation”.

Quote duration is 15 seconds by baseline. Show “Quote expires in …” as information, not pressure; do not announce each second or use an urgent flashing color. Expiry preserves side/quantity and replaces Confirm with “Get a new quote”. If MFA takes longer, get a fresh quote and require review of any changed price/fee. No automatic reprice or automatic order placement after reauthentication. The future accessibility review must assess the time-limited quote interaction, not claim conformance solely from a countdown.

Balance failures: Buy needs enough SIM_INR including fee and simulator FNC inventory; Sell needs enough FNC and simulator quote liquidity. Explain only safe availability details. Available actions can include Request test credits when permitted, Edit quantity or Try later. Never Deposit BPI, Convert INR or Buy FNC to unlock payments. Quote generation does not reserve liquidity; review helper says “Availability is checked again when the simulated order executes.”

## 5. Order result F-03 and receipt F-08

| State | Headline | Action |
|---|---|---|
| `CREATED` | Order prepared | Review if still valid |
| `AUTHORIZED` / `QUEUED` | Simulated order processing | Track same ID; no duplicate order |
| `FILLED` | Simulated buy/sell completed | View fill, Portfolio and public proof |
| `REJECTED` | Simulated order not executed | Safe reason, edit/request new quote if allowed |
| `EXPIRED` | Quote expired before execution | Get fresh quote; no asset change |
| `CANCELED` | Simulated order canceled | Return to trade |
| Transport uncertainty | Checking order status | Fetch existing order; do not assume rejection |

Receipt fields: order/transaction ID, Buy/Sell/Transfer, FNC quantity, quote price, fee, total/net SIM_INR, created/executed times, source feed sequence if expanded, chain status/block and environment. A FINCOIN fill is atomic and has no simulated fiat gateway settlement step. Do not reuse BPI pending-settlement labels. Test transfers use Confirmed rather than Filled, with source/recipient visible only to authorized participants.

No partial fills in v1. If an API unexpectedly returns a partial result, treat it as an unsupported contract state needing investigation, not a misleading completed order. Portfolio projection lag after fill says “Trade completed; portfolio is updating” with authoritative wallet balance and analytics as-of marker kept distinct.

## 6. Portfolio F-04

Top row: FNC Holdings, Current Value, Average Buy Price; second row Realized P&L, Unrealized P&L, Return %. Separate SIM_INR credit card under Wallet, never merged into FNC holding value. Table below: purchased lots, grant lots, carried-in lots, remaining quantity, known basis, acquisition/transfer time and provenance. Do not expose another user's identity through transferred basis evidence.

| Requested measure | Final definition / label |
|---|---|
| FINCOIN Holdings | Total owned FNC atoms converted to up to 8 decimals; available/reserved separately if relevant |
| Current Value | Marked FNC holdings using latest valid synthetic price, rounded per Role 1; SIM_INR denomination |
| Average Buy Price | “Average cost of remaining purchased FNC”; remaining purchased known basis including buy fees / remaining purchased quantity; excludes grants and separately labeled carry-ins |
| Realized P&L | Net simulated sell proceeds minus FIFO allocated known cost; purchased, carried-in and grant-derived results reported separately |
| Unrealized P&L | Current marked value of known-basis eligible lots minus remaining basis; exclude future sell fees; grant-derived value separate |
| Return % | “Realized return on purchased lots”; sum realized P&L for own purchased-lot disposals / sum allocated acquisition cost for those disposals × 100 |

The Return % definition is the Role 2 extension to Role 1's absolute-P&L-only baseline. It is a realized cost-based ratio, not annualized return, total-account performance, time-weighted return or a forecast. The primary percentage uses all eligible own purchased-lot disposals in this sandbox epoch; label “Since enrollment”. Exclude grants, unknown basis and carried-in lots from this ratio, with an explanation and separate amounts. A zero denominator displays “Not available — no purchased lots sold”. Do not render 0% for unknown/no history.

For a partial disposal, denominator and proceeds follow the exact FIFO cost/proceeds allocation supplied by backend analytics. Prices/fees/costs use exact values; percent display rounds to two decimal places only at presentation. Tooltip gives numerator, denominator, period, exclusions and data-as-of. Do not expose a numeric percentage until UX-E04 agrees this contract. Until then show “Return calculation unavailable” while absolute P&L remains usable.

Example from Role 1: buy 2 FNC at SIM_INR 100, gross 200, fee 0.20, cost 200.20; sell 1 at 120, fee 0.12, net 119.88, allocated cost 100.10. Realized P&L is SIM_INR 19.78; the specified realized purchased-lot return is 19.76% after two-decimal rounding. Show losses symmetrically. This example is educational, not sample data substituted into a real portfolio.

Unknown-basis holdings remain in quantity totals, but affected P&L is unavailable with reason; known-basis P&L is explicitly partial. Test grant values do not become successful investment performance. Insufficient price history and missing current price never become zero-valued assets.

## 7. Wallet F-05, transfer F-06 and receive F-07

Wallet rows: FNC available/reserved and SIM_INR available/reserved; test network address; recent grants/transfers/fills. Request test credits or Request test FNC grant is deliberate and capped, with actual server operation/result. Exhausted cap displays next eligibility if server provides it. No real deposit or withdrawal button.

Transfer: own FNC wallet, recipient `fc_sbx_…` address, quantity to eight decimals, zero test transfer fee, review and authorization. Resolve network and recipient; reject BPI address with “This address belongs to BPI. Enter a FINCOIN test address.” No silent routing into a BPI transfer. Receipt labels “Test transfer confirmed” only after chain confirmation.

Receive: own FINCOIN test address, full copy/select, domain/network, optional address-only QR and “Send test FNC on this FINCHAIN network only.” An address QR contains no secret; it must not claim mainnet compatibility or a money deposit. If QR rendering is unavailable, selectable address remains. No seed/private-key export because this prototype uses service-held signing keys.

## 8. State and responsive requirements

Loading market and loading portfolio are independent. Feed unavailable disables new quote creation while allowing authenticated history and eligible non-price-dependent test transfers according to service state. Inventory exhaustion is an execution-availability message, not a red negative holding. Empty portfolio invites a capped test grant or learning flow; no prefilled profit.

Mobile order: simulator notice → holdings/current price → action tabs/form → quote review → chart → portfolio/history. All action sheets preserve full amount/fee and separate SIM_INR labels. Chart hover tooltips gain tap and accessible table alternatives. Persistent bottom Trade action navigates to form and never submits an order.

Acceptance covers long/fractional quantities, price decline, no basis, mixed grants/purchases, zero denominator, stale feed, quote expiry during MFA, insufficient credit, exhausted inventory, canceled/unknown order, successful fill with delayed portfolio, and complete FINCOIN operation with BPI offline.
