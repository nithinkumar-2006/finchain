# FINCHAIN — Database Architecture

Status: sandbox architecture v1.0. This document owns financial consistency contracts.

## 1. Databases and access

| Database | Contents | Writer roles |
|---|---|---|
| `identity_db` | Subjects, credentials, sessions, MFA, token grants | Identity only |
| `bpi_db` | BPI application, financial ledger, risk, private projections | BPI-specific roles with table-level grants |
| `fincoin_db` | FINCOIN application, test ledger, quotes, market, analytics | FINCOIN-specific roles |
| `gateway_sim_db` | Synthetic gateway operations and immutable statements | Simulator only |
| `explorer_bpi_db`, `explorer_fincoin_db` | Sanitized public projection | Respective projection writer; explorer reads only |

There are no cross-domain foreign keys, transactions, financial SQL joins, or shared wallet tables. Identity subject IDs are opaque references copied into each domain; domain membership determines financial authorization. Local databases may share a PostgreSQL server under separate roles. Application roles cannot create extensions, bypass row security, or become ledger/migration roles.

Within each financial database, separate `app`, `ledger`, `readmodel`, and `audit` schemas. API writes drafts/commands/application state. Ledger worker exclusively writes chain, journal, balance, nonce, hold and financial payment-state columns through owned operations. Use separate draft and financial-state tables to make column ownership unambiguous. Projection workers cannot write ledger tables. Migration role is offline outside deployments.

## 2. Logical entities

| Area | Tables and essential fields |
|---|---|
| Identity | `subjects(id,status)`, `credentials(subject_id,password_hash)`, `sessions(id,subject_id,family_id,expires_at,revoked_at)`, `refresh_tokens(token_hash,family_id,parent_id,used_at)`, `mfa_factors`, `recovery_codes`, `web_sessions` |
| Domain membership | `profiles(subject_id,status)`, `organizations(id,status)`, `memberships(subject_id,organization_id,role,permissions_version)`, `outlets` |
| Wallet | `wallets(id,owner_type,owner_id,currency,address,key_id,status)`, `wallet_state(wallet_id,next_nonce,version)`, `wallet_balances(wallet_id,settled_minor,pending_minor,held_minor,version)` |
| Payments | `payment_drafts(id,sender,receiver,amount_minor,currency,payment_type,payload_hash,expires_at,request_id)`, `authorizations(id,payload_hash,actor,permissions_version,expires_at)`, `payment_state(payment_id,business_status,chain_status,settlement_status,version)` |
| Reservations | `holds(id,payment_id,wallet_id,amount_minor,expires_at,status)`, `nonce_claims(wallet_id,nonce,payment_id,status)`, `limit_reservations` |
| Requests/refunds | `payment_requests(id,payee,amount_minor,expires_at,status,active_payment_id)`, `refunds(id,original_payment_id,refund_payment_id,amount_minor)`, `refund_totals(original_payment_id,reserved_minor,completed_minor)` |
| Accounting | `accounts(id,owner_ref,asset_code,account_class,normal_side)`, `journals(id,operation_id,event_type,created_at,reverses_journal_id)`, `journal_lines(journal_id,line_no,account_id,asset_code,side,amount_atomic)` |
| Chain | `chain_heads(network_id,height,block_hash,writer_epoch)`, `blocks(network_id,height,previous_hash,merkle_root,block_hash,writer_key_id,signature)`, `chain_transactions(transaction_id,transaction_hash,network_id,kind,payload,signature,nonce)`, `block_memberships(block_height,tx_index,transaction_hash)`, `journal_commitments(transaction_id,journal_id,commitment,salt_ref)` |
| Async | `commands(command_id,aggregate_id,payload_hash,status,lease_until,attempts,next_attempt_at)`, `outbox(event_id,aggregate_version,payload,published_at)`, `consumer_inbox(consumer,event_id,processed_at)` |
| Gateway | `gateway_operations(operation_id,payment_id,type,status,provider_ref,last_checked_at)`, `gateway_inbox(provider,event_id,body_hash,evidence,status)`, `reconciliation_runs`, `reconciliation_cases` |
| Risk/audit | `risk_decisions(payment_id,payload_hash,policy_version,score,outcome,expires_at)`, `risk_cases`, `audit_events(id,actor,action,resource_ref,reason,event_hash,previous_hash)` |
| Commerce | `products`, `inventory`, `inventory_reservations`, `carts`, `orders(id,total_minor,status)`, `order_items`, `invoices`, `fulfillments`, `disputes` |
| FINCOIN app | `asset_definitions`, `quotes`, `orders`, `fills`, `faucet_grants`, `market_ticks`, `candles`; separate domain copies of wallet/ledger/commands |
| FINCOIN analytics | `lots`, `lot_disposals`, `positions`, `portfolio_snapshots`, `analytics_checkpoints` |

All financial tables carry the network/environment or inherit it through an enforced foreign key; no row can target a different chain epoch accidentally. `created_at` and `occurred_at` use UTC `timestamptz`; ordering uses block height/index or aggregate sequence, not clock timestamps alone.

The wallet/balance columns above describe BPI's single-denomination wallet. FINCOIN instead uses `wallet_asset_balances(wallet_id,asset_code,available_atomic,reserved_atomic,version)` with one row per asset, while `wallet_state.next_nonce` applies to the wallet's outgoing commands across both assets. Its accounts and journals retain explicit asset codes. Do not create a single mixed-asset numeric balance. FINCOIN portfolio lots are private analytics; they are not BPI account or settlement records.

## 3. Exact value rules and constraints

Use `BIGINT` for BPI INR minor units with explicit business bounds below overflow. Use `NUMERIC(38,0)` for FINCOIN atomic units and SIM_INR minor units; calculate intermediate products with arbitrary precision. Wire values are canonical unsigned decimal strings with no signs, exponents, leading zeros except `0`, or decimal points. Debit/credit side supplies journal direction. Reject zero-value transfers, unsupported assets and excessive precision.

Require:

* Unique `(network_id, address)`, `transaction_hash`, `(network_id, block_height)`, `(network_id, block_height, tx_index)`, and one membership per transaction.
* Unique `(network_id, sender_wallet_id, nonce)` for included user transactions; system events use a separate issuer sequence.
* Partial uniqueness for one active hold per payment and one active nonce claim per wallet.
* Unique journal `operation_id` per domain; unique fill per order; unique gateway provider event and operation/result application.
* Unique `(principal_id, domain, route, idempotency_key)` with a stored request hash.
* Positive journal line amounts; line asset equals account asset; balanced debits/credits per asset per journal.
* `held_minor >= 0`, `settled_minor >= held_minor`, `pending_minor >= 0` for ordinary BPI wallets.
* Request active attempt and refund totals updated under locks with amount bounds.

A row `CHECK` cannot validate an aggregate journal sum. Enforce balance with a deferred constraint trigger and a restricted posting procedure, both in the same transaction; remove direct INSERT/UPDATE/DELETE grants for other roles. Ledger journals and blocks are append-only. Database superusers remain trusted; remote checkpoints and restricted credentials mitigate but do not eliminate that power.

## 4. Accounting model

BPI uses credit-normal wallet liabilities and a debit-normal synthetic gateway asset. These are simulation bookkeeping labels, not representations of audited real-world liabilities/assets.

| Operation | Debit | Credit |
|---|---|---|
| Sandbox funding success | Synthetic gateway asset | User settled liability |
| Payment inclusion | Sender settled liability | Receiver pending liability |
| Settlement success | Receiver pending liability | Receiver settled liability |
| Definitive settlement failure | Receiver pending liability | Sender settled liability |
| Redemption inclusion | User settled liability | Redemption pending liability |
| Redemption success | Redemption pending liability | Synthetic gateway asset |
| Redemption failure | Redemption pending liability | User settled liability |

Holds reduce available balance without moving settled liabilities. A payment inclusion consumes its hold and settled funds atomically. A refund is a new payment with reversed parties, not a mutation of the original lines. System corrections require explicit linked journals with reason and approvals. FINCOIN uses a distinct balanced subledger per asset with issuance contra accounts and simulator inventory accounts; [FINCOIN_ARCHITECTURE.md](FINCOIN_ARCHITECTURE.md) defines trading postings.

Accounting source of truth is journal lines. Balance rows are synchronous transactionally maintained projections for spending decisions; read models are asynchronous. The chain commits the transaction and salted journal digest in the same transaction. Replay needs authorized journal detail as well as headers; the redacted public chain alone cannot reconstruct private balances.

## 5. Transaction boundaries and concurrency

**Reservation transaction:** lock payment, sender wallet, relevant limit/request/refund rows in stable key order; verify authorization and expected version; establish nonce claim and hold; update balance/limit projections and state; emit reservation event. It does not write a financial journal because ownership has not moved.

**Block transaction:** acquire the network writer lock and current fencing epoch; lock candidate payments and affected accounts in deterministic order; revalidate each transaction and hold; append journal lines, update balances, consume nonces/holds, insert transactions and block, advance head, update business/settlement state, append audit/outbox records; commit together. Invalid candidates produce terminal rejection records with hold release and no financial inclusion. Build hashes/signatures from the final proposed contents before commit; signer failure rolls back.

**Settlement-result transaction:** lock operation and payment plus involved accounts, deduplicate result, append system transaction/journal/block and update wallet/payment atomically. Do not perform external HTTP inside a database transaction. Duplicate outcomes return the already-recorded result.

Use serializable transactions for financial posting and reservation, plus explicit row locks and uniqueness. Retry serialization/deadlock failures up to five times with jitter and the same operation ID; after exhaustion leave command retryable. PostgreSQL may abort serializable transactions, so retry the whole transaction, not its last SQL statement. See [PostgreSQL transaction isolation](https://www.postgresql.org/docs/18/transaction-iso.html). A writer epoch plus head compare-and-swap prevents two processes advancing the same head; Redis locks are not consensus or spending locks.

## 6. Durable messaging and recovery

PostgreSQL command and outbox tables are the queue of record. Workers lease jobs with `FOR UPDATE SKIP LOCKED`, a bounded lease and heartbeat. Expired leases allow retry. Every job checks its durable operation result before mutating. Outbox events may be delivered more than once if a worker crashes after sending and before marking delivery. Consumers atomically record `(consumer,event_id)` and their projection/application effect.

An event envelope includes `schema_version`, `domain`, `environment`, `network_id`, `event_id`, `aggregate_id`, `aggregate_version`, `correlation_id`, `causation_id`, `occurred_at`, and a minimal payload. Consumers detect sequence gaps, park out-of-order events, and recover from the authoritative stream. Events contain references rather than unnecessary profile/financial details. Retain durable operation uniqueness beyond API idempotency response-cache expiry.

## 7. Querying, partitioning, and retention

Index payment history by `(owner_ref,created_at DESC,id DESC)`, merchant history by `(organization_id,status,created_at,id)`, unsettled operations by `(status,next_attempt_at)`, commands by `(status,next_attempt_at)`, and transactions by hash/height. Use keyset pagination with stable tie breakers. Never authorize payments from a read replica.

Start with ordinary tables. Partition high-volume audit/events/history by month once measured need justifies it; ensure deduplication uniqueness is preserved with an unpartitioned key registry where global constraints would otherwise be lost. Retain financial journals, blocks and operation IDs for the sandbox epoch and its declared archival period. Suggested prototype policy: 30 days debug logs, 90 days risk raw signals, 180 days audit exports, 90 days archived sandbox epochs. These are configurable project defaults, not legal retention claims; reconcile them with privacy commitments before collecting real personal data.

Encrypted point-in-time backups must cover the entire domain database so blocks and journals restore together. Snapshot manifests record schema version, network ID, chain head and accounting totals. Rebuild projections from domain events/journals with checkpoints; verify balances against replay before reopening writes. Back up encrypted journal commitment salts and signing-key metadata under separate access control so private evidence remains verifiable.

## 8. Database acceptance checks

Property tests generate random funding/transfers/returns/redemptions and prove journal balance, nonnegative spendable funds and supply conservation. Concurrency tests race reservations, QR claims, refunds, nonce use and settlement retries. Fault tests kill workers before/after commit and after gateway submission. A full replay must match all balance projections and chain roots. Restore testing must prove unresolved external operations are queried before any resubmission can create new value.
