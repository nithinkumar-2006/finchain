import secrets
import uuid
from contextlib import contextmanager
from collections import defaultdict
from sqlalchemy import create_engine, select, func, event, text
from sqlalchemy.orm import sessionmaker
from .storage import (Base, Network, Subject, Principal, Validator, Head, Wallet, Account, Balance, Hold,
                      Operation, Idempotency, Command, Authorization, Journal, JournalLine, Block,
                      ChainTransaction, Outbox, Audit, AuditHead, DomainGrant, utcnow)
from .protocol import (ZERO, address, canonical, sha, wire_time, commitment, merkle_root, merkle_proof,
                       verify_block, verify_signature, sign_payload, integer)
from .signing import Envelope


class RuleViolation(Exception):
    def __init__(self, code, status=409):
        self.code, self.status = code, status


class Store:
    def __init__(self, settings, signer=None):
        self.settings, self.signer = settings, signer
        options = {"hide_parameters": True, "pool_pre_ping": True}
        if not settings.test_mode and settings.role in {"ledger", "bootstrap"}:
            options["isolation_level"] = "SERIALIZABLE"
        if settings.test_mode and settings.database_url.startswith("sqlite"):
            options.update(execution_options={"schema_translate_map": {s: None for s in ("core", "ledger", "ops", "app", "audit", "readmodel")}}, connect_args={"check_same_thread": False})
        self.engine = create_engine(settings.database_url, **options)
        if self.engine.dialect.name == "sqlite":
            @event.listens_for(self.engine, "connect")
            def fk(connection, _):
                connection.execute("PRAGMA foreign_keys=ON")
        self.session_factory = sessionmaker(self.engine, expire_on_commit=False)
        self.envelope = Envelope(settings.encryption_key)

    def schema_tables(self):
        from .storage import COMMON_TABLES
        if self.settings.domain == "BPI":
            from .bpi_models import BPI_TABLES
            extra = BPI_TABLES
        else:
            from .fincoin_models import FINCOIN_TABLES
            extra = FINCOIN_TABLES
        return [Base.metadata.tables[name] for name in COMMON_TABLES] + list(extra)

    @contextmanager
    def transaction(self):
        with self.session_factory.begin() as db:
            yield db

    def network(self, db, lock=False):
        query = select(Network).where(Network.network_code == self.settings.network_code)
        network = db.scalar(query.with_for_update() if lock else query)
        if not network or network.domain != self.settings.domain or network.environment != "sandbox":
            raise RuleViolation("NETWORK_NOT_INITIALIZED", 503)
        return network

    def writer(self, db):
        if self.settings.role not in {"ledger", "bootstrap"}:
            raise RuleViolation("LEDGER_WRITER_REQUIRED", 403)
        network = self.network(db)
        head = db.scalar(select(Head).where(Head.network_id == network.id).with_for_update())
        if not head:
            raise RuleViolation("CHAIN_HEAD_MISSING", 503)
        if self.settings.role == "ledger" and (not hasattr(self, "writer_epoch") or head.writer_epoch != self.writer_epoch):
            raise RuleViolation("STALE_WRITER_EPOCH", 503)
        return network, head

    def sync_subject(self, db, principal):
        sid = uuid.UUID(principal["id"])
        insert = __import__("sqlalchemy.dialects."+self.engine.dialect.name, fromlist=["insert"]).insert
        db.execute(insert(Subject).values(id=sid, status="ACTIVE", credentials_version=principal["credentials_version"], label="Sandbox participant", created_at=utcnow()).on_conflict_do_nothing(index_elements=["id"]))
        user = db.scalar(select(Subject).where(Subject.id == sid).with_for_update())
        user.credentials_version = principal["credentials_version"]
        if user.status != "ACTIVE":
            raise RuleViolation("SUBJECT_DISABLED", 403)
        owner = db.scalar(select(Principal).where(Principal.subject_id == sid))
        if owner is None:
            owner = Principal(id=uuid.uuid4(), subject_id=sid, kind="USER")
            db.add(owner)
            db.flush()
        return user, owner

    def audit(self, db, action, result, actor=None, operation=None):
        head = db.scalar(select(AuditHead).where(AuditHead.stream == "domain").with_for_update())
        if head is None:
            raise RuleViolation("AUDIT_UNAVAILABLE", 503)
        record_id, timestamp = uuid.uuid4(), utcnow()
        value = sha(canonical({"id": str(record_id), "actor": str(actor) if actor else None, "operation": str(operation) if operation else None,
                               "action": action, "result": result, "timestamp": wire_time(timestamp), "previous_hash": head.head}))
        db.add(Audit(id=record_id, created_at=timestamp, actor_id=actor, operation_id=operation, action=action, result=result, previous_hash=head.head, event_hash=value))
        head.head = value
        db.flush()

    def operation(self, db, kind, actor=None, parent=None, slot=None):
        if parent:
            found = db.scalar(select(Operation).where(Operation.parent_id == parent, Operation.slot == slot))
            if found:
                return found
        operation = Operation(id=uuid.uuid5(parent, str(slot)) if parent else uuid.uuid4(), network_id=self.network(db).id, kind=kind, actor_id=actor, parent_id=parent, slot=slot)
        if parent:
            operation.created_at = db.get(Operation, parent).created_at
        db.add(operation)
        db.flush()
        return operation

    def idempotent(self, db, subject, route, key, payload, create):
        key = uuid.UUID(str(key))
        fingerprint = sha(canonical(payload))
        # Caller holds subject lock, including for first-time keys.
        existing = db.scalar(select(Idempotency).where(Idempotency.subject_id == subject.id, Idempotency.route == route, Idempotency.key == key))
        if existing:
            if existing.request_digest != fingerprint:
                raise RuleViolation("IDEMPOTENCY_CONFLICT")
            return existing.response
        operation = self.operation(db, route.upper().replace("/", "_")[:32], subject.id)
        response = create(operation)
        db.add(Idempotency(subject_id=subject.id, route=route, key=key, request_digest=fingerprint, operation_id=operation.id, response=response))
        self.audit(db, route, "ACCEPTED", subject.id, operation.id)
        return response

    def account(self, db, network_id, wallet_id, asset, bucket, normal="CREDIT"):
        code = f"{wallet_id or 'system'}:{asset}:{bucket}"
        row = db.scalar(select(Account).where(Account.network_id == network_id, Account.account_code == code))
        if row is None:
            row = Account(id=uuid.uuid5(network_id, code), network_id=network_id, wallet_id=wallet_id, asset_code=asset, bucket=bucket, account_code=code, normal_side=normal)
            db.add(row)
            db.flush()
            db.add(Balance(account_id=row.id, amount=0))
            db.flush()
        return row

    def create_wallet(self, db, owner_id, label):
        network, _ = self.writer(db)
        existing = db.scalar(select(Wallet).where(Wallet.network_id == network.id, Wallet.owner_id == owner_id))
        if existing:
            return existing
        key_id = uuid.uuid4()
        public = self.signer.public_key(key_id)
        row = Wallet(id=uuid.uuid4(), network_id=network.id, owner_id=owner_id, address=address(public, network.domain), public_key=public, key_id=key_id, label=label)
        db.add(row)
        db.flush()
        for asset in network.policy["assets"]:
            for bucket in ("SETTLED", "PENDING"):
                self.account(db, network.id, row.id, asset, bucket)
        return row

    def wallet_values(self, db, wallet):
        assets = self.network(db).policy["assets"]
        result = {}
        for asset in assets:
            balances = dict(db.execute(select(Account.bucket, Balance.amount).join(Balance, Balance.account_id == Account.id).where(Account.wallet_id == wallet.id, Account.asset_code == asset)).all())
            held = int(db.scalar(select(func.coalesce(func.sum(Hold.amount), 0)).where(Hold.wallet_id == wallet.id, Hold.asset_code == asset, Hold.status == "ACTIVE")) or 0)
            settled, pending = int(balances.get("SETTLED", 0)), int(balances.get("PENDING", 0))
            result[asset] = {"settled": str(settled), "pending": str(pending), "held": str(held), "available": str(settled-held)}
        return result

    def post(self, db, operation, kind, lines, signed=None, sender=None):
        network, head = self.writer(db)
        old = db.scalar(select(Journal).where(Journal.operation_id == operation.id))
        if old:
            return db.scalar(select(ChainTransaction).where(ChainTransaction.journal_id == old.id))
        totals, normalized = defaultdict(int), []
        for account, side, amount in lines:
            if amount <= 0 or amount > 10**38-1 or account.network_id != network.id or account.asset_code not in network.policy["assets"] or side not in {"DEBIT", "CREDIT"}:
                raise RuleViolation("INVALID_JOURNAL")
            totals[account.asset_code] += amount if side == "DEBIT" else -amount
            normalized.append({"account_id": str(account.id), "asset": account.asset_code, "side": side, "amount": str(amount)})
        if not lines or any(totals.values()):
            raise RuleViolation("UNBALANCED_JOURNAL")
        balances = {b.account_id: b for b in db.scalars(select(Balance).where(Balance.account_id.in_([a.id for a, _, _ in lines])).order_by(Balance.account_id).with_for_update())}
        deltas = defaultdict(int)
        for account, side, amount in lines:
            deltas[account.id] += amount if side == account.normal_side else -amount
        if any(int(balances[aid].amount) + delta < 0 for aid, delta in deltas.items()):
            raise RuleViolation("INSUFFICIENT_BALANCE")
        journal = Journal(id=uuid.uuid5(operation.id, "journal"), operation_id=operation.id, network_id=network.id, kind=kind)
        db.add(journal)
        db.flush()
        for i, (account, side, amount) in enumerate(lines, 1):
            db.add(JournalLine(journal_id=journal.id, line_no=i, network_id=network.id, account_id=account.id, asset_code=account.asset_code, side=side, amount=amount))
        for aid, delta in deltas.items():
            balances[aid].amount = int(balances[aid].amount) + delta
            balances[aid].version += 1
        validator = db.get(Validator, head.validator_id)
        if not validator.active:
            raise RuleViolation("PRODUCER_INACTIVE", 503)
        if signed is None:
            payload = {"protocol_version": "1", "domain": network.domain, "environment": "sandbox", "network_id": network.network_code,
                       "kind": kind, "issuer_id": str(validator.id), "operation_id": str(operation.id),
                       "journal_id": str(journal.id), "timestamp": wire_time(operation.created_at), "journal_digest": sha(canonical(normalized))}
            signed = {**self.signer.transaction(validator.id, payload), "payload": payload, "public_key": validator.public_key}
        verify_signature(signed["public_key"], signed["payload"], signed["signature"], signed["transaction_hash"])
        salt = secrets.token_bytes(32)
        jc = commitment(normalized, salt)
        body = [(signed["transaction_hash"], jc)]
        header = {"protocol_version": "1", "network_id": network.network_code, "height": str(head.height+1), "previous_hash": head.block_hash,
                  "timestamp": wire_time(), "merkle_root": merkle_root(body), "transaction_count": "1", "writer_epoch": str(head.writer_epoch), "validator_key_id": str(validator.id)}
        bh, bs = self.signer.block(validator.id, header)
        verify_block(validator.public_key, header, body, bh, bs, head.block_hash, head.height+1)
        block = Block(id=uuid.uuid4(), network_id=network.id, height=head.height+1, block_hash=bh, header=header, signature=bs, validator_id=validator.id)
        db.add(block)
        db.flush()
        txid = uuid.uuid4()
        tx = ChainTransaction(id=txid, network_id=network.id, block_id=block.id, tx_index=0, journal_id=journal.id,
            transaction_hash=signed["transaction_hash"], payload=signed["payload"], signature=signed["signature"], public_key=signed["public_key"],
            journal_commitment=jc, salt_ciphertext=self.envelope.encrypt(f"journal:{txid}:salt", salt),
            sender_wallet_id=sender.id if sender else None, nonce=sender.next_nonce if sender else None)
        db.add(tx)
        if sender:
            sender.next_nonce += 1
        head.height, head.block_hash = block.height, bh
        validator.last_heartbeat = utcnow()
        db.add(Outbox(operation_id=operation.id, event_type="ledger.committed", payload={"block_id": str(block.id), "height": str(block.height)}))
        self.audit(db, kind, "COMMITTED", operation.actor_id, operation.id)
        db.flush()
        return tx

    def initialize(self, policy, activate=True):
        if self.settings.role != "bootstrap":
            raise RuleViolation("BOOTSTRAP_REQUIRED", 403)
        with self.transaction() as db:
            existing = db.scalar(select(Network).where(Network.network_code == self.settings.network_code))
            if existing:
                if existing.policy != policy:
                    raise RuleViolation("GENESIS_POLICY_MISMATCH")
                return existing.id
            network = Network(id=uuid.uuid4(), network_code=self.settings.network_code, domain=self.settings.domain, policy=policy)
            db.add(network)
            db.add(AuditHead(stream="domain"))
            db.flush()
            validator_id = uuid.uuid4()
            validator = Validator(id=validator_id, network_id=network.id, public_key=self.signer.public_key(validator_id), key_handle=str(validator_id), active=True)
            db.add(validator)
            db.flush()
            header = {"protocol_version": "1", "network_id": network.network_code, "height": "0", "previous_hash": ZERO,
                      "timestamp": wire_time(), "merkle_root": merkle_root([]), "transaction_count": "0", "writer_epoch": "1", "validator_key_id": str(validator_id),
                      "policy_commitment": sha(canonical(policy))}
            bh, bs = self.signer.block(validator_id, header)
            db.add(Block(network_id=network.id, height=0, block_hash=bh, header=header, signature=bs, validator_id=validator.id))
            db.add(Head(network_id=network.id, height=0, block_hash=bh, writer_epoch=1, validator_id=validator.id))
            network.status = "ACTIVE" if activate else "INITIALIZING"
            self.audit(db, "network.initialize", "COMMITTED")
            return network.id

    def validate_chain(self):
        with self.transaction() as db:
            network = self.network(db)
            previous, replay, count = ZERO, defaultdict(int), 0
            nonces = defaultdict(int)
            blocks = db.scalars(select(Block).where(Block.network_id == network.id).order_by(Block.height)).all()
            for height, block in enumerate(blocks):
                rows = db.scalars(select(ChainTransaction).where(ChainTransaction.block_id == block.id).order_by(ChainTransaction.tx_index)).all()
                body = [(r.transaction_hash, r.journal_commitment) for r in rows]
                validator = db.get(Validator, block.validator_id)
                if block.header["network_id"] != network.network_code or block.height != height or validator.network_id != network.id:
                    raise RuleViolation("BLOCK_NETWORK_MISMATCH")
                if height == 0 and block.header.get("policy_commitment") != sha(canonical(network.policy)):
                    raise RuleViolation("GENESIS_POLICY_MISMATCH")
                verify_block(validator.public_key, block.header, body, block.block_hash, block.signature, previous, height)
                for tx in rows:
                    if tx.network_id != network.id or tx.payload.get("network_id") != network.network_code or tx.payload.get("domain") != network.domain or tx.payload.get("environment") != "sandbox":
                        raise RuleViolation("TRANSACTION_NETWORK_MISMATCH")
                    verify_signature(tx.public_key, tx.payload, tx.signature, tx.transaction_hash)
                    if tx.sender_wallet_id:
                        wallet = db.get(Wallet, tx.sender_wallet_id)
                        if tx.nonce != nonces[wallet.id] or tx.payload.get("nonce") != str(tx.nonce) or tx.public_key != wallet.public_key or tx.payload.get("sender_address", tx.payload.get("wallet_address")) != wallet.address or tx.payload.get("key_id") != str(wallet.key_id):
                            raise RuleViolation("NONCE_OR_KEY_REPLAY_MISMATCH")
                        nonces[wallet.id] += 1
                    elif tx.public_key != validator.public_key:
                        raise RuleViolation("SYSTEM_ISSUER_MISMATCH")
                    lines = db.scalars(select(JournalLine).where(JournalLine.journal_id == tx.journal_id).order_by(JournalLine.line_no)).all()
                    normalized = []
                    totals = defaultdict(int)
                    for line in lines:
                        account = db.get(Account, line.account_id)
                        amount = int(line.amount)
                        totals[line.asset_code] += amount if line.side == "DEBIT" else -amount
                        replay[line.account_id] += amount if line.side == account.normal_side else -amount
                        normalized.append({"account_id": str(line.account_id), "asset": line.asset_code, "side": line.side, "amount": str(amount)})
                    if not lines or any(totals.values()) or commitment(normalized, self.envelope.decrypt(f"journal:{tx.id}:salt", tx.salt_ciphertext)) != tx.journal_commitment:
                        raise RuleViolation("JOURNAL_PROOF_INVALID")
                    count += 1
                previous = block.block_hash
            for balance in db.scalars(select(Balance)):
                if replay[balance.account_id] != int(balance.amount):
                    raise RuleViolation("BALANCE_REPLAY_MISMATCH")
            for wallet in db.scalars(select(Wallet)):
                if wallet.next_nonce != nonces[wallet.id]:
                    raise RuleViolation("NONCE_REPLAY_MISMATCH")
            head = db.scalar(select(Head).where(Head.network_id == network.id))
            if head.block_hash != previous or head.height != len(blocks)-1:
                raise RuleViolation("HEAD_MISMATCH")
            return {"valid": True, "blocks": len(blocks), "transactions": count, "head": previous, "environment": "sandbox"}
