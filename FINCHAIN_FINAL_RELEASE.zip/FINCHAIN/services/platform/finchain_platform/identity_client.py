import httpx
from urllib.parse import urlsplit
from .ledger import RuleViolation


class IdentityClient:
    def __init__(self, settings):
        self.settings = settings
    def validate(self, payload):
        try:
            with httpx.Client(timeout=5, trust_env=False) as client:
                response = client.post(self.settings.identity_url+"/internal/v1/validate", json=payload,
                    headers={"Host": urlsplit(self.settings.origin).netloc, "X-Service-Domain": self.settings.domain, "X-Service-Key": self.settings.service_secret})
        except httpx.HTTPError:
            raise RuleViolation("IDENTITY_UNAVAILABLE", 503) from None
        if response.status_code >= 500:
            raise RuleViolation("IDENTITY_UNAVAILABLE", 503)
        if response.status_code != 200:
            try:
                code = response.json().get("code", "INVALID_SESSION")
            except ValueError:
                code = "INVALID_SESSION"
            raise RuleViolation(code, 401)
        return response.json()
    def browser(self, request):
        return self.validate({"browser_cookie": request.cookies.get("__Host-finchain-session", ""),
                              "csrf_token": request.headers.get("x-csrf-token"), "mutation": request.method not in {"GET", "HEAD"}})
    def grant(self, subject, session, version):
        return self.validate({"subject_id": str(subject), "session_id": str(session) if session else None, "credentials_version": version})
