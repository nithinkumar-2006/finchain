"""Private signer adapters. File-derived sandbox keys must stay in the signer process."""
import secrets
import httpx
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from .protocol import sign_payload, sign_block


class Envelope:
    def __init__(self, key):
        self._key = key
    def encrypt(self, context, raw):
        nonce = secrets.token_bytes(12)
        return b"\x01" + nonce + AESGCM(self._key).encrypt(nonce, raw, context.encode())
    def decrypt(self, context, data):
        if data[:1] != b"\x01":
            raise ValueError("Unknown key version")
        return AESGCM(self._key).decrypt(data[1:13], data[13:], context.encode())


class SandboxSigner:
    def __init__(self, master, network):
        if len(master) != 32:
            raise ValueError("Independent 256-bit signer master required")
        self._master, self.network = master, network
    def _key(self, handle):
        seed = HKDF(algorithm=hashes.SHA256(), length=32, salt=None, info=("FINCHAIN:KEY:v1:"+self.network+":"+str(handle)).encode()).derive(self._master)
        return Ed25519PrivateKey.from_private_bytes(seed)
    def public_key(self, handle):
        return self._key(handle).public_key().public_bytes_raw()
    def transaction(self, handle, payload):
        if payload["network_id"] != self.network:
            raise ValueError("Signer network mismatch")
        return sign_payload(self._key(handle), payload)
    def block(self, handle, header):
        if header["network_id"] != self.network:
            raise ValueError("Signer network mismatch")
        return sign_block(self._key(handle), header)


class RemoteSigner:
    def __init__(self, url, secret):
        self._url, self._secret = url, secret
    def _request(self, route, payload):
        with httpx.Client(timeout=5, trust_env=False) as client:
            result = client.post(self._url + route, json=payload, headers={"X-Service-Key": self._secret})
            result.raise_for_status()
            return result.json()
    def public_key(self, handle):
        return bytes.fromhex(self._request("/public-key", {"handle": str(handle)})["public_key"])
    def transaction(self, handle, payload):
        return self._request("/transaction", {"handle": str(handle), "payload": payload})
    def block(self, handle, header):
        value = self._request("/block", {"handle": str(handle), "header": header})
        return value["block_hash"], value["signature"]
