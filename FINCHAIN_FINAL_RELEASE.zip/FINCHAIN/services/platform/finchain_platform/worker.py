import hashlib
import hmac
import logging
import os
import time
import uuid
from pathlib import Path
import httpx
from sqlalchemy import select, text, case
from sqlalchemy.exc import OperationalError
from .config import DomainSettings
from .storage import Head, Command, Operation, utcnow
from .ledger import RuleViolation
from .signing import RemoteSigner
from .identity_client import IdentityClient
from .protocol import canonical

logger = logging.getLogger("finchain.worker")


class Worker:
    def __init__(self, store, identity, gateway=None, gateway_key=None, gateway_secret=None):
        self.store, self.identity = store, identity
        self.gateway, self._gateway_key, self._gateway_secret = gateway, gateway_key, gateway_secret
        self.lease = None

    def acquire(self):
        if self.store.engine.dialect.name == "postgresql":
            lock_id = int.from_bytes(hashlib.sha256(self.store.settings.network_code.encode()).digest()[:8], "big", signed=True)
            self.lease = self.store.engine.connect()
            if not self.lease.scalar(text("SELECT pg_try_advisory_lock(:key)"), {"key": lock_id}):
                raise RuntimeError("Another domain ledger writer is active")
            self.lease.commit()
        with self.store.transaction() as db:
            network = self.store.network(db)
            head = db.scalar(select(Head).where(Head.network_id == network.id).with_for_update())
            head.writer_epoch += 1
            self.store.writer_epoch = head.writer_epoch

    def fail_command(self, command_id, code):
        with self.store.transaction() as db:
            _, _ = self.store.writer(db)
            command = db.scalar(select(Command).where(Command.id == command_id).with_for_update())
            if not command or command.state != "QUEUED": return
            command.state, command.error_code = "REJECTED", code
            operation = db.get(Operation, command.operation_id)
            if self.store.settings.domain == "BPI" and command.kind == "PAYMENT":
                from .bpi_models import PaymentState
                state = db.scalar(select(PaymentState).where(PaymentState.payment_id == uuid.UUID(command.payload["payment_id"])))
                if state is None:
                    state = PaymentState(payment_id=uuid.UUID(command.payload["payment_id"]))
                    db.add(state)
                state.business_status, state.chain_status, state.reason_code = "REJECTED", "REJECTED", code
            if self.store.settings.domain == "FINCOIN":
                from .fincoin_models import FincoinOrder, AssetTransfer, Grant
                if command.kind == "FILL":
                    order = db.get(FincoinOrder, uuid.UUID(command.payload["order_id"]))
                    order.status, order.reason_code = "REJECTED", code
                elif command.kind == "TRANSFER":
                    db.get(AssetTransfer, uuid.UUID(command.payload["transfer_id"])).status = "REJECTED"
                elif command.kind == "GRANT":
                    db.get(Grant, uuid.UUID(command.payload["grant_id"])).status = "REJECTED"
            self.store.audit(db, "command.reject", code, operation.actor_id, operation.id)

    def step(self):
        if self.lease:
            self.lease.exec_driver_sql("SELECT 1")
        with self.store.transaction() as db:
            command_id = db.scalar(select(Command.id).where(Command.state == "QUEUED", Command.next_attempt_at <= utcnow()).order_by(case((Command.kind == "ADMIN", 0), else_=1), Command.created_at, Command.id).limit(1))
        if command_id:
            for attempt in range(5):
                try:
                    self.store.process_command(command_id, self.identity.grant)
                    break
                except OperationalError as exc:
                    if getattr(exc.orig, "sqlstate", None) not in {"40001", "40P01"} or attempt == 4: raise
                    time.sleep(0.03*(attempt+1))
                except RuleViolation as exc:
                    if exc.status >= 500: raise
                    self.fail_command(command_id, exc.code)
                    break
                except ValueError:
                    self.fail_command(command_id, "TRANSACTION_VALIDATION_FAILED")
                    break
        if self.store.settings.domain == "BPI":
            self.settle_step()
            self.expire_orders()
            from .integrations import Integrations
            integrations = Integrations(self.store)
            integrations.queue_events()
            integrations.deliver()
        else:
            self.store.add_tick()

    def settle_step(self):
        from .bpi_models import Settlement
        with self.store.transaction() as db:
            settlement = db.scalar(select(Settlement).where(Settlement.result_applied_at.is_(None), Settlement.next_check_at <= utcnow()).order_by(Settlement.next_check_at, Settlement.created_at).limit(1))
        if not settlement or not self.gateway:
            return
        payload = {"operation_id": str(settlement.operation_id), "network_id": self.store.settings.network_code, "amount_minor": str(settlement.amount), "currency": "INR",
                   "environment": "sandbox", "kind": settlement.kind, "scenario": settlement.scenario}
        with httpx.Client(timeout=5, trust_env=False) as client:
            response = client.post(self.gateway+"/operations", json=payload, headers={"X-Service-Key": self._gateway_secret})
            response.raise_for_status()
            received = response.json()
        expected = hmac.new(self._gateway_key, canonical(received["evidence"]), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(received.get("signature", ""), expected):
            raise RuleViolation("GATEWAY_SIGNATURE_INVALID", 503)
        self.store.apply_gateway_result(settlement.id, received["evidence"])

    def expire_orders(self):
        from .bpi_models import CommerceOrder, OrderItem, Product, PaymentRequest
        with self.store.transaction() as db:
            self.store.writer(db)
            orders = db.scalars(select(CommerceOrder).where(CommerceOrder.status == "PAYMENT_PENDING", CommerceOrder.reservation_expires_at <= utcnow()).with_for_update().limit(20)).all()
            for order in orders:
                for item in db.scalars(select(OrderItem).where(OrderItem.order_id == order.id)):
                    product = db.scalar(select(Product).where(Product.id == item.product_id).with_for_update())
                    product.stock += item.quantity
                order.status = "EXPIRED"
                request = db.scalar(select(PaymentRequest).where(PaymentRequest.order_id == order.id))
                if request and request.status == "OPEN": request.status = "EXPIRED"
                self.store.audit(db, "commerce.reservation", "EXPIRED", order.buyer_id, order.operation_id)


def main():
    logging.basicConfig(level=logging.INFO, format='{"level":"%(levelname)s","event":"%(message)s"}')
    settings = DomainSettings.from_env()
    if settings.role != "ledger":
        raise ValueError("Worker requires SERVICE_ROLE=ledger")
    signer = RemoteSigner(settings.signer_url, Path(os.environ["SIGNER_SERVICE_KEY_FILE"]).read_text().strip())
    if settings.domain == "BPI":
        from .bpi import BPI
        store = BPI(settings, signer)
    else:
        from .fincoin import FINCOIN
        store = FINCOIN(settings, signer)
    worker = Worker(store, IdentityClient(settings), settings.gateway_url,
                    Path(os.environ["GATEWAY_SIGNING_KEY_FILE"]).read_bytes() if settings.domain == "BPI" else None,
                    Path(os.environ["GATEWAY_SERVICE_KEY_FILE"]).read_text().strip() if settings.domain == "BPI" else None)
    worker.acquire()
    while True:
        try:
            worker.step()
        except Exception:
            # No exception/request/locals dump: even infrastructure errors can contain secrets.
            logger.error("domain_worker_step_failed")
        time.sleep(1)


if __name__ == "__main__":
    main()
