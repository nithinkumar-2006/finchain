"""Neutral ledger/storage primitives instantiated in separate financial databases.

There is no connection, table or balance shared between BPI and FINCOIN.
"""
import uuid
from datetime import datetime, timezone
from sqlalchemy import (Column, Uuid, String, Integer, BigInteger, Numeric, Boolean, LargeBinary, JSON, DateTime,
                        ForeignKey, ForeignKeyConstraint, UniqueConstraint, CheckConstraint, Index, MetaData)
from sqlalchemy.orm import declarative_base
from sqlalchemy.types import TypeDecorator


def utcnow():
    return datetime.now(timezone.utc)


class UTC(TypeDecorator):
    impl = DateTime(timezone=True)
    cache_ok = True
    def process_bind_param(self, value, dialect):
        if value is not None and value.tzinfo is None:
            raise ValueError("UTC timezone required")
        return value
    def process_result_value(self, value, dialect):
        return value.replace(tzinfo=timezone.utc) if value is not None and value.tzinfo is None else value


Base = declarative_base(metadata=MetaData())
Q = Numeric(38, 0)


class Record:
    id = Column(Uuid, primary_key=True, default=uuid.uuid4)
    created_at = Column(UTC, nullable=False, default=utcnow)


class Network(Record, Base):
    __tablename__ = "networks"
    __table_args__ = (CheckConstraint("domain IN ('BPI','FINCOIN') AND environment = 'sandbox'", name="sandbox_domain"), {"schema": "core"})
    network_code = Column(String(80), nullable=False, unique=True)
    domain = Column(String(8), nullable=False)
    environment = Column(String(8), nullable=False, default="sandbox")
    policy = Column(JSON, nullable=False)
    status = Column(String(16), nullable=False, default="INITIALIZING")


class Subject(Record, Base):
    __tablename__ = "subjects"
    __table_args__ = {"schema": "core"}
    status = Column(String(16), nullable=False, default="ACTIVE")
    credentials_version = Column(Integer, nullable=False)
    label = Column(String(80), nullable=False, default="Sandbox participant")


class Principal(Record, Base):
    __tablename__ = "principals"
    __table_args__ = (CheckConstraint("kind IN ('USER','ORGANIZATION','SERVICE')", name="principal_kind"), {"schema": "core"})
    subject_id = Column(Uuid, ForeignKey("core.subjects.id"), unique=True)
    service_code = Column(String(32), unique=True)
    kind = Column(String(16), nullable=False)


class Validator(Record, Base):
    __tablename__ = "validators"
    __table_args__ = {"schema": "core"}
    network_id = Column(Uuid, ForeignKey("core.networks.id"), nullable=False, index=True)
    public_key = Column(LargeBinary, nullable=False)
    key_handle = Column(String(80), nullable=False, unique=True)
    active = Column(Boolean, nullable=False, default=True)
    valid_from_height = Column(BigInteger, nullable=False, default=0)
    last_heartbeat = Column(UTC)


class Head(Record, Base):
    __tablename__ = "chain_heads"
    __table_args__ = {"schema": "ledger"}
    network_id = Column(Uuid, ForeignKey("core.networks.id"), nullable=False, unique=True)
    height = Column(BigInteger, nullable=False, default=-1)
    block_hash = Column(String(64), nullable=False, default="0"*64)
    writer_epoch = Column(BigInteger, nullable=False, default=0)
    validator_id = Column(Uuid, ForeignKey("core.validators.id"), nullable=False)


class Wallet(Record, Base):
    __tablename__ = "wallets"
    __table_args__ = (UniqueConstraint("network_id", "owner_id"), UniqueConstraint("id", "network_id"), CheckConstraint("next_nonce >= 0", name="wallet_nonce"), {"schema": "ledger"})
    network_id = Column(Uuid, ForeignKey("core.networks.id"), nullable=False)
    owner_id = Column(Uuid, ForeignKey("core.principals.id"), nullable=False, index=True)
    address = Column(String(100), nullable=False, unique=True)
    public_key = Column(LargeBinary, nullable=False)
    key_id = Column(Uuid, nullable=False, unique=True)
    status = Column(String(16), nullable=False, default="ACTIVE")
    next_nonce = Column(BigInteger, nullable=False, default=0)
    label = Column(String(80), nullable=False, default="Sandbox wallet")


class Account(Record, Base):
    __tablename__ = "accounts"
    __table_args__ = (UniqueConstraint("network_id", "account_code"), UniqueConstraint("id", "asset_code", "network_id"),
        ForeignKeyConstraint(["wallet_id", "network_id"], ["ledger.wallets.id", "ledger.wallets.network_id"]),
        CheckConstraint("normal_side IN ('DEBIT','CREDIT')", name="account_side"), {"schema": "ledger"})
    network_id = Column(Uuid, ForeignKey("core.networks.id"), nullable=False)
    wallet_id = Column(Uuid, index=True)
    asset_code = Column(String(16), nullable=False)
    bucket = Column(String(16), nullable=False)
    account_code = Column(String(120), nullable=False)
    normal_side = Column(String(6), nullable=False, default="CREDIT")


class Balance(Record, Base):
    __tablename__ = "balances"
    __table_args__ = (CheckConstraint("amount >= 0", name="nonnegative_balance"), {"schema": "ledger"})
    account_id = Column(Uuid, ForeignKey("ledger.accounts.id"), nullable=False, unique=True)
    amount = Column(Q, nullable=False, default=0)
    version = Column(BigInteger, nullable=False, default=0)


class Hold(Record, Base):
    __tablename__ = "holds"
    __table_args__ = (CheckConstraint("amount > 0", name="positive_hold"), {"schema": "ledger"})
    wallet_id = Column(Uuid, ForeignKey("ledger.wallets.id"), nullable=False, index=True)
    operation_id = Column(Uuid, ForeignKey("ops.operations.id"), nullable=False, unique=True)
    asset_code = Column(String(16), nullable=False)
    amount = Column(Q, nullable=False)
    nonce = Column(BigInteger, nullable=False)
    expires_at = Column(UTC, nullable=False)
    status = Column(String(16), nullable=False, default="ACTIVE")


Index("one_active_wallet_hold", Hold.wallet_id, unique=True, postgresql_where=Hold.status == "ACTIVE", sqlite_where=Hold.status == "ACTIVE")


class Operation(Record, Base):
    __tablename__ = "operations"
    __table_args__ = (UniqueConstraint("parent_id", "slot"), {"schema": "ops"})
    network_id = Column(Uuid, ForeignKey("core.networks.id"), nullable=False, index=True)
    actor_id = Column(Uuid, ForeignKey("core.subjects.id"))
    kind = Column(String(32), nullable=False)
    parent_id = Column(Uuid, ForeignKey("ops.operations.id"))
    slot = Column(String(32))


class Idempotency(Record, Base):
    __tablename__ = "idempotency_keys"
    __table_args__ = (UniqueConstraint("subject_id", "route", "key"), {"schema": "ops"})
    subject_id = Column(Uuid, ForeignKey("core.subjects.id"), nullable=False)
    route = Column(String(120), nullable=False)
    key = Column(Uuid, nullable=False)
    request_digest = Column(String(64), nullable=False)
    operation_id = Column(Uuid, ForeignKey("ops.operations.id"), nullable=False)
    response = Column(JSON, nullable=False)


class Command(Record, Base):
    __tablename__ = "commands"
    __table_args__ = (UniqueConstraint("operation_id", "kind"), {"schema": "ops"})
    operation_id = Column(Uuid, ForeignKey("ops.operations.id"), nullable=False, index=True)
    kind = Column(String(32), nullable=False)
    payload = Column(JSON, nullable=False)
    state = Column(String(16), nullable=False, default="QUEUED", index=True)
    attempts = Column(Integer, nullable=False, default=0)
    error_code = Column(String(40))
    next_attempt_at = Column(UTC, nullable=False, default=utcnow)


class Authorization(Record, Base):
    __tablename__ = "authorizations"
    __table_args__ = {"schema": "ops"}
    operation_id = Column(Uuid, ForeignKey("ops.operations.id"), nullable=False, unique=True)
    actor_id = Column(Uuid, ForeignKey("core.subjects.id"), nullable=False)
    credentials_version = Column(Integer, nullable=False)
    session_id = Column(Uuid, nullable=False)
    payload_digest = Column(String(64), nullable=False)
    payload = Column(JSON, nullable=False)
    signature = Column(String(86))
    transaction_hash = Column(String(64), unique=True)
    expires_at = Column(UTC, nullable=False)
    signed_at = Column(UTC)
    consumed_at = Column(UTC)


class Journal(Record, Base):
    __tablename__ = "transactions"
    __table_args__ = {"schema": "ledger"}
    operation_id = Column(Uuid, ForeignKey("ops.operations.id"), nullable=False, unique=True)
    network_id = Column(Uuid, ForeignKey("core.networks.id"), nullable=False)
    kind = Column(String(40), nullable=False)


class JournalLine(Record, Base):
    __tablename__ = "journal_lines"
    __table_args__ = (UniqueConstraint("journal_id", "line_no"),
        ForeignKeyConstraint(["account_id", "asset_code", "network_id"], ["ledger.accounts.id", "ledger.accounts.asset_code", "ledger.accounts.network_id"]),
        CheckConstraint("amount > 0 AND side IN ('DEBIT','CREDIT')", name="positive_journal_line"), {"schema": "ledger"})
    journal_id = Column(Uuid, ForeignKey("ledger.transactions.id"), nullable=False, index=True)
    line_no = Column(Integer, nullable=False)
    network_id = Column(Uuid, ForeignKey("core.networks.id"), nullable=False)
    account_id = Column(Uuid, nullable=False, index=True)
    asset_code = Column(String(16), nullable=False)
    side = Column(String(6), nullable=False)
    amount = Column(Q, nullable=False)


class Block(Record, Base):
    __tablename__ = "blocks"
    __table_args__ = (UniqueConstraint("network_id", "height"), {"schema": "ledger"})
    network_id = Column(Uuid, ForeignKey("core.networks.id"), nullable=False)
    height = Column(BigInteger, nullable=False)
    block_hash = Column(String(64), nullable=False, unique=True)
    header = Column(JSON, nullable=False)
    signature = Column(String(86), nullable=False)
    validator_id = Column(Uuid, ForeignKey("core.validators.id"), nullable=False)


class ChainTransaction(Record, Base):
    __tablename__ = "blockchain_transactions"
    __table_args__ = (UniqueConstraint("block_id", "tx_index"), UniqueConstraint("sender_wallet_id", "nonce"), {"schema": "ledger"})
    network_id = Column(Uuid, ForeignKey("core.networks.id"), nullable=False)
    block_id = Column(Uuid, ForeignKey("ledger.blocks.id"), nullable=False, index=True)
    tx_index = Column(Integer, nullable=False)
    journal_id = Column(Uuid, ForeignKey("ledger.transactions.id"), nullable=False, unique=True)
    transaction_hash = Column(String(64), nullable=False, unique=True)
    payload = Column(JSON, nullable=False)
    signature = Column(String(86), nullable=False)
    public_key = Column(LargeBinary, nullable=False)
    journal_commitment = Column(String(64), nullable=False)
    salt_ciphertext = Column(LargeBinary, nullable=False)
    sender_wallet_id = Column(Uuid, ForeignKey("ledger.wallets.id"))
    nonce = Column(BigInteger)


class Outbox(Record, Base):
    __tablename__ = "outbox"
    __table_args__ = (UniqueConstraint("operation_id", "event_type"), {"schema": "ops"})
    operation_id = Column(Uuid, ForeignKey("ops.operations.id"), nullable=False, index=True)
    event_type = Column(String(48), nullable=False)
    payload = Column(JSON, nullable=False)
    published_at = Column(UTC)


class Audit(Record, Base):
    __tablename__ = "audit_logs"
    __table_args__ = {"schema": "audit"}
    actor_id = Column(Uuid, ForeignKey("core.subjects.id"))
    operation_id = Column(Uuid, ForeignKey("ops.operations.id"))
    action = Column(String(48), nullable=False)
    result = Column(String(40), nullable=False)
    previous_hash = Column(String(64), nullable=False)
    event_hash = Column(String(64), nullable=False, unique=True)


class AuditHead(Record, Base):
    __tablename__ = "audit_streams"
    __table_args__ = {"schema": "audit"}
    stream = Column(String(16), nullable=False, unique=True)
    head = Column(String(64), nullable=False, default="0"*64)


class DomainGrant(Record, Base):
    __tablename__ = "staff_grants"
    __table_args__ = (UniqueConstraint("subject_id", "role"), {"schema": "core"})
    subject_id = Column(Uuid, ForeignKey("core.subjects.id"), nullable=False)
    role = Column(String(16), nullable=False)
    revoked_at = Column(UTC)


COMMON_TABLES = tuple(Base.metadata.tables)
