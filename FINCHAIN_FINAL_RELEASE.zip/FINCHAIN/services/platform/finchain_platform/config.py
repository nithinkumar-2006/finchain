import base64
import os
from pathlib import Path
from dataclasses import dataclass, field


@dataclass(frozen=True)
class DomainSettings:
    domain: str
    database_url: str = field(repr=False)
    encryption_key: bytes = field(repr=False)
    network_code: str = ""
    origin: str = "https://localhost:8443"
    identity_url: str = "http://identity:8000"
    service_secret: str = field(default="", repr=False)
    signer_url: str = ""
    gateway_url: str = ""
    redis_url: str = ""
    role: str = "api"
    test_mode: bool = False

    def __post_init__(self):
        if self.domain not in {"BPI", "FINCOIN"} or len(self.encryption_key) != 32:
            raise ValueError("Isolated domain and 256-bit encryption key required")
        if not self.network_code:
            object.__setattr__(self, "network_code", f"finchain-{self.domain.lower()}-sandbox-1")
        if not self.network_code.startswith(f"finchain-{self.domain.lower()}-sandbox-"):
            raise ValueError("Sandbox domain network mismatch")
        if not self.test_mode and not self.database_url.startswith("postgresql+psycopg://"):
            raise ValueError("PostgreSQL required")
        if not self.origin.startswith("https://") or self.role not in {"api", "ledger", "bootstrap", "projection"}:
            raise ValueError("Invalid deployment boundary")

    @classmethod
    def from_env(cls):
        if os.environ.get("FINCHAIN_MODE") != "sandbox":
            raise ValueError("FINCHAIN_MODE=sandbox is mandatory")
        return cls(domain=os.environ["FINCHAIN_DOMAIN"], database_url=os.environ["DOMAIN_DATABASE_URL"],
            encryption_key=base64.b64decode(Path(os.environ["DOMAIN_ENCRYPTION_KEY_FILE"]).read_text().strip(), validate=True),
            network_code=os.environ["NETWORK_ID"], origin=os.environ["FINCHAIN_ORIGIN"],
            identity_url=os.environ["IDENTITY_INTERNAL_URL"], service_secret=Path(os.environ["SERVICE_SECRET_FILE"]).read_text().strip(),
            signer_url=os.environ.get("SIGNER_URL", ""), gateway_url=os.environ.get("GATEWAY_URL", ""),
            redis_url=os.environ.get("REDIS_URL", ""), role=os.environ.get("SERVICE_ROLE", "api"))
