import math
import uuid
from datetime import timedelta
from sqlalchemy import select, func
from .ledger import Store, RuleViolation
from .storage import (Wallet, Principal, Operation, Command, Authorization, Journal, Account, Balance, utcnow)
from .fincoin_models import Tick, Quote, FincoinOrder, Fill, AssetTransfer, Lot, Disposal, Grant
from .protocol import integer, canonical, payload_digest, wire_time, read_time, PaymentPayload, validate_address, validate_user_transaction

SCALE = 100000000
FINCOIN_POLICY = {"assets": {"FINCOIN": 8, "SIM_INR": 2}, "initial_fincoin_atoms": "100000000000000", "initial_quote_minor": "100000000", "fee_bps": "10", "consensus": "single-authorized-producer", "threshold": "1", "post_genesis_fincoin_mint": False}


def quote_math(side, quantity, price):
    if side not in {"BUY", "SELL"} or quantity <= 0 or price <= 0:
        raise RuleViolation("INVALID_QUOTE", 422)
    gross = (quantity*price + SCALE-1)//SCALE if side == "BUY" else quantity*price//SCALE
    fee = (gross*10+9999)//10000
    total = gross+fee if side == "BUY" else gross-fee
    if gross <= 0 or total <= 0:
        raise RuleViolation("QUANTITY_TOO_SMALL", 422)
    return gross, fee, total


class FINCOIN(Store):
    def __init__(self, settings, signer=None):
        if settings.domain != "FINCOIN":
            raise ValueError("FINCOIN cannot use BPI storage")
        super().__init__(settings, signer)

    def initialize_fincoin(self):
        self.initialize(FINCOIN_POLICY, activate=False)
        with self.transaction() as db:
            network, head = self.writer(db)
            existing = db.scalar(select(Operation).where(Operation.kind == "GENESIS_ISSUANCE"))
            if existing:
                return
            inventory_owner = Principal(id=uuid.uuid4(), kind="SERVICE", service_code="SIMULATOR")
            db.add(inventory_owner)
            db.flush()
            wallet = self.create_wallet(db, inventory_owner.id, "FINCOIN simulator inventory")
            lines = []
            for asset, amount in (("FINCOIN", 10**14), ("SIM_INR", 10**8)):
                issuance = self.account(db, network.id, None, asset, "ISSUANCE", "DEBIT")
                inventory = self.account(db, network.id, wallet.id, asset, "SETTLED")
                lines.extend([(issuance, "DEBIT", amount), (inventory, "CREDIT", amount)])
            op = self.operation(db, "GENESIS_ISSUANCE")
            self.post(db, op, "GENESIS_ISSUANCE", lines)
            network.status = "ACTIVE"

    def own_wallet(self, db, subject, wallet_id=None):
        query = select(Wallet).join(Principal, Principal.id == Wallet.owner_id).where(Principal.subject_id == subject.id)
        if wallet_id:
            query = query.where(Wallet.id == uuid.UUID(str(wallet_id)))
        wallet = db.scalar(query)
        if not wallet or wallet.status != "ACTIVE":
            raise RuleViolation("WALLET_NOT_FOUND", 404)
        return wallet

    def request_wallet(self, principal, key):
        with self.transaction() as db:
            actor, owner = self.sync_subject(db, principal)
            def create(op):
                found = db.scalar(select(Wallet).where(Wallet.owner_id == owner.id))
                if found:
                    return {"operation_id": str(op.id), "wallet_id": str(found.id), "status": "READY"}
                db.add(Command(operation_id=op.id, kind="CREATE_WALLET", payload={"owner_id": str(owner.id)}))
                return {"operation_id": str(op.id), "status": "QUEUED"}
            return self.idempotent(db, actor, "fincoin-wallet", key, {}, create)

    def wallets(self, principal):
        with self.transaction() as db:
            actor, _ = self.sync_subject(db, principal)
            wallet = db.scalar(select(Wallet).join(Principal, Principal.id == Wallet.owner_id).where(Principal.subject_id == actor.id))
            if wallet is None:
                return []
            return [{"id": str(wallet.id), "address": wallet.address, "balances": self.wallet_values(db, wallet), "domain": "FINCOIN", "environment": "sandbox", "value_kind": "simulated"}]

    def request_grant(self, principal, key, asset, quantity):
        if asset not in {"FINCOIN", "SIM_INR"}:
            raise RuleViolation("UNSUPPORTED_ASSET", 422)
        amount = integer(quantity, maximum=10*SCALE if asset == "FINCOIN" else 1000000)
        with self.transaction() as db:
            actor, _ = self.sync_subject(db, principal)
            wallet = self.own_wallet(db, actor)
            def create(op):
                used = int(db.scalar(select(func.coalesce(func.sum(Grant.quantity), 0)).where(Grant.wallet_id == wallet.id, Grant.asset_code == asset, Grant.created_at > utcnow()-timedelta(days=1))) or 0)
                cap = 10*SCALE if asset == "FINCOIN" else 1000000
                if used+amount > cap:
                    raise RuleViolation("GRANT_CAP_REACHED", 429)
                grant = Grant(id=uuid.uuid4(), operation_id=op.id, wallet_id=wallet.id, asset_code=asset, quantity=amount)
                db.add(grant)
                db.add(Command(operation_id=op.id, kind="GRANT", payload={"grant_id": str(grant.id)}))
                return {"operation_id": str(op.id), "grant_id": str(grant.id), "status": "QUEUED"}
            return self.idempotent(db, actor, "grant", key, {"asset": asset, "quantity": quantity}, create)

    def add_tick(self, price=None):
        with self.transaction() as db:
            _, head = self.writer(db)
            last = db.scalar(select(Tick).order_by(Tick.sequence.desc()).limit(1))
            sequence = last.sequence+1 if last else 0
            # Deterministic synthetic series; never substituted for an external market price.
            value = price if price is not None else 10000 + ((sequence*37) % 1001)-500
            if type(value) is not int or value <= 0:
                raise RuleViolation("INVALID_PRICE")
            db.add(Tick(sequence=sequence, price=value, observed_at=utcnow()))

    def quote(self, principal, key, side, quantity):
        q = integer(quantity, maximum=10000*SCALE)
        with self.transaction() as db:
            actor, _ = self.sync_subject(db, principal)
            wallet = self.own_wallet(db, actor)
            tick = db.scalar(select(Tick).order_by(Tick.sequence.desc()).limit(1))
            if tick is None or tick.observed_at + timedelta(seconds=10) <= utcnow():
                raise RuleViolation("SYNTHETIC_FEED_STALE", 503)
            gross, fee, total = quote_math(side, q, int(tick.price))
            def create(op):
                quote_id, auth_id = uuid.uuid4(), uuid.uuid4()
                expiry = utcnow()+timedelta(seconds=15)
                payload = {"protocol_version": "1", "domain": "FINCOIN", "environment": "sandbox", "network_id": self.settings.network_code,
                           "kind": "TRADE", "quote_id": str(quote_id), "wallet_address": wallet.address, "side": side, "quantity_atoms": quantity,
                           "price_minor": str(tick.price), "gross_minor": str(gross), "fee_minor": str(fee), "total_minor": str(total), "nonce": str(wallet.next_nonce),
                           "timestamp": wire_time(), "expires_at": wire_time(expiry), "feed_sequence": str(tick.sequence), "authorization_ref": str(auth_id), "key_id": str(wallet.key_id)}
                row = Quote(id=quote_id, operation_id=op.id, wallet_id=wallet.id, side=side, quantity=q, price=tick.price, gross=gross, fee=fee, total=total,
                            tick_id=tick.id, expires_at=expiry, payload=payload, payload_digest=payload_digest(payload))
                db.add(row)
                db.add(Authorization(id=auth_id, operation_id=op.id, actor_id=actor.id, credentials_version=principal["credentials_version"], session_id=uuid.UUID(principal["session_id"]), payload_digest=row.payload_digest, payload=payload, expires_at=expiry))
                return {"quote_id": str(row.id), "payload_digest": row.payload_digest, "side": side, "quantity_atoms": quantity, "price_minor": str(tick.price), "gross_minor": str(gross),
                        "fee_minor": str(fee), "total_minor": str(total), "expires_at": wire_time(expiry), "source": "synthetic", "environment": "sandbox"}
            return self.idempotent(db, actor, "quote", key, {"side": side, "quantity": quantity}, create)

    def authorize_quote(self, principal, key, quote_id, expected_digest):
        with self.transaction() as db:
            actor, _ = self.sync_subject(db, principal)
            quote = db.get(Quote, uuid.UUID(str(quote_id)))
            if quote is None:
                raise RuleViolation("QUOTE_NOT_FOUND", 404)
            self.own_wallet(db, actor, quote.wallet_id)
            if quote.payload_digest != expected_digest or quote.expires_at <= utcnow():
                raise RuleViolation("QUOTE_EXPIRED_OR_CHANGED")
            if principal["auth_time"] < int(utcnow().timestamp())-300:
                raise RuleViolation("REAUTHENTICATION_REQUIRED", 403)
            def create(op):
                order = db.scalar(select(FincoinOrder).where(FincoinOrder.quote_id == quote.id))
                if order is None:
                    order = FincoinOrder(id=uuid.uuid4(), quote_id=quote.id, operation_id=quote.operation_id)
                    db.add(order)
                    db.add(Command(operation_id=quote.operation_id, kind="FILL", payload={"order_id": str(order.id)}))
                return {"order_id": str(order.id), "operation_id": str(quote.operation_id), "status": "QUEUED"}
            return self.idempotent(db, actor, "order", key, {"quote_id": str(quote.id), "payload_digest": expected_digest}, create)

    def transfer_draft(self, principal, key, recipient, quantity):
        q = integer(quantity)
        validate_address(recipient, "FINCOIN")
        with self.transaction() as db:
            actor, _ = self.sync_subject(db, principal)
            sender = self.own_wallet(db, actor)
            receiver = db.scalar(select(Wallet).where(Wallet.address == recipient))
            if not receiver or receiver.id == sender.id or receiver.status != "ACTIVE":
                raise RuleViolation("INVALID_RECIPIENT", 422)
            def create(op):
                transfer_id, auth_id = uuid.uuid4(), uuid.uuid4()
                expiry = utcnow()+timedelta(minutes=5)
                payload = PaymentPayload(domain="FINCOIN", network_id=self.settings.network_code, transaction_id=str(transfer_id), kind="ASSET_TRANSFER", sender_address=sender.address,
                    receiver_address=receiver.address, amount_minor=quantity, currency="FINCOIN", timestamp=wire_time(), expires_at=wire_time(expiry), nonce=str(sender.next_nonce),
                    payment_type="ASSET", authorization_ref=str(auth_id), key_id=str(sender.key_id)).model_dump()
                db.add(AssetTransfer(id=transfer_id, operation_id=op.id, sender_id=sender.id, receiver_id=receiver.id, quantity=q, payload=payload))
                db.add(Authorization(id=auth_id, operation_id=op.id, actor_id=actor.id, credentials_version=principal["credentials_version"], session_id=uuid.UUID(principal["session_id"]), payload_digest=payload_digest(payload), payload=payload, expires_at=expiry))
                return {"transfer_id": str(transfer_id), "payload_digest": payload_digest(payload), "quantity_atoms": quantity, "recipient": recipient, "status": "DRAFT"}
            return self.idempotent(db, actor, "transfer-draft", key, {"recipient": recipient, "quantity": quantity}, create)

    def authorize_transfer(self, principal, key, transfer_id, expected_digest):
        if principal["auth_time"] < int(utcnow().timestamp())-300:
            raise RuleViolation("REAUTHENTICATION_REQUIRED", 403)
        with self.transaction() as db:
            actor, _ = self.sync_subject(db, principal)
            transfer = db.get(AssetTransfer, uuid.UUID(str(transfer_id)))
            if not transfer:
                raise RuleViolation("TRANSFER_NOT_FOUND", 404)
            self.own_wallet(db, actor, transfer.sender_id)
            if expected_digest != payload_digest(transfer.payload) or read_time(transfer.payload["expires_at"]) <= utcnow():
                raise RuleViolation("TRANSFER_EXPIRED_OR_CHANGED")
            def create(op):
                if transfer.status == "DRAFT":
                    db.add(Command(operation_id=transfer.operation_id, kind="TRANSFER", payload={"transfer_id": str(transfer.id)}))
                    transfer.status = "QUEUED"
                return {"transfer_id": str(transfer.id), "status": transfer.status}
            return self.idempotent(db, actor, "transfer-authorize", key, {"transfer_id": str(transfer.id), "digest": expected_digest}, create)

    def consume_lots(self, db, wallet, quantity):
        remaining, portions = quantity, []
        lots = db.scalars(select(Lot).where(Lot.wallet_id == wallet.id, Lot.quantity > 0).order_by(Lot.created_at, Lot.id).with_for_update()).all()
        for lot in lots:
            part = min(remaining, int(lot.quantity))
            cost = int(lot.remaining_cost) if part == int(lot.quantity) else int(lot.remaining_cost)*part//int(lot.quantity)
            lot.quantity = int(lot.quantity)-part
            lot.remaining_cost = int(lot.remaining_cost)-cost
            portions.append((lot, part, cost))
            remaining -= part
            if not remaining:
                break
        if remaining:
            raise RuleViolation("COST_BASIS_INCOMPLETE")
        return portions

    def process_command(self, command_id, validate_principal):
        with self.transaction() as db:
            network, head = self.writer(db)
            command = db.scalar(select(Command).where(Command.id == command_id).with_for_update())
            if not command or command.state != "QUEUED":
                return
            op = db.get(Operation, command.operation_id)
            if command.kind == "ADMIN":
                from .admin import Administration
                Administration(self).process(db, command, validate_principal)
                return
            if network.status != "ACTIVE":
                raise RuleViolation("NETWORK_PAUSED", 503)
            inventory = db.scalar(select(Wallet).join(Principal, Principal.id == Wallet.owner_id).where(Principal.service_code == "SIMULATOR"))
            if inventory is None:
                raise RuleViolation("GENESIS_ISSUANCE_REQUIRED", 503)
            if command.kind == "CREATE_WALLET":
                self.create_wallet(db, uuid.UUID(command.payload["owner_id"]), "FINCOIN test wallet")
                self.audit(db, "wallet.create", "COMMITTED", op.actor_id, op.id)
                command.state = "SUCCEEDED"
                return
            if command.kind == "GRANT":
                validate_principal(op.actor_id, None, None)
                grant = db.get(Grant, uuid.UUID(command.payload["grant_id"]))
                wallet = db.get(Wallet, grant.wallet_id)
                source = self.account(db, network.id, inventory.id, grant.asset_code, "SETTLED")
                target = self.account(db, network.id, wallet.id, grant.asset_code, "SETTLED")
                tx = self.post(db, op, "TEST_GRANT", [(source, "DEBIT", int(grant.quantity)), (target, "CREDIT", int(grant.quantity))])
                if grant.asset_code == "FINCOIN":
                    db.add(Lot(wallet_id=wallet.id, journal_id=tx.journal_id, quantity=grant.quantity, remaining_cost=0, provenance="grant"))
                grant.status = "COMPLETED"
                command.state = "SUCCEEDED"
                return
            auth = db.scalar(select(Authorization).where(Authorization.operation_id == op.id))
            validate_principal(auth.actor_id, auth.session_id, auth.credentials_version)
            if auth.expires_at <= utcnow() or auth.consumed_at:
                raise RuleViolation("AUTHORIZATION_EXPIRED")
            if command.kind == "FILL":
                order = db.get(FincoinOrder, uuid.UUID(command.payload["order_id"]))
                quote = db.get(Quote, order.quote_id)
                wallet = db.scalar(select(Wallet).where(Wallet.id == quote.wallet_id).with_for_update())
                if wallet.status != "ACTIVE" or wallet.next_nonce != int(quote.payload["nonce"]) or quote.expires_at <= utcnow():
                    raise RuleViolation("QUOTE_EXPIRED_OR_NONCE_CHANGED")
                q, gross, fee, total = int(quote.quantity), int(quote.gross), int(quote.fee), int(quote.total)
                uf = self.account(db, network.id, wallet.id, "FINCOIN", "SETTLED")
                uq = self.account(db, network.id, wallet.id, "SIM_INR", "SETTLED")
                inf = self.account(db, network.id, inventory.id, "FINCOIN", "SETTLED")
                inq = self.account(db, network.id, inventory.id, "SIM_INR", "SETTLED")
                fees = self.account(db, network.id, None, "SIM_INR", "FEES")
                if quote.side == "BUY":
                    lines = [(uq,"DEBIT",total),(inq,"CREDIT",gross),(fees,"CREDIT",fee),(inf,"DEBIT",q),(uf,"CREDIT",q)]
                else:
                    lines = [(uf,"DEBIT",q),(inf,"CREDIT",q),(inq,"DEBIT",gross),(uq,"CREDIT",total),(fees,"CREDIT",fee)]
                signed = self.signer.transaction(wallet.key_id, quote.payload)
                tx = self.post(db, op, "SIMULATED_"+quote.side, lines, {**signed, "payload": quote.payload, "public_key": wallet.public_key}, wallet)
                fill = Fill(id=uuid.uuid4(), order_id=order.id, journal_id=tx.journal_id, wallet_id=wallet.id, side=quote.side, quantity=q, gross=gross, fee=fee, total=total)
                db.add(fill)
                db.flush()
                if quote.side == "BUY":
                    db.add(Lot(wallet_id=wallet.id, journal_id=tx.journal_id, quantity=q, remaining_cost=total, provenance="purchased"))
                else:
                    portions = self.consume_lots(db, wallet, q)
                    assigned = 0
                    for index, (lot, part, cost) in enumerate(portions):
                        proceeds = total-assigned if index == len(portions)-1 else total*part//q
                        assigned += proceeds
                        db.add(Disposal(fill_id=fill.id, lot_id=lot.id, quantity=part, cost=cost, proceeds=proceeds, provenance=lot.provenance))
                order.status, order.filled_at = "FILLED", utcnow()
            elif command.kind == "TRANSFER":
                transfer = db.get(AssetTransfer, uuid.UUID(command.payload["transfer_id"]))
                wallet = db.scalar(select(Wallet).where(Wallet.id == transfer.sender_id).with_for_update())
                receiver = db.get(Wallet, transfer.receiver_id)
                if wallet.status != "ACTIVE" or receiver.status != "ACTIVE":
                    raise RuleViolation("WALLET_RESTRICTED")
                signed = self.signer.transaction(wallet.key_id, transfer.payload)
                validate_user_transaction(transfer.payload, wallet.public_key, signed["signature"], signed["transaction_hash"], network.network_code, wallet.next_nonce)
                source = self.account(db, network.id, wallet.id, "FINCOIN", "SETTLED")
                target = self.account(db, network.id, receiver.id, "FINCOIN", "SETTLED")
                tx = self.post(db, op, "ASSET_TRANSFER", [(source,"DEBIT",int(transfer.quantity)),(target,"CREDIT",int(transfer.quantity))], {**signed, "payload": transfer.payload, "public_key": wallet.public_key}, wallet)
                for lot, part, cost in self.consume_lots(db, wallet, int(transfer.quantity)):
                    db.add(Lot(wallet_id=receiver.id, journal_id=tx.journal_id, quantity=part, remaining_cost=cost, provenance="grant" if lot.provenance == "grant" else "carried"))
                transfer.status = "CONFIRMED"
            else:
                raise RuleViolation("UNKNOWN_COMMAND")
            auth.signature, auth.transaction_hash, auth.signed_at, auth.consumed_at = signed["signature"], signed["transaction_hash"], utcnow(), utcnow()
            command.state = "SUCCEEDED"

    def portfolio(self, principal):
        with self.transaction() as db:
            actor, _ = self.sync_subject(db, principal)
            wallet = self.own_wallet(db, actor)
            lots = db.scalars(select(Lot).where(Lot.wallet_id == wallet.id)).all()
            disposals = db.execute(select(Disposal).join(Fill, Fill.id == Disposal.fill_id).where(Fill.wallet_id == wallet.id)).scalars().all()
            tick = db.scalar(select(Tick).order_by(Tick.sequence.desc()).limit(1))
            price = int(tick.price) if tick and tick.observed_at + timedelta(seconds=10) > utcnow() else None
            quantity = sum(int(l.quantity) for l in lots)
            purchased = [l for l in lots if l.provenance == "purchased"]
            purchased_disposals = [d for d in disposals if d.provenance == "purchased"]
            realized = sum(int(d.proceeds)-int(d.cost) for d in purchased_disposals)
            cost_sold = sum(int(d.cost) for d in purchased_disposals)
            basis = sum(int(l.remaining_cost) for l in purchased)
            eligible_quantity = sum(int(l.quantity) for l in purchased)
            return {"quantity_atoms": str(quantity), "price_minor": str(price) if price else None,
                    "current_value_minor": str(quantity*price//SCALE) if price else None,
                    "remaining_purchased_cost_minor": str(basis), "remaining_purchased_quantity_atoms": str(eligible_quantity),
                    "realized_purchased_pnl_minor": str(realized), "realized_purchased_cost_minor": str(cost_sold),
                    "unrealized_purchased_pnl_minor": str(eligible_quantity*price//SCALE-basis) if price else None,
                    "grant_realized_pnl_minor": str(sum(int(d.proceeds)-int(d.cost) for d in disposals if d.provenance == "grant")),
                    "carried_realized_pnl_minor": str(sum(int(d.proceeds)-int(d.cost) for d in disposals if d.provenance == "carried")),
                    "return_numerator": str(realized), "return_denominator": str(cost_sold) if cost_sold else None,
                    "lots": [{"quantity_atoms": str(l.quantity), "cost_minor": str(l.remaining_cost), "provenance": l.provenance} for l in lots if l.quantity],
                    "source": "synthetic", "domain": "FINCOIN", "environment": "sandbox", "as_of": wire_time()}
