from dataclasses import dataclass


@dataclass(frozen=True)
class RiskResult:
    score: int
    severity: str
    decision: str
    reasons: tuple[str, ...]


def assess(*, amount, new_recipient, recent_count, failed_count, flagged=False):
    score, reasons = 0, []
    for applies, points, reason in [
        (new_recipient, 15, "NEW_RECIPIENT"),
        (amount >= 1000000, 35, "LARGE_SIMULATED_PAYMENT"),
        (recent_count >= 5, 35, "HIGH_PAYMENT_VELOCITY"),
        (failed_count >= 3, 25, "REPEATED_FAILED_PAYMENTS"),
        (flagged, 100, "WALLET_RESTRICTED"),
    ]:
        if applies:
            score += points
            reasons.append(reason)
    score = min(100, score)
    severity = "LOW" if score <= 30 else "MEDIUM" if score <= 60 else "HIGH" if score <= 80 else "CRITICAL"
    decision = "DENY" if score > 80 else "REVIEW" if score > 60 else "ALLOW"
    return RiskResult(score, severity, decision, tuple(reasons))
