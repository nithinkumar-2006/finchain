"""Private per-domain signer with durable one-use grant binding."""
import hmac
import os
import uuid
from pathlib import Path
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import Column, Uuid, String, create_engine, select
from sqlalchemy.orm import declarative_base, sessionmaker
from .storage import Record
from .signing import SandboxSigner
from .protocol import payload_digest, block_hash

SignerBase = declarative_base()


class SigningGrant(Record, SignerBase):
    __tablename__ = "signing_grants"
    grant_id = Column(String(120), nullable=False, unique=True)
    payload_digest = Column(String(64), nullable=False)
    key_handle = Column(Uuid, nullable=False)


class KeyBody(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    handle: str = Field(max_length=36)


class TransactionBody(KeyBody):
    payload: dict


class BlockBody(KeyBody):
    header: dict


def create_app():
    if os.environ.get("FINCHAIN_MODE") != "sandbox":
        raise ValueError("Sandbox signer only")
    url = os.environ["SIGNER_DATABASE_URL"]
    if not url.startswith("postgresql+psycopg://"):
        raise ValueError("Private signer PostgreSQL database required")
    secret = Path(os.environ["SIGNER_SERVICE_KEY_FILE"]).read_text().strip()
    signer = SandboxSigner(Path(os.environ["SIGNER_MASTER_KEY_FILE"]).read_bytes(), os.environ["NETWORK_ID"])
    engine = create_engine(url, hide_parameters=True)
    sessions = sessionmaker(engine)
    app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)

    @app.middleware("http")
    async def boundary(request, call_next):
        if not hmac.compare_digest(request.headers.get("x-service-key", ""), secret):
            return JSONResponse({"code": "FORBIDDEN"}, status_code=403)
        body = await request.body()
        if len(body) > 32768:
            return JSONResponse({"code": "REQUEST_TOO_LARGE"}, status_code=413)
        return await call_next(request)

    def bind(handle, grant_id, digest):
        from sqlalchemy.dialects.postgresql import insert
        key_id = uuid.UUID(handle)
        with sessions.begin() as db:
            db.execute(insert(SigningGrant).values(id=uuid.uuid4(), grant_id=grant_id, payload_digest=digest, key_handle=key_id).on_conflict_do_nothing(index_elements=["grant_id"]))
            row = db.scalar(select(SigningGrant).where(SigningGrant.grant_id == grant_id).with_for_update())
            return row.payload_digest == digest and row.key_handle == key_id

    @app.post("/public-key")
    def public(body: KeyBody):
        return {"public_key": signer.public_key(uuid.UUID(body.handle)).hex()}

    @app.post("/transaction")
    def transaction(body: TransactionBody):
        reference = body.payload.get("authorization_ref") or body.payload.get("operation_id")
        if not reference or not bind(body.handle, "tx:"+str(uuid.UUID(reference)), payload_digest(body.payload)):
            return JSONResponse({"code": "SIGNING_GRANT_CONFLICT"}, status_code=409)
        return signer.transaction(uuid.UUID(body.handle), body.payload)

    @app.post("/block")
    def block(body: BlockBody):
        # Uncommitted proposals may be retried with a new timestamp/hash. Block publication and
        # fencing remain the ledger's responsibility; signer never publishes a proposal.
        value, signature = signer.block(uuid.UUID(body.handle), body.header)
        return {"block_hash": value, "signature": signature}

    return app
