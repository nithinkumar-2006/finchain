"""Version-one signed ledger protocol. All public output is explicitly projected."""
import base64
import hashlib
import json
import re
from datetime import datetime, timezone
from typing import Literal
from uuid import UUID
import rfc8785
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from pydantic import BaseModel, ConfigDict, Field, field_validator

ZERO = "0" * 64
MAX_AMOUNT = 10**18


def sha(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def canonical(value: dict | list) -> bytes:
    return rfc8785.dumps(value)


def parse_json(value: bytes) -> dict:
    if len(value) > 16384:
        raise ValueError("Payload too large")
    def pairs(items):
        result = {}
        for key, item in items:
            if key in result:
                raise ValueError("Duplicate JSON field")
            result[key] = item
        return result
    parsed = json.loads(value, object_pairs_hook=pairs, parse_constant=lambda _: (_ for _ in ()).throw(ValueError("Nonfinite JSON")))
    if not isinstance(parsed, dict):
        raise ValueError("Expected object")
    return parsed


def integer(value: str, positive=True, maximum=MAX_AMOUNT) -> int:
    if not isinstance(value, str) or not re.fullmatch(r"0|[1-9][0-9]*", value):
        raise ValueError("Canonical unsigned decimal string required")
    result = int(value)
    if result > maximum or result < (1 if positive else 0):
        raise ValueError("Amount outside permitted range")
    return result


def wire_time(value=None):
    value = value or datetime.now(timezone.utc)
    return value.astimezone(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def read_time(value):
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z", value):
        raise ValueError("Canonical UTC milliseconds required")
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def address(public: bytes, domain: str):
    if domain not in {"BPI", "FINCOIN"} or len(public) != 32:
        raise ValueError("Invalid network/key")
    prefix = "bpi_sbx_" if domain == "BPI" else "fc_sbx_"
    body = sha(public)
    return prefix + body + sha((prefix + body).encode())[:8]


def validate_address(value, domain):
    prefix = "bpi_sbx_" if domain == "BPI" else "fc_sbx_"
    if not isinstance(value, str) or not re.fullmatch(prefix + "[0-9a-f]{72}", value) or sha(value[:-8].encode())[:8] != value[-8:]:
        raise ValueError("Invalid domain address/checksum")
    return value


class PaymentPayload(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    protocol_version: Literal["1"] = "1"
    domain: Literal["BPI", "FINCOIN"]
    environment: Literal["sandbox"] = "sandbox"
    network_id: str
    transaction_id: str
    kind: Literal["PAYMENT_TRANSFER", "ASSET_TRANSFER", "TRADE", "REDEMPTION"]
    sender_address: str
    receiver_address: str
    amount_minor: str
    currency: Literal["INR", "FINCOIN", "SIM_INR"]
    fee_minor: Literal["0"] = "0"
    timestamp: str
    expires_at: str
    nonce: str
    payment_type: Literal["P2P", "P2B", "B2P", "B2B", "ASSET", "TRADE", "REDEMPTION"]
    request_id: str | None = None
    order_id: str | None = None
    authorization_ref: str
    key_id: str

    @field_validator("amount_minor")
    @classmethod
    def amount(cls, value):
        integer(value)
        return value

    @field_validator("nonce")
    @classmethod
    def nonce_value(cls, value):
        integer(value, positive=False)
        return value

    @field_validator("timestamp", "expires_at")
    @classmethod
    def timestamp_value(cls, value):
        read_time(value)
        return value

    @field_validator("transaction_id", "authorization_ref", "key_id")
    @classmethod
    def uuid_value(cls, value):
        if str(UUID(value)) != value:
            raise ValueError("Canonical UUID required")
        return value


def payload_digest(payload):
    return sha(b"FINCHAIN:PAYLOAD:v1:" + canonical(payload))


def sign_payload(private: Ed25519PrivateKey, payload):
    digest = payload_digest(payload)
    signature = private.sign(bytes.fromhex(digest))
    return {"payload_digest": digest, "signature": base64.urlsafe_b64encode(signature).decode().rstrip("="),
            "transaction_hash": sha(b"FINCHAIN:TX:v1:" + bytes.fromhex(digest) + signature)}


def verify_signature(public, payload, signature, transaction_hash):
    if not re.fullmatch(r"[A-Za-z0-9_-]{86}", signature):
        raise ValueError("Invalid signature encoding")
    raw = base64.urlsafe_b64decode(signature + "==")
    if base64.urlsafe_b64encode(raw).decode().rstrip("=") != signature:
        raise ValueError("Noncanonical signature")
    pd = bytes.fromhex(payload_digest(payload))
    try:
        Ed25519PublicKey.from_public_bytes(public).verify(raw, pd)
    except InvalidSignature:
        raise ValueError("Invalid signature") from None
    if sha(b"FINCHAIN:TX:v1:" + pd + raw) != transaction_hash:
        raise ValueError("Transaction hash mismatch")


def validate_user_transaction(payload, public, signature, tx_hash, network, nonce, timestamp=None):
    parsed = PaymentPayload.model_validate(payload)
    moment = timestamp or datetime.now(timezone.utc)
    if parsed.network_id != network or parsed.domain not in {"BPI", "FINCOIN"}:
        raise ValueError("Wrong network")
    if parsed.domain == "BPI" and parsed.currency != "INR" or parsed.domain == "FINCOIN" and parsed.currency == "INR":
        raise ValueError("Cross-domain asset")
    if not network.startswith("finchain-" + parsed.domain.lower() + "-sandbox-"):
        raise ValueError("Wrong domain")
    validate_address(parsed.sender_address, parsed.domain)
    validate_address(parsed.receiver_address, parsed.domain)
    if parsed.sender_address != address(public, parsed.domain):
        raise ValueError("Sender address does not bind the signing key")
    if int(parsed.nonce) != nonce:
        raise ValueError("Incorrect nonce")
    start, expiry = read_time(parsed.timestamp), read_time(parsed.expires_at)
    if expiry <= moment or start.timestamp() > moment.timestamp() + 30 or not 0 < (expiry-start).total_seconds() <= 300:
        raise ValueError("Expired/invalid validity window")
    verify_signature(public, payload, signature, tx_hash)
    return parsed


def commitment(journal, salt):
    if len(salt) != 32:
        raise ValueError("32-byte salt required")
    return sha(b"\x03" + salt + hashlib.sha256(canonical(journal)).digest())


def leaf(tx_hash, journal_commitment):
    return sha(b"\x00" + bytes.fromhex(tx_hash) + bytes.fromhex(journal_commitment))


def merkle_root(items):
    nodes = [leaf(tx, jc) for tx, jc in items]
    if not nodes:
        return sha(b"\x02")
    while len(nodes) > 1:
        if len(nodes) % 2:
            nodes.append(nodes[-1])
        nodes = [sha(b"\x01" + bytes.fromhex(nodes[i]) + bytes.fromhex(nodes[i+1])) for i in range(0, len(nodes), 2)]
    return nodes[0]


def merkle_proof(items, position):
    nodes, proof = [leaf(tx, jc) for tx, jc in items], []
    if not 0 <= position < len(nodes):
        raise ValueError("Invalid leaf index")
    while len(nodes) > 1:
        if len(nodes) % 2:
            nodes.append(nodes[-1])
        proof.append({"side": "left" if position % 2 else "right", "hash": nodes[position ^ 1]})
        nodes = [sha(b"\x01" + bytes.fromhex(nodes[i]) + bytes.fromhex(nodes[i+1])) for i in range(0, len(nodes), 2)]
        position //= 2
    return proof


def check_proof(tx_hash, jc, proof, root):
    result = leaf(tx_hash, jc)
    for step in proof:
        if step["side"] not in {"left", "right"}:
            return False
        left, right = (step["hash"], result) if step["side"] == "left" else (result, step["hash"])
        result = sha(b"\x01" + bytes.fromhex(left) + bytes.fromhex(right))
    return result == root


def block_hash(header):
    return sha(b"FINCHAIN:BLOCK:v1:" + canonical(header))


def sign_block(private, header):
    value = block_hash(header)
    return value, base64.urlsafe_b64encode(private.sign(bytes.fromhex(value))).decode().rstrip("=")


def verify_block(public, header, body, value, signature, previous, height):
    if header["height"] != str(height) or header["previous_hash"] != previous or header["transaction_count"] != str(len(body)):
        raise ValueError("Block linkage/order mismatch")
    if header["merkle_root"] != merkle_root(body) or block_hash(header) != value:
        raise ValueError("Block commitment mismatch")
    if len(body) > 100 or len(canonical(body)) > 1024 * 1024:
        raise ValueError("Block size limit exceeded")
    try:
        Ed25519PublicKey.from_public_bytes(public).verify(base64.urlsafe_b64decode(signature + "=="), bytes.fromhex(value))
    except (InvalidSignature, ValueError):
        raise ValueError("Invalid block signature") from None
