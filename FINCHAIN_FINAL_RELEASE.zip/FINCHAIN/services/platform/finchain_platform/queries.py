import uuid
from datetime import timedelta
from zoneinfo import ZoneInfo
from sqlalchemy import select, func, or_
from .storage import Wallet, Principal, Operation, Command, Journal, ChainTransaction, Block, Validator, Head, DomainGrant, Audit, utcnow
from .bpi_models import Payment, PaymentState, FraudScore, Merchant, Membership, Settlement, Product, CommerceOrder, OrderItem, Invoice, Notification
from .fincoin_models import Quote, FincoinOrder, Fill, Tick, AssetTransfer
from .ledger import RuleViolation
from .protocol import wire_time, merkle_proof


class Queries:
    def __init__(self, store):
        self.store = store

    def operation(self, principal, operation_id):
        with self.store.transaction() as db:
            actor, _ = self.store.sync_subject(db, principal)
            op = db.get(Operation, uuid.UUID(str(operation_id)))
            if not op or op.actor_id != actor.id:
                raise RuleViolation("OPERATION_NOT_FOUND", 404)
            cmd = db.scalar(select(Command).where(Command.operation_id == op.id))
            return {"id": str(op.id), "status": cmd.state if cmd else "ACCEPTED", "error_code": cmd.error_code if cmd else None}

    def _owned_ids(self, db, actor):
        owner_ids = list(db.scalars(select(Principal.id).where(Principal.subject_id == actor.id)))
        if self.store.settings.domain == "BPI":
            owner_ids += list(db.scalars(select(Merchant.principal_id).join(Membership, Membership.merchant_id == Merchant.id).where(Membership.subject_id == actor.id, Membership.revoked_at.is_(None))))
        return list(db.scalars(select(Wallet.id).where(Wallet.owner_id.in_(owner_ids))))

    def _receipt(self, db, payment):
        state = db.scalar(select(PaymentState).where(PaymentState.payment_id == payment.id))
        risk = db.scalar(select(FraudScore).where(FraudScore.payment_id == payment.id))
        child = db.scalar(select(Operation).where(Operation.parent_id == payment.operation_id, Operation.slot == "INCLUDE"))
        journal = db.scalar(select(Journal).where(Journal.operation_id == child.id)) if child else None
        tx = db.scalar(select(ChainTransaction).where(ChainTransaction.journal_id == journal.id)) if journal else None
        block = db.get(Block, tx.block_id) if tx else None
        sender, receiver = db.get(Wallet, payment.sender_id), db.get(Wallet, payment.receiver_id)
        return {"id": str(payment.id), "operation_id": str(payment.operation_id), "sender": sender.label, "receiver": receiver.label,
                "sender_id": str(sender.id), "receiver_id": str(receiver.id), "sender_address": sender.address, "receiver_address": receiver.address,
                "amount_minor": str(payment.amount), "currency": "INR", "fee_minor": "0", "payment_type": payment.payment_type, "purpose": payment.purpose,
                "created_at": wire_time(payment.created_at), "status": state.business_status if state else "DRAFT", "chain_status": state.chain_status if state else "NOT_SUBMITTED",
                "settlement_status": state.settlement_status if state else "NOT_STARTED", "reason_code": state.reason_code if state else None,
                "risk_status": risk.decision if risk else None, "risk_level": "LOW" if risk and risk.score <= 30 else "MEDIUM" if risk and risk.score <= 60 else "HIGH" if risk and risk.score <= 80 else "CRITICAL" if risk else None,
                "block_height": str(block.height) if block else None, "transaction_hash": tx.transaction_hash if tx else None,
                "payload_digest": payment.payload_digest, "expires_at": wire_time(payment.expires_at), "environment": "sandbox", "value_kind": "simulated", "domain": "BPI"}

    def receipt(self, principal, payment_id):
        with self.store.transaction() as db:
            actor, _ = self.store.sync_subject(db, principal)
            ids = self._owned_ids(db, actor)
            payment = db.get(Payment, uuid.UUID(str(payment_id)))
            if not payment or not (payment.sender_id in ids or payment.receiver_id in ids):
                raise RuleViolation("PAYMENT_NOT_FOUND", 404)
            return self._receipt(db, payment)

    def payments(self, principal, wallet_id=None, status=None, direction=None, cursor=None, limit=25):
        with self.store.transaction() as db:
            actor, _ = self.store.sync_subject(db, principal)
            ids = self._owned_ids(db, actor)
            if wallet_id:
                wid = uuid.UUID(str(wallet_id))
                if wid not in ids:
                    raise RuleViolation("WALLET_NOT_FOUND", 404)
                ids = [wid]
            query = select(Payment).outerjoin(PaymentState, PaymentState.payment_id == Payment.id)
            clause = Payment.sender_id.in_(ids) if direction == "sent" else Payment.receiver_id.in_(ids) if direction == "received" else or_(Payment.sender_id.in_(ids), Payment.receiver_id.in_(ids))
            query = query.where(clause)
            if status == "pending": query = query.where(PaymentState.business_status.in_(["AUTHORIZED", "RISK_REVIEW", "RESERVED", "SETTLEMENT_PENDING", "SETTLEMENT_UNKNOWN"]))
            elif status == "failed": query = query.where(PaymentState.business_status.in_(["REJECTED", "RETURNED"]))
            elif status == "refund": query = query.where(Payment.original_payment_id.is_not(None))
            elif status == "flagged": query = query.where(PaymentState.business_status == "RISK_REVIEW")
            elif status == "merchant": query = query.where(Payment.payment_type != "P2P")
            if cursor:
                marker = db.get(Payment, uuid.UUID(cursor))
                if not marker or not (marker.sender_id in ids or marker.receiver_id in ids):
                    raise RuleViolation("INVALID_CURSOR", 422)
                query = query.where(or_(Payment.created_at < marker.created_at, (Payment.created_at == marker.created_at) & (Payment.id < marker.id)))
            rows = db.scalars(query.order_by(Payment.created_at.desc(), Payment.id.desc()).limit(limit+1)).all()
            return {"items": [self._receipt(db, p) for p in rows[:limit]], "next_cursor": str(rows[limit-1].id) if len(rows) > limit else None}

    def dashboard(self, principal, wallet_id):
        with self.store.transaction() as db:
            actor, _ = self.store.sync_subject(db, principal)
            wallet = self.store.owned_wallet(db, actor, wallet_id)
            start = utcnow().astimezone(ZoneInfo("Asia/Kolkata")).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            def total(column):
                return str(int(db.scalar(select(func.coalesce(func.sum(Payment.amount),0)).join(PaymentState, PaymentState.payment_id == Payment.id).where(column == wallet.id, PaymentState.business_status == "COMPLETED", PaymentState.completed_at >= start, Payment.original_payment_id.is_(None))) or 0))
            return {"wallet_id": str(wallet.id), "balances": self.store.wallet_values(db, wallet), "sent_minor": total(Payment.sender_id), "received_minor": total(Payment.receiver_id), "period_start": wire_time(start), "timezone": "Asia/Kolkata", "as_of": wire_time(), "environment": "sandbox"}

    def merchants(self, principal):
        with self.store.transaction() as db:
            actor, _ = self.store.sync_subject(db, principal)
            rows = db.execute(select(Merchant, Membership).join(Membership, Membership.merchant_id == Merchant.id).where(Membership.subject_id == actor.id, Membership.revoked_at.is_(None))).all()
            return [{"id": str(m.id), "owner_id": str(m.principal_id), "name": m.display_name, "category": m.category, "status": m.status, "role": membership.role} for m, membership in rows]

    def notifications(self, principal, notification_id=None):
        with self.store.transaction() as db:
            actor,_=self.store.sync_subject(db,principal)
            if notification_id:
                row=db.get(Notification,uuid.UUID(str(notification_id)))
                if not row or row.subject_id!=actor.id: raise RuleViolation("NOTIFICATION_NOT_FOUND",404)
                row.read_at=utcnow()
                return {"status":"READ"}
            rows=db.scalars(select(Notification).where(Notification.subject_id==actor.id).order_by(Notification.created_at.desc()).limit(50)).all()
            return {"items":[{"id":str(n.id),"message":n.message,"read":n.read_at is not None,"time":wire_time(n.created_at)} for n in rows]}

    def merchant_report(self,principal,merchant_id):
        from .commerce import Commerce
        with self.store.transaction() as db:
            actor,_=self.store.sync_subject(db,principal)
            merchant,_=Commerce(self.store).member(db,actor,merchant_id)
            wallet=db.scalar(select(Wallet).where(Wallet.owner_id==merchant.principal_id))
            invoices=db.scalars(select(Invoice).where(Invoice.merchant_id==merchant.id).order_by(Invoice.created_at.desc()).limit(100)).all()
            orders=db.scalars(select(CommerceOrder).where(CommerceOrder.merchant_id==merchant.id).order_by(CommerceOrder.created_at.desc()).limit(100)).all()
            products=db.scalars(select(Product).where(Product.merchant_id==merchant.id,Product.deleted_at.is_(None)).order_by(Product.created_at.desc()).limit(100)).all()
            daily={};customers={}
            if wallet:
                rows=db.scalars(select(Payment).join(PaymentState,PaymentState.payment_id==Payment.id).where(Payment.receiver_id==wallet.id,Payment.original_payment_id.is_(None),PaymentState.business_status=="COMPLETED",PaymentState.completed_at>=utcnow()-timedelta(days=30))).all()
                for payment in rows:
                    day=payment.created_at.astimezone(ZoneInfo("Asia/Kolkata")).date().isoformat()
                    daily[day]=daily.get(day,0)+payment.amount
                    reference=str(payment.sender_id)
                    entry=customers.setdefault(reference,{"wallet_reference":reference,"payments":0,"total_minor":0})
                    entry["payments"]+=1;entry["total_minor"]+=payment.amount
            return {"invoices":[{"id":str(i.id),"number":i.number,"total_minor":str(i.total),"status":i.status} for i in invoices],"orders":[{"id":str(o.id),"status":o.status,"total_minor":str(o.total)} for o in orders],"products":[{"id":str(p.id),"name":p.name,"price_minor":str(p.price),"stock":p.stock} for p in products],"daily":[{"date":d,"received_minor":str(total)} for d,total in sorted(daily.items())],"customers":[{**c,"total_minor":str(c["total_minor"])} for c in customers.values()],"window":"Last 30 days; completed incoming payments excluding refunds","environment":"sandbox"}

    def catalog(self, category=None):
        with self.store.transaction() as db:
            query = select(Product).where(Product.deleted_at.is_(None))
            if category: query = query.where(Product.category == category)
            rows = db.scalars(query.order_by(Product.created_at.desc()).limit(100)).all()
            return [{"id": str(p.id), "merchant_id": str(p.merchant_id), "name": p.name, "description": p.description, "category": p.category, "price_minor": str(p.price), "stock": p.stock, "environment": "sandbox", "sample_item": True} for p in rows]

    def orders(self, principal):
        with self.store.transaction() as db:
            actor, _ = self.store.sync_subject(db, principal)
            rows = db.scalars(select(CommerceOrder).where(CommerceOrder.buyer_id == actor.id).order_by(CommerceOrder.created_at.desc()).limit(50)).all()
            return [{"id": str(o.id), "total_minor": str(o.total), "status": o.status, "created_at": wire_time(o.created_at), "environment": "sandbox"} for o in rows]

    def market(self):
        with self.store.transaction() as db:
            ticks = db.scalars(select(Tick).order_by(Tick.sequence.desc()).limit(120)).all()
            last = ticks[0] if ticks else None
            total = int(db.scalar(select(func.coalesce(func.sum(Fill.quantity), 0)).where(Fill.created_at > utcnow()-timedelta(days=1))) or 0)
            from .storage import Account, Balance
            supply = db.scalar(select(Balance.amount).join(Account, Account.id == Balance.account_id).where(Account.asset_code == "FINCOIN", Account.bucket == "ISSUANCE"))
            return {"source": "synthetic", "price_minor": str(last.price) if last else None, "stale": not last or last.observed_at+timedelta(seconds=10) <= utcnow(),
                    "observed_at": wire_time(last.observed_at) if last else None, "supply_atoms": str(supply) if supply is not None else None, "volume_24h_atoms": str(total),
                    "ticks": [{"sequence": str(t.sequence), "price_minor": str(t.price), "time": wire_time(t.observed_at)} for t in reversed(ticks)], "environment": "sandbox"}

    def fincoin_orders(self, principal):
        with self.store.transaction() as db:
            actor, _ = self.store.sync_subject(db, principal)
            ids = self._owned_ids(db, actor)
            rows = db.execute(select(FincoinOrder, Quote).join(Quote, Quote.id == FincoinOrder.quote_id).where(Quote.wallet_id.in_(ids)).order_by(FincoinOrder.created_at.desc()).limit(50)).all()
            return [{"id": str(o.id), "side": q.side, "quantity_atoms": str(q.quantity), "total_minor": str(q.total), "fee_minor": str(q.fee), "status": o.status, "reason_code": o.reason_code, "created_at": wire_time(o.created_at), "environment": "sandbox"} for o, q in rows]

    def settlements(self, principal, wallet_id):
        with self.store.transaction() as db:
            actor, _ = self.store.sync_subject(db, principal)
            wallet = self.store.owned_wallet(db, actor, wallet_id)
            payments = select(Payment.id).where(or_(Payment.sender_id == wallet.id, Payment.receiver_id == wallet.id))
            rows = db.scalars(select(Settlement).where(or_(Settlement.wallet_id == wallet.id, Settlement.payment_id.in_(payments))).order_by(Settlement.created_at.desc()).limit(100)).all()
            return [{"id":str(s.id),"kind":s.kind,"amount_minor":str(s.amount),"status":s.status,"payment_id":str(s.payment_id) if s.payment_id else None,"applied":s.result_applied_at is not None,"created_at":wire_time(s.created_at),"environment":"sandbox"} for s in rows]

    def transfers(self, principal):
        with self.store.transaction() as db:
            actor, _ = self.store.sync_subject(db, principal)
            ids = self._owned_ids(db, actor)
            rows = db.execute(select(AssetTransfer, ChainTransaction.transaction_hash).outerjoin(Journal, Journal.operation_id == AssetTransfer.operation_id).outerjoin(ChainTransaction, ChainTransaction.journal_id == Journal.id).where(or_(AssetTransfer.sender_id.in_(ids),AssetTransfer.receiver_id.in_(ids))).order_by(AssetTransfer.created_at.desc()).limit(100)).all()
            return [{"id":str(t.id),"quantity_atoms":str(t.quantity),"status":t.status,"transaction_hash":tx,"created_at":wire_time(t.created_at),"environment":"sandbox"} for t,tx in rows]

    def admin(self, principal):
        with self.store.transaction() as db:
            actor, _ = self.store.sync_subject(db, principal)
            grant = db.scalar(select(DomainGrant).where(DomainGrant.subject_id == actor.id, DomainGrant.role.in_(["admin", "compliance"]), DomainGrant.revoked_at.is_(None)))
            if grant is None or principal["assurance"] != "MFA" or principal["auth_time"] < int(utcnow().timestamp())-300:
                raise RuleViolation("DOMAIN_STAFF_MFA_REQUIRED", 403)
            network = self.store.network(db)
            head = db.scalar(select(Head).where(Head.network_id == network.id))
            self.store.audit(db, "admin.read", "ALLOWED", actor.id)
            audits = db.scalars(select(Audit).order_by(Audit.created_at.desc()).limit(50)).all()
            return {"domain": network.domain, "network_id": network.network_code, "status": network.status, "height": str(head.height),
                    "wallets": db.scalar(select(func.count()).select_from(Wallet)), "blocks": db.scalar(select(func.count()).select_from(Block)),
                    "transactions": db.scalar(select(func.count()).select_from(ChainTransaction)), "validators": db.scalar(select(func.count()).select_from(Validator).where(Validator.active.is_(True))),
                    "audit": [{"id": str(a.id), "action": a.action, "result": a.result, "time": wire_time(a.created_at)} for a in audits], "environment": "sandbox"}
