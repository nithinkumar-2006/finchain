from sqlalchemy import Column, Uuid, String, Integer, BigInteger, JSON, Boolean, ForeignKey, UniqueConstraint, CheckConstraint
from .storage import Base, Record, UTC, Q, utcnow


class Merchant(Record, Base):
    __tablename__ = "merchant_accounts"
    __table_args__ = {"schema": "app"}
    principal_id = Column(Uuid, ForeignKey("core.principals.id"), nullable=False, unique=True)
    display_name = Column(String(80), nullable=False)
    category = Column(String(32), nullable=False)
    status = Column(String(24), nullable=False, default="SANDBOX_ACTIVE")
    timezone = Column(String(40), nullable=False, default="Asia/Kolkata")


class Membership(Record, Base):
    __tablename__ = "merchant_memberships"
    __table_args__ = (UniqueConstraint("merchant_id", "subject_id"), {"schema": "app"})
    merchant_id = Column(Uuid, ForeignKey("app.merchant_accounts.id"), nullable=False, index=True)
    subject_id = Column(Uuid, ForeignKey("core.subjects.id"), nullable=False, index=True)
    role = Column(String(16), nullable=False)
    revoked_at = Column(UTC)


class PaymentRequest(Record, Base):
    __tablename__ = "payment_requests"
    __table_args__ = (CheckConstraint("amount > 0", name="positive_request"), {"schema": "app"})
    operation_id = Column(Uuid, ForeignKey("ops.operations.id"), nullable=False, unique=True)
    wallet_id = Column(Uuid, ForeignKey("ledger.wallets.id"), nullable=False, index=True)
    token_digest = Column(String(64), nullable=False, unique=True)
    amount = Column(BigInteger, nullable=False)
    expires_at = Column(UTC, nullable=False)
    status = Column(String(16), nullable=False, default="OPEN")
    active_payment_id = Column(Uuid)
    order_id = Column(Uuid, ForeignKey("app.commerce_orders.id"))


class QRPayment(Record, Base):
    __tablename__ = "qr_payments"
    __table_args__ = {"schema": "app"}
    request_id = Column(Uuid, ForeignKey("app.payment_requests.id"), nullable=False, unique=True)
    signed_link = Column(String(600), nullable=False)


class Payment(Record, Base):
    __tablename__ = "payments"
    __table_args__ = (CheckConstraint("amount > 0", name="positive_payment"), {"schema": "app"})
    operation_id = Column(Uuid, ForeignKey("ops.operations.id"), nullable=False, unique=True)
    actor_id = Column(Uuid, ForeignKey("core.subjects.id"), nullable=False, index=True)
    sender_id = Column(Uuid, ForeignKey("ledger.wallets.id"), nullable=False, index=True)
    receiver_id = Column(Uuid, ForeignKey("ledger.wallets.id"), nullable=False, index=True)
    amount = Column(BigInteger, nullable=False)
    payment_type = Column(String(8), nullable=False)
    expires_at = Column(UTC, nullable=False)
    request_id = Column(Uuid, ForeignKey("app.payment_requests.id"), index=True)
    original_payment_id = Column(Uuid, ForeignKey("app.payments.id"), index=True)
    purpose = Column(String(16), nullable=False, default="PAYMENT")
    payload = Column(JSON, nullable=False)
    payload_digest = Column(String(64), nullable=False)


class PaymentState(Record, Base):
    __tablename__ = "payment_states"
    __table_args__ = {"schema": "ledger"}
    payment_id = Column(Uuid, ForeignKey("app.payments.id"), nullable=False, unique=True)
    business_status = Column(String(32), nullable=False, default="AUTHORIZED")
    chain_status = Column(String(16), nullable=False, default="NOT_SUBMITTED")
    settlement_status = Column(String(16), nullable=False, default="NOT_STARTED")
    reason_code = Column(String(40))
    completed_at = Column(UTC)
    version = Column(Integer, nullable=False, default=1)


class FraudScore(Record, Base):
    __tablename__ = "fraud_scores"
    __table_args__ = (CheckConstraint("score >= 0 AND score <= 100", name="risk_range"), {"schema": "app"})
    payment_id = Column(Uuid, ForeignKey("app.payments.id"), nullable=False, unique=True)
    policy_version = Column(String(16), nullable=False, default="rules-v1")
    payload_digest = Column(String(64), nullable=False)
    score = Column(Integer, nullable=False)
    decision = Column(String(16), nullable=False)
    reasons = Column(JSON, nullable=False)
    expires_at = Column(UTC, nullable=False)


class FraudEvent(Record, Base):
    __tablename__ = "fraud_events"
    __table_args__ = {"schema": "app"}
    payment_id = Column(Uuid, ForeignKey("app.payments.id"), nullable=False, index=True)
    reviewer_id = Column(Uuid, ForeignKey("core.subjects.id"))
    decision = Column(String(16), nullable=False)
    reason = Column(String(300), nullable=False)


class Refund(Record, Base):
    __tablename__ = "refunds"
    __table_args__ = {"schema": "app"}
    original_payment_id = Column(Uuid, ForeignKey("app.payments.id"), nullable=False, index=True)
    refund_payment_id = Column(Uuid, ForeignKey("app.payments.id"), nullable=False, unique=True)
    amount = Column(BigInteger, nullable=False)


class Settlement(Record, Base):
    __tablename__ = "settlements"
    __table_args__ = {"schema": "ledger"}
    operation_id = Column(Uuid, ForeignKey("ops.operations.id"), nullable=False, unique=True)
    payment_id = Column(Uuid, ForeignKey("app.payments.id"), unique=True)
    wallet_id = Column(Uuid, ForeignKey("ledger.wallets.id"), nullable=False)
    kind = Column(String(16), nullable=False)
    amount = Column(BigInteger, nullable=False)
    scenario = Column(String(16), nullable=False, default="SUCCESS")
    status = Column(String(16), nullable=False, default="PENDING")
    result_applied_at = Column(UTC)
    next_check_at = Column(UTC, nullable=False, default=utcnow)


class GatewayEvidence(Record, Base):
    __tablename__ = "gateway_transactions"
    __table_args__ = {"schema": "ops"}
    settlement_id = Column(Uuid, ForeignKey("ledger.settlements.id"), nullable=False, index=True)
    provider_event_id = Column(Uuid, nullable=False, unique=True)
    response_digest = Column(String(64), nullable=False)
    response = Column(JSON, nullable=False)
    status = Column(String(16), nullable=False)


class Product(Record, Base):
    __tablename__ = "merchant_products"
    __table_args__ = (CheckConstraint("price > 0 AND stock >= 0", name="product_values"), {"schema": "app"})
    merchant_id = Column(Uuid, ForeignKey("app.merchant_accounts.id"), nullable=False, index=True)
    name = Column(String(100), nullable=False)
    description = Column(String(500), nullable=False)
    category = Column(String(32), nullable=False)
    price = Column(BigInteger, nullable=False)
    stock = Column(Integer, nullable=False)
    deleted_at = Column(UTC)


class CommerceOrder(Record, Base):
    __tablename__ = "commerce_orders"
    __table_args__ = {"schema": "app"}
    operation_id = Column(Uuid, ForeignKey("ops.operations.id"), nullable=False, unique=True)
    buyer_id = Column(Uuid, ForeignKey("core.subjects.id"), nullable=False, index=True)
    merchant_id = Column(Uuid, ForeignKey("app.merchant_accounts.id"), nullable=False, index=True)
    total = Column(BigInteger, nullable=False)
    status = Column(String(24), nullable=False, default="PAYMENT_PENDING")
    reservation_expires_at = Column(UTC, nullable=False)
    paid_at = Column(UTC)


class OrderItem(Record, Base):
    __tablename__ = "order_items"
    __table_args__ = (CheckConstraint("quantity > 0 AND unit_price > 0", name="order_item_values"), {"schema": "app"})
    order_id = Column(Uuid, ForeignKey("app.commerce_orders.id"), nullable=False, index=True)
    product_id = Column(Uuid, ForeignKey("app.merchant_products.id"), nullable=False)
    name_snapshot = Column(String(100), nullable=False)
    unit_price = Column(BigInteger, nullable=False)
    quantity = Column(Integer, nullable=False)


class Invoice(Record, Base):
    __tablename__ = "invoices"
    __table_args__ = (UniqueConstraint("merchant_id", "number"), {"schema": "app"})
    merchant_id = Column(Uuid, ForeignKey("app.merchant_accounts.id"), nullable=False, index=True)
    request_id = Column(Uuid, ForeignKey("app.payment_requests.id"), nullable=False, unique=True)
    number = Column(String(40), nullable=False)
    lines = Column(JSON, nullable=False)
    total = Column(BigInteger, nullable=False)
    status = Column(String(16), nullable=False, default="ISSUED")


class Approval(Record, Base):
    __tablename__ = "approval_decisions"
    __table_args__ = (UniqueConstraint("payment_id", "approver_id"), {"schema": "app"})
    payment_id = Column(Uuid, ForeignKey("app.payments.id"), nullable=False)
    approver_id = Column(Uuid, ForeignKey("core.subjects.id"), nullable=False)
    payload_digest = Column(String(64), nullable=False)
    decision = Column(String(16), nullable=False)


class APIKey(Record, Base):
    __tablename__ = "api_keys"
    __table_args__ = {"schema": "app"}
    merchant_id = Column(Uuid, ForeignKey("app.merchant_accounts.id"), nullable=False, index=True)
    creator_id = Column(Uuid, ForeignKey("core.subjects.id"), nullable=False)
    prefix = Column(String(16), nullable=False)
    secret_digest = Column(String(64), nullable=False, unique=True)
    scopes = Column(JSON, nullable=False)
    expires_at = Column(UTC, nullable=False)
    revoked_at = Column(UTC)


class Webhook(Record, Base):
    __tablename__ = "webhooks"
    __table_args__ = {"schema": "app"}
    merchant_id = Column(Uuid, ForeignKey("app.merchant_accounts.id"), nullable=False, index=True)
    destination = Column(String(300), nullable=False)
    events = Column(JSON, nullable=False)
    secret_ciphertext = Column(__import__('sqlalchemy').LargeBinary, nullable=False)
    status = Column(String(16), nullable=False, default="UNVERIFIED")


class WebhookDelivery(Record, Base):
    __tablename__ = "webhook_deliveries"
    __table_args__ = (UniqueConstraint("webhook_id", "event_id"), {"schema": "ops"})
    webhook_id = Column(Uuid, ForeignKey("app.webhooks.id"), nullable=False, index=True)
    event_id = Column(Uuid, nullable=False)
    event_type = Column(String(48), nullable=False)
    payload = Column(JSON, nullable=False)
    status = Column(String(16), nullable=False, default="QUEUED")
    attempts = Column(Integer, nullable=False, default=0)
    response_status = Column(Integer)
    next_attempt_at = Column(UTC, nullable=False, default=utcnow)


class WebhookInbox(Record, Base):
    __tablename__ = "webhook_inbox"
    __table_args__ = (UniqueConstraint("webhook_id", "event_id"), {"schema": "app"})
    webhook_id = Column(Uuid, ForeignKey("app.webhooks.id"), nullable=False)
    event_id = Column(Uuid, nullable=False)
    payload_digest = Column(String(64), nullable=False)


class Notification(Record, Base):
    __tablename__ = "notifications"
    __table_args__ = {"schema": "app"}
    subject_id = Column(Uuid, ForeignKey("core.subjects.id"), nullable=False, index=True)
    message = Column(String(300), nullable=False)
    read_at = Column(UTC)


class Setting(Record, Base):
    __tablename__ = "system_settings"
    __table_args__ = {"schema": "app"}
    setting_key = Column(String(80), nullable=False, unique=True)
    value = Column(JSON, nullable=False)
    version = Column(Integer, nullable=False, default=1)


BPI_TABLES = tuple(value.__table__ for value in list(globals().values()) if isinstance(value, type) and value.__module__ == __name__ and hasattr(value, "__table__"))
