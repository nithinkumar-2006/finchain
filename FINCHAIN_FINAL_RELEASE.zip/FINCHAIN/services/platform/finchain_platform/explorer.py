"""Public proof projection. The public API has no private database credentials."""
import os
import time
from fastapi import FastAPI, Query
from fastapi.responses import JSONResponse
from sqlalchemy import Column, Uuid, String, BigInteger, JSON, ForeignKey, UniqueConstraint, create_engine, select, func
from sqlalchemy.orm import declarative_base, sessionmaker
from .storage import Record, Block, ChainTransaction, Validator
from .protocol import verify_block, merkle_proof, wire_time

PublicBase = declarative_base()


class PublicBlock(Record, PublicBase):
    __tablename__ = "public_blocks"
    __table_args__ = (UniqueConstraint("network_id", "height"),)
    network_id = Column(String(80), nullable=False)
    height = Column(BigInteger, nullable=False)
    block_hash = Column(String(64), nullable=False, unique=True)
    header = Column(JSON, nullable=False)
    signature = Column(String(86), nullable=False)
    validator_public_key = Column(String(64), nullable=False)
    body = Column(JSON, nullable=False)


class PublicTransaction(Record, PublicBase):
    __tablename__ = "public_transactions"
    block_id = Column(Uuid, ForeignKey("public_blocks.id"), nullable=False, index=True)
    transaction_hash = Column(String(64), nullable=False, unique=True)
    tx_index = Column(BigInteger, nullable=False)
    journal_commitment = Column(String(64), nullable=False)


class Projector:
    def __init__(self, source_engine, destination_engine):
        self.source, self.destination = source_engine, destination_engine

    def step(self):
        with sessionmaker(self.destination).begin() as target:
            last = target.scalar(select(PublicBlock).order_by(PublicBlock.height.desc()).limit(1))
            height, previous = (last.height, last.block_hash) if last else (-1, "0"*64)
            with sessionmaker(self.source)() as source:
                block = source.scalar(select(Block).where(Block.height == height+1))
                if block is None: return False
                public_key = source.scalar(select(Validator.public_key).where(Validator.id == block.validator_id))
                pairs = source.execute(select(ChainTransaction.transaction_hash, ChainTransaction.journal_commitment).where(ChainTransaction.block_id == block.id).order_by(ChainTransaction.tx_index)).all()
                body = [list(p) for p in pairs]
                verify_block(public_key, block.header, body, block.block_hash, block.signature, previous, height+1)
                allowed = {"protocol_version", "network_id", "height", "previous_hash", "timestamp", "merkle_root", "transaction_count", "writer_epoch", "validator_key_id", "policy_commitment"}
                if set(block.header)-allowed:
                    raise ValueError("Public header contains forbidden fields")
                row = PublicBlock(id=block.id, created_at=block.created_at, network_id=block.header["network_id"], height=block.height, block_hash=block.block_hash,
                    header=block.header, signature=block.signature, validator_public_key=public_key.hex(), body=body)
                target.add(row)
                target.flush()
                for i, (tx, jc) in enumerate(pairs):
                    target.add(PublicTransaction(block_id=block.id, transaction_hash=tx, tx_index=i, journal_commitment=jc))
        return True


def block_dict(row):
    return {"height": str(row.height), "block_hash": row.block_hash, "header": row.header, "signature": row.signature,
            "validator_public_key": row.validator_public_key, "body": row.body, "environment": "sandbox"}


def create_app(databases=None):
    databases = databases or {"bpi": os.environ["EXPLORER_BPI_DATABASE_URL"], "fincoin": os.environ["EXPLORER_FINCOIN_DATABASE_URL"]}
    engines = {domain: create_engine(url, hide_parameters=True, pool_pre_ping=True) for domain, url in databases.items()}
    app = FastAPI(title="FINCHAIN Public Proof Explorer", docs_url=None, redoc_url=None)

    @app.middleware("http")
    async def headers(request, call_next):
        response = await call_next(request)
        response.headers.update({"X-Content-Type-Options": "nosniff", "Content-Security-Policy": "default-src 'none'; frame-ancestors 'none'", "Referrer-Policy": "no-referrer"})
        return response

    def db_for(domain):
        if domain not in engines: raise ValueError("Unknown domain")
        return sessionmaker(engines[domain])()

    @app.exception_handler(ValueError)
    async def invalid(_, exc): return JSONResponse({"code": "INVALID_PUBLIC_QUERY"}, status_code=422)

    @app.get("/v1/explorer/{domain}/blocks")
    def blocks(domain: str, before: int | None=None, limit: int=Query(default=20, ge=1, le=100)):
        with db_for(domain) as db:
            query = select(PublicBlock)
            if before is not None: query = query.where(PublicBlock.height < before)
            rows = db.scalars(query.order_by(PublicBlock.height.desc()).limit(limit)).all()
            return {"items": [block_dict(b) for b in rows], "next_before": rows[-1].height if len(rows)==limit else None}

    @app.get("/v1/explorer/{domain}/blocks/{reference}")
    def block(domain: str, reference: str):
        if len(reference) > 64: raise ValueError()
        with db_for(domain) as db:
            row = db.scalar(select(PublicBlock).where(PublicBlock.height == int(reference))) if reference.isdigit() else db.scalar(select(PublicBlock).where(PublicBlock.block_hash == reference))
            if not row: return JSONResponse({"code": "PUBLIC_RECORD_NOT_FOUND"}, status_code=404)
            return block_dict(row)

    @app.get("/v1/explorer/{domain}/transactions")
    def transactions(domain: str, limit: int=Query(default=20, ge=1, le=100)):
        with db_for(domain) as db:
            rows = db.execute(select(PublicTransaction, PublicBlock.height).join(PublicBlock, PublicBlock.id == PublicTransaction.block_id).order_by(PublicBlock.height.desc(), PublicTransaction.tx_index.desc()).limit(limit)).all()
            return {"items": [{"transaction_hash": t.transaction_hash, "journal_commitment": t.journal_commitment, "height": str(height)} for t,height in rows]}

    @app.get("/v1/explorer/{domain}/transactions/{transaction_hash}")
    def transaction(domain: str, transaction_hash: str):
        import re
        if not re.fullmatch("[0-9a-f]{64}", transaction_hash): raise ValueError()
        with db_for(domain) as db:
            tx = db.scalar(select(PublicTransaction).where(PublicTransaction.transaction_hash == transaction_hash))
            if not tx: return JSONResponse({"code": "PUBLIC_RECORD_NOT_FOUND"}, status_code=404)
            block = db.get(PublicBlock, tx.block_id)
            return {"transaction_hash": tx.transaction_hash, "journal_commitment": tx.journal_commitment,
                    "proof": merkle_proof(block.body, tx.tx_index), "block": block_dict(block), "environment": "sandbox"}

    @app.get("/v1/explorer/{domain}/network")
    def network(domain: str):
        with db_for(domain) as db:
            head = db.scalar(select(PublicBlock).order_by(PublicBlock.height.desc()).limit(1))
            return {"network_id": head.network_id if head else None, "height": str(head.height) if head else None,
                    "blocks": db.scalar(select(func.count()).select_from(PublicBlock)), "transactions": db.scalar(select(func.count()).select_from(PublicTransaction)),
                    "last_block_at": head.header["timestamp"] if head else None, "consensus": "Single authorized producer; followers do not vote", "environment": "sandbox"}

    return app


def main():
    source = create_engine(os.environ["PROJECTION_SOURCE_DATABASE_URL"], hide_parameters=True)
    destination = create_engine(os.environ["PROJECTION_DATABASE_URL"], hide_parameters=True)
    projector = Projector(source, destination)
    while True:
        if not projector.step(): time.sleep(1)


if __name__ == "__main__": main()
