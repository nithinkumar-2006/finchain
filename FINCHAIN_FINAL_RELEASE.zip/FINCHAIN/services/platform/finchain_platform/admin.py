"""Scoped, audited operations. No endpoint edits balances, issuance, keys or history."""
import uuid
from sqlalchemy import select
from .storage import DomainGrant, Command, Wallet, Operation, Subject, utcnow
from .ledger import RuleViolation


class Administration:
    def __init__(self, store): self.store = store

    def check(self, db, actor, principal, roles=("admin","compliance")):
        grant = db.scalar(select(DomainGrant).where(DomainGrant.subject_id == actor.id,DomainGrant.role.in_(roles),DomainGrant.revoked_at.is_(None)))
        if not grant or principal.get("assurance") != "MFA" or principal.get("auth_time",0) < int(utcnow().timestamp())-300:
            raise RuleViolation("DOMAIN_STAFF_MFA_REQUIRED",403)

    def review_queue(self, principal):
        if self.store.settings.domain != "BPI": raise RuleViolation("BPI_ONLY",404)
        from .bpi_models import Payment,PaymentState,FraudScore
        with self.store.transaction() as db:
            actor,_=self.store.sync_subject(db,principal)
            self.check(db,actor,principal)
            rows=db.execute(select(Payment,PaymentState,FraudScore).join(PaymentState,PaymentState.payment_id==Payment.id).join(FraudScore,FraudScore.payment_id==Payment.id).where(PaymentState.business_status=="RISK_REVIEW").order_by(Payment.created_at).limit(100)).all()
            self.store.audit(db,"risk.queue.read","ALLOWED",actor.id)
            return [{"payment_id":str(p.id),"amount_minor":str(p.amount),"payment_type":p.payment_type,"score":r.score,"reasons":r.reasons,"status":s.business_status,"environment":"sandbox"} for p,s,r in rows]

    def submit(self, principal, key, action, target, decision):
        allowed={"NETWORK":{"PAUSED","ACTIVE"},"WALLET":{"RESTRICTED","ACTIVE"},"RISK":{"REJECT","CANCEL"}}
        if action not in allowed or decision not in allowed[action] or action=="RISK" and self.store.settings.domain!="BPI":
            raise RuleViolation("INVALID_ADMIN_ACTION",422)
        with self.store.transaction() as db:
            actor,_=self.store.sync_subject(db,principal)
            self.check(db,actor,principal,("admin",) if action=="NETWORK" else ("admin","compliance"))
            def create(op):
                payload={"action":action,"target":str(target) if target else None,"decision":decision,"session_id":principal["session_id"],"credentials_version":principal["credentials_version"]}
                db.add(Command(operation_id=op.id,kind="ADMIN",payload=payload))
                return {"operation_id":str(op.id),"status":"QUEUED","environment":"sandbox"}
            return self.store.idempotent(db,actor,"admin-action",key,{"action":action,"target":str(target) if target else None,"decision":decision},create)

    def process(self, db, command, validate):
        operation=db.get(Operation,command.operation_id)
        actor=db.get(Subject,operation.actor_id)
        value=command.payload
        principal=validate(actor.id,uuid.UUID(value["session_id"]),value["credentials_version"])
        self.check(db,actor,principal,("admin",) if value["action"]=="NETWORK" else ("admin","compliance"))
        if value["action"]=="NETWORK":
            self.store.network(db).status=value["decision"]
        elif value["action"]=="WALLET":
            wallet=db.get(Wallet,uuid.UUID(value["target"]))
            if not wallet: raise RuleViolation("WALLET_NOT_FOUND",404)
            wallet.status=value["decision"]
        else:
            from .bpi_models import PaymentState,FraudEvent
            state=db.scalar(select(PaymentState).where(PaymentState.payment_id==uuid.UUID(value["target"])).with_for_update())
            if not state or state.business_status!="RISK_REVIEW": raise RuleViolation("CASE_NOT_REVIEWABLE")
            state.business_status="REJECTED" if value["decision"]=="REJECT" else "CANCELED"
            state.reason_code="REVIEW_"+value["decision"]
            state.chain_status="NOT_SUBMITTED"
            db.add(FraudEvent(payment_id=state.payment_id,reviewer_id=actor.id,decision=value["decision"],reason="Manual sandbox review; no funds moved. A new payment requires fresh authorization and risk assessment."))
        command.state="SUCCEEDED"
        self.store.audit(db,"admin."+value["action"].lower(),value["decision"],actor.id,operation.id)
