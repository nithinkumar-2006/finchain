import uuid
from datetime import timedelta
from sqlalchemy import select
from .storage import Principal, Wallet, utcnow
from .bpi_models import Merchant, Membership, Product, CommerceOrder, OrderItem, PaymentRequest, QRPayment, Invoice, Payment, Approval
from .ledger import RuleViolation
from .protocol import integer

CATEGORIES = {"Mobile Recharge", "Utilities", "Shopping", "Travel", "Subscriptions", "Services"}


class Commerce:
    def __init__(self, bpi):
        self.bpi = bpi

    def member(self, db, actor, merchant_id, roles=None):
        merchant = db.get(Merchant, uuid.UUID(str(merchant_id)))
        membership = db.scalar(select(Membership).where(Membership.merchant_id == merchant.id, Membership.subject_id == actor.id, Membership.revoked_at.is_(None))) if merchant else None
        if not membership or roles and membership.role not in roles:
            raise RuleViolation("MERCHANT_NOT_FOUND", 404)
        return merchant, membership

    def create_product(self, principal, key, merchant_id, name, description, category, price, stock):
        amount = integer(price, maximum=10000000)
        if category not in CATEGORIES or not 0 <= stock <= 100000:
            raise RuleViolation("INVALID_PRODUCT", 422)
        with self.bpi.transaction() as db:
            actor, _ = self.bpi.sync_subject(db, principal)
            merchant, _ = self.member(db, actor, merchant_id, {"owner"})
            def create(op):
                product = Product(id=uuid.uuid4(), merchant_id=merchant.id, name=name, description=description, category=category, price=amount, stock=stock)
                db.add(product)
                return {"product_id": str(product.id), "status": "CREATED"}
            return self.bpi.idempotent(db, actor, "product", key, {"merchant": str(merchant_id), "name": name, "description": description, "category": category, "price": price, "stock": str(stock)}, create)

    def checkout(self, principal, key, items):
        if not 1 <= len(items) <= 20 or len({i["product_id"] for i in items}) != len(items):
            raise RuleViolation("INVALID_CART", 422)
        with self.bpi.transaction() as db:
            actor, _ = self.bpi.sync_subject(db, principal)
            def create(op):
                products = db.scalars(select(Product).where(Product.id.in_([uuid.UUID(i["product_id"]) for i in items]), Product.deleted_at.is_(None)).order_by(Product.id).with_for_update()).all()
                if len(products) != len(items) or len({p.merchant_id for p in products}) != 1:
                    raise RuleViolation("ONE_MERCHANT_PER_CHECKOUT", 422)
                quantities = {i["product_id"]: i["quantity"] for i in items}
                total = 0
                for product in products:
                    q = quantities[str(product.id)]
                    if type(q) is not int or not 1 <= q <= 100 or q > product.stock:
                        raise RuleViolation("STOCK_UNAVAILABLE")
                    product.stock -= q
                    total += product.price*q
                if total > 10000000:
                    raise RuleViolation("CHECKOUT_LIMIT", 422)
                merchant = db.get(Merchant, products[0].merchant_id)
                wallet = db.scalar(select(Wallet).where(Wallet.owner_id == merchant.principal_id))
                if not wallet:
                    raise RuleViolation("MERCHANT_WALLET_NOT_READY", 409)
                order = CommerceOrder(id=uuid.uuid4(), operation_id=op.id, buyer_id=actor.id, merchant_id=merchant.id, total=total, reservation_expires_at=utcnow()+timedelta(minutes=15))
                db.add(order)
                db.flush()
                for product in products:
                    db.add(OrderItem(order_id=order.id, product_id=product.id, name_snapshot=product.name, unit_price=product.price, quantity=quantities[str(product.id)]))
                request_op = self.bpi.operation(db, "ORDER_REQUEST", actor.id, op.id, "REQUEST")
                request = self.bpi._request(db, request_op, wallet, total, 15, order.id)
                return {"order_id": str(order.id), "total_minor": str(total), "request": request, "status": "PAYMENT_PENDING", "environment": "sandbox"}
            return self.bpi.idempotent(db, actor, "checkout", key, {"items": items}, create)

    def invoice(self, principal, key, merchant_id, lines):
        if not 1 <= len(lines) <= 20:
            raise RuleViolation("INVALID_INVOICE", 422)
        with self.bpi.transaction() as db:
            actor, _ = self.bpi.sync_subject(db, principal)
            merchant, _ = self.member(db, actor, merchant_id, {"owner", "cashier", "maker"})
            wallet = db.scalar(select(Wallet).where(Wallet.owner_id == merchant.principal_id))
            if not wallet:
                raise RuleViolation("MERCHANT_WALLET_NOT_READY")
            total = sum(integer(line["unit_price_minor"], maximum=10000000)*line["quantity"] for line in lines)
            if total > 10000000 or any(type(line["quantity"]) is not int or not 1 <= line["quantity"] <= 100 for line in lines):
                raise RuleViolation("INVALID_INVOICE", 422)
            def create(op):
                req = self.bpi._request(db, op, wallet, total, 60)
                invoice = Invoice(id=uuid.uuid4(), merchant_id=merchant.id, request_id=uuid.UUID(req["request_id"]), number="INV-"+str(op.id)[:8].upper(), lines=lines, total=total)
                db.add(invoice)
                return {"invoice_id": str(invoice.id), "number": invoice.number, "request": req, "total_minor": str(total), "status": "ISSUED"}
            return self.bpi.idempotent(db, actor, "invoice", key, {"merchant_id": str(merchant_id), "lines": lines}, create)

    def grant_membership(self, principal, merchant_id, subject_id, role):
        if role not in {"cashier", "maker", "checker", "integration", "analyst"} or principal["assurance"] != "MFA" or principal["auth_time"] < int(utcnow().timestamp())-300:
            raise RuleViolation("MFA_OR_ROLE_REQUIRED", 403)
        with self.bpi.transaction() as db:
            actor, _ = self.bpi.sync_subject(db, principal)
            merchant, _ = self.member(db, actor, merchant_id, {"owner"})
            from .storage import Subject
            target = db.get(Subject, uuid.UUID(str(subject_id)))
            if not target or target.id == actor.id:
                raise RuleViolation("ELIGIBLE_MEMBER_REQUIRED", 422)
            old = db.scalar(select(Membership).where(Membership.merchant_id == merchant.id, Membership.subject_id == target.id))
            if old:
                if old.role == "owner":
                    raise RuleViolation("OWNER_REPLACEMENT_NOT_SUPPORTED", 409)
                old.role, old.revoked_at = role, None
            else:
                db.add(Membership(merchant_id=merchant.id, subject_id=target.id, role=role))
            self.bpi.audit(db, "merchant.membership", "GRANTED", actor.id)

    def approve(self, principal, payment_id, digest):
        if principal["assurance"] != "MFA" or principal["auth_time"] < int(utcnow().timestamp())-300:
            raise RuleViolation("RECENT_MFA_REQUIRED", 403)
        with self.bpi.transaction() as db:
            actor, _ = self.bpi.sync_subject(db, principal)
            payment = db.get(Payment, uuid.UUID(str(payment_id)))
            if not payment or payment.actor_id == actor.id or payment.payload_digest != digest or payment.expires_at <= utcnow():
                raise RuleViolation("APPROVAL_INELIGIBLE")
            wallet = db.get(Wallet, payment.sender_id)
            merchant = db.scalar(select(Merchant).where(Merchant.principal_id == wallet.owner_id))
            if not merchant:
                raise RuleViolation("APPROVAL_INELIGIBLE")
            self.member(db, actor, merchant.id, {"checker", "owner"})
            if not db.scalar(select(Approval).where(Approval.payment_id == payment.id, Approval.approver_id == actor.id)):
                db.add(Approval(payment_id=payment.id, approver_id=actor.id, payload_digest=digest, decision="APPROVE"))
            self.bpi.audit(db, "merchant.approval", "APPROVED", actor.id, payment.operation_id)
