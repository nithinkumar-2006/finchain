"""Merchant credentials and signed delivery to a local sandbox inbox only."""
import hashlib
import hmac
import secrets
import uuid
from datetime import timedelta
from urllib.parse import urlsplit
import httpx
from sqlalchemy import select
from .storage import Wallet, Outbox, Subject, utcnow
from .bpi_models import APIKey, Webhook, WebhookDelivery, WebhookInbox, Merchant, Membership, Payment
from .commerce import Commerce
from .ledger import RuleViolation
from .protocol import sha, canonical, wire_time

SCOPES={"payments:read","requests:write"}
EVENTS={"settlement.completed","payment.failed"}


class Integrations:
    def __init__(self, store): self.store=store; self.commerce=Commerce(store)

    def member(self, db, principal, merchant_id, write=False):
        actor,_=self.store.sync_subject(db,principal)
        if write and (principal["assurance"]!="MFA" or principal["auth_time"]<int(utcnow().timestamp())-300):
            raise RuleViolation("RECENT_MFA_REQUIRED",403)
        merchant,_=self.commerce.member(db,actor,merchant_id,{"owner","integration"})
        return actor,merchant

    def create_key(self, principal, merchant_id, scopes):
        if not scopes or not set(scopes)<=SCOPES or len(scopes)!=len(set(scopes)): raise RuleViolation("INVALID_SCOPES",422)
        token="fc_sbx_"+secrets.token_urlsafe(32)
        with self.store.transaction() as db:
            actor,merchant=self.member(db,principal,merchant_id,True)
            key=APIKey(id=uuid.uuid4(),merchant_id=merchant.id,creator_id=actor.id,prefix=token[:15],secret_digest=sha(token.encode()),scopes=scopes,expires_at=utcnow()+timedelta(days=30))
            db.add(key)
            self.store.audit(db,"api-key.create","CREATED",actor.id)
            return {"id":str(key.id),"token":token,"scopes":scopes,"expires_at":wire_time(key.expires_at),"shown_once":True}

    def list_config(self, principal, merchant_id):
        with self.store.transaction() as db:
            _,merchant=self.member(db,principal,merchant_id)
            keys=db.scalars(select(APIKey).where(APIKey.merchant_id==merchant.id).order_by(APIKey.created_at.desc())).all()
            hooks=db.scalars(select(Webhook).where(Webhook.merchant_id==merchant.id).order_by(Webhook.created_at.desc())).all()
            deliveries=db.scalars(select(WebhookDelivery).join(Webhook,Webhook.id==WebhookDelivery.webhook_id).where(Webhook.merchant_id==merchant.id).order_by(WebhookDelivery.created_at.desc()).limit(50)).all()
            return {"keys":[{"id":str(k.id),"prefix":k.prefix,"scopes":k.scopes,"expires_at":wire_time(k.expires_at),"revoked":k.revoked_at is not None} for k in keys],"webhooks":[{"id":str(h.id),"destination":h.destination,"status":h.status,"events":h.events} for h in hooks],"deliveries":[{"id":str(d.id),"event_type":d.event_type,"status":d.status,"attempts":d.attempts,"response_status":d.response_status} for d in deliveries]}

    def revoke_key(self, principal, merchant_id, key_id):
        with self.store.transaction() as db:
            actor,merchant=self.member(db,principal,merchant_id,True)
            key=db.get(APIKey,uuid.UUID(str(key_id)))
            if not key or key.merchant_id!=merchant.id: raise RuleViolation("KEY_NOT_FOUND",404)
            key.revoked_at=utcnow()
            self.store.audit(db,"api-key.revoke","REVOKED",actor.id)

    def key_context(self, db, token, scope):
        if not token.startswith("fc_sbx_") or len(token)!=50: raise RuleViolation("INVALID_API_KEY",401)
        key=db.scalar(select(APIKey).where(APIKey.secret_digest==sha(token.encode())).with_for_update())
        if not key or key.revoked_at or key.expires_at<=utcnow() or scope not in key.scopes: raise RuleViolation("INVALID_API_KEY",401)
        if db.get(Subject,key.creator_id).status!="ACTIVE": raise RuleViolation("INVALID_API_KEY",401)
        member=db.scalar(select(Membership).where(Membership.merchant_id==key.merchant_id,Membership.subject_id==key.creator_id,Membership.revoked_at.is_(None),Membership.role.in_(["owner","integration"])))
        if not member: raise RuleViolation("INVALID_API_KEY",401)
        merchant=db.get(Merchant,key.merchant_id)
        if merchant.status!="SANDBOX_ACTIVE": raise RuleViolation("MERCHANT_RESTRICTED",403)
        return key,merchant

    def key_payments(self, token):
        with self.store.transaction() as db:
            key,merchant=self.key_context(db,token,"payments:read")
            wallet=db.scalar(select(Wallet).where(Wallet.owner_id==merchant.principal_id))
            rows=db.scalars(select(Payment).where(Payment.receiver_id==wallet.id).order_by(Payment.created_at.desc()).limit(50)).all() if wallet else []
            from .queries import Queries
            self.store.audit(db,"api-key.payments","READ",key.creator_id)
            return {"items":[Queries(self.store)._receipt(db,p) for p in rows]}

    def key_request(self, token, idempotency, amount):
        from .storage import Subject
        from .protocol import integer
        value=integer(amount,maximum=10000000)
        with self.store.transaction() as db:
            key,merchant=self.key_context(db,token,"requests:write")
            actor=db.scalar(select(Subject).where(Subject.id==key.creator_id).with_for_update())
            if actor.status!="ACTIVE": raise RuleViolation("INVALID_API_KEY",401)
            wallet=db.scalar(select(Wallet).where(Wallet.owner_id==merchant.principal_id))
            if not wallet: raise RuleViolation("WALLET_NOT_READY")
            return self.store.idempotent(db,actor,"key-request:"+str(key.id),idempotency,{"amount_minor":amount},lambda op:self.store._request(db,op,wallet,value,15))

    def create_hook(self, principal, merchant_id):
        secret=secrets.token_urlsafe(32)
        with self.store.transaction() as db:
            actor,merchant=self.member(db,principal,merchant_id,True)
            existing=db.scalar(select(Webhook).where(Webhook.merchant_id==merchant.id,Webhook.status=="ACTIVE"))
            if existing: raise RuleViolation("SANDBOX_WEBHOOK_ALREADY_ACTIVE")
            hook=Webhook(id=uuid.uuid4(),merchant_id=merchant.id,destination="sandbox://local-inbox",events=sorted(EVENTS),status="ACTIVE")
            hook.secret_ciphertext=self.store.envelope.encrypt(f"webhook:{hook.id}",secret.encode())
            db.add(hook)
            self.store.audit(db,"webhook.create","ACTIVE",actor.id)
            return {"id":str(hook.id),"signing_secret":secret,"destination":hook.destination,"shown_once":True}

    def queue_events(self):
        with self.store.transaction() as db:
            self.store.writer(db)
            events=db.scalars(select(Outbox).where(Outbox.published_at.is_(None)).order_by(Outbox.created_at).limit(30).with_for_update()).all()
            for event in events:
                if event.event_type in EVENTS and event.payload.get("payment_id"):
                    payment=db.get(Payment,uuid.UUID(event.payload["payment_id"]))
                    owners=list(db.scalars(select(Wallet.owner_id).where(Wallet.id.in_([payment.sender_id,payment.receiver_id]))))
                    merchants=select(Merchant.id).where(Merchant.principal_id.in_(owners))
                    for hook in db.scalars(select(Webhook).where(Webhook.merchant_id.in_(merchants),Webhook.status=="ACTIVE")):
                        if event.event_type in hook.events:
                            payload={"event_id":str(event.id),"payment_id":str(payment.id),"event_type":event.event_type,"environment":"sandbox","domain":"BPI"}
                            db.add(WebhookDelivery(webhook_id=hook.id,event_id=event.id,event_type=event.event_type,payload=payload))
                event.published_at=utcnow()

    def accept_local(self, hook_id, timestamp, signature, payload):
        try:
            if abs(int(utcnow().timestamp())-int(timestamp))>300: raise ValueError()
        except (ValueError,TypeError): raise RuleViolation("INVALID_WEBHOOK_SIGNATURE",401) from None
        with self.store.transaction() as db:
            hook=db.get(Webhook,uuid.UUID(hook_id))
            if not hook or hook.status!="ACTIVE": raise RuleViolation("INVALID_WEBHOOK_SIGNATURE",401)
            secret=self.store.envelope.decrypt(f"webhook:{hook.id}",hook.secret_ciphertext)
            expected=hmac.new(secret,timestamp.encode()+b"."+canonical(payload),hashlib.sha256).hexdigest()
            if not hmac.compare_digest(signature,expected): raise RuleViolation("INVALID_WEBHOOK_SIGNATURE",401)
            event_id=uuid.UUID(payload.get("event_id",""))
            delivery=db.scalar(select(WebhookDelivery).where(WebhookDelivery.webhook_id==hook.id,WebhookDelivery.event_id==event_id).with_for_update())
            if not delivery or delivery.payload!=payload: raise RuleViolation("WEBHOOK_PAYLOAD_MISMATCH",409)
            if not db.scalar(select(WebhookInbox).where(WebhookInbox.webhook_id==hook.id,WebhookInbox.event_id==event_id)):
                db.add(WebhookInbox(webhook_id=hook.id,event_id=event_id,payload_digest=sha(canonical(payload))))
            return {"accepted":True,"event_id":str(event_id),"sink":"local_sandbox"}

    def deliver(self, send=None):
        with self.store.transaction() as db:
            self.store.writer(db)
            row=db.scalar(select(WebhookDelivery).where(WebhookDelivery.status=="QUEUED",WebhookDelivery.next_attempt_at<=utcnow()).order_by(WebhookDelivery.created_at).limit(1))
            if not row: return
            hook=db.get(Webhook,row.webhook_id)
            timestamp=str(int(utcnow().timestamp()))
            signature=hmac.new(self.store.envelope.decrypt(f"webhook:{hook.id}",hook.secret_ciphertext),timestamp.encode()+b"."+canonical(row.payload),hashlib.sha256).hexdigest()
            identifier,payload,hook_id=row.id,row.payload,str(hook.id)
        headers={"Host":urlsplit(self.store.settings.origin).netloc,"X-Webhook-Id":hook_id,"X-Webhook-Timestamp":timestamp,"X-Webhook-Signature":signature}
        status=0
        try:
            if send:
                response=send(payload,headers)
            else:
                with httpx.Client(timeout=5,trust_env=False) as client:
                    response=client.post("http://bpi-api:8000/internal/webhook-sink",json=payload,headers=headers)
            status=response.status_code
            accepted=status==200 and response.json().get("event_id")==payload["event_id"] and response.json().get("accepted") is True
        except (httpx.HTTPError,ValueError): accepted=False
        with self.store.transaction() as db:
            self.store.writer(db)
            row=db.scalar(select(WebhookDelivery).where(WebhookDelivery.id==identifier).with_for_update())
            row.attempts+=1;row.response_status=status or None
            row.status="DELIVERED" if accepted else "FAILED" if row.attempts>=5 else "QUEUED"
            row.next_attempt_at=utcnow()+timedelta(seconds=min(300,2**row.attempts))
            self.store.audit(db,"webhook.delivery",row.status)
