import secrets
import uuid
from datetime import timedelta
from sqlalchemy import select, func, or_
from .storage import (Wallet, Principal, Subject, Operation, Command, Authorization, Hold, Account, Balance, Journal, ChainTransaction, Outbox, utcnow)
from .bpi_models import (Merchant, Membership, PaymentRequest, QRPayment, Payment, PaymentState, FraudScore, FraudEvent,
                         Refund, Settlement, GatewayEvidence, Product, CommerceOrder, OrderItem, Invoice, Approval, Notification)
from .ledger import Store, RuleViolation
from .protocol import PaymentPayload, payload_digest, integer, validate_address, wire_time, sha, canonical, validate_user_transaction
from .risk import assess

BPI_POLICY = {"assets": {"INR": 2}, "fee_minor": "0", "daily_funding_cap": "1000000", "payment_cap": "10000000", "consensus": "single-authorized-producer", "threshold": "1"}


class BPI(Store):
    def __init__(self, settings, signer=None):
        if settings.domain != "BPI":
            raise ValueError("BPI cannot use FINCOIN storage")
        super().__init__(settings, signer)

    def owned_wallet(self, db, actor, wallet_id, spend=False):
        wallet = db.get(Wallet, uuid.UUID(str(wallet_id)))
        if wallet is None or wallet.network_id != self.network(db).id:
            raise RuleViolation("WALLET_NOT_FOUND", 404)
        owner = db.get(Principal, wallet.owner_id)
        if owner.subject_id == actor.id:
            return wallet
        merchant = db.scalar(select(Merchant).where(Merchant.principal_id == owner.id))
        member = db.scalar(select(Membership).where(Membership.merchant_id == merchant.id, Membership.subject_id == actor.id, Membership.revoked_at.is_(None))) if merchant else None
        if not member or spend and member.role not in {"owner", "maker"}:
            raise RuleViolation("WALLET_NOT_FOUND", 404)
        return wallet

    def request_wallet(self, principal, key, label="Personal BPI"):
        with self.transaction() as db:
            actor, owner = self.sync_subject(db, principal)
            def create(op):
                existing = db.scalar(select(Wallet).where(Wallet.owner_id == owner.id))
                if existing:
                    return {"operation_id": str(op.id), "wallet_id": str(existing.id), "status": "READY"}
                db.add(Command(operation_id=op.id, kind="CREATE_WALLET", payload={"owner_id": str(owner.id), "label": label}))
                return {"operation_id": str(op.id), "status": "QUEUED"}
            return self.idempotent(db, actor, "wallet", key, {"label": label}, create)

    def wallets(self, principal):
        with self.transaction() as db:
            actor, owner = self.sync_subject(db, principal)
            owners = [owner.id] + list(db.scalars(select(Merchant.principal_id).join(Membership, Membership.merchant_id == Merchant.id).where(Membership.subject_id == actor.id, Membership.revoked_at.is_(None))))
            rows = db.scalars(select(Wallet).where(Wallet.owner_id.in_(owners))).all()
            return [{"id": str(w.id), "address": w.address, "label": w.label, "owner_id": str(w.owner_id), "owner_kind": db.get(Principal, w.owner_id).kind,
                     "balances": self.wallet_values(db, w), "status": w.status, "domain": "BPI", "environment": "sandbox", "value_kind": "simulated"} for w in rows]

    def merchant_onboard(self, principal, key, name, category):
        with self.transaction() as db:
            actor, _ = self.sync_subject(db, principal)
            def create(op):
                owner = Principal(id=uuid.uuid4(), kind="ORGANIZATION")
                db.add(owner)
                db.flush()
                merchant = Merchant(id=uuid.uuid4(), principal_id=owner.id, display_name=name, category=category)
                db.add(merchant)
                db.flush()
                db.add(Membership(merchant_id=merchant.id, subject_id=actor.id, role="owner"))
                db.add(Command(operation_id=op.id, kind="CREATE_WALLET", payload={"owner_id": str(owner.id), "label": name}))
                return {"merchant_id": str(merchant.id), "operation_id": str(op.id), "status": "SANDBOX_ACTIVE"}
            return self.idempotent(db, actor, "merchant", key, {"name": name, "category": category}, create)

    def create_request(self, principal, key, wallet_id, amount, minutes=15):
        value = integer(amount, maximum=10000000)
        with self.transaction() as db:
            actor, _ = self.sync_subject(db, principal)
            wallet = self.owned_wallet(db, actor, wallet_id)
            def create(op):
                return self._request(db, op, wallet, value, minutes)
            return self.idempotent(db, actor, "request", key, {"wallet_id": str(wallet_id), "amount": amount, "minutes": str(minutes)}, create)

    def _request(self, db, op, wallet, amount, minutes, order_id=None):
        secret = secrets.token_urlsafe(24)
        row = PaymentRequest(id=uuid.uuid4(), operation_id=op.id, wallet_id=wallet.id, token_digest=sha(secret.encode()), amount=amount,
                             expires_at=utcnow()+timedelta(minutes=minutes), order_id=order_id)
        db.add(row)
        db.flush()
        # Opaque request identifier is high entropy; server resolution is the authority.
        link = self.settings.origin + "/request/" + secret
        db.add(QRPayment(request_id=row.id, signed_link=link))
        return {"request_id": str(row.id), "link": link, "amount_minor": str(amount), "currency": "INR", "expires_at": wire_time(row.expires_at), "status": "OPEN", "environment": "sandbox"}

    def resolve_request(self, token):
        if len(token) != 32:
            raise RuleViolation("REQUEST_NOT_FOUND", 404)
        with self.transaction() as db:
            row = db.scalar(select(PaymentRequest).where(PaymentRequest.token_digest == sha(token.encode())))
            if row is None:
                raise RuleViolation("REQUEST_NOT_FOUND", 404)
            wallet = db.get(Wallet, row.wallet_id)
            status = "EXPIRED" if row.status == "OPEN" and row.expires_at <= utcnow() else row.status
            return {"id": str(row.id), "recipient": wallet.label, "address": wallet.address, "amount_minor": str(row.amount), "currency": "INR",
                    "status": status, "expires_at": wire_time(row.expires_at), "domain": "BPI", "environment": "sandbox", "value_kind": "simulated"}

    def create_draft(self, principal, key, sender_id, receiver_address, amount, request_id=None, original_id=None, redemption=False):
        value = integer(amount, maximum=10000000)
        validate_address(receiver_address, "BPI")
        with self.transaction() as db:
            actor, _ = self.sync_subject(db, principal)
            sender = self.owned_wallet(db, actor, sender_id, spend=True)
            receiver = db.scalar(select(Wallet).where(Wallet.address == receiver_address, Wallet.network_id == sender.network_id))
            if receiver is None or (receiver.id == sender.id) != redemption or receiver.status != "ACTIVE" or sender.status != "ACTIVE":
                raise RuleViolation("INVALID_RECIPIENT", 422)
            if redemption and (request_id or original_id):
                raise RuleViolation("INVALID_REDEMPTION", 422)
            if db.get(Principal, sender.owner_id).kind == "ORGANIZATION" and principal["assurance"] != "MFA":
                raise RuleViolation("MFA_REQUIRED", 403)
            req = db.get(PaymentRequest, uuid.UUID(str(request_id))) if request_id else None
            if request_id and (not req or req.wallet_id != receiver.id or req.amount != value or req.expires_at <= utcnow() or req.status != "OPEN"):
                raise RuleViolation("REQUEST_UNAVAILABLE")
            original = None
            if original_id:
                original = db.scalar(select(Payment).where(Payment.id == uuid.UUID(str(original_id))).with_for_update())
                state = db.scalar(select(PaymentState).where(PaymentState.payment_id == original.id)) if original else None
                if not original or not state or state.business_status != "COMPLETED" or original.receiver_id != sender.id or original.sender_id != receiver.id or original.original_payment_id:
                    raise RuleViolation("REFUND_INELIGIBLE")
            request_data = {"sender_id": str(sender_id), "receiver_address": receiver_address, "amount_minor": amount, "request_id": str(request_id) if request_id else None, "original_id": str(original_id) if original_id else None, "redemption": redemption}
            def create(op):
                payment_id, auth_id = uuid.uuid4(), uuid.uuid4()
                source_kind = "B" if db.get(Principal, sender.owner_id).kind == "ORGANIZATION" else "P"
                target_kind = "B" if db.get(Principal, receiver.owner_id).kind == "ORGANIZATION" else "P"
                payment_type = "REDEEM" if redemption else source_kind + "2" + target_kind
                expiry = utcnow()+timedelta(minutes=5)
                payload = PaymentPayload(domain="BPI", network_id=self.settings.network_code, transaction_id=str(payment_id), kind="REDEMPTION" if redemption else "PAYMENT_TRANSFER",
                    sender_address=sender.address, receiver_address=receiver.address, amount_minor=amount, currency="INR", timestamp=wire_time(), expires_at=wire_time(expiry),
                    nonce=str(sender.next_nonce), payment_type="REDEMPTION" if redemption else payment_type, request_id=str(req.id) if req else None, order_id=str(req.order_id) if req and req.order_id else None,
                    authorization_ref=str(auth_id), key_id=str(sender.key_id)).model_dump()
                payment = Payment(id=payment_id, operation_id=op.id, actor_id=actor.id, sender_id=sender.id, receiver_id=receiver.id, amount=value,
                    payment_type=payment_type, expires_at=expiry, request_id=req.id if req else None, original_payment_id=original.id if original else None,
                    purpose="REDEMPTION" if redemption else "REFUND" if original else "PAYMENT", payload=payload, payload_digest=payload_digest(payload))
                db.add(payment)
                db.add(Authorization(id=auth_id, operation_id=op.id, actor_id=actor.id, credentials_version=principal["credentials_version"], session_id=uuid.UUID(principal["session_id"]),
                    payload_digest=payment.payload_digest, payload=payload, expires_at=expiry))
                db.flush()
                if original:
                    db.add(Refund(original_payment_id=original.id, refund_payment_id=payment.id, amount=value))
                return {"payment_id": str(payment_id), "operation_id": str(op.id), "payload_digest": payment.payload_digest, "amount_minor": amount,
                        "recipient": "Sandbox gateway redemption (no real payout)" if redemption else receiver.label, "sender": sender.label, "receiver_address": receiver.address, "payment_type": payment_type,
                        "fee_minor": "0", "expires_at": wire_time(expiry), "status": "DRAFT", "environment": "sandbox"}
            return self.idempotent(db, actor, "payment-draft", key, request_data, create)

    def redemption_draft(self, principal, key, wallet_id, amount):
        with self.transaction() as db:
            actor, _ = self.sync_subject(db, principal)
            address = self.owned_wallet(db, actor, wallet_id, spend=True).address
        return self.create_draft(principal, key, wallet_id, address, amount, redemption=True)

    def authorize(self, principal, key, payment_id, expected_digest):
        with self.transaction() as db:
            actor, _ = self.sync_subject(db, principal)
            payment = db.get(Payment, uuid.UUID(str(payment_id)))
            if not payment or payment.actor_id != actor.id:
                raise RuleViolation("PAYMENT_NOT_FOUND", 404)
            sender = self.owned_wallet(db, actor, payment.sender_id, spend=True)
            if expected_digest != payment.payload_digest or payment.expires_at <= utcnow():
                raise RuleViolation("REVIEW_EXPIRED_OR_CHANGED")
            if principal["auth_time"] < int(utcnow().timestamp())-300:
                raise RuleViolation("REAUTHENTICATION_REQUIRED", 403)
            if db.get(Principal, sender.owner_id).kind == "ORGANIZATION":
                if principal["assurance"] != "MFA":
                    raise RuleViolation("MFA_REQUIRED", 403)
                approval = db.scalar(select(Approval).where(Approval.payment_id == payment.id, Approval.approver_id != actor.id, Approval.payload_digest == expected_digest, Approval.decision == "APPROVE"))
                if approval is None:
                    raise RuleViolation("INDEPENDENT_APPROVAL_REQUIRED", 403)
            def create(op):
                existing = db.scalar(select(Command).where(Command.operation_id == payment.operation_id, Command.kind == "PAYMENT"))
                if existing is None:
                    db.add(Command(operation_id=payment.operation_id, kind="PAYMENT", payload={"payment_id": str(payment.id)}))
                return {"payment_id": str(payment.id), "operation_id": str(payment.operation_id), "status": "QUEUED"}
            return self.idempotent(db, actor, "authorize", key, {"payment_id": str(payment_id), "payload_digest": expected_digest}, create)

    def funding(self, principal, key, wallet_id, amount, scenario="SUCCESS"):
        value = integer(amount, maximum=1000000)
        if scenario not in {"SUCCESS", "FAILURE", "UNKNOWN"}:
            raise RuleViolation("INVALID_SCENARIO", 422)
        with self.transaction() as db:
            actor, _ = self.sync_subject(db, principal)
            wallet = self.owned_wallet(db, actor, wallet_id)
            def create(op):
                total = int(db.scalar(select(func.coalesce(func.sum(Settlement.amount), 0)).join(Operation, Operation.id == Settlement.operation_id).where(Operation.actor_id == actor.id, Settlement.kind == "FUNDING", Settlement.created_at >= utcnow()-timedelta(days=1))) or 0)
                pending = list(db.scalars(select(Command).join(Operation, Operation.id == Command.operation_id).where(Operation.actor_id == actor.id, Command.kind == "FUNDING", Command.state == "QUEUED")))
                total += sum(int(c.payload["amount"]) for c in pending)
                if total+value > 1000000:
                    raise RuleViolation("FUNDING_CAP_REACHED", 429)
                db.add(Command(operation_id=op.id, kind="FUNDING", payload={"wallet_id": str(wallet.id), "amount": amount, "scenario": scenario}))
                return {"operation_id": str(op.id), "status": "QUEUED", "environment": "sandbox", "value_kind": "simulated"}
            return self.idempotent(db, actor, "funding", key, {"wallet_id": str(wallet_id), "amount": amount, "scenario": scenario}, create)

    def process_command(self, command_id, validate_principal):
        with self.transaction() as db:
            network, head = self.writer(db)
            command = db.scalar(select(Command).where(Command.id == command_id).with_for_update())
            if not command or command.state != "QUEUED":
                return
            operation = db.get(Operation, command.operation_id)
            if command.kind == "ADMIN":
                from .admin import Administration
                Administration(self).process(db, command, validate_principal)
                return
            if command.kind == "CREATE_WALLET":
                wallet = self.create_wallet(db, uuid.UUID(command.payload["owner_id"]), command.payload["label"])
                self.audit(db, "wallet.create", "COMMITTED", operation.actor_id, operation.id)
                command.state = "SUCCEEDED"
                return
            if network.status != "ACTIVE":
                raise RuleViolation("NETWORK_PAUSED", 503)
            if command.kind == "FUNDING":
                validate_principal(operation.actor_id, None, None)
                db.add(Settlement(operation_id=operation.id, wallet_id=uuid.UUID(command.payload["wallet_id"]), kind="FUNDING", amount=int(command.payload["amount"]), scenario=command.payload["scenario"]))
                command.state = "SUCCEEDED"
                self.audit(db, "funding.request", "QUEUED", operation.actor_id, operation.id)
                return
            if command.kind != "PAYMENT":
                raise RuleViolation("UNKNOWN_COMMAND")
            payment = db.get(Payment, uuid.UUID(command.payload["payment_id"]))
            auth = db.scalar(select(Authorization).where(Authorization.operation_id == operation.id))
            live = validate_principal(auth.actor_id, auth.session_id, auth.credentials_version)
            sender = db.scalar(select(Wallet).where(Wallet.id == payment.sender_id).with_for_update())
            actor = db.get(Subject, auth.actor_id)
            if not actor or actor.status != "ACTIVE":
                raise RuleViolation("SUBJECT_DISABLED", 403)
            self.owned_wallet(db, actor, sender.id, spend=True)
            if db.get(Principal, sender.owner_id).kind == "ORGANIZATION":
                if not live or live.get("assurance") != "MFA" or live.get("auth_time", 0) < int(utcnow().timestamp())-300:
                    raise RuleViolation("RECENT_MFA_REQUIRED", 403)
                merchant = db.scalar(select(Merchant).where(Merchant.principal_id == sender.owner_id))
                approvals = db.scalars(select(Approval).where(Approval.payment_id == payment.id, Approval.approver_id != actor.id, Approval.payload_digest == payment.payload_digest, Approval.decision == "APPROVE")).all()
                eligible = any(db.scalar(select(Membership.id).join(Subject, Subject.id == Membership.subject_id).where(Membership.merchant_id == merchant.id, Membership.subject_id == a.approver_id, Membership.revoked_at.is_(None), Membership.role.in_(["owner", "checker"]), Subject.status == "ACTIVE")) for a in approvals)
                if not eligible:
                    raise RuleViolation("INDEPENDENT_APPROVAL_REQUIRED", 403)
            receiver = db.get(Wallet, payment.receiver_id)
            state = db.scalar(select(PaymentState).where(PaymentState.payment_id == payment.id))
            if state is None:
                state = PaymentState(payment_id=payment.id)
                db.add(state)
            signed = self.signer.transaction(sender.key_id, payment.payload)
            validate_user_transaction(payment.payload, sender.public_key, signed["signature"], signed["transaction_hash"], network.network_code, sender.next_nonce)
            auth.signature, auth.transaction_hash, auth.signed_at = signed["signature"], signed["transaction_hash"], utcnow()
            recent = int(db.scalar(select(func.count()).select_from(Payment).join(PaymentState, PaymentState.payment_id == Payment.id).where(Payment.sender_id == sender.id, Payment.created_at > utcnow()-timedelta(minutes=1))) or 0)
            known = db.scalar(select(Payment.id).join(PaymentState, PaymentState.payment_id == Payment.id).where(Payment.sender_id == sender.id, Payment.receiver_id == receiver.id, PaymentState.business_status == "COMPLETED").limit(1)) is not None
            failures = int(db.scalar(select(func.count()).select_from(Payment).join(PaymentState, PaymentState.payment_id == Payment.id).where(Payment.sender_id == sender.id, Payment.created_at > utcnow()-timedelta(hours=1), PaymentState.business_status == "REJECTED")) or 0)
            result = assess(amount=payment.amount, new_recipient=not known, recent_count=recent, failed_count=failures, flagged=sender.status != "ACTIVE" or receiver.status != "ACTIVE")
            db.add(FraudScore(payment_id=payment.id, payload_digest=payment.payload_digest, score=result.score, decision=result.decision, reasons=list(result.reasons), expires_at=utcnow()+timedelta(seconds=60)))
            if result.decision != "ALLOW":
                state.business_status = "RISK_REVIEW" if result.decision == "REVIEW" else "REJECTED"
                state.chain_status = "NOT_SUBMITTED" if result.decision == "REVIEW" else "REJECTED"
                state.reason_code = "REVIEW_REQUIRED" if result.decision == "REVIEW" else "RISK_DECLINED"
                command.state = "SUCCEEDED"
                db.add(FraudEvent(payment_id=payment.id, decision=result.decision, reason="Deterministic risk rules require attention"))
                self.audit(db, "payment.risk", result.decision, operation.actor_id, operation.id)
                return
            request = db.scalar(select(PaymentRequest).where(PaymentRequest.id == payment.request_id).with_for_update()) if payment.request_id else None
            if request and (request.status != "OPEN" or request.expires_at <= utcnow() or request.amount != payment.amount):
                raise RuleViolation("REQUEST_ALREADY_CLAIMED")
            if payment.original_payment_id:
                original = db.scalar(select(Payment).where(Payment.id == payment.original_payment_id).with_for_update())
                used = int(db.scalar(select(func.coalesce(func.sum(Payment.amount), 0)).join(PaymentState, PaymentState.payment_id == Payment.id).where(Payment.original_payment_id == original.id, PaymentState.business_status.in_(["RESERVED", "SETTLEMENT_PENDING", "SETTLEMENT_UNKNOWN", "COMPLETED"]))) or 0)
                if used + payment.amount > original.amount:
                    raise RuleViolation("REFUND_LIMIT_EXCEEDED")
            available = int(self.wallet_values(db, sender)["INR"]["available"])
            if available < payment.amount:
                raise RuleViolation("INSUFFICIENT_BALANCE")
            hold = Hold(wallet_id=sender.id, operation_id=operation.id, asset_code="INR", amount=payment.amount, nonce=sender.next_nonce, expires_at=payment.expires_at)
            db.add(hold)
            db.flush()
            state.business_status, state.chain_status = "RESERVED", "QUEUED"
            source = self.account(db, network.id, sender.id, "INR", "SETTLED")
            pending = self.account(db, network.id, receiver.id, "INR", "PENDING")
            include = self.operation(db, "PAYMENT_INCLUDE", operation.actor_id, operation.id, "INCLUDE")
            self.post(db, include, "REDEMPTION" if payment.purpose == "REDEMPTION" else "PAYMENT_TRANSFER", [(source, "DEBIT", payment.amount), (pending, "CREDIT", payment.amount)],
                      {**signed, "payload": payment.payload, "public_key": sender.public_key}, sender)
            auth.consumed_at = utcnow()
            hold.status = "CONSUMED"
            state.business_status, state.chain_status, state.settlement_status = "SETTLEMENT_PENDING", "CONFIRMED", "PENDING"
            if request:
                request.status, request.active_payment_id = "CLAIMED", payment.id
            settlement_op = self.operation(db, "SETTLEMENT", operation.actor_id, operation.id, "SETTLEMENT")
            db.add(Settlement(operation_id=settlement_op.id, payment_id=payment.id, wallet_id=receiver.id, kind="REDEMPTION" if payment.purpose == "REDEMPTION" else "TRANSFER", amount=payment.amount))
            command.state = "SUCCEEDED"

    def apply_gateway_result(self, settlement_id, evidence):
        with self.transaction() as db:
            network, _ = self.writer(db)
            settlement = db.scalar(select(Settlement).where(Settlement.id == settlement_id).with_for_update())
            if settlement is None or evidence.get("environment") != "sandbox" or evidence["operation_id"] != str(settlement.operation_id) or evidence["amount_minor"] != str(settlement.amount) or evidence["currency"] != "INR" or evidence["network_id"] != network.network_code:
                raise RuleViolation("GATEWAY_EVIDENCE_MISMATCH")
            if evidence["status"] not in {"SUCCEEDED", "FAILED", "UNKNOWN"}:
                raise RuleViolation("INVALID_GATEWAY_STATE")
            event_id = uuid.UUID(evidence["event_id"])
            digest = sha(canonical(evidence))
            prior = db.scalar(select(GatewayEvidence).where(GatewayEvidence.provider_event_id == event_id))
            if prior:
                if prior.response_digest != digest:
                    raise RuleViolation("GATEWAY_EVENT_CONFLICT")
                return
            db.add(GatewayEvidence(settlement_id=settlement.id, provider_event_id=event_id, response_digest=digest, response=evidence, status=evidence["status"]))
            if settlement.result_applied_at:
                if settlement.status != evidence["status"]:
                    self.audit(db, "gateway.conflict", "QUARANTINED", operation=settlement.operation_id)
                return
            settlement.status = evidence["status"]
            payment = db.get(Payment, settlement.payment_id) if settlement.payment_id else None
            state = db.scalar(select(PaymentState).where(PaymentState.payment_id == payment.id)) if payment else None
            if evidence["status"] == "UNKNOWN":
                if state:
                    state.business_status, state.settlement_status = "SETTLEMENT_UNKNOWN", "UNKNOWN"
                settlement.next_check_at = utcnow()+timedelta(seconds=5)
                return
            outcome = evidence["status"] == "SUCCEEDED"
            result_op = self.operation(db, "SETTLEMENT_RESULT", parent=settlement.operation_id, slot="APPLY_TERMINAL")
            wallet = db.get(Wallet, settlement.wallet_id)
            if settlement.kind == "FUNDING" and outcome:
                gateway = self.account(db, network.id, None, "INR", "GATEWAY", "DEBIT")
                target = self.account(db, network.id, wallet.id, "INR", "SETTLED")
                self.post(db, result_op, "FUNDING_SUCCEEDED", [(gateway, "DEBIT", settlement.amount), (target, "CREDIT", settlement.amount)])
            elif settlement.kind in {"TRANSFER", "REDEMPTION"}:
                pending = self.account(db, network.id, payment.receiver_id, "INR", "PENDING")
                target = self.account(db, network.id, None, "INR", "GATEWAY", "DEBIT") if settlement.kind == "REDEMPTION" and outcome else self.account(db, network.id, payment.receiver_id if outcome else payment.sender_id, "INR", "SETTLED")
                self.post(db, result_op, "SETTLEMENT_SUCCEEDED" if outcome else "PAYMENT_RETURNED", [(pending, "DEBIT", settlement.amount), (target, "CREDIT", settlement.amount)])
                state.business_status, state.settlement_status = ("COMPLETED", "SUCCEEDED") if outcome else ("RETURNED", "FAILED")
                state.completed_at = utcnow() if outcome else None
                if payment.request_id:
                    request = db.get(PaymentRequest, payment.request_id)
                    request.status = "PAID" if outcome else "OPEN" if request.expires_at > utcnow() else "EXPIRED"
                    if not outcome:
                        request.active_payment_id = None
                    if request.order_id and outcome:
                        order = db.get(CommerceOrder, request.order_id)
                        order.status = "PAID" if order.reservation_expires_at > utcnow() else "PAID_REVIEW"
                        order.paid_at = utcnow()
                    invoice = db.scalar(select(Invoice).where(Invoice.request_id == request.id))
                    if invoice and outcome:
                        invoice.status = "PAID"
            settlement.result_applied_at = utcnow()
            if payment:
                subjects = {payment.actor_id}
                recipient = db.get(Principal, wallet.owner_id)
                if recipient.subject_id:
                    subjects.add(recipient.subject_id)
                else:
                    merchant = db.scalar(select(Merchant).where(Merchant.principal_id == recipient.id))
                    if merchant:
                        subjects.update(db.scalars(select(Membership.subject_id).where(Membership.merchant_id == merchant.id, Membership.role == "owner", Membership.revoked_at.is_(None))))
                for subject in subjects:
                    db.add(Notification(subject_id=subject, message=f"Sandbox payment {payment.id}: {state.business_status}."))
            db.add(Outbox(operation_id=result_op.id, event_type="settlement.completed" if outcome else "payment.failed", payload={"settlement_id": str(settlement.id), "payment_id": str(payment.id) if payment else None, "environment": "sandbox"}))
            self.audit(db, "gateway.apply", evidence["status"], operation=settlement.operation_id)
