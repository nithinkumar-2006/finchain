import secrets
import uuid
from fastapi import FastAPI, Request, Query
from fastapi.responses import JSONResponse, Response
from fastapi.exceptions import RequestValidationError
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy.exc import SQLAlchemyError
from starlette.middleware.cors import CORSMiddleware
from starlette.middleware.trustedhost import TrustedHostMiddleware
from urllib.parse import urlsplit
import redis
from .config import DomainSettings
from .ledger import RuleViolation
from .identity_client import IdentityClient
from .queries import Queries


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True, hide_input_in_errors=True)


class WalletBody(Strict):
    label: str = Field(default="Personal BPI", min_length=1, max_length=80)


class Money(Strict):
    wallet_id: str = Field(max_length=36)
    amount_minor: str = Field(pattern=r"^[1-9][0-9]{0,17}$")


class Funding(Money):
    scenario: str = Field(default="SUCCESS", pattern="^(SUCCESS|FAILURE|UNKNOWN)$")


class RequestBody(Money):
    expires_minutes: int = Field(default=15, ge=1, le=60)


class Draft(Strict):
    sender_wallet_id: str = Field(max_length=36)
    receiver_address: str = Field(max_length=100)
    amount_minor: str = Field(pattern=r"^[1-9][0-9]{0,17}$")
    request_id: str | None = Field(default=None, max_length=36)
    original_payment_id: str | None = Field(default=None, max_length=36)


class Confirmation(Strict):
    payload_digest: str = Field(pattern=r"^[0-9a-f]{64}$")


class MerchantBody(Strict):
    name: str = Field(min_length=2, max_length=80)
    category: str = Field(min_length=1, max_length=32)


class ProductBody(Strict):
    name: str = Field(min_length=1, max_length=100)
    description: str = Field(min_length=1, max_length=500)
    category: str = Field(max_length=32)
    price_minor: str = Field(pattern=r"^[1-9][0-9]{0,7}$")
    stock: int = Field(ge=0, le=100000)


class CartItem(Strict):
    product_id: str = Field(max_length=36)
    quantity: int = Field(ge=1, le=100)


class Checkout(Strict):
    items: list[CartItem] = Field(min_length=1, max_length=20)


class InvoiceLine(Strict):
    description: str = Field(min_length=1, max_length=160)
    quantity: int = Field(ge=1, le=100)
    unit_price_minor: str = Field(pattern=r"^[1-9][0-9]{0,7}$")


class InvoiceBody(Strict):
    lines: list[InvoiceLine] = Field(min_length=1, max_length=20)


class MemberBody(Strict):
    subject_id: str = Field(max_length=36)
    role: str = Field(pattern="^(cashier|maker|checker|integration|analyst)$")


class QuoteBody(Strict):
    side: str = Field(pattern="^(BUY|SELL)$")
    quantity_atoms: str = Field(pattern=r"^[1-9][0-9]{0,17}$")


class GrantBody(Strict):
    asset: str = Field(pattern="^(FINCOIN|SIM_INR)$")
    quantity_atoms: str = Field(pattern=r"^[1-9][0-9]{0,17}$")


class TransferBody(Strict):
    recipient_address: str = Field(max_length=100)
    quantity_atoms: str = Field(pattern=r"^[1-9][0-9]{0,17}$")


class AdminAction(Strict):
    action: str = Field(pattern="^(NETWORK|WALLET|RISK)$")
    target: str | None = Field(default=None, max_length=36)
    decision: str = Field(pattern="^(PAUSED|ACTIVE|RESTRICTED|REJECT|CANCEL)$")


class KeyScopes(Strict):
    scopes: list[str] = Field(min_length=1, max_length=2)


class KeyRequest(Strict):
    amount_minor: str = Field(pattern=r"^[1-9][0-9]{0,7}$")


class RateLimiter:
    def __init__(self, url, domain):
        if not url:
            raise ValueError("REDIS_URL required for domain API")
        self.redis = redis.Redis.from_url(url, socket_timeout=2, socket_connect_timeout=2)
        self.domain = domain
    def check(self, peer):
        from .protocol import sha
        try:
            value = self.redis.eval("local n=redis.call('INCR',KEYS[1]); if n==1 then redis.call('EXPIRE',KEYS[1],60) end; return n", 1, "rate:"+self.domain+":"+sha(peer.encode()))
            if value > 120:
                raise RuleViolation("RATE_LIMITED", 429)
        except redis.RedisError:
            raise RuleViolation("RATE_LIMIT_UNAVAILABLE", 503) from None


def create_app(settings=None, store=None, identity=None, limiter=None):
    settings = settings or DomainSettings.from_env()
    if store is None:
        if settings.domain == "BPI":
            from .bpi import BPI
            store = BPI(settings)
        else:
            from .fincoin import FINCOIN
            store = FINCOIN(settings)
    identity = identity or IdentityClient(settings)
    limiter = limiter or (None if settings.test_mode else RateLimiter(settings.redis_url, settings.domain))
    query = Queries(store)
    from .admin import Administration
    administration = Administration(store)
    prefix = "/v1/"+settings.domain.lower()
    app = FastAPI(title="FINCHAIN "+settings.domain+" sandbox", docs_url=None, redoc_url=None, openapi_url=None)
    app.state.store = store
    app.add_middleware(CORSMiddleware, allow_origins=[settings.origin], allow_credentials=True, allow_methods=["GET", "POST", "DELETE"], allow_headers=["Content-Type", "X-CSRF-Token", "Idempotency-Key"])
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=[urlsplit(settings.origin).hostname])

    def error(code, status):
        return JSONResponse({"code": code, "status": status, "type": "about:blank", "title": "Request could not be completed", "request_id": str(uuid.uuid4())}, status_code=status, media_type="application/problem+json")

    @app.middleware("http")
    async def boundary(request, call_next):
        response = None
        service_route = settings.domain == "BPI" and (request.url.path == "/internal/webhook-sink" or request.url.path.startswith("/v1/bpi/merchant-api/"))
        if request.method not in {"GET", "HEAD", "OPTIONS"} and not service_route:
            csrf = request.headers.get("x-csrf-token", "")
            if request.headers.get("origin") != settings.origin or len(csrf) != 43 or not secrets.compare_digest(csrf, request.cookies.get("__Host-finchain-csrf", "")):
                response = error("CSRF_FAILED", 403)
            elif request.headers.get("content-type", "").split(";")[0] != "application/json":
                response = error("JSON_REQUIRED", 415)
        if response is None:
            body = bytearray()
            async for chunk in request.stream():
                body.extend(chunk)
                if len(body) > 16384:
                    response = error("REQUEST_TOO_LARGE", 413)
                    break
            if response is None:
                request._body = bytes(body)
                response = await call_next(request)
        response.headers.update({"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY", "Referrer-Policy": "no-referrer", "Content-Security-Policy": "default-src 'none'; frame-ancestors 'none'", "Strict-Transport-Security": "max-age=31536000"})
        return response

    @app.exception_handler(RuleViolation)
    async def violation(_, exc): return error(exc.code, exc.status)
    @app.exception_handler(RequestValidationError)
    async def validation(_, exc): return error("INVALID_INPUT", 422)
    @app.exception_handler(ValueError)
    async def value_error(_, exc): return error("INVALID_INPUT", 422)
    @app.exception_handler(SQLAlchemyError)
    async def database_error(_, exc): return error("DATABASE_UNAVAILABLE", 503)

    def principal(request):
        if limiter: limiter.check(request.client.host if request.client else "unknown")
        return identity.browser(request)
    def key(request):
        try: return uuid.UUID(request.headers.get("idempotency-key", ""))
        except ValueError: raise RuleViolation("IDEMPOTENCY_KEY_REQUIRED", 422) from None

    @app.get("/health/live")
    def live(): return {"status": "alive", "domain": settings.domain, "environment": "sandbox"}

    @app.get("/health/ready")
    def ready():
        with store.transaction() as db: store.network(db)
        if limiter: limiter.redis.ping()
        return {"status": "ready", "domain": settings.domain, "environment": "sandbox"}

    @app.get(prefix+"/wallets")
    def wallets(request: Request): return {"items": store.wallets(principal(request))}

    @app.post(prefix+"/wallets", status_code=202)
    def create_wallet(body: WalletBody, request: Request):
        p = principal(request)
        return store.request_wallet(p, key(request), body.label) if settings.domain == "BPI" else store.request_wallet(p, key(request))

    @app.get(prefix+"/operations/{operation_id}")
    def operation(operation_id: uuid.UUID, request: Request): return query.operation(principal(request), operation_id)

    @app.get(prefix+"/admin/overview")
    def admin(request: Request): return query.admin(principal(request))

    @app.post(prefix+"/admin/actions", status_code=202)
    def admin_action(body: AdminAction, request: Request): return administration.submit(principal(request), key(request), body.action, body.target, body.decision)

    if settings.domain == "BPI":
        @app.get(prefix+"/admin/risk-reviews")
        def risk_reviews(request: Request): return {"items": administration.review_queue(principal(request))}

    if settings.domain == "BPI":
        from .commerce import Commerce
        from .integrations import Integrations
        commerce = Commerce(store)
        integrations = Integrations(store)

        @app.get(prefix+"/merchants/{merchant_id}/integrations")
        def integration_config(merchant_id: uuid.UUID, request: Request): return integrations.list_config(principal(request), merchant_id)

        @app.post(prefix+"/merchants/{merchant_id}/api-keys",status_code=201)
        def create_key(merchant_id: uuid.UUID,body: KeyScopes,request: Request): return integrations.create_key(principal(request),merchant_id,body.scopes)

        @app.delete(prefix+"/merchants/{merchant_id}/api-keys/{key_id}",status_code=204)
        def revoke_key(merchant_id: uuid.UUID,key_id: uuid.UUID,request: Request):
            integrations.revoke_key(principal(request),merchant_id,key_id)
            return Response(status_code=204)

        @app.post(prefix+"/merchants/{merchant_id}/webhooks",status_code=201)
        def create_hook(merchant_id: uuid.UUID,request: Request): return integrations.create_hook(principal(request),merchant_id)

        def api_token(request):
            if limiter: limiter.check(request.client.host if request.client else "unknown")
            value=request.headers.get("authorization","")
            if not value.startswith("Bearer "): raise RuleViolation("INVALID_API_KEY",401)
            return value[7:]

        @app.get(prefix+"/merchant-api/payments")
        def key_payments(request: Request): return integrations.key_payments(api_token(request))

        @app.post(prefix+"/merchant-api/payment-requests",status_code=201)
        def key_request(body: KeyRequest,request: Request): return integrations.key_request(api_token(request),key(request),body.amount_minor)

        @app.post("/internal/webhook-sink")
        async def local_sink(request: Request):
            from .protocol import parse_json
            return integrations.accept_local(request.headers.get("x-webhook-id",""),request.headers.get("x-webhook-timestamp",""),request.headers.get("x-webhook-signature",""),parse_json(await request.body()))

        @app.get(prefix+"/dashboard")
        def dashboard(wallet_id: uuid.UUID, request: Request): return query.dashboard(principal(request), wallet_id)

        @app.get(prefix+"/settlements")
        def settlements(wallet_id: uuid.UUID, request: Request): return {"items": query.settlements(principal(request), wallet_id)}

        @app.get(prefix+"/payments")
        def payments(request: Request, wallet_id: uuid.UUID | None=None, status: str | None=None, direction: str | None=None, cursor: uuid.UUID | None=None, limit: int=Query(default=25, ge=1, le=100)):
            return query.payments(principal(request), wallet_id, status, direction, str(cursor) if cursor else None, limit)

        @app.get(prefix+"/payments/{payment_id}")
        def receipt(payment_id: uuid.UUID, request: Request): return query.receipt(principal(request), payment_id)

        @app.post(prefix+"/payment-drafts", status_code=201)
        def draft(body: Draft, request: Request):
            return store.create_draft(principal(request), key(request), body.sender_wallet_id, body.receiver_address, body.amount_minor, body.request_id, body.original_payment_id)

        @app.post(prefix+"/payment-drafts/{payment_id}/authorizations", status_code=202)
        def authorize(payment_id: uuid.UUID, body: Confirmation, request: Request): return store.authorize(principal(request), key(request), payment_id, body.payload_digest)

        @app.post(prefix+"/sandbox/funding", status_code=202)
        def funding(body: Funding, request: Request): return store.funding(principal(request), key(request), body.wallet_id, body.amount_minor, body.scenario)

        @app.post(prefix+"/redemption-drafts", status_code=201)
        def redemption(body: Money, request: Request): return store.redemption_draft(principal(request), key(request), body.wallet_id, body.amount_minor)

        @app.post(prefix+"/payment-requests", status_code=201)
        def payment_request(body: RequestBody, request: Request): return store.create_request(principal(request), key(request), body.wallet_id, body.amount_minor, body.expires_minutes)

        @app.get(prefix+"/payment-requests/{token}")
        def resolve(token: str, request: Request):
            if limiter: limiter.check(request.client.host if request.client else "unknown")
            return store.resolve_request(token)

        @app.get(prefix+"/merchants")
        def merchants(request: Request): return {"items": query.merchants(principal(request))}

        @app.get(prefix+"/merchants/{merchant_id}/report")
        def merchant_report(merchant_id: uuid.UUID,request: Request): return query.merchant_report(principal(request),merchant_id)

        @app.get(prefix+"/notifications")
        def notifications(request: Request): return query.notifications(principal(request))

        @app.post(prefix+"/notifications/{notification_id}/read")
        def read_notification(notification_id: uuid.UUID,request: Request): return query.notifications(principal(request),notification_id)

        @app.post(prefix+"/merchants", status_code=201)
        def onboard(body: MerchantBody, request: Request): return store.merchant_onboard(principal(request), key(request), body.name, body.category)

        @app.post(prefix+"/merchants/{merchant_id}/products", status_code=201)
        def product(merchant_id: uuid.UUID, body: ProductBody, request: Request):
            return commerce.create_product(principal(request), key(request), merchant_id, body.name, body.description, body.category, body.price_minor, body.stock)

        @app.get(prefix+"/commerce/products")
        def catalog(category: str | None=None): return {"items": query.catalog(category)}

        @app.post(prefix+"/commerce/orders", status_code=201)
        def checkout(body: Checkout, request: Request): return commerce.checkout(principal(request), key(request), [i.model_dump() for i in body.items])

        @app.get(prefix+"/commerce/orders")
        def orders(request: Request): return {"items": query.orders(principal(request))}

        @app.post(prefix+"/merchants/{merchant_id}/invoices", status_code=201)
        def invoice(merchant_id: uuid.UUID, body: InvoiceBody, request: Request): return commerce.invoice(principal(request), key(request), merchant_id, [line.model_dump() for line in body.lines])

        @app.post(prefix+"/merchants/{merchant_id}/memberships", status_code=204)
        def member(merchant_id: uuid.UUID, body: MemberBody, request: Request):
            commerce.grant_membership(principal(request), merchant_id, body.subject_id, body.role)
            return Response(status_code=204)

        @app.post(prefix+"/payouts/{payment_id}/approvals", status_code=204)
        def approve(payment_id: uuid.UUID, body: Confirmation, request: Request):
            commerce.approve(principal(request), payment_id, body.payload_digest)
            return Response(status_code=204)

    else:
        @app.get(prefix+"/transfers")
        def transfers(request: Request): return {"items": query.transfers(principal(request))}

        @app.get(prefix+"/market")
        def market(): return query.market()

        @app.get(prefix+"/portfolio")
        def portfolio(request: Request): return store.portfolio(principal(request))

        @app.post(prefix+"/sandbox/grants", status_code=202)
        def grant(body: GrantBody, request: Request): return store.request_grant(principal(request), key(request), body.asset, body.quantity_atoms)

        @app.post(prefix+"/quotes", status_code=201)
        def quote(body: QuoteBody, request: Request): return store.quote(principal(request), key(request), body.side, body.quantity_atoms)

        @app.post(prefix+"/quotes/{quote_id}/authorizations", status_code=202)
        def order(quote_id: uuid.UUID, body: Confirmation, request: Request): return store.authorize_quote(principal(request), key(request), quote_id, body.payload_digest)

        @app.get(prefix+"/orders")
        def order_list(request: Request): return {"items": query.fincoin_orders(principal(request))}

        @app.post(prefix+"/transfer-drafts", status_code=201)
        def transfer(body: TransferBody, request: Request): return store.transfer_draft(principal(request), key(request), body.recipient_address, body.quantity_atoms)

        @app.post(prefix+"/transfer-drafts/{transfer_id}/authorizations", status_code=202)
        def transfer_confirm(transfer_id: uuid.UUID, body: Confirmation, request: Request): return store.authorize_transfer(principal(request), key(request), transfer_id, body.payload_digest)

    return app
