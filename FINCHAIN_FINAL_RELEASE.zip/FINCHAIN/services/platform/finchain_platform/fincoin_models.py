from sqlalchemy import Column, Uuid, String, Integer, JSON, ForeignKey, UniqueConstraint, CheckConstraint
from .storage import Base, Record, UTC, Q


class Tick(Record, Base):
    __tablename__ = "fincoin_price_history"
    __table_args__ = (CheckConstraint("price > 0", name="positive_synthetic_price"), {"schema": "app"})
    sequence = Column(Integer, nullable=False, unique=True)
    price = Column(Q, nullable=False)
    observed_at = Column(UTC, nullable=False, index=True)
    source = Column(String(16), nullable=False, default="synthetic")


class Quote(Record, Base):
    __tablename__ = "fincoin_quotes"
    __table_args__ = {"schema": "app"}
    operation_id = Column(Uuid, ForeignKey("ops.operations.id"), nullable=False, unique=True)
    wallet_id = Column(Uuid, ForeignKey("ledger.wallets.id"), nullable=False, index=True)
    side = Column(String(4), nullable=False)
    quantity = Column(Q, nullable=False)
    price = Column(Q, nullable=False)
    gross = Column(Q, nullable=False)
    fee = Column(Q, nullable=False)
    total = Column(Q, nullable=False)
    tick_id = Column(Uuid, ForeignKey("app.fincoin_price_history.id"), nullable=False)
    expires_at = Column(UTC, nullable=False)
    payload = Column(JSON, nullable=False)
    payload_digest = Column(String(64), nullable=False)


class FincoinOrder(Record, Base):
    __tablename__ = "fincoin_orders"
    __table_args__ = {"schema": "app"}
    quote_id = Column(Uuid, ForeignKey("app.fincoin_quotes.id"), nullable=False, unique=True)
    operation_id = Column(Uuid, ForeignKey("ops.operations.id"), nullable=False, unique=True)
    status = Column(String(16), nullable=False, default="QUEUED")
    reason_code = Column(String(40))
    filled_at = Column(UTC)


class Fill(Record, Base):
    __tablename__ = "fincoin_fills"
    __table_args__ = {"schema": "ledger"}
    order_id = Column(Uuid, ForeignKey("app.fincoin_orders.id"), nullable=False, unique=True)
    journal_id = Column(Uuid, ForeignKey("ledger.transactions.id"), nullable=False, unique=True)
    wallet_id = Column(Uuid, ForeignKey("ledger.wallets.id"), nullable=False, index=True)
    side = Column(String(4), nullable=False)
    quantity = Column(Q, nullable=False)
    gross = Column(Q, nullable=False)
    fee = Column(Q, nullable=False)
    total = Column(Q, nullable=False)


class AssetTransfer(Record, Base):
    __tablename__ = "fincoin_transactions"
    __table_args__ = {"schema": "app"}
    operation_id = Column(Uuid, ForeignKey("ops.operations.id"), nullable=False, unique=True)
    sender_id = Column(Uuid, ForeignKey("ledger.wallets.id"), nullable=False, index=True)
    receiver_id = Column(Uuid, ForeignKey("ledger.wallets.id"), nullable=False, index=True)
    quantity = Column(Q, nullable=False)
    payload = Column(JSON, nullable=False)
    status = Column(String(16), nullable=False, default="DRAFT")


class Lot(Record, Base):
    __tablename__ = "fincoin_cost_lots"
    __table_args__ = (CheckConstraint("quantity >= 0 AND remaining_cost >= 0", name="nonnegative_lot"), {"schema": "readmodel"})
    wallet_id = Column(Uuid, ForeignKey("ledger.wallets.id"), nullable=False, index=True)
    journal_id = Column(Uuid, ForeignKey("ledger.transactions.id"), nullable=False, index=True)
    quantity = Column(Q, nullable=False)
    remaining_cost = Column(Q, nullable=False)
    provenance = Column(String(16), nullable=False)


class Disposal(Record, Base):
    __tablename__ = "fincoin_lot_disposals"
    __table_args__ = (UniqueConstraint("fill_id", "lot_id"), {"schema": "readmodel"})
    fill_id = Column(Uuid, ForeignKey("ledger.fincoin_fills.id"), nullable=False, index=True)
    lot_id = Column(Uuid, ForeignKey("readmodel.fincoin_cost_lots.id"), nullable=False, index=True)
    quantity = Column(Q, nullable=False)
    cost = Column(Q, nullable=False)
    proceeds = Column(Q, nullable=False)
    provenance = Column(String(16), nullable=False)


class Grant(Record, Base):
    __tablename__ = "fincoin_faucet_grants"
    __table_args__ = {"schema": "app"}
    operation_id = Column(Uuid, ForeignKey("ops.operations.id"), nullable=False, unique=True)
    wallet_id = Column(Uuid, ForeignKey("ledger.wallets.id"), nullable=False, index=True)
    asset_code = Column(String(16), nullable=False)
    quantity = Column(Q, nullable=False)
    status = Column(String(16), nullable=False, default="QUEUED")


FINCOIN_TABLES = tuple(value.__table__ for value in list(globals().values()) if isinstance(value, type) and value.__module__ == __name__ and hasattr(value, "__table__"))
