"""Independent durable gateway simulator; no banking/payment-provider integration."""
import hmac
import hashlib
import os
import uuid
from datetime import timedelta
from pathlib import Path
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import Column, Uuid, String, JSON, create_engine, select
from sqlalchemy.orm import declarative_base, sessionmaker
from .storage import Record, UTC, utcnow
from .protocol import canonical, integer
from .ledger import RuleViolation

GatewayBase = declarative_base()


class GatewayOperation(Record, GatewayBase):
    __tablename__ = "gateway_operations"
    operation_id = Column(Uuid, nullable=False, unique=True)
    network_id = Column(String(80), nullable=False)
    request_digest = Column(String(64), nullable=False)
    request = Column(JSON, nullable=False)
    status = Column(String(16), nullable=False)
    event_id = Column(Uuid, nullable=False, default=uuid.uuid4)
    resolve_at = Column(UTC)


class GatewayStatement(Record, GatewayBase):
    __tablename__ = "gateway_statements"
    operation_id = Column(Uuid, nullable=False, unique=True)
    evidence = Column(JSON, nullable=False)


class Simulator:
    def __init__(self, url, signing_key, network="finchain-bpi-sandbox-1", test_mode=False):
        if not test_mode and not url.startswith("postgresql+psycopg://"):
            raise ValueError("Gateway requires its own PostgreSQL database")
        if len(signing_key) < 32 or not network.startswith("finchain-bpi-sandbox-"):
            raise ValueError("Invalid gateway sandbox configuration")
        self.engine = create_engine(url, hide_parameters=True)
        self.sessions = sessionmaker(self.engine, expire_on_commit=False)
        self._key, self.network = signing_key, network

    def submit(self, request):
        if request["network_id"] != self.network or request["environment"] != "sandbox" or request["currency"] != "INR" or request["scenario"] not in {"SUCCESS", "FAILURE", "UNKNOWN"} or request["kind"] not in {"FUNDING", "TRANSFER", "REDEMPTION"}:
            raise RuleViolation("GATEWAY_REQUEST_INVALID", 422)
        integer(request["amount_minor"])
        operation_id = uuid.UUID(request["operation_id"])
        request_hash = hashlib.sha256(canonical(request)).hexdigest()
        insert = __import__("sqlalchemy.dialects."+self.engine.dialect.name, fromlist=["insert"]).insert
        with self.sessions.begin() as db:
            status = "UNKNOWN" if request["scenario"] == "UNKNOWN" else "FAILED" if request["scenario"] == "FAILURE" else "SUCCEEDED"
            db.execute(insert(GatewayOperation).values(id=uuid.uuid4(), created_at=utcnow(), operation_id=operation_id, network_id=self.network, request_digest=request_hash,
                request=request, status=status, event_id=uuid.uuid4(), resolve_at=utcnow()+timedelta(seconds=15) if status == "UNKNOWN" else None).on_conflict_do_nothing(index_elements=["operation_id"]))
            row = db.scalar(select(GatewayOperation).where(GatewayOperation.operation_id == operation_id).with_for_update())
            if row.request_digest != request_hash:
                raise RuleViolation("GATEWAY_IDEMPOTENCY_CONFLICT")
            if row.status == "UNKNOWN" and row.resolve_at <= utcnow():
                row.status, row.event_id = "SUCCEEDED", uuid.uuid4()
            evidence = {"operation_id": str(row.operation_id), "event_id": str(row.event_id), "network_id": self.network, "amount_minor": row.request["amount_minor"],
                        "currency": "INR", "status": row.status, "environment": "sandbox", "provider": "FINCHAIN_SIMULATOR"}
            if row.status != "UNKNOWN" and not db.scalar(select(GatewayStatement).where(GatewayStatement.operation_id == row.operation_id)):
                db.add(GatewayStatement(operation_id=row.operation_id, evidence=evidence))
            return {"evidence": evidence, "signature": hmac.new(self._key, canonical(evidence), hashlib.sha256).hexdigest()}


class GatewayRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    operation_id: str = Field(max_length=36)
    network_id: str = Field(max_length=80)
    environment: str = Field(max_length=8)
    currency: str = Field(max_length=3)
    amount_minor: str = Field(max_length=19)
    kind: str = Field(max_length=16)
    scenario: str = Field(max_length=16)


def create_app():
    if os.environ.get("GATEWAY_MODE") != "simulated":
        raise ValueError("Only simulated gateway mode exists")
    secret = Path(os.environ["GATEWAY_SERVICE_KEY_FILE"]).read_text().strip()
    signing_key = Path(os.environ["GATEWAY_SIGNING_KEY_FILE"]).read_bytes()
    simulator = Simulator(os.environ["GATEWAY_DATABASE_URL"], signing_key, os.environ["NETWORK_ID"])
    app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)

    @app.middleware("http")
    async def auth(request: Request, call_next):
        if not hmac.compare_digest(request.headers.get("x-service-key", ""), secret):
            return JSONResponse({"code": "FORBIDDEN"}, status_code=403)
        return await call_next(request)

    @app.exception_handler(RuleViolation)
    async def violation(_, exc):
        return JSONResponse({"code": exc.code}, status_code=exc.status)

    @app.post("/operations")
    def submit(body: GatewayRequest):
        return simulator.submit(body.model_dump())

    @app.get("/health/ready")
    def ready():
        with simulator.engine.connect() as connection:
            connection.exec_driver_sql("SELECT 1")
        return {"status": "ready", "environment": "sandbox"}

    return app
