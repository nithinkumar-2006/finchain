"""Forward-only, transactional, checksum-verified SQL migrations for one database."""
import argparse
import hashlib
import os
from pathlib import Path
from sqlalchemy import create_engine, text


def migrate(url, kind):
    if not url.startswith("postgresql+psycopg://"):
        raise ValueError("Dedicated PostgreSQL database required")
    if kind not in {"bpi", "fincoin", "gateway", "signer", "public"}:
        raise ValueError("Unknown database kind")
    root = Path(__file__).parent / "migrations"
    files = sorted(root.glob(f"{kind}_*.sql"))
    if kind in {"bpi", "fincoin"}:
        files += sorted(root.glob("ledger_*.sql"))
    engine = create_engine(url, hide_parameters=True)
    with engine.begin() as connection:
        connection.execute(text("SELECT pg_advisory_xact_lock(1976132401)"))
        connection.execute(text("CREATE TABLE IF NOT EXISTS public.schema_migrations(version text PRIMARY KEY, kind text NOT NULL, checksum text NOT NULL, applied_at timestamptz NOT NULL DEFAULT now())"))
        previous = dict(connection.execute(text("SELECT DISTINCT kind, kind FROM public.schema_migrations")).all())
        if previous and set(previous) != {kind}:
            raise ValueError("Refusing to mix domains or service schemas in one database")
        for file in files:
            raw = file.read_bytes()
            checksum = hashlib.sha256(raw).hexdigest()
            old = connection.execute(text("SELECT checksum FROM public.schema_migrations WHERE version=:v"), {"v": file.name}).scalar()
            if old:
                if old != checksum:
                    raise ValueError("Applied migration checksum mismatch: " + file.name)
                continue
            with connection.connection.driver_connection.cursor() as cursor:
                cursor.execute(raw.decode("utf-8"))
            connection.execute(text("INSERT INTO public.schema_migrations(version,kind,checksum) VALUES (:v,:k,:c)"), {"v": file.name, "k": kind, "c": checksum})
            print("Applied", file.name)
    engine.dispose()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("kind", choices=["bpi", "fincoin", "gateway", "signer", "public"])
    args = parser.parse_args()
    migrate(os.environ["MIGRATION_DATABASE_URL"], args.kind)
