-- Immutable initial schema snapshot; apply with migrate.py.
CREATE SCHEMA IF NOT EXISTS "app";
CREATE SCHEMA IF NOT EXISTS "audit";
CREATE SCHEMA IF NOT EXISTS "core";
CREATE SCHEMA IF NOT EXISTS "ledger";
CREATE SCHEMA IF NOT EXISTS "ops";

CREATE TABLE app.system_settings (
	setting_key VARCHAR(80) NOT NULL, 
	value JSON NOT NULL, 
	version INTEGER NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (setting_key)
)

;

CREATE TABLE audit.audit_streams (
	stream VARCHAR(16) NOT NULL, 
	head VARCHAR(64) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (stream)
)

;

CREATE TABLE core.networks (
	network_code VARCHAR(80) NOT NULL, 
	domain VARCHAR(8) NOT NULL, 
	environment VARCHAR(8) NOT NULL, 
	policy JSON NOT NULL, 
	status VARCHAR(16) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT sandbox_domain CHECK (domain IN ('BPI','FINCOIN') AND environment = 'sandbox'), 
	UNIQUE (network_code)
)

;

CREATE TABLE core.subjects (
	status VARCHAR(16) NOT NULL, 
	credentials_version INTEGER NOT NULL, 
	label VARCHAR(80) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id)
)

;

CREATE TABLE app.notifications (
	subject_id UUID NOT NULL, 
	message VARCHAR(300) NOT NULL, 
	read_at TIMESTAMP WITH TIME ZONE, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(subject_id) REFERENCES core.subjects (id)
)

;
CREATE INDEX ix_app_notifications_subject_id ON app.notifications (subject_id);

CREATE TABLE core.principals (
	subject_id UUID, 
	service_code VARCHAR(32), 
	kind VARCHAR(16) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT principal_kind CHECK (kind IN ('USER','ORGANIZATION','SERVICE')), 
	UNIQUE (subject_id), 
	FOREIGN KEY(subject_id) REFERENCES core.subjects (id), 
	UNIQUE (service_code)
)

;

CREATE TABLE core.staff_grants (
	subject_id UUID NOT NULL, 
	role VARCHAR(16) NOT NULL, 
	revoked_at TIMESTAMP WITH TIME ZONE, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (subject_id, role), 
	FOREIGN KEY(subject_id) REFERENCES core.subjects (id)
)

;

CREATE TABLE core.validators (
	network_id UUID NOT NULL, 
	public_key BYTEA NOT NULL, 
	key_handle VARCHAR(80) NOT NULL, 
	active BOOLEAN NOT NULL, 
	valid_from_height BIGINT NOT NULL, 
	last_heartbeat TIMESTAMP WITH TIME ZONE, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(network_id) REFERENCES core.networks (id), 
	UNIQUE (key_handle)
)

;
CREATE INDEX ix_core_validators_network_id ON core.validators (network_id);

CREATE TABLE ops.operations (
	network_id UUID NOT NULL, 
	actor_id UUID, 
	kind VARCHAR(32) NOT NULL, 
	parent_id UUID, 
	slot VARCHAR(32), 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (parent_id, slot), 
	FOREIGN KEY(network_id) REFERENCES core.networks (id), 
	FOREIGN KEY(actor_id) REFERENCES core.subjects (id), 
	FOREIGN KEY(parent_id) REFERENCES ops.operations (id)
)

;
CREATE INDEX ix_ops_operations_network_id ON ops.operations (network_id);

CREATE TABLE app.merchant_accounts (
	principal_id UUID NOT NULL, 
	display_name VARCHAR(80) NOT NULL, 
	category VARCHAR(32) NOT NULL, 
	status VARCHAR(24) NOT NULL, 
	timezone VARCHAR(40) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (principal_id), 
	FOREIGN KEY(principal_id) REFERENCES core.principals (id)
)

;

CREATE TABLE audit.audit_logs (
	actor_id UUID, 
	operation_id UUID, 
	action VARCHAR(48) NOT NULL, 
	result VARCHAR(40) NOT NULL, 
	previous_hash VARCHAR(64) NOT NULL, 
	event_hash VARCHAR(64) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(actor_id) REFERENCES core.subjects (id), 
	FOREIGN KEY(operation_id) REFERENCES ops.operations (id), 
	UNIQUE (event_hash)
)

;

CREATE TABLE ledger.blocks (
	network_id UUID NOT NULL, 
	height BIGINT NOT NULL, 
	block_hash VARCHAR(64) NOT NULL, 
	header JSON NOT NULL, 
	signature VARCHAR(86) NOT NULL, 
	validator_id UUID NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (network_id, height), 
	FOREIGN KEY(network_id) REFERENCES core.networks (id), 
	UNIQUE (block_hash), 
	FOREIGN KEY(validator_id) REFERENCES core.validators (id)
)

;

CREATE TABLE ledger.chain_heads (
	network_id UUID NOT NULL, 
	height BIGINT NOT NULL, 
	block_hash VARCHAR(64) NOT NULL, 
	writer_epoch BIGINT NOT NULL, 
	validator_id UUID NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (network_id), 
	FOREIGN KEY(network_id) REFERENCES core.networks (id), 
	FOREIGN KEY(validator_id) REFERENCES core.validators (id)
)

;

CREATE TABLE ledger.transactions (
	operation_id UUID NOT NULL, 
	network_id UUID NOT NULL, 
	kind VARCHAR(40) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (operation_id), 
	FOREIGN KEY(operation_id) REFERENCES ops.operations (id), 
	FOREIGN KEY(network_id) REFERENCES core.networks (id)
)

;

CREATE TABLE ledger.wallets (
	network_id UUID NOT NULL, 
	owner_id UUID NOT NULL, 
	address VARCHAR(100) NOT NULL, 
	public_key BYTEA NOT NULL, 
	key_id UUID NOT NULL, 
	status VARCHAR(16) NOT NULL, 
	next_nonce BIGINT NOT NULL, 
	label VARCHAR(80) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (network_id, owner_id), 
	UNIQUE (id, network_id), 
	CONSTRAINT wallet_nonce CHECK (next_nonce >= 0), 
	FOREIGN KEY(network_id) REFERENCES core.networks (id), 
	FOREIGN KEY(owner_id) REFERENCES core.principals (id), 
	UNIQUE (address), 
	UNIQUE (key_id)
)

;
CREATE INDEX ix_ledger_wallets_owner_id ON ledger.wallets (owner_id);

CREATE TABLE ops.authorizations (
	operation_id UUID NOT NULL, 
	actor_id UUID NOT NULL, 
	credentials_version INTEGER NOT NULL, 
	session_id UUID NOT NULL, 
	payload_digest VARCHAR(64) NOT NULL, 
	payload JSON NOT NULL, 
	signature VARCHAR(86), 
	transaction_hash VARCHAR(64), 
	expires_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	signed_at TIMESTAMP WITH TIME ZONE, 
	consumed_at TIMESTAMP WITH TIME ZONE, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (operation_id), 
	FOREIGN KEY(operation_id) REFERENCES ops.operations (id), 
	FOREIGN KEY(actor_id) REFERENCES core.subjects (id), 
	UNIQUE (transaction_hash)
)

;

CREATE TABLE ops.commands (
	operation_id UUID NOT NULL, 
	kind VARCHAR(32) NOT NULL, 
	payload JSON NOT NULL, 
	state VARCHAR(16) NOT NULL, 
	attempts INTEGER NOT NULL, 
	error_code VARCHAR(40), 
	next_attempt_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (operation_id, kind), 
	FOREIGN KEY(operation_id) REFERENCES ops.operations (id)
)

;
CREATE INDEX ix_ops_commands_operation_id ON ops.commands (operation_id);
CREATE INDEX ix_ops_commands_state ON ops.commands (state);

CREATE TABLE ops.idempotency_keys (
	subject_id UUID NOT NULL, 
	route VARCHAR(120) NOT NULL, 
	key UUID NOT NULL, 
	request_digest VARCHAR(64) NOT NULL, 
	operation_id UUID NOT NULL, 
	response JSON NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (subject_id, route, key), 
	FOREIGN KEY(subject_id) REFERENCES core.subjects (id), 
	FOREIGN KEY(operation_id) REFERENCES ops.operations (id)
)

;

CREATE TABLE ops.outbox (
	operation_id UUID NOT NULL, 
	event_type VARCHAR(48) NOT NULL, 
	payload JSON NOT NULL, 
	published_at TIMESTAMP WITH TIME ZONE, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (operation_id, event_type), 
	FOREIGN KEY(operation_id) REFERENCES ops.operations (id)
)

;
CREATE INDEX ix_ops_outbox_operation_id ON ops.outbox (operation_id);

CREATE TABLE app.api_keys (
	merchant_id UUID NOT NULL, 
	creator_id UUID NOT NULL, 
	prefix VARCHAR(16) NOT NULL, 
	secret_digest VARCHAR(64) NOT NULL, 
	scopes JSON NOT NULL, 
	expires_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	revoked_at TIMESTAMP WITH TIME ZONE, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(merchant_id) REFERENCES app.merchant_accounts (id), 
	FOREIGN KEY(creator_id) REFERENCES core.subjects (id), 
	UNIQUE (secret_digest)
)

;
CREATE INDEX ix_app_api_keys_merchant_id ON app.api_keys (merchant_id);

CREATE TABLE app.commerce_orders (
	operation_id UUID NOT NULL, 
	buyer_id UUID NOT NULL, 
	merchant_id UUID NOT NULL, 
	total BIGINT NOT NULL, 
	status VARCHAR(24) NOT NULL, 
	reservation_expires_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	paid_at TIMESTAMP WITH TIME ZONE, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (operation_id), 
	FOREIGN KEY(operation_id) REFERENCES ops.operations (id), 
	FOREIGN KEY(buyer_id) REFERENCES core.subjects (id), 
	FOREIGN KEY(merchant_id) REFERENCES app.merchant_accounts (id)
)

;
CREATE INDEX ix_app_commerce_orders_buyer_id ON app.commerce_orders (buyer_id);
CREATE INDEX ix_app_commerce_orders_merchant_id ON app.commerce_orders (merchant_id);

CREATE TABLE app.merchant_memberships (
	merchant_id UUID NOT NULL, 
	subject_id UUID NOT NULL, 
	role VARCHAR(16) NOT NULL, 
	revoked_at TIMESTAMP WITH TIME ZONE, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (merchant_id, subject_id), 
	FOREIGN KEY(merchant_id) REFERENCES app.merchant_accounts (id), 
	FOREIGN KEY(subject_id) REFERENCES core.subjects (id)
)

;
CREATE INDEX ix_app_merchant_memberships_merchant_id ON app.merchant_memberships (merchant_id);
CREATE INDEX ix_app_merchant_memberships_subject_id ON app.merchant_memberships (subject_id);

CREATE TABLE app.merchant_products (
	merchant_id UUID NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	description VARCHAR(500) NOT NULL, 
	category VARCHAR(32) NOT NULL, 
	price BIGINT NOT NULL, 
	stock INTEGER NOT NULL, 
	deleted_at TIMESTAMP WITH TIME ZONE, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT product_values CHECK (price > 0 AND stock >= 0), 
	FOREIGN KEY(merchant_id) REFERENCES app.merchant_accounts (id)
)

;
CREATE INDEX ix_app_merchant_products_merchant_id ON app.merchant_products (merchant_id);

CREATE TABLE app.webhooks (
	merchant_id UUID NOT NULL, 
	destination VARCHAR(300) NOT NULL, 
	events JSON NOT NULL, 
	secret_ciphertext BYTEA NOT NULL, 
	status VARCHAR(16) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(merchant_id) REFERENCES app.merchant_accounts (id)
)

;
CREATE INDEX ix_app_webhooks_merchant_id ON app.webhooks (merchant_id);

CREATE TABLE ledger.accounts (
	network_id UUID NOT NULL, 
	wallet_id UUID, 
	asset_code VARCHAR(16) NOT NULL, 
	bucket VARCHAR(16) NOT NULL, 
	account_code VARCHAR(120) NOT NULL, 
	normal_side VARCHAR(6) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (network_id, account_code), 
	UNIQUE (id, asset_code, network_id), 
	FOREIGN KEY(wallet_id, network_id) REFERENCES ledger.wallets (id, network_id), 
	CONSTRAINT account_side CHECK (normal_side IN ('DEBIT','CREDIT')), 
	FOREIGN KEY(network_id) REFERENCES core.networks (id)
)

;
CREATE INDEX ix_ledger_accounts_wallet_id ON ledger.accounts (wallet_id);

CREATE TABLE ledger.blockchain_transactions (
	network_id UUID NOT NULL, 
	block_id UUID NOT NULL, 
	tx_index INTEGER NOT NULL, 
	journal_id UUID NOT NULL, 
	transaction_hash VARCHAR(64) NOT NULL, 
	payload JSON NOT NULL, 
	signature VARCHAR(86) NOT NULL, 
	public_key BYTEA NOT NULL, 
	journal_commitment VARCHAR(64) NOT NULL, 
	salt_ciphertext BYTEA NOT NULL, 
	sender_wallet_id UUID, 
	nonce BIGINT, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (block_id, tx_index), 
	UNIQUE (sender_wallet_id, nonce), 
	FOREIGN KEY(network_id) REFERENCES core.networks (id), 
	FOREIGN KEY(block_id) REFERENCES ledger.blocks (id), 
	UNIQUE (journal_id), 
	FOREIGN KEY(journal_id) REFERENCES ledger.transactions (id), 
	UNIQUE (transaction_hash), 
	FOREIGN KEY(sender_wallet_id) REFERENCES ledger.wallets (id)
)

;
CREATE INDEX ix_ledger_blockchain_transactions_block_id ON ledger.blockchain_transactions (block_id);

CREATE TABLE ledger.holds (
	wallet_id UUID NOT NULL, 
	operation_id UUID NOT NULL, 
	asset_code VARCHAR(16) NOT NULL, 
	amount NUMERIC(38, 0) NOT NULL, 
	nonce BIGINT NOT NULL, 
	expires_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	status VARCHAR(16) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT positive_hold CHECK (amount > 0), 
	FOREIGN KEY(wallet_id) REFERENCES ledger.wallets (id), 
	UNIQUE (operation_id), 
	FOREIGN KEY(operation_id) REFERENCES ops.operations (id)
)

;
CREATE INDEX ix_ledger_holds_wallet_id ON ledger.holds (wallet_id);
CREATE UNIQUE INDEX one_active_wallet_hold ON ledger.holds (wallet_id) WHERE status = 'ACTIVE';

CREATE TABLE app.order_items (
	order_id UUID NOT NULL, 
	product_id UUID NOT NULL, 
	name_snapshot VARCHAR(100) NOT NULL, 
	unit_price BIGINT NOT NULL, 
	quantity INTEGER NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT order_item_values CHECK (quantity > 0 AND unit_price > 0), 
	FOREIGN KEY(order_id) REFERENCES app.commerce_orders (id), 
	FOREIGN KEY(product_id) REFERENCES app.merchant_products (id)
)

;
CREATE INDEX ix_app_order_items_order_id ON app.order_items (order_id);

CREATE TABLE app.payment_requests (
	operation_id UUID NOT NULL, 
	wallet_id UUID NOT NULL, 
	token_digest VARCHAR(64) NOT NULL, 
	amount BIGINT NOT NULL, 
	expires_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	status VARCHAR(16) NOT NULL, 
	active_payment_id UUID, 
	order_id UUID, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT positive_request CHECK (amount > 0), 
	UNIQUE (operation_id), 
	FOREIGN KEY(operation_id) REFERENCES ops.operations (id), 
	FOREIGN KEY(wallet_id) REFERENCES ledger.wallets (id), 
	UNIQUE (token_digest), 
	FOREIGN KEY(order_id) REFERENCES app.commerce_orders (id)
)

;
CREATE INDEX ix_app_payment_requests_wallet_id ON app.payment_requests (wallet_id);

CREATE TABLE ledger.balances (
	account_id UUID NOT NULL, 
	amount NUMERIC(38, 0) NOT NULL, 
	version BIGINT NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT nonnegative_balance CHECK (amount >= 0), 
	UNIQUE (account_id), 
	FOREIGN KEY(account_id) REFERENCES ledger.accounts (id)
)

;

CREATE TABLE ledger.journal_lines (
	journal_id UUID NOT NULL, 
	line_no INTEGER NOT NULL, 
	network_id UUID NOT NULL, 
	account_id UUID NOT NULL, 
	asset_code VARCHAR(16) NOT NULL, 
	side VARCHAR(6) NOT NULL, 
	amount NUMERIC(38, 0) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (journal_id, line_no), 
	FOREIGN KEY(account_id, asset_code, network_id) REFERENCES ledger.accounts (id, asset_code, network_id), 
	CONSTRAINT positive_journal_line CHECK (amount > 0 AND side IN ('DEBIT','CREDIT')), 
	FOREIGN KEY(journal_id) REFERENCES ledger.transactions (id), 
	FOREIGN KEY(network_id) REFERENCES core.networks (id)
)

;
CREATE INDEX ix_ledger_journal_lines_account_id ON ledger.journal_lines (account_id);
CREATE INDEX ix_ledger_journal_lines_journal_id ON ledger.journal_lines (journal_id);

CREATE TABLE ops.webhook_deliveries (
	webhook_id UUID NOT NULL, 
	event_id UUID NOT NULL, 
	event_type VARCHAR(48) NOT NULL, 
	payload JSON NOT NULL, 
	status VARCHAR(16) NOT NULL, 
	attempts INTEGER NOT NULL, 
	response_status INTEGER, 
	next_attempt_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (webhook_id, event_id), 
	FOREIGN KEY(webhook_id) REFERENCES app.webhooks (id)
)

;
CREATE INDEX ix_ops_webhook_deliveries_webhook_id ON ops.webhook_deliveries (webhook_id);

CREATE TABLE app.invoices (
	merchant_id UUID NOT NULL, 
	request_id UUID NOT NULL, 
	number VARCHAR(40) NOT NULL, 
	lines JSON NOT NULL, 
	total BIGINT NOT NULL, 
	status VARCHAR(16) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (merchant_id, number), 
	FOREIGN KEY(merchant_id) REFERENCES app.merchant_accounts (id), 
	UNIQUE (request_id), 
	FOREIGN KEY(request_id) REFERENCES app.payment_requests (id)
)

;
CREATE INDEX ix_app_invoices_merchant_id ON app.invoices (merchant_id);

CREATE TABLE app.payments (
	operation_id UUID NOT NULL, 
	actor_id UUID NOT NULL, 
	sender_id UUID NOT NULL, 
	receiver_id UUID NOT NULL, 
	amount BIGINT NOT NULL, 
	payment_type VARCHAR(8) NOT NULL, 
	expires_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	request_id UUID, 
	original_payment_id UUID, 
	purpose VARCHAR(16) NOT NULL, 
	payload JSON NOT NULL, 
	payload_digest VARCHAR(64) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT positive_payment CHECK (amount > 0), 
	UNIQUE (operation_id), 
	FOREIGN KEY(operation_id) REFERENCES ops.operations (id), 
	FOREIGN KEY(actor_id) REFERENCES core.subjects (id), 
	FOREIGN KEY(sender_id) REFERENCES ledger.wallets (id), 
	FOREIGN KEY(receiver_id) REFERENCES ledger.wallets (id), 
	FOREIGN KEY(request_id) REFERENCES app.payment_requests (id), 
	FOREIGN KEY(original_payment_id) REFERENCES app.payments (id)
)

;
CREATE INDEX ix_app_payments_actor_id ON app.payments (actor_id);
CREATE INDEX ix_app_payments_original_payment_id ON app.payments (original_payment_id);
CREATE INDEX ix_app_payments_receiver_id ON app.payments (receiver_id);
CREATE INDEX ix_app_payments_request_id ON app.payments (request_id);
CREATE INDEX ix_app_payments_sender_id ON app.payments (sender_id);

CREATE TABLE app.qr_payments (
	request_id UUID NOT NULL, 
	signed_link VARCHAR(600) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (request_id), 
	FOREIGN KEY(request_id) REFERENCES app.payment_requests (id)
)

;

CREATE TABLE app.approval_decisions (
	payment_id UUID NOT NULL, 
	approver_id UUID NOT NULL, 
	payload_digest VARCHAR(64) NOT NULL, 
	decision VARCHAR(16) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (payment_id, approver_id), 
	FOREIGN KEY(payment_id) REFERENCES app.payments (id), 
	FOREIGN KEY(approver_id) REFERENCES core.subjects (id)
)

;

CREATE TABLE app.fraud_events (
	payment_id UUID NOT NULL, 
	reviewer_id UUID, 
	decision VARCHAR(16) NOT NULL, 
	reason VARCHAR(300) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(payment_id) REFERENCES app.payments (id), 
	FOREIGN KEY(reviewer_id) REFERENCES core.subjects (id)
)

;
CREATE INDEX ix_app_fraud_events_payment_id ON app.fraud_events (payment_id);

CREATE TABLE app.fraud_scores (
	payment_id UUID NOT NULL, 
	policy_version VARCHAR(16) NOT NULL, 
	payload_digest VARCHAR(64) NOT NULL, 
	score INTEGER NOT NULL, 
	decision VARCHAR(16) NOT NULL, 
	reasons JSON NOT NULL, 
	expires_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT risk_range CHECK (score >= 0 AND score <= 100), 
	UNIQUE (payment_id), 
	FOREIGN KEY(payment_id) REFERENCES app.payments (id)
)

;

CREATE TABLE app.refunds (
	original_payment_id UUID NOT NULL, 
	refund_payment_id UUID NOT NULL, 
	amount BIGINT NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(original_payment_id) REFERENCES app.payments (id), 
	UNIQUE (refund_payment_id), 
	FOREIGN KEY(refund_payment_id) REFERENCES app.payments (id)
)

;
CREATE INDEX ix_app_refunds_original_payment_id ON app.refunds (original_payment_id);

CREATE TABLE ledger.payment_states (
	payment_id UUID NOT NULL, 
	business_status VARCHAR(32) NOT NULL, 
	chain_status VARCHAR(16) NOT NULL, 
	settlement_status VARCHAR(16) NOT NULL, 
	reason_code VARCHAR(40), 
	completed_at TIMESTAMP WITH TIME ZONE, 
	version INTEGER NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (payment_id), 
	FOREIGN KEY(payment_id) REFERENCES app.payments (id)
)

;

CREATE TABLE ledger.settlements (
	operation_id UUID NOT NULL, 
	payment_id UUID, 
	wallet_id UUID NOT NULL, 
	kind VARCHAR(16) NOT NULL, 
	amount BIGINT NOT NULL, 
	scenario VARCHAR(16) NOT NULL, 
	status VARCHAR(16) NOT NULL, 
	result_applied_at TIMESTAMP WITH TIME ZONE, 
	next_check_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (operation_id), 
	FOREIGN KEY(operation_id) REFERENCES ops.operations (id), 
	UNIQUE (payment_id), 
	FOREIGN KEY(payment_id) REFERENCES app.payments (id), 
	FOREIGN KEY(wallet_id) REFERENCES ledger.wallets (id)
)

;

CREATE TABLE ops.gateway_transactions (
	settlement_id UUID NOT NULL, 
	provider_event_id UUID NOT NULL, 
	response_digest VARCHAR(64) NOT NULL, 
	response JSON NOT NULL, 
	status VARCHAR(16) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(settlement_id) REFERENCES ledger.settlements (id), 
	UNIQUE (provider_event_id)
)

;
CREATE INDEX ix_ops_gateway_transactions_settlement_id ON ops.gateway_transactions (settlement_id);