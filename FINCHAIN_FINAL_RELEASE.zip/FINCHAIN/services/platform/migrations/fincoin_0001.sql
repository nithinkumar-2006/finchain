-- Immutable initial schema snapshot; apply with migrate.py.
CREATE SCHEMA IF NOT EXISTS "app";
CREATE SCHEMA IF NOT EXISTS "audit";
CREATE SCHEMA IF NOT EXISTS "core";
CREATE SCHEMA IF NOT EXISTS "ledger";
CREATE SCHEMA IF NOT EXISTS "ops";
CREATE SCHEMA IF NOT EXISTS "readmodel";

CREATE TABLE app.fincoin_price_history (
	sequence INTEGER NOT NULL, 
	price NUMERIC(38, 0) NOT NULL, 
	observed_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	source VARCHAR(16) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT positive_synthetic_price CHECK (price > 0), 
	UNIQUE (sequence)
)

;
CREATE INDEX ix_app_fincoin_price_history_observed_at ON app.fincoin_price_history (observed_at);

CREATE TABLE audit.audit_streams (
	stream VARCHAR(16) NOT NULL, 
	head VARCHAR(64) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (stream)
)

;

CREATE TABLE core.networks (
	network_code VARCHAR(80) NOT NULL, 
	domain VARCHAR(8) NOT NULL, 
	environment VARCHAR(8) NOT NULL, 
	policy JSON NOT NULL, 
	status VARCHAR(16) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT sandbox_domain CHECK (domain IN ('BPI','FINCOIN') AND environment = 'sandbox'), 
	UNIQUE (network_code)
)

;

CREATE TABLE core.subjects (
	status VARCHAR(16) NOT NULL, 
	credentials_version INTEGER NOT NULL, 
	label VARCHAR(80) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id)
)

;

CREATE TABLE core.principals (
	subject_id UUID, 
	service_code VARCHAR(32), 
	kind VARCHAR(16) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT principal_kind CHECK (kind IN ('USER','ORGANIZATION','SERVICE')), 
	UNIQUE (subject_id), 
	FOREIGN KEY(subject_id) REFERENCES core.subjects (id), 
	UNIQUE (service_code)
)

;

CREATE TABLE core.staff_grants (
	subject_id UUID NOT NULL, 
	role VARCHAR(16) NOT NULL, 
	revoked_at TIMESTAMP WITH TIME ZONE, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (subject_id, role), 
	FOREIGN KEY(subject_id) REFERENCES core.subjects (id)
)

;

CREATE TABLE core.validators (
	network_id UUID NOT NULL, 
	public_key BYTEA NOT NULL, 
	key_handle VARCHAR(80) NOT NULL, 
	active BOOLEAN NOT NULL, 
	valid_from_height BIGINT NOT NULL, 
	last_heartbeat TIMESTAMP WITH TIME ZONE, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(network_id) REFERENCES core.networks (id), 
	UNIQUE (key_handle)
)

;
CREATE INDEX ix_core_validators_network_id ON core.validators (network_id);

CREATE TABLE ops.operations (
	network_id UUID NOT NULL, 
	actor_id UUID, 
	kind VARCHAR(32) NOT NULL, 
	parent_id UUID, 
	slot VARCHAR(32), 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (parent_id, slot), 
	FOREIGN KEY(network_id) REFERENCES core.networks (id), 
	FOREIGN KEY(actor_id) REFERENCES core.subjects (id), 
	FOREIGN KEY(parent_id) REFERENCES ops.operations (id)
)

;
CREATE INDEX ix_ops_operations_network_id ON ops.operations (network_id);

CREATE TABLE audit.audit_logs (
	actor_id UUID, 
	operation_id UUID, 
	action VARCHAR(48) NOT NULL, 
	result VARCHAR(40) NOT NULL, 
	previous_hash VARCHAR(64) NOT NULL, 
	event_hash VARCHAR(64) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(actor_id) REFERENCES core.subjects (id), 
	FOREIGN KEY(operation_id) REFERENCES ops.operations (id), 
	UNIQUE (event_hash)
)

;

CREATE TABLE ledger.blocks (
	network_id UUID NOT NULL, 
	height BIGINT NOT NULL, 
	block_hash VARCHAR(64) NOT NULL, 
	header JSON NOT NULL, 
	signature VARCHAR(86) NOT NULL, 
	validator_id UUID NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (network_id, height), 
	FOREIGN KEY(network_id) REFERENCES core.networks (id), 
	UNIQUE (block_hash), 
	FOREIGN KEY(validator_id) REFERENCES core.validators (id)
)

;

CREATE TABLE ledger.chain_heads (
	network_id UUID NOT NULL, 
	height BIGINT NOT NULL, 
	block_hash VARCHAR(64) NOT NULL, 
	writer_epoch BIGINT NOT NULL, 
	validator_id UUID NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (network_id), 
	FOREIGN KEY(network_id) REFERENCES core.networks (id), 
	FOREIGN KEY(validator_id) REFERENCES core.validators (id)
)

;

CREATE TABLE ledger.transactions (
	operation_id UUID NOT NULL, 
	network_id UUID NOT NULL, 
	kind VARCHAR(40) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (operation_id), 
	FOREIGN KEY(operation_id) REFERENCES ops.operations (id), 
	FOREIGN KEY(network_id) REFERENCES core.networks (id)
)

;

CREATE TABLE ledger.wallets (
	network_id UUID NOT NULL, 
	owner_id UUID NOT NULL, 
	address VARCHAR(100) NOT NULL, 
	public_key BYTEA NOT NULL, 
	key_id UUID NOT NULL, 
	status VARCHAR(16) NOT NULL, 
	next_nonce BIGINT NOT NULL, 
	label VARCHAR(80) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (network_id, owner_id), 
	UNIQUE (id, network_id), 
	CONSTRAINT wallet_nonce CHECK (next_nonce >= 0), 
	FOREIGN KEY(network_id) REFERENCES core.networks (id), 
	FOREIGN KEY(owner_id) REFERENCES core.principals (id), 
	UNIQUE (address), 
	UNIQUE (key_id)
)

;
CREATE INDEX ix_ledger_wallets_owner_id ON ledger.wallets (owner_id);

CREATE TABLE ops.authorizations (
	operation_id UUID NOT NULL, 
	actor_id UUID NOT NULL, 
	credentials_version INTEGER NOT NULL, 
	session_id UUID NOT NULL, 
	payload_digest VARCHAR(64) NOT NULL, 
	payload JSON NOT NULL, 
	signature VARCHAR(86), 
	transaction_hash VARCHAR(64), 
	expires_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	signed_at TIMESTAMP WITH TIME ZONE, 
	consumed_at TIMESTAMP WITH TIME ZONE, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (operation_id), 
	FOREIGN KEY(operation_id) REFERENCES ops.operations (id), 
	FOREIGN KEY(actor_id) REFERENCES core.subjects (id), 
	UNIQUE (transaction_hash)
)

;

CREATE TABLE ops.commands (
	operation_id UUID NOT NULL, 
	kind VARCHAR(32) NOT NULL, 
	payload JSON NOT NULL, 
	state VARCHAR(16) NOT NULL, 
	attempts INTEGER NOT NULL, 
	error_code VARCHAR(40), 
	next_attempt_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (operation_id, kind), 
	FOREIGN KEY(operation_id) REFERENCES ops.operations (id)
)

;
CREATE INDEX ix_ops_commands_operation_id ON ops.commands (operation_id);
CREATE INDEX ix_ops_commands_state ON ops.commands (state);

CREATE TABLE ops.idempotency_keys (
	subject_id UUID NOT NULL, 
	route VARCHAR(120) NOT NULL, 
	key UUID NOT NULL, 
	request_digest VARCHAR(64) NOT NULL, 
	operation_id UUID NOT NULL, 
	response JSON NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (subject_id, route, key), 
	FOREIGN KEY(subject_id) REFERENCES core.subjects (id), 
	FOREIGN KEY(operation_id) REFERENCES ops.operations (id)
)

;

CREATE TABLE ops.outbox (
	operation_id UUID NOT NULL, 
	event_type VARCHAR(48) NOT NULL, 
	payload JSON NOT NULL, 
	published_at TIMESTAMP WITH TIME ZONE, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (operation_id, event_type), 
	FOREIGN KEY(operation_id) REFERENCES ops.operations (id)
)

;
CREATE INDEX ix_ops_outbox_operation_id ON ops.outbox (operation_id);

CREATE TABLE app.fincoin_faucet_grants (
	operation_id UUID NOT NULL, 
	wallet_id UUID NOT NULL, 
	asset_code VARCHAR(16) NOT NULL, 
	quantity NUMERIC(38, 0) NOT NULL, 
	status VARCHAR(16) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (operation_id), 
	FOREIGN KEY(operation_id) REFERENCES ops.operations (id), 
	FOREIGN KEY(wallet_id) REFERENCES ledger.wallets (id)
)

;
CREATE INDEX ix_app_fincoin_faucet_grants_wallet_id ON app.fincoin_faucet_grants (wallet_id);

CREATE TABLE app.fincoin_quotes (
	operation_id UUID NOT NULL, 
	wallet_id UUID NOT NULL, 
	side VARCHAR(4) NOT NULL, 
	quantity NUMERIC(38, 0) NOT NULL, 
	price NUMERIC(38, 0) NOT NULL, 
	gross NUMERIC(38, 0) NOT NULL, 
	fee NUMERIC(38, 0) NOT NULL, 
	total NUMERIC(38, 0) NOT NULL, 
	tick_id UUID NOT NULL, 
	expires_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	payload JSON NOT NULL, 
	payload_digest VARCHAR(64) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (operation_id), 
	FOREIGN KEY(operation_id) REFERENCES ops.operations (id), 
	FOREIGN KEY(wallet_id) REFERENCES ledger.wallets (id), 
	FOREIGN KEY(tick_id) REFERENCES app.fincoin_price_history (id)
)

;
CREATE INDEX ix_app_fincoin_quotes_wallet_id ON app.fincoin_quotes (wallet_id);

CREATE TABLE app.fincoin_transactions (
	operation_id UUID NOT NULL, 
	sender_id UUID NOT NULL, 
	receiver_id UUID NOT NULL, 
	quantity NUMERIC(38, 0) NOT NULL, 
	payload JSON NOT NULL, 
	status VARCHAR(16) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (operation_id), 
	FOREIGN KEY(operation_id) REFERENCES ops.operations (id), 
	FOREIGN KEY(sender_id) REFERENCES ledger.wallets (id), 
	FOREIGN KEY(receiver_id) REFERENCES ledger.wallets (id)
)

;
CREATE INDEX ix_app_fincoin_transactions_receiver_id ON app.fincoin_transactions (receiver_id);
CREATE INDEX ix_app_fincoin_transactions_sender_id ON app.fincoin_transactions (sender_id);

CREATE TABLE ledger.accounts (
	network_id UUID NOT NULL, 
	wallet_id UUID, 
	asset_code VARCHAR(16) NOT NULL, 
	bucket VARCHAR(16) NOT NULL, 
	account_code VARCHAR(120) NOT NULL, 
	normal_side VARCHAR(6) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (network_id, account_code), 
	UNIQUE (id, asset_code, network_id), 
	FOREIGN KEY(wallet_id, network_id) REFERENCES ledger.wallets (id, network_id), 
	CONSTRAINT account_side CHECK (normal_side IN ('DEBIT','CREDIT')), 
	FOREIGN KEY(network_id) REFERENCES core.networks (id)
)

;
CREATE INDEX ix_ledger_accounts_wallet_id ON ledger.accounts (wallet_id);

CREATE TABLE ledger.blockchain_transactions (
	network_id UUID NOT NULL, 
	block_id UUID NOT NULL, 
	tx_index INTEGER NOT NULL, 
	journal_id UUID NOT NULL, 
	transaction_hash VARCHAR(64) NOT NULL, 
	payload JSON NOT NULL, 
	signature VARCHAR(86) NOT NULL, 
	public_key BYTEA NOT NULL, 
	journal_commitment VARCHAR(64) NOT NULL, 
	salt_ciphertext BYTEA NOT NULL, 
	sender_wallet_id UUID, 
	nonce BIGINT, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (block_id, tx_index), 
	UNIQUE (sender_wallet_id, nonce), 
	FOREIGN KEY(network_id) REFERENCES core.networks (id), 
	FOREIGN KEY(block_id) REFERENCES ledger.blocks (id), 
	UNIQUE (journal_id), 
	FOREIGN KEY(journal_id) REFERENCES ledger.transactions (id), 
	UNIQUE (transaction_hash), 
	FOREIGN KEY(sender_wallet_id) REFERENCES ledger.wallets (id)
)

;
CREATE INDEX ix_ledger_blockchain_transactions_block_id ON ledger.blockchain_transactions (block_id);

CREATE TABLE ledger.holds (
	wallet_id UUID NOT NULL, 
	operation_id UUID NOT NULL, 
	asset_code VARCHAR(16) NOT NULL, 
	amount NUMERIC(38, 0) NOT NULL, 
	nonce BIGINT NOT NULL, 
	expires_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	status VARCHAR(16) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT positive_hold CHECK (amount > 0), 
	FOREIGN KEY(wallet_id) REFERENCES ledger.wallets (id), 
	UNIQUE (operation_id), 
	FOREIGN KEY(operation_id) REFERENCES ops.operations (id)
)

;
CREATE INDEX ix_ledger_holds_wallet_id ON ledger.holds (wallet_id);
CREATE UNIQUE INDEX one_active_wallet_hold ON ledger.holds (wallet_id) WHERE status = 'ACTIVE';

CREATE TABLE readmodel.fincoin_cost_lots (
	wallet_id UUID NOT NULL, 
	journal_id UUID NOT NULL, 
	quantity NUMERIC(38, 0) NOT NULL, 
	remaining_cost NUMERIC(38, 0) NOT NULL, 
	provenance VARCHAR(16) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT nonnegative_lot CHECK (quantity >= 0 AND remaining_cost >= 0), 
	FOREIGN KEY(wallet_id) REFERENCES ledger.wallets (id), 
	FOREIGN KEY(journal_id) REFERENCES ledger.transactions (id)
)

;
CREATE INDEX ix_readmodel_fincoin_cost_lots_journal_id ON readmodel.fincoin_cost_lots (journal_id);
CREATE INDEX ix_readmodel_fincoin_cost_lots_wallet_id ON readmodel.fincoin_cost_lots (wallet_id);

CREATE TABLE app.fincoin_orders (
	quote_id UUID NOT NULL, 
	operation_id UUID NOT NULL, 
	status VARCHAR(16) NOT NULL, 
	reason_code VARCHAR(40), 
	filled_at TIMESTAMP WITH TIME ZONE, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (quote_id), 
	FOREIGN KEY(quote_id) REFERENCES app.fincoin_quotes (id), 
	UNIQUE (operation_id), 
	FOREIGN KEY(operation_id) REFERENCES ops.operations (id)
)

;

CREATE TABLE ledger.balances (
	account_id UUID NOT NULL, 
	amount NUMERIC(38, 0) NOT NULL, 
	version BIGINT NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT nonnegative_balance CHECK (amount >= 0), 
	UNIQUE (account_id), 
	FOREIGN KEY(account_id) REFERENCES ledger.accounts (id)
)

;

CREATE TABLE ledger.journal_lines (
	journal_id UUID NOT NULL, 
	line_no INTEGER NOT NULL, 
	network_id UUID NOT NULL, 
	account_id UUID NOT NULL, 
	asset_code VARCHAR(16) NOT NULL, 
	side VARCHAR(6) NOT NULL, 
	amount NUMERIC(38, 0) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (journal_id, line_no), 
	FOREIGN KEY(account_id, asset_code, network_id) REFERENCES ledger.accounts (id, asset_code, network_id), 
	CONSTRAINT positive_journal_line CHECK (amount > 0 AND side IN ('DEBIT','CREDIT')), 
	FOREIGN KEY(journal_id) REFERENCES ledger.transactions (id), 
	FOREIGN KEY(network_id) REFERENCES core.networks (id)
)

;
CREATE INDEX ix_ledger_journal_lines_account_id ON ledger.journal_lines (account_id);
CREATE INDEX ix_ledger_journal_lines_journal_id ON ledger.journal_lines (journal_id);

CREATE TABLE ledger.fincoin_fills (
	order_id UUID NOT NULL, 
	journal_id UUID NOT NULL, 
	wallet_id UUID NOT NULL, 
	side VARCHAR(4) NOT NULL, 
	quantity NUMERIC(38, 0) NOT NULL, 
	gross NUMERIC(38, 0) NOT NULL, 
	fee NUMERIC(38, 0) NOT NULL, 
	total NUMERIC(38, 0) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (order_id), 
	FOREIGN KEY(order_id) REFERENCES app.fincoin_orders (id), 
	UNIQUE (journal_id), 
	FOREIGN KEY(journal_id) REFERENCES ledger.transactions (id), 
	FOREIGN KEY(wallet_id) REFERENCES ledger.wallets (id)
)

;
CREATE INDEX ix_ledger_fincoin_fills_wallet_id ON ledger.fincoin_fills (wallet_id);

CREATE TABLE readmodel.fincoin_lot_disposals (
	fill_id UUID NOT NULL, 
	lot_id UUID NOT NULL, 
	quantity NUMERIC(38, 0) NOT NULL, 
	cost NUMERIC(38, 0) NOT NULL, 
	proceeds NUMERIC(38, 0) NOT NULL, 
	provenance VARCHAR(16) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (fill_id, lot_id), 
	FOREIGN KEY(fill_id) REFERENCES ledger.fincoin_fills (id), 
	FOREIGN KEY(lot_id) REFERENCES readmodel.fincoin_cost_lots (id)
)

;
CREATE INDEX ix_readmodel_fincoin_lot_disposals_fill_id ON readmodel.fincoin_lot_disposals (fill_id);
CREATE INDEX ix_readmodel_fincoin_lot_disposals_lot_id ON readmodel.fincoin_lot_disposals (lot_id);