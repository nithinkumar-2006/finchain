-- Immutable initial schema snapshot; apply with migrate.py.

CREATE TABLE signing_grants (
	grant_id VARCHAR(120) NOT NULL, 
	payload_digest VARCHAR(64) NOT NULL, 
	key_handle UUID NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (grant_id)
)

;