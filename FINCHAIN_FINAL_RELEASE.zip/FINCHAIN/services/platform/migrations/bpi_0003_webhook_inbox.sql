CREATE TABLE app.webhook_inbox (
 id uuid PRIMARY KEY, created_at timestamptz NOT NULL,
 webhook_id uuid NOT NULL REFERENCES app.webhooks(id), event_id uuid NOT NULL,
 payload_digest varchar(64) NOT NULL, UNIQUE(webhook_id,event_id)
);
