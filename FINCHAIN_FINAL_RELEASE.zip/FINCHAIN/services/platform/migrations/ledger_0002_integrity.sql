-- Append-only posted records, deferred conservation and balance projection checks.
CREATE FUNCTION ledger.reject_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'posted records are append-only'; END $$;
CREATE TRIGGER immutable_journals BEFORE UPDATE OR DELETE ON ledger.transactions FOR EACH ROW EXECUTE FUNCTION ledger.reject_mutation();
CREATE TRIGGER immutable_lines BEFORE UPDATE OR DELETE ON ledger.journal_lines FOR EACH ROW EXECUTE FUNCTION ledger.reject_mutation();
CREATE TRIGGER immutable_blocks BEFORE UPDATE OR DELETE ON ledger.blocks FOR EACH ROW EXECUTE FUNCTION ledger.reject_mutation();
CREATE TRIGGER immutable_chain_transactions BEFORE UPDATE OR DELETE ON ledger.blockchain_transactions FOR EACH ROW EXECUTE FUNCTION ledger.reject_mutation();
CREATE TRIGGER immutable_audit BEFORE UPDATE OR DELETE ON audit.audit_logs FOR EACH ROW EXECUTE FUNCTION ledger.reject_mutation();

CREATE FUNCTION ledger.new_journal_lines_only() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM ledger.transactions WHERE id=NEW.journal_id AND xmin::text::bigint = txid_current() % 4294967296) THEN
    RAISE EXCEPTION 'cannot extend a previously committed journal';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER new_lines_only BEFORE INSERT ON ledger.journal_lines FOR EACH ROW EXECUTE FUNCTION ledger.new_journal_lines_only();

CREATE FUNCTION ledger.verify_journal() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE n integer;
BEGIN
  SELECT count(*) INTO n FROM ledger.journal_lines WHERE journal_id=NEW.id;
  IF n < 2 OR EXISTS (
    SELECT asset_code FROM ledger.journal_lines WHERE journal_id=NEW.id GROUP BY asset_code
    HAVING sum(CASE side WHEN 'DEBIT' THEN amount ELSE -amount END) <> 0
  ) THEN RAISE EXCEPTION 'journal must balance independently for each asset'; END IF;
  IF EXISTS (SELECT 1 FROM ledger.journal_lines WHERE journal_id=NEW.id AND network_id<>NEW.network_id) THEN
    RAISE EXCEPTION 'journal network mismatch';
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM ledger.blockchain_transactions t JOIN ledger.blocks b ON b.id=t.block_id
    WHERE t.journal_id=NEW.id AND t.network_id=NEW.network_id AND b.network_id=NEW.network_id
  ) THEN RAISE EXCEPTION 'journal and chain inclusion must commit together'; END IF;
  RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER balanced_journal AFTER INSERT ON ledger.transactions DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION ledger.verify_journal();

CREATE FUNCTION ledger.verify_balance() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE expected numeric; actual numeric;
BEGIN
  SELECT coalesce(sum(CASE WHEN j.side=a.normal_side THEN j.amount ELSE -j.amount END),0) INTO expected
    FROM ledger.accounts a LEFT JOIN ledger.journal_lines j ON j.account_id=a.id WHERE a.id=NEW.account_id;
  SELECT amount INTO actual FROM ledger.balances WHERE account_id=NEW.account_id;
  IF actual IS DISTINCT FROM expected THEN RAISE EXCEPTION 'balance does not match committed journal'; END IF;
  RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER balance_projection AFTER INSERT OR UPDATE ON ledger.balances DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION ledger.verify_balance();
CREATE CONSTRAINT TRIGGER line_projection AFTER INSERT ON ledger.journal_lines DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION ledger.verify_balance();

CREATE FUNCTION ledger.verify_asset() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM core.networks WHERE id=NEW.network_id AND policy::jsonb->'assets' ? NEW.asset_code) THEN
    RAISE EXCEPTION 'asset not allowed on this network';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER allowed_assets BEFORE INSERT OR UPDATE ON ledger.accounts FOR EACH ROW EXECUTE FUNCTION ledger.verify_asset();
CREATE TRIGGER immutable_account BEFORE UPDATE OR DELETE ON ledger.accounts FOR EACH ROW EXECUTE FUNCTION ledger.reject_mutation();
ALTER TABLE ledger.blockchain_transactions ADD CONSTRAINT tx_nonce_pair CHECK ((sender_wallet_id IS NULL AND nonce IS NULL) OR (sender_wallet_id IS NOT NULL AND nonce>=0));
ALTER TABLE core.principals ADD CONSTRAINT principal_binding CHECK ((kind='USER' AND subject_id IS NOT NULL AND service_code IS NULL) OR (kind='SERVICE' AND subject_id IS NULL AND service_code IS NOT NULL) OR (kind='ORGANIZATION' AND subject_id IS NULL AND service_code IS NULL));
ALTER TABLE core.staff_grants ADD CONSTRAINT staff_role CHECK (role IN ('admin','compliance','support'));
