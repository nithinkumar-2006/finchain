-- Immutable initial schema snapshot; apply with migrate.py.

CREATE TABLE public_blocks (
	network_id VARCHAR(80) NOT NULL, 
	height BIGINT NOT NULL, 
	block_hash VARCHAR(64) NOT NULL, 
	header JSON NOT NULL, 
	signature VARCHAR(86) NOT NULL, 
	validator_public_key VARCHAR(64) NOT NULL, 
	body JSON NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (network_id, height), 
	UNIQUE (block_hash)
)

;

CREATE TABLE public_transactions (
	block_id UUID NOT NULL, 
	transaction_hash VARCHAR(64) NOT NULL, 
	tx_index BIGINT NOT NULL, 
	journal_commitment VARCHAR(64) NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(block_id) REFERENCES public_blocks (id), 
	UNIQUE (transaction_hash)
)

;
CREATE INDEX ix_public_transactions_block_id ON public_transactions (block_id);