-- Immutable initial schema snapshot; apply with migrate.py.

CREATE TABLE gateway_operations (
	operation_id UUID NOT NULL, 
	network_id VARCHAR(80) NOT NULL, 
	request_digest VARCHAR(64) NOT NULL, 
	request JSON NOT NULL, 
	status VARCHAR(16) NOT NULL, 
	event_id UUID NOT NULL, 
	resolve_at TIMESTAMP WITH TIME ZONE, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (operation_id)
)

;

CREATE TABLE gateway_statements (
	operation_id UUID NOT NULL, 
	evidence JSON NOT NULL, 
	id UUID NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (operation_id)
)

;