"""Install NOLOGIN privilege groups in one financial database, using its migration owner."""
import os
from sqlalchemy import create_engine


def install(url, domain):
    if domain not in {"bpi", "fincoin"}:
        raise ValueError("Unknown domain")
    roles = {name: f"finchain_{domain}_{name}" for name in ("api", "writer", "projection", "operator")}
    engine = create_engine(url, hide_parameters=True)
    with engine.begin() as c:
        for role in roles.values():
            c.exec_driver_sql(f"DO $$ BEGIN IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='{role}') THEN CREATE ROLE {role} NOLOGIN; END IF; END $$")
            c.exec_driver_sql(f"GRANT USAGE ON SCHEMA core,ledger,ops,app,audit TO {role}")
        c.exec_driver_sql("REVOKE CREATE ON SCHEMA public FROM PUBLIC")
        api, writer, projection, operator = (roles[n] for n in ("api", "writer", "projection", "operator"))
        for role in (api, writer):
            c.exec_driver_sql(f"GRANT SELECT ON ALL TABLES IN SCHEMA core,ledger,ops,app,audit TO {role}")
            c.exec_driver_sql(f"GRANT INSERT,UPDATE ON core.subjects,core.principals,ops.operations,ops.idempotency_keys,ops.commands,ops.authorizations,ops.outbox,audit.audit_streams TO {role}")
            c.exec_driver_sql(f"GRANT INSERT ON audit.audit_logs TO {role}")
            c.exec_driver_sql(f"GRANT INSERT,UPDATE ON ALL TABLES IN SCHEMA app TO {role}")
        c.exec_driver_sql(f"GRANT INSERT,UPDATE ON ALL TABLES IN SCHEMA ledger TO {writer}")
        c.exec_driver_sql(f"GRANT UPDATE ON core.validators TO {writer}")
        c.exec_driver_sql(f"GRANT UPDATE (status) ON core.networks TO {writer}")
        c.exec_driver_sql(f"GRANT SELECT ON ledger.blocks TO {projection}")
        c.exec_driver_sql(f"GRANT SELECT (transaction_hash,journal_commitment,block_id,tx_index) ON ledger.blockchain_transactions TO {projection}")
        c.exec_driver_sql(f"GRANT SELECT (id,public_key) ON core.validators TO {projection}")
        c.exec_driver_sql(f"GRANT SELECT,INSERT,UPDATE ON core.staff_grants TO {operator}")
        c.exec_driver_sql(f"GRANT SELECT ON core.subjects TO {operator}")
        c.exec_driver_sql(f"GRANT SELECT,UPDATE ON core.networks TO {operator}")
        c.exec_driver_sql(f"GRANT SELECT,UPDATE ON audit.audit_streams TO {operator}")
        c.exec_driver_sql(f"GRANT INSERT ON audit.audit_logs TO {operator}")
        if domain == "fincoin":
            for role in (api, writer):
                c.exec_driver_sql(f"GRANT USAGE ON SCHEMA readmodel TO {role}")
                c.exec_driver_sql(f"GRANT SELECT ON ALL TABLES IN SCHEMA readmodel TO {role}")
            c.exec_driver_sql(f"GRANT INSERT,UPDATE ON ALL TABLES IN SCHEMA readmodel TO {writer}")
        else:
            c.exec_driver_sql(f"REVOKE INSERT,UPDATE ON app.fraud_scores,app.fraud_events FROM {api}")
            c.exec_driver_sql(f"GRANT INSERT,UPDATE ON ops.gateway_transactions,ops.webhook_deliveries TO {writer}")
    engine.dispose()


if __name__ == "__main__":
    install(os.environ["MIGRATION_DATABASE_URL"], os.environ["FINCHAIN_DOMAIN"].lower())
