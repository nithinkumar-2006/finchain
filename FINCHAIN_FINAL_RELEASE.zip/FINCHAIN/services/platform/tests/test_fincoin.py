import secrets
import uuid
from datetime import timedelta
import pytest
from sqlalchemy import select, inspect
from finchain_platform.storage import Base, Command, Account, Balance, utcnow
from finchain_platform.config import DomainSettings
from finchain_platform.signing import SandboxSigner
from finchain_platform.fincoin import FINCOIN, SCALE
from finchain_platform.fincoin_models import Tick, FincoinOrder
from finchain_platform.ledger import RuleViolation
from test_bpi import principal, drain


@pytest.fixture
def fc(tmp_path):
    cfg = DomainSettings("FINCOIN", f"sqlite:///{tmp_path / 'fincoin.db'}", secrets.token_bytes(32), role="bootstrap", test_mode=True)
    service = FINCOIN(cfg, SandboxSigner(secrets.token_bytes(32), cfg.network_code))
    Base.metadata.create_all(service.engine, tables=service.schema_tables())
    service.initialize_fincoin()
    yield service
    service.engine.dispose()


def enroll(fc, actor, credits=True):
    fc.request_wallet(actor, uuid.uuid4())
    drain(fc)
    if credits:
        fc.request_grant(actor, uuid.uuid4(), "SIM_INR", "100000")
        drain(fc)
    return fc.wallets(actor)[0]


def trade(fc, actor, side, quantity):
    quote = fc.quote(actor, uuid.uuid4(), side, str(quantity))
    order = fc.authorize_quote(actor, uuid.uuid4(), quote["quote_id"], quote["payload_digest"])
    drain(fc)
    return quote, order


def test_buy_sell_fifo_and_supply(fc):
    alice = principal()
    enroll(fc, alice)
    fc.add_tick(10000)
    quote, _ = trade(fc, alice, "BUY", 2*SCALE)
    assert quote["total_minor"] == "20020"
    fc.add_tick(12000)
    quote, _ = trade(fc, alice, "SELL", SCALE)
    assert quote["total_minor"] == "11988"
    portfolio = fc.portfolio(alice)
    assert portfolio["quantity_atoms"] == str(SCALE)
    assert portfolio["realized_purchased_pnl_minor"] == "1978"
    assert portfolio["remaining_purchased_cost_minor"] == "10010"
    assert portfolio["return_denominator"] == "10010"
    with fc.transaction() as db:
        issuance = db.scalar(select(Balance.amount).join(Account, Account.id == Balance.account_id).where(Account.asset_code == "FINCOIN", Account.bucket == "ISSUANCE"))
        assert int(issuance) == 10**14
    assert fc.validate_chain()["transactions"] == 4


def test_transfer_carries_basis_and_no_bpi_tables(fc):
    alice, bob = principal(), principal()
    a, b = enroll(fc, alice), enroll(fc, bob, credits=False)
    fc.add_tick(10000)
    trade(fc, alice, "BUY", 2*SCALE)
    draft = fc.transfer_draft(alice, uuid.uuid4(), b["address"], str(SCALE))
    fc.authorize_transfer(alice, uuid.uuid4(), draft["transfer_id"], draft["payload_digest"])
    drain(fc)
    portfolio = fc.portfolio(bob)
    assert portfolio["quantity_atoms"] == str(SCALE)
    assert portfolio["lots"][0]["cost_minor"] == "10010"
    assert portfolio["lots"][0]["provenance"] == "carried"
    assert "payments" not in inspect(fc.engine).get_table_names()
    assert "settlements" not in inspect(fc.engine).get_table_names()
    assert fc.validate_chain()["valid"]


def test_quote_expiry_and_stale_feed(fc):
    alice = principal()
    enroll(fc, alice)
    with pytest.raises(RuleViolation): fc.quote(alice, uuid.uuid4(), "BUY", str(SCALE))
    fc.add_tick(10000)
    quote = fc.quote(alice, uuid.uuid4(), "BUY", str(SCALE))
    with pytest.raises(RuleViolation): fc.authorize_quote(alice, uuid.uuid4(), quote["quote_id"], "0"*64)
    with fc.transaction() as db:
        db.scalar(select(Tick)).observed_at = utcnow()-timedelta(minutes=1)
    with pytest.raises(RuleViolation): fc.quote(alice, uuid.uuid4(), "BUY", str(SCALE))


def test_insufficient_credit_atomic_rollback(fc):
    alice = principal()
    enroll(fc, alice, credits=False)
    fc.add_tick(10000)
    quote = fc.quote(alice, uuid.uuid4(), "BUY", str(SCALE))
    fc.authorize_quote(alice, uuid.uuid4(), quote["quote_id"], quote["payload_digest"])
    with pytest.raises(RuleViolation): drain(fc)
    balances = fc.wallets(alice)[0]["balances"]
    assert balances["FINCOIN"]["available"] == "0" and balances["SIM_INR"]["available"] == "0"
    assert fc.validate_chain()["transactions"] == 1


def test_grant_basis_cap_and_cross_domain_rejection(fc):
    alice = principal()
    enroll(fc, alice, credits=False)
    fc.request_grant(alice, uuid.uuid4(), "FINCOIN", str(10*SCALE))
    drain(fc)
    with pytest.raises(RuleViolation): fc.request_grant(alice, uuid.uuid4(), "FINCOIN", "1")
    with pytest.raises(RuleViolation): fc.request_grant(alice, uuid.uuid4(), "INR", "1000")
    assert fc.portfolio(alice)["lots"][0]["provenance"] == "grant"
    with pytest.raises(ValueError): fc.transfer_draft(alice, uuid.uuid4(), "bpi_sbx_bad", "1000")
    assert fc.validate_chain()["transactions"] == 2
