import json
import shutil
import subprocess
import sys
from pathlib import Path


def test_configuration_isolated_secrets_and_repeat_protection(tmp_path):
    root=Path(__file__).resolve().parents[3]
    scripts=tmp_path/'scripts';scripts.mkdir()
    shutil.copy2(root/'scripts/configure_sandbox.py',scripts/'configure_sandbox.py')
    result=subprocess.run([sys.executable,str(scripts/'configure_sandbox.py')],capture_output=True,text=True)
    assert result.returncode==0,result.stderr
    compose=json.loads((tmp_path/'compose.json').read_text())
    services=compose['services']
    assert 'bpi-signer-master' not in services['bpi-api']['secrets']
    assert 'fincoin-encryption' not in services['bpi-api']['secrets']
    assert services['explorer']['secrets']==[]
    assert services['seed-demo']['profiles']==['demo']
    assert all('ports' not in services[n] for n in ('identity','bpi-api','fincoin-api','bpi-signer','fincoin-signer','gateway','postgres'))
    for service in services.values():
        for dependency in service.get('depends_on',{}): assert dependency in services
    private=tmp_path/'.secrets'
    assert (private/'bpi-signer-master').read_bytes() != (private/'fincoin-signer-master').read_bytes()
    assert 'EXPLORER_BPI_DATABASE_URL=' in (private/'explorer.env').read_text()
    key=(private/'bpi-signer-master').read_bytes()
    again=subprocess.run([sys.executable,str(scripts/'configure_sandbox.py')],capture_output=True,text=True)
    assert again.returncode!=0 and (private/'bpi-signer-master').read_bytes()==key
