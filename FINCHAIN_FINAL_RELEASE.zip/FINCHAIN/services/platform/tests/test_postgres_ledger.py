"""Real PostgreSQL integrity tests; only use explicitly named disposable *_test databases."""
import os
import secrets
import uuid
from dataclasses import replace
from pathlib import Path
import pytest
from sqlalchemy import text, select
from sqlalchemy.engine import make_url
from sqlalchemy.exc import DBAPIError
from finchain_platform.bpi import BPI, BPI_POLICY
from finchain_platform.fincoin import FINCOIN, SCALE
from finchain_platform.config import DomainSettings
from finchain_platform.signing import SandboxSigner
from finchain_platform.storage import Balance, Account, Wallet, Command, Journal, JournalLine, utcnow
from test_bpi import principal, wallet, fund, draft_and_authorize, drain, settle_all
from test_fincoin import enroll, trade


@pytest.fixture(scope="module", params=["BPI", "FINCOIN"])
def domain(request):
    name = request.param
    url = os.environ.get(name + "_TEST_DATABASE_URL")
    if not url:
        pytest.skip("Dedicated migrated PostgreSQL test database not configured")
    assert make_url(url).database.endswith("_test")
    # Persistent test-only keys permit rerunning replay checks on the same disposable database.
    directory = Path(__file__).resolve().parents[3] / ".tooling"
    directory.mkdir(exist_ok=True)
    keys = directory / (name.lower() + "-test-keys.bin")
    if not keys.exists():
        keys.write_bytes(secrets.token_bytes(64))
    value = keys.read_bytes()
    settings = DomainSettings(name, url, value[:32], role="bootstrap")
    service = (BPI if name == "BPI" else FINCOIN)(settings, SandboxSigner(value[32:], settings.network_code))
    service.initialize(BPI_POLICY) if name == "BPI" else service.initialize_fincoin()
    yield service
    service.engine.dispose()


def test_postgres_atomic_flows_and_replay(domain):
    actor = principal()
    if domain.settings.domain == "BPI":
        recipient = principal()
        a, b = wallet(domain, actor), wallet(domain, recipient)
        fund(domain, actor, a)
        draft_and_authorize(domain, actor, a, b)
        drain(domain)
        assert domain.wallets(recipient)[0]["balances"]["INR"]["pending"] == "50000"
        settle_all(domain)
        assert domain.wallets(recipient)[0]["balances"]["INR"]["available"] == "50000"
    else:
        enroll(domain, actor)
        domain.add_tick(10000)
        trade(domain, actor, "BUY", 2*SCALE)
        domain.add_tick(12000)
        trade(domain, actor, "SELL", SCALE)
        assert domain.portfolio(actor)["realized_purchased_pnl_minor"] == "1978"
    assert domain.validate_chain()["valid"]


def test_direct_balance_edit_rejected(domain):
    with pytest.raises(DBAPIError):
        with domain.engine.begin() as c:
            c.execute(text("UPDATE ledger.balances SET amount=amount+1"))


def test_runtime_cannot_mutate_financial_records(domain):
    role = "finchain_" + domain.settings.domain.lower() + "_api"
    for statement in ("UPDATE ledger.balances SET amount=amount", "DELETE FROM ledger.journal_lines", "TRUNCATE ledger.blocks", "UPDATE core.staff_grants SET role='admin'"):
        with pytest.raises(DBAPIError):
            with domain.engine.begin() as c:
                c.execute(text("SET LOCAL ROLE " + role))
                c.execute(text(statement))


def test_immutable_chain_and_journal(domain):
    for statement in ("UPDATE ledger.blocks SET block_hash=block_hash", "DELETE FROM ledger.transactions", "UPDATE audit.audit_logs SET result='TAMPERED'"):
        with pytest.raises(DBAPIError):
            with domain.engine.begin() as c:
                c.execute(text(statement))


def test_unbalanced_or_unattached_journal_cannot_commit(domain):
    with pytest.raises(DBAPIError):
        with domain.transaction() as db:
            op = domain.operation(db, "INVALID_TEST")
            db.add(Journal(operation_id=op.id, network_id=domain.network(db).id, kind="INVALID_TEST"))


def test_domain_schema_isolation(domain):
    forbidden = "app.fincoin_orders" if domain.settings.domain == "BPI" else "ledger.settlements"
    with domain.engine.connect() as c:
        assert c.execute(text("SELECT to_regclass(:name)"), {"name": forbidden}).scalar() is None


def test_actual_runtime_privileges_support_wallet_and_posting(domain):
    from finchain_platform.worker import Worker
    name = domain.settings.domain.lower()
    def scoped(role, setting):
        url = make_url(domain.settings.database_url).update_query_dict({"options":"-c role=finchain_"+name+"_"+role})
        config = replace(domain.settings, database_url=url.render_as_string(hide_password=False), role=setting)
        return type(domain)(config, domain.signer if role == "writer" else None)
    api, writer = scoped("api","api"), scoped("writer","ledger")
    class Identity:
        def grant(self,*args): return {"assurance":"MFA","auth_time":int(utcnow().timestamp())}
    worker = Worker(writer, Identity())
    worker.acquire()
    actor = principal()
    try:
        api.request_wallet(actor,uuid.uuid4())
        worker.step()
        a = api.wallets(actor)[0]
        if name == "bpi":
            api.funding(actor,uuid.uuid4(),a["id"],"100000")
            worker.step()
            settle_all(writer)
            assert api.wallets(actor)[0]["balances"]["INR"]["available"] == "100000"
        else:
            api.request_grant(actor,uuid.uuid4(),"SIM_INR","100000")
            worker.step()
            assert api.wallets(actor)[0]["balances"]["SIM_INR"]["available"] == "100000"
    finally:
        if worker.lease: worker.lease.close()
        api.engine.dispose(); writer.engine.dispose()


def test_concurrent_duplicate_nonce_cannot_double_spend(domain):
    if domain.settings.domain != "BPI":
        # FINCOIN has the same head/nonce primitives; its atomic fill is covered above.
        assert domain.validate_chain()["valid"]
        return
    from concurrent.futures import ThreadPoolExecutor
    from threading import Barrier
    from sqlalchemy.exc import OperationalError
    from finchain_platform.ledger import RuleViolation
    from finchain_platform.worker import Worker
    alice,bob,charlie=principal(),principal(),principal()
    a,b,c=wallet(domain,alice),wallet(domain,bob),wallet(domain,charlie)
    fund(domain,alice,a)
    first=draft_and_authorize(domain,alice,a,b,"80000")
    second=draft_and_authorize(domain,alice,a,c,"80000")
    with domain.transaction() as db:
        ids=list(db.scalars(select(Command.id).where(Command.operation_id.in_([uuid.UUID(first["operation_id"]),uuid.UUID(second["operation_id"])]))))
    barrier=Barrier(2)
    def attempt(identifier):
        barrier.wait(timeout=10)
        for _ in range(5):
            try:
                domain.process_command(identifier,lambda *args:alice)
                return "posted"
            except OperationalError as error:
                if getattr(error.orig,"sqlstate",None) not in {"40001","40P01"}: raise
            except (ValueError,RuleViolation):
                Worker(domain,None).fail_command(identifier,"NONCE_CHANGED")
                return "rejected"
        raise AssertionError("Serialization retry exhausted")
    with ThreadPoolExecutor(max_workers=2) as pool:
        assert sorted(pool.map(attempt,ids))==["posted","rejected"]
    assert domain.wallets(alice)[0]["balances"]["INR"]["available"]=="20000"
    settle_all(domain)
    assert domain.validate_chain()["valid"]
