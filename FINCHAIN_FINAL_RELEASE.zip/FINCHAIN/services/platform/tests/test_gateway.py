import secrets
import uuid
from datetime import timedelta
from sqlalchemy import select
import pytest
from finchain_platform.gateway import GatewayBase, GatewayOperation, GatewayStatement, Simulator
from finchain_platform.storage import utcnow
from finchain_platform.ledger import RuleViolation


def test_gateway_durable_idempotency_unknown_and_failure(tmp_path):
    s = Simulator(f"sqlite:///{tmp_path/'gateway.db'}", secrets.token_bytes(32), test_mode=True)
    GatewayBase.metadata.create_all(s.engine)
    request = {"operation_id": str(uuid.uuid4()), "network_id": s.network, "amount_minor": "50000", "environment": "sandbox", "currency": "INR", "kind": "TRANSFER", "scenario": "UNKNOWN"}
    first = s.submit(request)
    assert s.submit(request) == first and first["evidence"]["status"] == "UNKNOWN"
    with s.sessions.begin() as db:
        db.scalar(select(GatewayOperation)).resolve_at = utcnow()-timedelta(seconds=1)
    final = s.submit(request)
    assert final["evidence"]["status"] == "SUCCEEDED"
    assert s.submit(request) == final
    with s.sessions() as db:
        assert len(db.scalars(select(GatewayStatement)).all()) == 1
    with pytest.raises(RuleViolation): s.submit({**request, "amount_minor": "60000"})
    failure = s.submit({**request, "operation_id": str(uuid.uuid4()), "scenario": "FAILURE"})
    assert failure["evidence"]["status"] == "FAILED"
    with pytest.raises(RuleViolation): s.submit({**request, "currency": "FNC"})
