import secrets
import uuid
from datetime import timedelta
import pytest
from sqlalchemy import select, update
from finchain_platform.storage import Base, Wallet, Command, Authorization, Principal, Operation, utcnow
from finchain_platform.bpi_models import Settlement, Payment, PaymentState, Membership, Approval, Merchant
from finchain_platform.bpi import BPI, BPI_POLICY
from finchain_platform.config import DomainSettings
from finchain_platform.signing import SandboxSigner
from finchain_platform.ledger import RuleViolation


def principal():
    return {"id": str(uuid.uuid4()), "credentials_version": 1, "session_id": str(uuid.uuid4()), "assurance": "MFA", "auth_time": int(utcnow().timestamp())}


def drain(service):
    with service.transaction() as db:
        ids = list(db.scalars(select(Command.id).where(Command.state == "QUEUED").order_by(Command.created_at)))
    for command_id in ids:
        service.process_command(command_id, lambda *args: {"assurance": "MFA", "auth_time": int(utcnow().timestamp())})


def evidence(service, settlement, status="SUCCEEDED"):
    return {"event_id": str(uuid.uuid4()), "operation_id": str(settlement.operation_id), "amount_minor": str(settlement.amount),
            "currency": "INR", "network_id": service.settings.network_code, "status": status, "environment": "sandbox"}


def settle_all(service, status="SUCCEEDED"):
    with service.transaction() as db:
        rows = db.scalars(select(Settlement).where(Settlement.result_applied_at.is_(None))).all()
    for row in rows:
        service.apply_gateway_result(row.id, evidence(service, row, status))


@pytest.fixture
def bpi(tmp_path):
    cfg = DomainSettings("BPI", f"sqlite:///{tmp_path / 'bpi.db'}", secrets.token_bytes(32), role="bootstrap", test_mode=True)
    service = BPI(cfg, SandboxSigner(secrets.token_bytes(32), cfg.network_code))
    Base.metadata.create_all(service.engine, tables=service.schema_tables())
    service.initialize(BPI_POLICY)
    yield service
    service.engine.dispose()


def wallet(service, actor, merchant=False):
    if merchant:
        service.merchant_onboard(actor, uuid.uuid4(), "Sample merchant", "Services")
    else:
        service.request_wallet(actor, uuid.uuid4())
    drain(service)
    return service.wallets(actor)[0]


def fund(service, actor, target, amount="100000"):
    service.funding(actor, uuid.uuid4(), target["id"], amount)
    drain(service)
    settle_all(service)


def draft_and_authorize(service, actor, sender, receiver, amount="50000", **kwargs):
    draft = service.create_draft(actor, uuid.uuid4(), sender["id"], receiver["address"], amount, **kwargs)
    if sender["owner_kind"] == "ORGANIZATION":
        checker = principal()
        with service.transaction() as db:
            subject, _ = service.sync_subject(db, checker)
            merchant = db.scalar(select(Merchant).where(Merchant.principal_id == db.get(Wallet, uuid.UUID(sender["id"])).owner_id))
            db.add(Membership(merchant_id=merchant.id, subject_id=subject.id, role="checker"))
            db.add(Approval(payment_id=uuid.UUID(draft["payment_id"]), approver_id=subject.id, payload_digest=draft["payload_digest"], decision="APPROVE"))
    service.authorize(actor, uuid.uuid4(), draft["payment_id"], draft["payload_digest"])
    return draft


@pytest.mark.parametrize("source_merchant,target_merchant,kind", [(False,False,"P2P"),(False,True,"P2B"),(True,False,"B2P"),(True,True,"B2B")])
def test_payment_types_and_settlement(bpi, source_merchant, target_merchant, kind):
    alice, bob = principal(), principal()
    a, b = wallet(bpi, alice, source_merchant), wallet(bpi, bob, target_merchant)
    fund(bpi, alice, a)
    draft = draft_and_authorize(bpi, alice, a, b)
    assert draft["payment_type"] == kind
    drain(bpi)
    assert bpi.wallets(alice)[0]["balances"]["INR"]["available"] == "50000"
    assert bpi.wallets(bob)[0]["balances"]["INR"]["pending"] == "50000"
    assert bpi.wallets(bob)[0]["balances"]["INR"]["available"] == "0"
    settle_all(bpi)
    assert bpi.wallets(bob)[0]["balances"]["INR"]["available"] == "50000"
    assert bpi.validate_chain()["transactions"] == 3


def test_gateway_unknown_failure_and_replay(bpi):
    alice, bob = principal(), principal()
    a, b = wallet(bpi, alice), wallet(bpi, bob)
    fund(bpi, alice, a)
    draft_and_authorize(bpi, alice, a, b)
    drain(bpi)
    with bpi.transaction() as db:
        row = db.scalar(select(Settlement).where(Settlement.kind == "TRANSFER"))
    bpi.apply_gateway_result(row.id, evidence(bpi, row, "UNKNOWN"))
    assert bpi.wallets(bob)[0]["balances"]["INR"]["available"] == "0"
    terminal = evidence(bpi, row, "FAILED")
    bpi.apply_gateway_result(row.id, terminal)
    bpi.apply_gateway_result(row.id, terminal)
    assert bpi.wallets(alice)[0]["balances"]["INR"]["available"] == "100000"
    assert bpi.validate_chain()["transactions"] == 3


def test_idempotency_conflict_and_double_spend_rollback(bpi):
    alice, bob = principal(), principal()
    a, b = wallet(bpi, alice), wallet(bpi, bob)
    fund(bpi, alice, a)
    key = uuid.uuid4()
    draft = bpi.create_draft(alice, key, a["id"], b["address"], "75000")
    assert draft == bpi.create_draft(alice, key, a["id"], b["address"], "75000")
    with pytest.raises(RuleViolation): bpi.create_draft(alice, key, a["id"], b["address"], "70000")
    second = bpi.create_draft(alice, uuid.uuid4(), a["id"], b["address"], "75000")
    bpi.authorize(alice, uuid.uuid4(), draft["payment_id"], draft["payload_digest"])
    bpi.authorize(alice, uuid.uuid4(), second["payment_id"], second["payload_digest"])
    with bpi.transaction() as db:
        ids = list(db.scalars(select(Command.id).where(Command.state == "QUEUED").order_by(Command.created_at)))
    bpi.process_command(ids[0], lambda *args: None)
    with pytest.raises(ValueError): bpi.process_command(ids[1], lambda *args: None)
    assert bpi.wallets(alice)[0]["balances"]["INR"]["available"] == "25000"
    assert bpi.validate_chain()["transactions"] == 2


def test_qr_single_claim_and_refund(bpi):
    alice, bob = principal(), principal()
    a, b = wallet(bpi, alice), wallet(bpi, bob)
    fund(bpi, alice, a)
    req = bpi.create_request(bob, uuid.uuid4(), b["id"], "50000")
    resolved = bpi.resolve_request(req["link"].split("/")[-1])
    assert resolved["status"] == "OPEN" and resolved["amount_minor"] == "50000"
    paid = draft_and_authorize(bpi, alice, a, b, request_id=req["request_id"])
    drain(bpi)
    settle_all(bpi)
    assert bpi.resolve_request(req["link"].split("/")[-1])["status"] == "PAID"
    with pytest.raises(RuleViolation): bpi.create_draft(alice, uuid.uuid4(), a["id"], b["address"], "50000", request_id=req["request_id"])
    draft_and_authorize(bpi, bob, b, a, "25000", original_id=paid["payment_id"])
    drain(bpi)
    settle_all(bpi)
    assert bpi.wallets(alice)[0]["balances"]["INR"]["available"] == "75000"
    assert bpi.validate_chain()["transactions"] == 5


def test_privacy_ownership_and_confirmed_block_failure(bpi, monkeypatch):
    alice, bob = principal(), principal()
    a, b = wallet(bpi, alice), wallet(bpi, bob)
    with pytest.raises(RuleViolation): bpi.funding(bob, uuid.uuid4(), a["id"], "1000")
    fund(bpi, alice, a)
    draft_and_authorize(bpi, alice, a, b)
    def broken(*args): raise RuntimeError("Signer unavailable")
    monkeypatch.setattr(bpi.signer, "block", broken)
    with pytest.raises(RuntimeError): drain(bpi)
    assert bpi.wallets(alice)[0]["balances"]["INR"]["available"] == "100000"
    assert bpi.wallets(bob)[0]["balances"]["INR"]["pending"] == "0"
