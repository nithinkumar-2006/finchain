import json
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from finchain_platform.explorer import PublicBase, Projector, create_app
from test_bpi import bpi, principal, wallet, fund, draft_and_authorize, drain, settle_all


def test_public_projection_verifies_chain_and_excludes_private_fields(bpi,tmp_path):
    alice,bob=principal(),principal()
    a,b=wallet(bpi,alice),wallet(bpi,bob)
    fund(bpi,alice,a)
    draft_and_authorize(bpi,alice,a,b)
    drain(bpi);settle_all(bpi)
    url=f"sqlite:///{tmp_path/'public.db'}"
    engine=create_engine(url)
    PublicBase.metadata.create_all(engine)
    projector=Projector(bpi.engine,engine)
    count=0
    while projector.step(): count+=1
    assert count==4 and not projector.step()
    with TestClient(create_app({"bpi":url})) as client:
        blocks=client.get('/v1/explorer/bpi/blocks').json()
        transactions=client.get('/v1/explorer/bpi/transactions').json()
        tx=transactions['items'][0]['transaction_hash']
        proof=client.get('/v1/explorer/bpi/transactions/'+tx).json()
        encoded=json.dumps([blocks,transactions,proof])
        for private in (a['address'],b['address'],alice['id'],bob['id'],'amount_minor','risk_score','payload','salt_ciphertext'):
            assert private not in encoded
        assert 'proof' in proof and 'validator_public_key' in proof['block']
    engine.dispose()
