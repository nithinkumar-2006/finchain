import copy
import secrets
import uuid
from datetime import datetime, timedelta, timezone
import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from finchain_platform.protocol import *


@pytest.fixture
def transaction():
    key = Ed25519PrivateKey.generate()
    public = key.public_key().public_bytes_raw()
    ts = datetime.now(timezone.utc)
    payload = PaymentPayload(domain="BPI", network_id="finchain-bpi-sandbox-1", transaction_id=str(uuid.uuid4()),
        kind="PAYMENT_TRANSFER", sender_address=address(public, "BPI"), receiver_address=address(Ed25519PrivateKey.generate().public_key().public_bytes_raw(), "BPI"),
        amount_minor="50000", currency="INR", timestamp=wire_time(ts), expires_at=wire_time(ts+timedelta(minutes=5)),
        nonce="0", payment_type="P2P", authorization_ref=str(uuid.uuid4()), key_id=str(uuid.uuid4())).model_dump()
    return key, public, payload, sign_payload(key, payload)


def test_signed_transaction(transaction):
    _, public, payload, signed = transaction
    assert validate_user_transaction(payload, public, signed["signature"], signed["transaction_hash"], payload["network_id"], 0).amount_minor == "50000"


@pytest.mark.parametrize("field,value", [("amount_minor", "60000"), ("nonce", "1"), ("domain", "FINCOIN"), ("currency", "FINCOIN"), ("risk_score", 0)])
def test_tampering(transaction, field, value):
    _, public, payload, signed = transaction
    payload[field] = value
    with pytest.raises(ValueError):
        validate_user_transaction(payload, public, signed["signature"], signed["transaction_hash"], "finchain-bpi-sandbox-1", 0)


@pytest.mark.parametrize("value", ["-1", "0", "1.1", "01", "1e2", "NaN", 500, "9"*39])
def test_invalid_amounts(value):
    with pytest.raises(ValueError): integer(value)


def test_nonce_expiry_address_signature(transaction):
    _, public, payload, signed = transaction
    with pytest.raises(ValueError):
        validate_user_transaction(payload, public, signed["signature"], signed["transaction_hash"], payload["network_id"], 1)
    with pytest.raises(ValueError):
        validate_user_transaction(payload, public, signed["signature"], signed["transaction_hash"], payload["network_id"], 0, datetime.now(timezone.utc)+timedelta(hours=1))
    with pytest.raises(ValueError): validate_address(payload["sender_address"], "FINCOIN")
    with pytest.raises(ValueError): verify_signature(public, payload, "a"*86, signed["transaction_hash"])


def test_jcs_and_duplicate_keys():
    assert canonical({"b": "2", "a": "1"}) == b'{"a":"1","b":"2"}'
    assert canonical({"\u20ac": "€", "\r": "x"}) == b'{"\\r":"x","\xe2\x82\xac":"\xe2\x82\xac"}'
    with pytest.raises(ValueError): parse_json(b'{"a":1,"a":2}')
    with pytest.raises(ValueError): parse_json(b'{"a":NaN}')


def test_merkle_odd_proofs_and_salt():
    entries = [(sha(str(i).encode()), commitment([{"amount": "50000"}], secrets.token_bytes(32))) for i in range(5)]
    root = merkle_root(entries)
    for i, (tx, jc) in enumerate(entries):
        assert check_proof(tx, jc, merkle_proof(entries, i), root)
        assert not check_proof(sha(b"tampered"), jc, merkle_proof(entries, i), root)
    assert merkle_root(entries[::-1]) != root
    assert commitment([], b"a"*32) != commitment([], b"b"*32)


def test_block_validation():
    key = Ed25519PrivateKey.generate()
    body = [(sha(b"transaction"), sha(b"private commitment"))]
    header = {"protocol_version": "1", "network_id": "finchain-bpi-sandbox-1", "height": "1", "previous_hash": ZERO,
              "timestamp": wire_time(), "merkle_root": merkle_root(body), "transaction_count": "1", "writer_epoch": "1", "validator_key_id": str(uuid.uuid4())}
    value, signature = sign_block(key, header)
    verify_block(key.public_key().public_bytes_raw(), header, body, value, signature, ZERO, 1)
    with pytest.raises(ValueError): verify_block(key.public_key().public_bytes_raw(), header, body[::-1] + body, value, signature, ZERO, 1)
    with pytest.raises(ValueError): verify_block(key.public_key().public_bytes_raw(), header, body, value, signature, sha(b"wrong"), 1)
