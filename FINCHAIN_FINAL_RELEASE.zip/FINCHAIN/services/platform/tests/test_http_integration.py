"""Real identity and domain HTTP contracts with in-process transports, no fake principals."""
import json
import secrets
import uuid
from dataclasses import replace
import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from fastapi.testclient import TestClient
from sqlalchemy import select
from finchain_identity.app import create_app as identity_app, COOKIE, CSRF
from finchain_identity.config import Settings
from finchain_identity.models import Base as IdentityBase, AuditStream, EmailOutbox
from finchain_platform.api import create_app
from finchain_platform.identity_client import IdentityClient
from finchain_platform.ledger import RuleViolation
from finchain_platform.config import DomainSettings
from finchain_platform.bpi import BPI, BPI_POLICY
from finchain_platform.storage import Base
from finchain_platform.signing import SandboxSigner
from finchain_platform.queries import Queries
from test_bpi import drain, settle_all

PASSWORD = "integration test password 123!"
ORIGIN = "https://localhost:8443"


@pytest.fixture
def stack(tmp_path):
    key = rsa.generate_private_key(public_exponent=65537,key_size=3072).private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption())
    settings = Settings(f"sqlite:///{tmp_path/'identity.db'}",key,secrets.token_bytes(32),secrets.token_bytes(32),test_mode=True,internal_keys={"BPI":"b"*43,"FINCOIN":"f"*43})
    app = identity_app(settings)
    identity = app.state.identity
    IdentityBase.metadata.create_all(identity.engine)
    with identity.transaction() as db: db.add(AuditStream(name="identity"))
    internal = TestClient(app,base_url=ORIGIN)
    cfg = DomainSettings("BPI",f"sqlite:///{tmp_path/'bpi.db'}",secrets.token_bytes(32),role="bootstrap",test_mode=True)
    bpi = BPI(cfg,SandboxSigner(secrets.token_bytes(32),cfg.network_code))
    Base.metadata.create_all(bpi.engine,tables=bpi.schema_tables())
    bpi.initialize(BPI_POLICY)
    class Bridge(IdentityClient):
        def validate(self, payload):
            response = internal.post("/internal/v1/validate",json=payload,headers={"X-Service-Domain":"BPI","X-Service-Key":"b"*43})
            if response.status_code != 200: raise RuleViolation(response.json()["code"],response.status_code)
            return response.json()
    domain = TestClient(create_app(replace(cfg,role="api"),bpi,Bridge(cfg)),base_url=ORIGIN)
    yield app, identity, bpi, domain, internal
    domain.close(); internal.close(); bpi.engine.dispose(); identity.engine.dispose()


def sign_in(stack, email):
    app, identity, _, domain, _ = stack
    browser = TestClient(app,base_url=ORIGIN)
    browser.get("/v1/identity/csrf")
    assert post(browser,"/v1/identity/registrations",{"email":email,"password":PASSWORD}).status_code==202
    with identity.transaction() as db:
        rows = db.scalars(select(EmailOutbox).order_by(EmailOutbox.created_at.desc())).all()
        token = json.loads(identity.crypto.decrypt(f"email_outbox:{rows[0].id}:payload",rows[0].payload_ciphertext))["token"]
    assert post(browser,"/v1/identity/email-verification/confirm",{"token":token}).status_code==204
    assert post(browser,"/v1/identity/sessions",{"email":email,"password":PASSWORD}).status_code==200
    return browser


def post(client, path, data, key=None):
    return client.post(path,json=data,headers={"Origin":ORIGIN,"X-CSRF-Token":client.cookies.get(CSRF,""),"Idempotency-Key":str(key or uuid.uuid4())})


def use(domain,browser):
    domain.cookies.clear()
    domain.cookies.update(browser.cookies)


def test_identity_to_payment_http_flow_and_private_receipt_scope(stack):
    _,_,bpi,domain,_ = stack
    alice,bob,eve=[sign_in(stack,name+"@example.com") for name in ("alice","bob","eve")]
    def enroll(browser):
        use(domain,browser)
        assert post(domain,"/v1/bpi/wallets",{}).status_code==202
        drain(bpi)
        return domain.get("/v1/bpi/wallets").json()["items"][0]
    a,b=enroll(alice),enroll(bob)
    use(domain,alice)
    assert post(domain,"/v1/bpi/sandbox/funding",{"wallet_id":a["id"],"amount_minor":"100000"}).status_code==202
    drain(bpi);settle_all(bpi)
    draft=post(domain,"/v1/bpi/payment-drafts",{"sender_wallet_id":a["id"],"receiver_address":b["address"],"amount_minor":"50000"})
    assert draft.status_code==201
    value=draft.json()
    assert post(domain,"/v1/bpi/payment-drafts/"+value["payment_id"]+"/authorizations",{"payload_digest":value["payload_digest"]}).status_code==202
    drain(bpi)
    assert domain.get("/v1/bpi/payments/"+value["payment_id"]).json()["status"]=="SETTLEMENT_PENDING"
    settle_all(bpi)
    use(domain,bob)
    assert domain.get("/v1/bpi/payments/"+value["payment_id"]).json()["status"]=="COMPLETED"
    assert domain.get("/v1/bpi/wallets").json()["items"][0]["balances"]["INR"]["available"]=="50000"
    use(domain,eve)
    assert domain.get("/v1/bpi/payments/"+value["payment_id"]).status_code==404
    assert domain.get("/v1/bpi/admin/overview").status_code==403


def test_revocation_and_csrf_propagate_to_financial_api(stack):
    _,_,_,domain,internal=stack
    browser=sign_in(stack,"alice@example.com")
    use(domain,browser)
    assert domain.post("/v1/bpi/wallets",json={}).status_code==403
    assert domain.get("/v1/bpi/wallets").status_code==200
    assert post(browser,"/v1/identity/logout",{}).status_code==204
    assert domain.get("/v1/bpi/wallets").status_code==401
    assert internal.post("/internal/v1/validate",json={"subject_id":str(uuid.uuid4())}).status_code==403


def test_internal_principal_contains_no_private_identity_fields(stack):
    _,_,_,_,internal=stack
    browser=sign_in(stack,"alice@example.com")
    response=internal.post("/internal/v1/validate",json={"browser_cookie":browser.cookies.get(COOKIE)},headers={"X-Service-Domain":"BPI","X-Service-Key":"b"*43})
    assert response.status_code==200
    assert set(response.json())=={"id","credentials_version","session_id","assurance","auth_time"}
    assert "alice" not in response.text and "password" not in response.text
