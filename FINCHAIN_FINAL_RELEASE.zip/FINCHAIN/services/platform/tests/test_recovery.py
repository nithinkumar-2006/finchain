import uuid
import pytest
from sqlalchemy import select
from finchain_platform.storage import Operation
from finchain_platform.bpi_models import Settlement
from finchain_platform.protocol import payload_digest
from test_bpi import bpi, principal, wallet, fund, drain, settle_all, evidence


@pytest.mark.parametrize("outcome", ["SUCCEEDED", "FAILED"])
def test_redemption_pending_and_terminal(bpi, outcome):
    actor = principal()
    a = wallet(bpi, actor)
    fund(bpi, actor, a)
    draft = bpi.redemption_draft(actor, uuid.uuid4(), a["id"], "20000")
    bpi.authorize(actor, uuid.uuid4(), draft["payment_id"], draft["payload_digest"])
    drain(bpi)
    values = bpi.wallets(actor)[0]["balances"]["INR"]
    assert values["available"] == "80000"
    assert values["pending"] == "20000"
    with bpi.transaction() as db:
        row = db.scalar(select(Settlement).where(Settlement.kind == "REDEMPTION"))
    bpi.apply_gateway_result(row.id, evidence(bpi, row, "UNKNOWN"))
    assert bpi.wallets(actor)[0]["balances"]["INR"]["available"] == "80000"
    terminal = evidence(bpi, row, outcome)
    bpi.apply_gateway_result(row.id, terminal)
    bpi.apply_gateway_result(row.id, terminal)
    values = bpi.wallets(actor)[0]["balances"]["INR"]
    assert values["available"] == ("80000" if outcome == "SUCCEEDED" else "100000")
    assert values["pending"] == "0"
    assert bpi.validate_chain()["valid"]


def test_system_signing_survives_database_rollback(bpi):
    actor = principal()
    a = wallet(bpi, actor)
    bpi.funding(actor, uuid.uuid4(), a["id"], "100000")
    drain(bpi)
    with bpi.transaction() as db:
        row = db.scalar(select(Settlement))
    original = bpi.signer
    bindings = {}
    class DurableBinding:
        fail_once = True
        def transaction(self, key, payload):
            grant = payload["operation_id"]
            digest = payload_digest(payload)
            assert grant not in bindings or bindings[grant] == digest
            bindings[grant] = digest
            return original.transaction(key, payload)
        def block(self, key, header):
            if self.fail_once:
                self.fail_once = False
                raise ConnectionError("Simulated crash after durable signer acceptance")
            return original.block(key, header)
    bpi.signer = DurableBinding()
    result = evidence(bpi, row)
    with pytest.raises(ConnectionError):
        bpi.apply_gateway_result(row.id, result)
    assert bpi.wallets(actor)[0]["balances"]["INR"]["available"] == "0"
    bpi.apply_gateway_result(row.id, result)
    assert len(bindings) == 1
    assert bpi.wallets(actor)[0]["balances"]["INR"]["available"] == "100000"
    assert bpi.validate_chain()["valid"]
