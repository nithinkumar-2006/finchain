import uuid
from dataclasses import replace
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select
from finchain_platform.admin import Administration
from finchain_platform.api import create_app
from finchain_platform.integrations import Integrations
from finchain_platform.commerce import Commerce
from finchain_platform.storage import DomainGrant, Wallet
from finchain_platform.bpi_models import Merchant, Membership, WebhookDelivery, WebhookInbox, Product, CommerceOrder
from finchain_platform.ledger import RuleViolation
from finchain_platform.worker import Worker
from test_bpi import bpi, principal, wallet, fund, draft_and_authorize, drain, settle_all


def test_scoped_key_issue_use_revoke_and_membership_recheck(bpi):
    owner=principal(); wallet(bpi,owner,True)
    with bpi.transaction() as db: merchant=db.scalar(select(Merchant))
    integration=Integrations(bpi)
    credentials=integration.create_key(owner,merchant.id,["payments:read","requests:write"])
    assert credentials["token"] not in str(integration.list_config(owner,merchant.id))
    key=uuid.uuid4()
    request=integration.key_request(credentials["token"],key,"10000")
    assert request==integration.key_request(credentials["token"],key,"10000")
    assert integration.key_payments(credentials["token"])["items"]==[]
    with pytest.raises(RuleViolation): integration.key_request(credentials["token"],key,"20000")
    integration.revoke_key(owner,merchant.id,credentials["id"])
    with pytest.raises(RuleViolation): integration.key_payments(credentials["token"])
    credentials=integration.create_key(owner,merchant.id,["payments:read"])
    with bpi.transaction() as db:
        db.scalar(select(Membership)).role="analyst"
    with pytest.raises(RuleViolation): integration.key_payments(credentials["token"])


def test_webhook_is_delivered_only_after_authenticated_local_http_ack(bpi):
    owner,buyer=principal(),principal()
    merchant_wallet=wallet(bpi,owner,True); customer=wallet(bpi,buyer)
    with bpi.transaction() as db: merchant=db.scalar(select(Merchant))
    integration=Integrations(bpi)
    integration.create_hook(owner,merchant.id)
    fund(bpi,buyer,customer)
    draft_and_authorize(bpi,buyer,customer,merchant_wallet)
    drain(bpi);settle_all(bpi);integration.queue_events()
    with bpi.transaction() as db:
        delivery=db.scalar(select(WebhookDelivery))
        assert delivery.status=="QUEUED"
    client=TestClient(create_app(replace(bpi.settings,role="api"),bpi,identity=object()),base_url=bpi.settings.origin)
    def send(payload,headers): return client.post("/internal/webhook-sink",json=payload,headers=headers)
    integration.deliver(send)
    with bpi.transaction() as db:
        assert db.scalar(select(WebhookDelivery)).status=="DELIVERED"
        assert db.scalar(select(WebhookDelivery)).response_status==200
        assert len(db.scalars(select(WebhookInbox)).all())==1
    assert client.post("/internal/webhook-sink",json={},headers={"x-webhook-id":str(uuid.uuid4()),"x-webhook-timestamp":"0","x-webhook-signature":"bad"}).status_code==401
    client.close()


def test_admin_worker_rechecks_domain_grant_and_pause_resume(bpi):
    admin=principal(); control=Administration(bpi)
    with pytest.raises(RuleViolation): control.submit(admin,uuid.uuid4(),"NETWORK",None,"PAUSED")
    with bpi.transaction() as db:
        subject,_=bpi.sync_subject(db,admin)
        db.add(DomainGrant(subject_id=subject.id,role="admin"))
    class Identity:
        def grant(self,*args): return admin
    worker=Worker(bpi,Identity())
    control.submit(admin,uuid.uuid4(),"NETWORK",None,"PAUSED")
    worker.step()
    with bpi.transaction() as db: assert bpi.network(db).status=="PAUSED"
    customer=principal();bpi.request_wallet(customer,uuid.uuid4())
    control.submit(admin,uuid.uuid4(),"NETWORK",None,"ACTIVE")
    worker.step()
    with bpi.transaction() as db: assert bpi.network(db).status=="ACTIVE"
    with pytest.raises(RuleViolation): control.submit(admin,uuid.uuid4(),"NETWORK",None,"MINT")


def test_commerce_stock_reservation_idempotency_and_payment_link(bpi):
    owner,buyer=principal(),principal()
    merchant_wallet=wallet(bpi,owner,True); customer=wallet(bpi,buyer)
    with bpi.transaction() as db: merchant=db.scalar(select(Merchant))
    commerce=Commerce(bpi)
    product=commerce.create_product(owner,uuid.uuid4(),merchant.id,"Sample","Sandbox service","Services","10000",2)
    key=uuid.uuid4();items=[{"product_id":product["product_id"],"quantity":1}]
    order=commerce.checkout(buyer,key,items)
    assert commerce.checkout(buyer,key,items)==order
    with bpi.transaction() as db: assert db.get(Product,uuid.UUID(product["product_id"])).stock==1
    fund(bpi,buyer,customer)
    draft_and_authorize(bpi,buyer,customer,merchant_wallet,"10000",request_id=order["request"]["request_id"])
    drain(bpi)
    with bpi.transaction() as db: assert db.get(CommerceOrder,uuid.UUID(order["order_id"])).status=="PAYMENT_PENDING"
    settle_all(bpi)
    with bpi.transaction() as db: assert db.get(CommerceOrder,uuid.UUID(order["order_id"])).status=="PAID"
