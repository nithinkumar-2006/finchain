from unittest.mock import patch
import pytest
from sqlalchemy import select
from finchain_identity.email_worker import deliver_one
from finchain_identity.models import EmailOutbox
from conftest import post


def test_local_delivery_only_after_smtp_acceptance(client,app):
    post(client,'/registrations',{'email':'alice@example.com','password':'correct sandbox password 123'})
    identity=app.state.identity
    with patch('finchain_identity.email_worker.smtplib.SMTP') as smtp:
        smtp.return_value.__enter__.return_value.send_message.side_effect=OSError('temporary failure')
        with pytest.raises(OSError): deliver_one(identity)
    with identity.transaction() as db: assert db.scalar(select(EmailOutbox)).state=='SANDBOX_QUEUED'
    with patch('finchain_identity.email_worker.smtplib.SMTP') as smtp:
        assert deliver_one(identity)
        message=smtp.return_value.__enter__.return_value.send_message.call_args.args[0]
        assert '/verify-email#' in message.get_content()
        assert 'local test inbox' in message.get_content()
    assert not deliver_one(identity)
    with pytest.raises(ValueError): deliver_one(identity,'smtp.external.example')
