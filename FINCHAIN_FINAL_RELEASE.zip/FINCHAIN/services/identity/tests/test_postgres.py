"""Concurrency tests only against an explicitly supplied disposable *_test database.

The caller must apply the migration before running. No database/schema is dropped.
"""
import os
import json
import secrets
import uuid
from concurrent.futures import ThreadPoolExecutor
from threading import Barrier
import pytest
from sqlalchemy import select, text
from sqlalchemy.engine import make_url
from sqlalchemy.exc import DBAPIError
from finchain_identity.config import Settings
from finchain_identity.service import Identity, Denied
from finchain_identity.models import User, EmailOutbox, RefreshToken, LoginSession, AuditLog
from conftest import PASSWORD

pytestmark = pytest.mark.postgres


@pytest.fixture
def pg(key):
    url = os.environ.get("IDENTITY_TEST_DATABASE_URL")
    if not url:
        pytest.skip("Set IDENTITY_TEST_DATABASE_URL to a migrated disposable PostgreSQL *_test database")
    if not make_url(url).database.endswith("_test"):
        pytest.fail("Concurrency tests require an explicitly named *_test database")
    s = Identity(Settings(database_url=url, private_key=key, encryption_key=secrets.token_bytes(32), lookup_key=secrets.token_bytes(32)))
    yield s
    s.engine.dispose()


def create_account(s):
    email = f"{uuid.uuid4()}@example.com"
    s.register(email, PASSWORD)
    with s.sessions() as db:
        user = db.scalar(select(User).where(User.email_lookup_digest == s.crypto.lookup("email", email)))
        row = db.scalar(select(EmailOutbox).where(EmailOutbox.user_id == user.id))
        value = json.loads(s.crypto.decrypt(f"email_outbox:{row.id}:payload", row.payload_ciphertext))["token"]
    s.consume_challenge(value, "VERIFY_EMAIL")
    return email, s.login(email, PASSWORD, None, "pg-test")


def test_simultaneous_refresh_same_token_revokes_family(pg):
    _, (browser, csrf) = create_account(pg)
    with pg.transaction() as db:
        user, session, web = pg.authenticate(db, browser, csrf)
        old = pg.crypto.decrypt(f"web_sessions:{web.id}:refresh", web.refresh_token_ciphertext)
        sid = session.id
    barrier = Barrier(2)

    def attempt():
        barrier.wait(timeout=10)
        try:
            with pg.transaction() as db:
                u, s, w = pg.authenticate(db, browser, csrf)
                pg.rotate(db, u, s, w, old)
            return "rotated"
        except Denied:
            return "denied"

    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(lambda _: attempt(), range(2)))
    assert sorted(results) == ["denied", "rotated"]
    with pg.sessions() as db:
        assert db.get(LoginSession, sid).revoked_at is not None
        assert len(db.scalars(select(RefreshToken).where(RefreshToken.session_id == sid)).all()) == 2


def test_simultaneous_reset_consumed_once(pg):
    email, _ = create_account(pg)
    pg.request_challenge(email, "RESET_PASSWORD")
    with pg.sessions() as db:
        user = db.scalar(select(User).where(User.email_lookup_digest == pg.crypto.lookup("email", email)))
        rows = db.scalars(select(EmailOutbox).where(EmailOutbox.user_id == user.id).order_by(EmailOutbox.created_at.desc())).all()
        value = json.loads(pg.crypto.decrypt(f"email_outbox:{rows[0].id}:payload", rows[0].payload_ciphertext))["token"]
    barrier = Barrier(2)

    def attempt():
        barrier.wait(timeout=10)
        try:
            pg.consume_challenge(value, "RESET_PASSWORD", "new sufficiently long password")
            return "reset"
        except Denied:
            return "denied"

    with ThreadPoolExecutor(max_workers=2) as pool:
        assert sorted(pool.map(lambda _: attempt(), range(2))) == ["denied", "reset"]


def test_postgres_audit_append_only(pg):
    create_account(pg)
    with pytest.raises(DBAPIError):
        with pg.engine.begin() as connection:
            connection.execute(text("UPDATE auth.audit_logs SET result = 'TAMPERED' WHERE sequence = 1"))


def test_runtime_role_cannot_grant_admin(pg):
    email, _ = create_account(pg)
    with pg.sessions() as db:
        user = db.scalar(select(User).where(User.email_lookup_digest == pg.crypto.lookup("email", email)))
        uid = user.id
    with pytest.raises(DBAPIError):
        with pg.engine.begin() as connection:
            connection.execute(text("SET LOCAL ROLE finchain_identity_runtime"))
            connection.execute(text("INSERT INTO auth.role_grants(id,created_at,user_id,role) VALUES (:id,now(),:uid,'admin')"), {"id": uuid.uuid4(), "uid": uid})
