import base64
import json
import secrets
import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from fastapi.testclient import TestClient
from sqlalchemy import select
from finchain_identity.app import create_app, CSRF, COOKIE, PREFIX
from finchain_identity.config import Settings
from finchain_identity.models import Base, AuditStream, EmailOutbox

PASSWORD = "a long sandbox password 123!"


@pytest.fixture(scope="session")
def key():
    return rsa.generate_private_key(public_exponent=65537, key_size=3072).private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())


@pytest.fixture
def app(tmp_path, key):
    settings = Settings(database_url=f"sqlite:///{tmp_path / 'identity.db'}", private_key=key,
                        encryption_key=secrets.token_bytes(32), lookup_key=secrets.token_bytes(32), test_mode=True)
    application = create_app(settings)
    service = application.state.identity
    Base.metadata.create_all(service.engine)
    with service.transaction() as db:
        db.add(AuditStream(name="identity"))
    yield application
    service.engine.dispose()


@pytest.fixture
def client(app):
    with TestClient(app, base_url=app.state.identity.settings.origin) as c:
        c.get(PREFIX + "/csrf")
        yield c


def post(client, path, data=None, **kwargs):
    headers = {"Origin": "https://localhost:8443", "X-CSRF-Token": client.cookies.get(CSRF, ""), "Content-Type": "application/json"}
    headers.update(kwargs.pop("headers", {}))
    return client.post(PREFIX + path, json=data or {}, headers=headers, **kwargs)


def challenge(app, purpose):
    service = app.state.identity
    with service.sessions() as db:
        for row in db.scalars(select(EmailOutbox).order_by(EmailOutbox.created_at.desc())):
            payload = json.loads(service.crypto.decrypt(f"email_outbox:{row.id}:payload", row.payload_ciphertext))
            if payload["purpose"] == purpose:
                return payload["token"]
    raise AssertionError("Missing encrypted sandbox delivery")


def account(client, app, email="alice@example.com", login=True):
    assert post(client, "/registrations", {"email": email, "password": PASSWORD}).status_code == 202
    assert post(client, "/email-verification/confirm", {"token": challenge(app, "VERIFY_EMAIL")}).status_code == 204
    if login:
        assert post(client, "/sessions", {"email": email, "password": PASSWORD}).status_code == 200


@pytest.fixture
def signed_in(client, app):
    account(client, app)
    return client
