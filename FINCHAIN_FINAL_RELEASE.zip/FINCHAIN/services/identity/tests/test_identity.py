import json
import uuid
from datetime import timedelta
import jwt
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select, update
from finchain_identity.app import PREFIX, COOKIE, CSRF
from finchain_identity.crypto import digest, audit_hash, totp_code
from finchain_identity.models import (User, Credential, LoginSession, RefreshToken, WebSession, Challenge, EmailOutbox, AuditLog, Role, now)
from finchain_identity.service import Denied
from conftest import post, challenge, account, PASSWORD


def test_register_verification_login_logout(client, app):
    post(client, "/registrations", {"email": "Alice@example.com", "password": PASSWORD})
    assert post(client, "/sessions", {"email": "alice@example.com", "password": PASSWORD}).status_code == 401
    secret = challenge(app, "VERIFY_EMAIL")
    assert post(client, "/email-verification/confirm", {"token": secret}).status_code == 204
    assert post(client, "/email-verification/confirm", {"token": secret}).status_code == 400
    response = post(client, "/sessions", {"email": "alice@example.com", "password": PASSWORD})
    assert response.status_code == 200
    assert "access_token" not in response.text and "refresh_token" not in response.text
    headers = response.headers.get_list("set-cookie")
    assert any(COOKIE in h and "HttpOnly" in h and "Secure" in h and "SameSite=lax" in h and "Domain=" not in h for h in headers)
    assert client.get(PREFIX + "/me").json()["roles"] == ["consumer"]
    assert post(client, "/logout").status_code == 204
    assert client.get(PREFIX + "/me").status_code == 401


def test_passwords_and_identity_encrypted(signed_in, app, caplog):
    service = app.state.identity
    with service.sessions() as db:
        user, cred = db.scalar(select(User)), db.scalar(select(Credential))
        assert cred.password_hash.startswith("$argon2id$")
        assert service.crypto.verify_password(cred.password_hash, PASSWORD)
        assert b"alice@example.com" not in user.email_ciphertext
        with pytest.raises(Exception):
            service.crypto.decrypt(f"users:{uuid.uuid4()}:email", user.email_ciphertext)
        for row in db.scalars(select(EmailOutbox)):
            assert b"alice@example.com" not in row.payload_ciphertext
        audit_text = " ".join(r.action + r.result for r in db.scalars(select(AuditLog)))
        assert PASSWORD not in audit_text
    assert PASSWORD not in caplog.text


def test_rotation_and_replay_revokes_family(signed_in, app):
    s = app.state.identity
    with s.sessions() as db:
        web = db.scalar(select(WebSession))
        stolen = s.crypto.decrypt(f"web_sessions:{web.id}:refresh", web.refresh_token_ciphertext)
    assert post(signed_in, "/sessions/refresh").status_code == 204
    with s.sessions() as db:
        rows = db.scalars(select(RefreshToken)).all()
        assert len(rows) == 2 and sum(r.used_at is not None for r in rows) == 1
    with pytest.raises(Denied):
        with s.transaction() as db:
            user, session, web = s.authenticate(db, signed_in.cookies.get(COOKIE), signed_in.cookies.get(CSRF))
            s.rotate(db, user, session, web, stolen)
    assert signed_in.get(PREFIX + "/me").status_code == 401
    assert post(signed_in, "/sessions/refresh").status_code == 401


def test_password_reset_revokes_all_and_no_auto_login(signed_in, app):
    c = signed_in
    post(c, "/forgot-password", {"email": "alice@example.com"})
    reset = challenge(app, "RESET_PASSWORD")
    assert post(c, "/email-verification/confirm", {"token": reset}).status_code == 400
    assert post(c, "/reset-password", {"token": reset, "password": "new password sufficiently long"}).status_code == 204
    assert c.get(PREFIX + "/me").status_code == 401
    assert post(c, "/reset-password", {"token": reset, "password": PASSWORD}).status_code == 400
    assert post(c, "/sessions", {"email": "alice@example.com", "password": PASSWORD}).status_code == 401
    assert post(c, "/sessions", {"email": "alice@example.com", "password": "new password sufficiently long"}).status_code == 200


def test_new_recovery_invalidates_old_and_expiry(signed_in, app):
    c, s = signed_in, app.state.identity
    post(c, "/forgot-password", {"email": "alice@example.com"})
    old = challenge(app, "RESET_PASSWORD")
    post(c, "/forgot-password", {"email": "alice@example.com"})
    new = challenge(app, "RESET_PASSWORD")
    assert post(c, "/reset-password", {"token": old, "password": PASSWORD}).status_code == 400
    with s.transaction() as db:
        db.execute(update(Challenge).where(Challenge.token_digest == digest(new)).values(expires_at=now() - timedelta(seconds=1)))
    assert post(c, "/reset-password", {"token": new, "password": PASSWORD}).status_code == 400


def test_generic_register_recovery_login(client, app):
    account(client, app, login=False)
    a = post(client, "/registrations", {"email": "alice@example.com", "password": PASSWORD})
    b = post(client, "/registrations", {"email": "other@example.com", "password": PASSWORD})
    assert a.status_code == b.status_code == 202 and a.json() == b.json()
    a = post(client, "/forgot-password", {"email": "alice@example.com"})
    b = post(client, "/forgot-password", {"email": "absent@example.com"})
    assert a.json() == b.json()
    a = post(client, "/sessions", {"email": "alice@example.com", "password": "wrong"})
    b = post(client, "/sessions", {"email": "absent@example.com", "password": "wrong"})
    assert a.status_code == b.status_code == 401 and a.json()["code"] == b.json()["code"]


def test_lockout_bounded_and_suspicious_login(client, app):
    account(client, app, login=False)
    for _ in range(5):
        assert post(client, "/sessions", {"email": "alice@example.com", "password": "wrong"}).status_code == 401
    assert post(client, "/sessions", {"email": "alice@example.com", "password": PASSWORD}).status_code == 401
    s = app.state.identity
    with s.transaction() as db:
        db.scalar(select(User)).locked_until = now() - timedelta(seconds=1)
    assert post(client, "/sessions", {"email": "alice@example.com", "password": PASSWORD}).status_code == 200
    assert post(client, "/sessions", {"email": "alice@example.com", "password": PASSWORD}, headers={"User-Agent": "changed-browser"}).status_code == 200
    with s.sessions() as db:
        assert db.scalar(select(AuditLog).where(AuditLog.action == "suspicious_login")) is not None


@pytest.mark.parametrize("payload", [{"role": "admin"}, {"roles": ["admin"]}, {"wallet_private_key": "CANARY_PRIVATE_KEY"}])
def test_mass_assignment_and_secret_validation(client, payload, caplog):
    r = post(client, "/registrations", {"email": "alice@example.com", "password": PASSWORD, **payload})
    assert r.status_code == 422
    assert PASSWORD not in r.text and "CANARY_PRIVATE_KEY" not in r.text + caplog.text


@pytest.mark.parametrize("headers", [{"Origin": "https://evil.example"}, {"X-CSRF-Token": ""}, {"X-CSRF-Token": "x" * 43}])
def test_csrf(signed_in, headers):
    assert post(signed_in, "/logout", headers=headers).status_code == 403
    assert signed_in.get(PREFIX + "/me").status_code == 200


def test_csrf_session_binding(signed_in):
    signed_in.cookies.clear()
    # Tested separately below with a real browser session and forged double submit pair.
    assert post(signed_in, "/logout").status_code == 403


def test_session_bound_csrf(signed_in):
    original = signed_in.cookies.get(COOKIE)
    signed_in.cookies.clear()
    signed_in.cookies.set(COOKIE, original)
    signed_in.cookies.set(CSRF, "z" * 43)
    assert post(signed_in, "/logout").status_code == 403


def test_cross_user_session_revoke(signed_in, app):
    alice = signed_in.get(PREFIX + "/me").json()["session_id"]
    with TestClient(app, base_url="https://localhost:8443") as bob:
        bob.get(PREFIX + "/csrf")
        account(bob, app, "bob@example.com")
        r = bob.delete(PREFIX + "/sessions/" + alice, headers={"Origin": "https://localhost:8443", "X-CSRF-Token": bob.cookies.get(CSRF)})
        assert r.status_code == 404
    assert signed_in.get(PREFIX + "/me").status_code == 200


def test_roles_and_mfa(signed_in, app):
    s, c = app.state.identity, signed_in
    assert c.get(PREFIX + "/audit-logs").status_code == 403
    uid = uuid.UUID(c.get(PREFIX + "/me").json()["id"])
    s.provision_role(uid, "admin", uuid.uuid4())
    assert c.get(PREFIX + "/me").status_code == 401
    assert post(c, "/sessions", {"email": "alice@example.com", "password": PASSWORD}).status_code == 200
    assert c.get(PREFIX + "/audit-logs").json()["code"] == "MFA_REQUIRED"
    enrollment = post(c, "/mfa/enrollments", {"password": PASSWORD})
    assert enrollment.status_code == 200
    secret = enrollment.json()["secret"]
    assert post(c, "/mfa/verifications", {"code": "000000"}).status_code == 401
    counter = int(now().timestamp()) // 30
    assert post(c, "/mfa/verifications", {"code": totp_code(secret, counter)}).status_code == 204
    assert c.get(PREFIX + "/me").status_code == 401
    assert post(c, "/sessions", {"email": "alice@example.com", "password": PASSWORD}).status_code == 401
    # The enrollment timestep cannot be replayed for login.
    assert post(c, "/sessions", {"email": "alice@example.com", "password": PASSWORD, "totp_code": totp_code(secret, counter)}).status_code == 401
    assert post(c, "/sessions", {"email": "alice@example.com", "password": PASSWORD, "totp_code": totp_code(secret, counter + 1)}).status_code == 200
    assert c.get(PREFIX + "/audit-logs").status_code == 200
    with s.transaction() as db:
        db.execute(Role.__table__.delete().where(Role.user_id == uid, Role.role == "admin"))
    assert c.get(PREFIX + "/audit-logs").status_code == 403


@pytest.mark.parametrize("mutation", ["aud", "iss", "exp", "missing", "alg", "kid", "jku"])
def test_jwt_rejection(signed_in, app, mutation):
    crypto, s = app.state.identity.crypto, app.state.identity
    with s.sessions() as db:
        web = db.scalar(select(WebSession))
        valid = crypto.decrypt(f"web_sessions:{web.id}:access", web.access_token_ciphertext)
    claims = crypto.decode(valid)
    headers = {"kid": s.settings.key_id, "typ": "at+jwt"}
    if mutation == "aud": claims["aud"] = "finchain:bpi:sandbox"
    if mutation == "iss": claims["iss"] = "https://evil.example"
    if mutation == "exp": claims["exp"] = 1
    if mutation == "missing": del claims["exp"]
    if mutation == "kid": headers["kid"] = "unknown"
    if mutation == "jku": headers["jku"] = "https://evil.example/key"
    encoded = jwt.encode(claims, "attacker-key", algorithm="HS256", headers=headers) if mutation == "alg" else jwt.encode(claims, crypto.private_key, algorithm="RS256", headers=headers)
    with pytest.raises((jwt.InvalidTokenError, ValueError)):
        crypto.decode(encoded)


def test_idle_expiry(signed_in, app):
    with app.state.identity.transaction() as db:
        db.scalar(select(LoginSession)).last_seen_at = now() - timedelta(hours=1)
    assert signed_in.get(PREFIX + "/me").status_code == 401
    assert post(signed_in, "/sessions/refresh").status_code == 401


def test_headers_cors_size_sql_xss(client, app):
    r = client.get(PREFIX + "/csrf", headers={"Origin": "https://evil.example"})
    assert "access-control-allow-origin" not in r.headers
    assert r.headers["cache-control"] == "no-store" and "frame-ancestors 'none'" in r.headers["content-security-policy"]
    r = client.get(PREFIX + "/csrf", headers={"Origin": "https://localhost:8443"})
    assert r.headers["access-control-allow-origin"] == "https://localhost:8443"
    r = post(client, "/registrations", {"email": "' OR 1=1--", "password": "<script>alert(1)</script>"})
    assert r.status_code == 422 and "<script>" not in r.text
    assert post(client, "/registrations", {"padding": "a" * 9000}).status_code == 413


def test_rate_limit_shared_and_proxy_not_trusted(client, app):
    s = app.state.identity
    for _ in range(s.settings.rate_limit):
        s.rate("peer", "test")
    with pytest.raises(Denied) as exc:
        s.rate("peer", "test")
    assert exc.value.status == 429
    for _ in range(60):
        r = client.get(PREFIX + "/csrf", headers={"X-Forwarded-For": str(uuid.uuid4())})
    assert r.status_code == 429


def test_audit_chain_and_no_secrets(signed_in, app):
    s = app.state.identity
    previous = "0" * 64
    with s.sessions() as db:
        for r in db.scalars(select(AuditLog).order_by(AuditLog.sequence)):
            assert r.previous_hash == previous
            payload = {"id": str(r.id), "sequence": r.sequence, "actor": str(r.actor_user_id) if r.actor_user_id else None,
                       "operator": str(r.operator_id) if r.operator_id else None, "action": r.action, "result": r.result,
                       "correlation_id": str(r.correlation_id), "created_at": r.created_at.isoformat(), "previous_hash": r.previous_hash}
            assert audit_hash(payload) == r.event_hash
            previous = r.event_hash


def test_audit_failure_rolls_back_registration(client, app, monkeypatch):
    def fail(*args, **kwargs):
        raise RuntimeError("Audit storage unavailable")
    monkeypatch.setattr(app.state.identity, "audit", fail)
    with pytest.raises(RuntimeError):
        post(client, "/registrations", {"email": "alice@example.com", "password": PASSWORD})
    with app.state.identity.sessions() as db:
        assert db.scalar(select(User)) is None


def test_rfc_totp_vector():
    import base64
    secret = base64.b32encode(b"12345678901234567890").decode()
    assert totp_code(secret, 1) == "287082"
