-- DBA runs once in identity_db. Provision passwords through secret management.
-- Migration owner is separate from the API and operator roles.
CREATE ROLE finchain_identity_runtime NOLOGIN;
CREATE ROLE finchain_identity_operator NOLOGIN;
GRANT USAGE ON SCHEMA auth TO finchain_identity_runtime, finchain_identity_operator;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA auth TO finchain_identity_runtime;
REVOKE UPDATE ON auth.audit_logs FROM finchain_identity_runtime;
REVOKE UPDATE ON auth.role_grants FROM finchain_identity_runtime;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA auth TO finchain_identity_operator;
REVOKE UPDATE ON auth.audit_logs FROM finchain_identity_operator;
-- Runtime may create consumer grants only, including if its SQL connection is compromised.
ALTER TABLE auth.role_grants ENABLE ROW LEVEL SECURITY;
ALTER TABLE auth.role_grants FORCE ROW LEVEL SECURITY;
CREATE POLICY role_read ON auth.role_grants FOR SELECT TO finchain_identity_runtime USING (true);
CREATE POLICY consumer_registration ON auth.role_grants FOR INSERT TO finchain_identity_runtime WITH CHECK (role = 'consumer');
CREATE POLICY operator_roles ON auth.role_grants TO finchain_identity_operator USING (true) WITH CHECK (true);
-- API login roles inherit runtime only; never grant operator/owner membership or BYPASSRLS.
-- Do not grant schema CREATE, audit TRUNCATE, DELETE, or any BPI/FINCOIN DB access.
