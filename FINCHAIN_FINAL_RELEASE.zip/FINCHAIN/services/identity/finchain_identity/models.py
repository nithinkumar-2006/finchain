import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, Integer, LargeBinary, ForeignKey, UniqueConstraint, CheckConstraint, Index, MetaData, DateTime
from sqlalchemy.orm import declarative_base
from sqlalchemy.types import TypeDecorator, Uuid


def now():
    return datetime.now(timezone.utc)


class UTCDateTime(TypeDecorator):
    impl = DateTime(timezone=True)
    cache_ok = True

    def process_bind_param(self, value, dialect):
        if value is not None and value.tzinfo is None:
            raise ValueError("Timezone required")
        return value

    def process_result_value(self, value, dialect):
        return value.replace(tzinfo=timezone.utc) if value is not None and value.tzinfo is None else value


Base = declarative_base(metadata=MetaData(schema="auth"))


class Record:
    id = Column(Uuid, primary_key=True, default=uuid.uuid4)
    created_at = Column(UTCDateTime, nullable=False, default=now)


class User(Record, Base):
    __tablename__ = "users"
    email_ciphertext = Column(LargeBinary, nullable=False)
    email_lookup_digest = Column(String(64), nullable=False, unique=True)
    lookup_key_version = Column(Integer, nullable=False, default=1)
    status = Column(String(16), nullable=False, default="ACTIVE")
    email_verified_at = Column(UTCDateTime)
    credentials_version = Column(Integer, nullable=False, default=1)
    failures = Column(Integer, nullable=False, default=0)
    locked_until = Column(UTCDateTime)
    last_authenticated_at = Column(UTCDateTime)
    last_login_digest = Column(String(64))
    updated_at = Column(UTCDateTime, nullable=False, default=now, onupdate=now)
    deleted_at = Column(UTCDateTime)
    __table_args__ = (CheckConstraint("status IN ('ACTIVE','DISABLED','DELETED')", name="user_status"), CheckConstraint("credentials_version > 0 AND failures >= 0", name="user_counters"))


class Credential(Record, Base):
    __tablename__ = "password_credentials"
    user_id = Column(Uuid, ForeignKey("auth.users.id"), nullable=False, unique=True)
    password_hash = Column(String(512), nullable=False)
    changed_at = Column(UTCDateTime, nullable=False, default=now)


class Role(Record, Base):
    __tablename__ = "role_grants"
    user_id = Column(Uuid, ForeignKey("auth.users.id"), nullable=False, index=True)
    role = Column(String(16), nullable=False)
    __table_args__ = (UniqueConstraint("user_id", "role"), CheckConstraint("role IN ('consumer','merchant','admin','compliance','support')", name="role_allowlist"))


class LoginSession(Record, Base):
    __tablename__ = "sessions"
    user_id = Column(Uuid, ForeignKey("auth.users.id"), nullable=False, index=True)
    authenticated_at = Column(UTCDateTime, nullable=False, default=now)
    last_seen_at = Column(UTCDateTime, nullable=False, default=now)
    expires_at = Column(UTCDateTime, nullable=False)
    revoked_at = Column(UTCDateTime)
    revocation_reason = Column(String(32))
    assurance_level = Column(String(8), nullable=False, default="PASSWORD")
    credentials_version = Column(Integer, nullable=False)
    __table_args__ = (CheckConstraint("expires_at > authenticated_at", name="session_expiry"), CheckConstraint("assurance_level IN ('PASSWORD','MFA')", name="session_assurance"))


class RefreshToken(Record, Base):
    __tablename__ = "refresh_tokens"
    session_id = Column(Uuid, ForeignKey("auth.sessions.id"), nullable=False, index=True)
    parent_token_id = Column(Uuid, unique=True)
    token_digest = Column(String(64), nullable=False, unique=True)
    expires_at = Column(UTCDateTime, nullable=False)
    used_at = Column(UTCDateTime)
    __table_args__ = (UniqueConstraint("id", "session_id"),)


from sqlalchemy import ForeignKeyConstraint, text
RefreshToken.__table__.append_constraint(ForeignKeyConstraint(["parent_token_id", "session_id"], ["auth.refresh_tokens.id", "auth.refresh_tokens.session_id"]))
Index("one_refresh_root", RefreshToken.session_id, unique=True, postgresql_where=text("parent_token_id IS NULL"), sqlite_where=text("parent_token_id IS NULL"))


class WebSession(Record, Base):
    __tablename__ = "web_sessions"
    session_id = Column(Uuid, ForeignKey("auth.sessions.id"), nullable=False, unique=True)
    browser_cookie_digest = Column(String(64), nullable=False, unique=True)
    csrf_digest = Column(String(64), nullable=False)
    refresh_token_ciphertext = Column(LargeBinary, nullable=False)
    access_token_ciphertext = Column(LargeBinary, nullable=False)


class Challenge(Record, Base):
    __tablename__ = "identity_challenges"
    user_id = Column(Uuid, ForeignKey("auth.users.id"), nullable=False, index=True)
    purpose = Column(String(16), nullable=False)
    token_digest = Column(String(64), nullable=False, unique=True)
    credentials_version = Column(Integer, nullable=False)
    expires_at = Column(UTCDateTime, nullable=False)
    used_at = Column(UTCDateTime)
    __table_args__ = (CheckConstraint("purpose IN ('VERIFY_EMAIL','RESET_PASSWORD')", name="challenge_purpose"),)


class EmailOutbox(Record, Base):
    __tablename__ = "email_outbox"
    user_id = Column(Uuid, ForeignKey("auth.users.id"), nullable=False, index=True)
    challenge_id = Column(Uuid, ForeignKey("auth.identity_challenges.id"), nullable=False, unique=True)
    payload_ciphertext = Column(LargeBinary, nullable=False)
    state = Column(String(16), nullable=False, default="SANDBOX_QUEUED")


class MFAFactor(Record, Base):
    __tablename__ = "mfa_factors"
    user_id = Column(Uuid, ForeignKey("auth.users.id"), nullable=False, unique=True)
    factor_type = Column(String(8), nullable=False, default="TOTP")
    totp_secret_ciphertext = Column(LargeBinary, nullable=False)
    expires_at = Column(UTCDateTime, nullable=False)
    verified_at = Column(UTCDateTime)
    last_counter = Column(Integer, nullable=False, default=-1)
    __table_args__ = (CheckConstraint("factor_type = 'TOTP'", name="mfa_type"),)


class RateBucket(Record, Base):
    __tablename__ = "rate_buckets"
    bucket_key = Column(String(64), nullable=False, unique=True)
    window = Column(Integer, nullable=False)
    hits = Column(Integer, nullable=False, default=0)


class AuditStream(Record, Base):
    __tablename__ = "audit_streams"
    name = Column(String(16), nullable=False, unique=True)
    sequence = Column(Integer, nullable=False, default=0)
    head = Column(String(64), nullable=False, default="0" * 64)


class AuditLog(Record, Base):
    __tablename__ = "audit_logs"
    sequence = Column(Integer, nullable=False, unique=True)
    actor_user_id = Column(Uuid, ForeignKey("auth.users.id"))
    operator_id = Column(Uuid)
    action = Column(String(40), nullable=False)
    result = Column(String(32), nullable=False)
    correlation_id = Column(Uuid, nullable=False)
    previous_hash = Column(String(64), nullable=False)
    event_hash = Column(String(64), nullable=False)
    __table_args__ = (Index("audit_actor_time", "actor_user_id", "created_at"),)
