import base64
import json
import secrets
import uuid
from contextlib import contextmanager
from datetime import timedelta
import jwt
from sqlalchemy import create_engine, select, update, event
from sqlalchemy.orm import sessionmaker
from .models import (Base, User, Credential, Role, LoginSession, RefreshToken, WebSession, Challenge,
                     EmailOutbox, MFAFactor, RateBucket, AuditStream, AuditLog, now)
from .crypto import Crypto, token, digest, match_totp, audit_hash


class Denied(Exception):
    def __init__(self, code="INVALID_CREDENTIALS", status=401):
        self.code, self.status = code, status


class Identity:
    def __init__(self, settings):
        self.settings = settings
        options = {"hide_parameters": True, "pool_pre_ping": True}
        if settings.test_mode and settings.database_url.startswith("sqlite"):
            options.update(execution_options={"schema_translate_map": {"auth": None}}, connect_args={"check_same_thread": False})
        self.engine = create_engine(settings.database_url, **options)
        if self.engine.dialect.name == "sqlite":
            @event.listens_for(self.engine, "connect")
            def sqlite_fk(connection, _):
                connection.execute("PRAGMA foreign_keys=ON")
        self.sessions = sessionmaker(self.engine, expire_on_commit=False)
        self.crypto = Crypto(settings)

    @contextmanager
    def transaction(self):
        with self.sessions() as db:
            try:
                yield db
                db.commit()
            except Denied:
                # Failed authentication/replay state and its audit must survive rejection.
                db.commit()
                raise
            except Exception:
                db.rollback()
                raise

    def audit(self, db, action, result, actor=None, operator=None):
        stream = db.scalar(select(AuditStream).where(AuditStream.name == "identity").with_for_update())
        if stream is None:
            raise RuntimeError("Identity migrations are required")
        timestamp, record_id, correlation = now(), uuid.uuid4(), uuid.uuid4()
        sequence = stream.sequence + 1
        payload = {"id": str(record_id), "sequence": sequence, "actor": str(actor) if actor else None,
                   "operator": str(operator) if operator else None,
                   "action": action, "result": result, "correlation_id": str(correlation),
                   "created_at": timestamp.isoformat(), "previous_hash": stream.head}
        value = audit_hash(payload)
        db.add(AuditLog(id=record_id, sequence=sequence, actor_user_id=actor, operator_id=operator, action=action, result=result,
                        correlation_id=correlation, created_at=timestamp, previous_hash=stream.head, event_hash=value))
        stream.sequence, stream.head = sequence, value
        db.flush()

    def rate(self, peer, route):
        key = self.crypto.lookup("rate", peer + "|" + route)
        window = int(now().timestamp()) // 60
        insert = __import__("sqlalchemy.dialects." + self.engine.dialect.name, fromlist=["insert"]).insert
        with self.transaction() as db:
            db.execute(insert(RateBucket).values(id=uuid.uuid4(), created_at=now(), bucket_key=key, window=window, hits=0).on_conflict_do_nothing(index_elements=["bucket_key"]))
            bucket = db.scalar(select(RateBucket).where(RateBucket.bucket_key == key).with_for_update())
            if bucket.window != window:
                bucket.window, bucket.hits = window, 0
            bucket.hits += 1
            maximum = min(5, self.settings.rate_limit) if route == "mfa-account" else self.settings.rate_limit
            if bucket.hits > maximum:
                if bucket.hits == maximum + 1:
                    self.audit(db, "rate_limit", "DENIED")
                raise Denied("RATE_LIMITED", 429)

    def user_by_email(self, db, email):
        return db.scalar(select(User).where(User.email_lookup_digest == self.crypto.lookup("email", email)).with_for_update())

    def lock_user(self, db, user_id):
        return db.scalar(select(User).where(User.id == user_id).with_for_update())

    def challenge(self, db, user, purpose):
        # Only the newest outstanding challenge of a purpose remains usable.
        db.execute(update(Challenge).where(Challenge.user_id == user.id, Challenge.purpose == purpose, Challenge.used_at.is_(None)).values(used_at=now()))
        secret, cid, mid = token(), uuid.uuid4(), uuid.uuid4()
        lifetime = 900 if purpose == "RESET_PASSWORD" else 3600
        db.add(Challenge(id=cid, user_id=user.id, purpose=purpose, token_digest=digest(secret), credentials_version=user.credentials_version, expires_at=now() + timedelta(seconds=lifetime)))
        db.flush()
        # Restricted, encrypted delivery queue. No external email is sent by this release.
        payload = json.dumps({"recipient": self.crypto.decrypt(f"users:{user.id}:email", user.email_ciphertext), "purpose": purpose, "token": secret})
        db.add(EmailOutbox(id=mid, user_id=user.id, challenge_id=cid, payload_ciphertext=self.crypto.encrypt(f"email_outbox:{mid}:payload", payload)))

    def register(self, email, password):
        password_hash = self.crypto.passwords.hash(password)
        # A blind-index bucket serializes creation for absent users as well.
        self.rate(self.crypto.lookup("registration", email), "registration-account")
        with self.transaction() as db:
            if self.user_by_email(db, email):
                self.audit(db, "register", "ACCEPTED")
                return
            user_id = uuid.uuid4()
            insert = __import__("sqlalchemy.dialects." + self.engine.dialect.name, fromlist=["insert"]).insert
            inserted = db.execute(insert(User).values(id=user_id, email_lookup_digest=self.crypto.lookup("email", email),
                                  email_ciphertext=self.crypto.encrypt(f"users:{user_id}:email", email), created_at=now()).on_conflict_do_nothing(index_elements=["email_lookup_digest"]).returning(User.id)).scalar_one_or_none()
            if inserted is None:
                self.audit(db, "register", "ACCEPTED")
                return
            user = self.lock_user(db, user_id)
            db.add(Credential(user_id=user.id, password_hash=password_hash))
            db.add(Role(user_id=user.id, role="consumer"))
            self.challenge(db, user, "VERIFY_EMAIL")
            self.audit(db, "register", "ACCEPTED", user.id)

    def request_challenge(self, email, purpose):
        self.rate(self.crypto.lookup("recovery", email), "challenge-account")
        with self.transaction() as db:
            user = self.user_by_email(db, email)
            if user and user.status == "ACTIVE" and (purpose != "VERIFY_EMAIL" or user.email_verified_at is None):
                self.challenge(db, user, purpose)
            self.audit(db, "recovery_request" if purpose == "RESET_PASSWORD" else "verification_request", "ACCEPTED")

    def consume_challenge(self, secret, purpose, password=None):
        new_hash = self.crypto.passwords.hash(password) if password is not None else None
        with self.transaction() as db:
            reference = db.scalar(select(Challenge).where(Challenge.token_digest == digest(secret), Challenge.purpose == purpose))
            if reference is None:
                self.audit(db, "challenge", "DENIED")
                raise Denied("INVALID_CHALLENGE", 400)
            user = self.lock_user(db, reference.user_id)
            challenge = db.scalar(select(Challenge).where(Challenge.id == reference.id).with_for_update().execution_options(populate_existing=True))
            if user.status != "ACTIVE" or challenge.used_at or challenge.expires_at <= now() or challenge.credentials_version != user.credentials_version:
                self.audit(db, "challenge", "DENIED", user.id)
                raise Denied("INVALID_CHALLENGE", 400)
            challenge.used_at = now()
            if purpose == "RESET_PASSWORD":
                credential = db.scalar(select(Credential).where(Credential.user_id == user.id))
                credential.password_hash, credential.changed_at = new_hash, now()
                user.credentials_version += 1
                user.failures, user.locked_until = 0, None
                self.revoke_all(db, user, "PASSWORD_RESET")
                db.execute(update(Challenge).where(Challenge.user_id == user.id, Challenge.used_at.is_(None)).values(used_at=now()))
            else:
                user.email_verified_at = now()
            self.audit(db, "password_reset" if password is not None else "email_verified", "SUCCEEDED", user.id)

    def revoke_all(self, db, user, reason):
        db.execute(update(LoginSession).where(LoginSession.user_id == user.id, LoginSession.revoked_at.is_(None)).values(revoked_at=now(), revocation_reason=reason))

    def login(self, email, password, otp, fingerprint):
        self.rate(self.crypto.lookup("login", email), "login-account")
        with self.transaction() as db:
            user = self.user_by_email(db, email)
            credential = db.scalar(select(Credential).where(Credential.user_id == user.id)) if user else None
            valid = self.crypto.verify_password(credential.password_hash if credential else self.crypto.dummy, password)
            locked = user and user.locked_until and user.locked_until > now()
            factor = db.scalar(select(MFAFactor).where(MFAFactor.user_id == user.id)) if user else None
            counter = None
            if valid and user and factor and factor.verified_at:
                counter = match_totp(self.crypto.decrypt(f"mfa_factors:{factor.id}:secret", factor.totp_secret_ciphertext), otp or "", factor.last_counter, now().timestamp())
                valid = counter is not None
            if not valid or not user or user.status != "ACTIVE" or locked:
                if user and not locked:
                    if user.locked_until:
                        user.failures, user.locked_until = 0, None
                    user.failures += 1
                    if user.failures >= 5:
                        user.locked_until = now() + timedelta(minutes=15)
                self.audit(db, "login", "DENIED", user.id if user else None)
                raise Denied()
            if user.email_verified_at is None:
                self.audit(db, "login", "DENIED", user.id)
                raise Denied()
            if factor and counter is not None:
                factor.last_counter = counter
            if self.crypto.passwords.check_needs_rehash(credential.password_hash):
                credential.password_hash = self.crypto.passwords.hash(password)
            signal = self.crypto.lookup("login-signal", fingerprint)
            suspicious = user.last_login_digest is not None and user.last_login_digest != signal
            if suspicious:
                self.audit(db, "suspicious_login", "NEW_NETWORK_OR_AGENT", user.id)
            user.last_login_digest, user.last_authenticated_at = signal, now()
            user.failures, user.locked_until = 0, None
            # Bound per-user server-side session storage; deterministic oldest-first revocation.
            active = db.scalars(select(LoginSession).where(LoginSession.user_id == user.id, LoginSession.revoked_at.is_(None), LoginSession.expires_at > now()).order_by(LoginSession.created_at)).all()
            for old in active[:-9] if len(active) >= 10 else []:
                old.revoked_at, old.revocation_reason = now(), "SESSION_LIMIT"
            session = LoginSession(id=uuid.uuid4(), user_id=user.id, authenticated_at=now(), last_seen_at=now(),
                                   expires_at=now() + timedelta(seconds=self.settings.session_seconds), credentials_version=user.credentials_version,
                                   assurance_level="MFA" if counter is not None else "PASSWORD")
            db.add(session)
            db.flush()
            refresh, browser, csrf = token(), token(), token()
            db.add(RefreshToken(session_id=session.id, token_digest=digest(refresh), expires_at=session.expires_at))
            web_id = uuid.uuid4()
            db.add(WebSession(id=web_id, session_id=session.id, browser_cookie_digest=digest(browser), csrf_digest=digest(csrf),
                              refresh_token_ciphertext=self.crypto.encrypt(f"web_sessions:{web_id}:refresh", refresh),
                              access_token_ciphertext=self.crypto.encrypt(f"web_sessions:{web_id}:access", self.crypto.issue(user, session))))
            self.audit(db, "login", "SUCCEEDED", user.id)
            return browser, csrf

    def authenticate(self, db, browser, csrf=None, check_access=True):
        web = db.scalar(select(WebSession).where(WebSession.browser_cookie_digest == digest(browser)))
        if web is None:
            raise Denied("INVALID_SESSION")
        reference = db.get(LoginSession, web.session_id)
        user = self.lock_user(db, reference.user_id)
        session = db.scalar(select(LoginSession).where(LoginSession.id == reference.id).with_for_update().execution_options(populate_existing=True))
        web = db.scalar(select(WebSession).where(WebSession.id == web.id).with_for_update().execution_options(populate_existing=True))
        if user.status != "ACTIVE" or session.revoked_at or session.expires_at <= now() or session.last_seen_at + timedelta(seconds=self.settings.idle_seconds) <= now() or user.credentials_version != session.credentials_version:
            raise Denied("INVALID_SESSION")
        if csrf is not None and not secrets.compare_digest(web.csrf_digest, digest(csrf)):
            self.audit(db, "csrf", "DENIED", user.id)
            raise Denied("CSRF_FAILED", 403)
        if check_access:
            try:
                claims = self.crypto.decode(self.crypto.decrypt(f"web_sessions:{web.id}:access", web.access_token_ciphertext))
                if claims["sub"] != str(user.id) or claims["sid"] != str(session.id) or claims["cv"] != user.credentials_version or claims["amr"] != session.assurance_level:
                    raise jwt.InvalidTokenError()
            except (jwt.InvalidTokenError, ValueError, KeyError, TypeError):
                raise Denied("ACCESS_EXPIRED") from None
        session.last_seen_at = now()
        return user, session, web

    def rotate(self, db, user, session, web, presented):
        old = db.scalar(select(RefreshToken).where(RefreshToken.token_digest == digest(presented), RefreshToken.session_id == session.id).with_for_update())
        if old is None or old.used_at or old.expires_at <= now():
            session.revoked_at, session.revocation_reason = now(), "REFRESH_REUSE"
            self.audit(db, "refresh", "FAMILY_REVOKED", user.id)
            raise Denied("INVALID_SESSION")
        old.used_at = now()
        new = token()
        db.add(RefreshToken(session_id=session.id, parent_token_id=old.id, token_digest=digest(new), expires_at=session.expires_at))
        web.refresh_token_ciphertext = self.crypto.encrypt(f"web_sessions:{web.id}:refresh", new)
        web.access_token_ciphertext = self.crypto.encrypt(f"web_sessions:{web.id}:access", self.crypto.issue(user, session))
        self.audit(db, "refresh", "ROTATED", user.id)

    def refresh(self, browser, csrf):
        with self.transaction() as db:
            user, session, web = self.authenticate(db, browser, csrf, check_access=False)
            self.rotate(db, user, session, web, self.crypto.decrypt(f"web_sessions:{web.id}:refresh", web.refresh_token_ciphertext))

    def logout(self, browser, csrf, target=None):
        with self.transaction() as db:
            user, session, _ = self.authenticate(db, browser, csrf, check_access=False)
            selected = db.scalar(select(LoginSession).where(LoginSession.id == (target or session.id), LoginSession.user_id == user.id).with_for_update())
            if selected is None:
                raise Denied("NOT_FOUND", 404)
            selected.revoked_at, selected.revocation_reason = now(), "LOGOUT"
            self.audit(db, "logout", "SUCCEEDED", user.id)

    def me(self, browser):
        with self.transaction() as db:
            user, session, _ = self.authenticate(db, browser)
            roles = list(db.scalars(select(Role.role).where(Role.user_id == user.id)))
            return {"id": str(user.id), "roles": sorted(roles), "email_verified": user.email_verified_at is not None,
                    "session_id": str(session.id), "assurance": session.assurance_level, "environment": "sandbox"}

    def list_sessions(self, browser):
        with self.transaction() as db:
            user, _, _ = self.authenticate(db, browser)
            rows = db.scalars(select(LoginSession).where(LoginSession.user_id == user.id, LoginSession.revoked_at.is_(None), LoginSession.expires_at > now()).order_by(LoginSession.created_at.desc()).limit(10)).all()
            return [{"id": str(s.id), "authenticated_at": s.authenticated_at, "expires_at": s.expires_at, "assurance": s.assurance_level} for s in rows]

    def require_role(self, db, user, session, permitted):
        roles = set(db.scalars(select(Role.role).where(Role.user_id == user.id)))
        if not roles.intersection(permitted):
            self.audit(db, "authorization", "ROLE_DENIED", user.id)
            raise Denied("FORBIDDEN", 403)
        if session.assurance_level != "MFA" or session.authenticated_at + timedelta(minutes=5) <= now():
            self.audit(db, "authorization", "STEP_UP_REQUIRED", user.id)
            raise Denied("MFA_REQUIRED", 403)

    def audit_view(self, browser):
        with self.transaction() as db:
            user, session, _ = self.authenticate(db, browser)
            self.require_role(db, user, session, {"admin", "compliance"})
            self.audit(db, "audit_read", "SUCCEEDED", user.id)
            rows = db.scalars(select(AuditLog).order_by(AuditLog.sequence.desc()).limit(50)).all()
            return [{"id": str(r.id), "action": r.action, "result": r.result, "created_at": r.created_at} for r in rows]

    def enroll_mfa(self, browser, csrf, password):
        with self.transaction() as db:
            user, session, _ = self.authenticate(db, browser, csrf)
            credential = db.scalar(select(Credential).where(Credential.user_id == user.id))
            if session.authenticated_at + timedelta(minutes=5) <= now() or not self.crypto.verify_password(credential.password_hash, password):
                self.audit(db, "mfa_enrollment", "DENIED", user.id)
                raise Denied()
            factor = db.scalar(select(MFAFactor).where(MFAFactor.user_id == user.id))
            if factor and factor.verified_at:
                raise Denied("MFA_ALREADY_ENROLLED", 409)
            if factor is None:
                factor = MFAFactor(id=uuid.uuid4(), user_id=user.id)
                db.add(factor)
            secret = base64.b32encode(secrets.token_bytes(20)).decode()
            factor.totp_secret_ciphertext = self.crypto.encrypt(f"mfa_factors:{factor.id}:secret", secret)
            factor.expires_at, factor.last_counter = now() + timedelta(minutes=5), -1
            self.audit(db, "mfa_enrollment", "PENDING", user.id)
            return {"factor_id": str(factor.id), "secret": secret, "algorithm": "SHA1", "digits": 6, "period": 30}

    def confirm_mfa(self, browser, csrf, code):
        with self.transaction() as db:
            user, session, _ = self.authenticate(db, browser, csrf)
            factor = db.scalar(select(MFAFactor).where(MFAFactor.user_id == user.id))
            if not factor or factor.verified_at or factor.expires_at <= now():
                raise Denied("INVALID_CHALLENGE", 400)
            counter = match_totp(self.crypto.decrypt(f"mfa_factors:{factor.id}:secret", factor.totp_secret_ciphertext), code, factor.last_counter, now().timestamp())
            if counter is None:
                self.audit(db, "mfa_confirmation", "DENIED", user.id)
                raise Denied()
            factor.verified_at, factor.last_counter = now(), counter
            user.credentials_version += 1
            self.revoke_all(db, user, "MFA_ENABLED")
            self.audit(db, "mfa_confirmation", "SUCCEEDED", user.id)

    def provision_role(self, user_id, role, operator_id):
        if role not in {"consumer", "merchant", "admin", "compliance", "support"}:
            raise ValueError("Unknown role")
        # Offline operator command only; credentials are the restricted DB operator identity.
        with self.transaction() as db:
            user = self.lock_user(db, user_id)
            if not user or user.status != "ACTIVE" or not user.email_verified_at:
                raise ValueError("An active verified user is required")
            if not db.scalar(select(Role).where(Role.user_id == user.id, Role.role == role)):
                db.add(Role(user_id=user.id, role=role))
                user.credentials_version += 1
                self.revoke_all(db, user, "ROLE_CHANGE")
                self.audit(db, "role_granted_" + role, "OPERATOR_APPROVED", user.id, operator_id)
