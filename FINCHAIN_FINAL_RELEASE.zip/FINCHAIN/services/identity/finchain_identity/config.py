import base64
import os
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlsplit


@dataclass(frozen=True)
class Settings:
    database_url: str = field(repr=False)
    private_key: bytes = field(repr=False)
    encryption_key: bytes = field(repr=False)
    lookup_key: bytes = field(repr=False)
    origin: str = "https://localhost:8443"
    issuer: str = "https://localhost:8443/v1/identity"
    key_id: str = "identity-sandbox-1"
    test_mode: bool = False
    access_seconds: int = 300
    session_seconds: int = 86400
    idle_seconds: int = 1800
    rate_limit: int = 60
    internal_keys: dict[str, str] = field(default_factory=dict, repr=False)

    def __post_init__(self):
        if not self.test_mode and not self.database_url.startswith("postgresql+psycopg://"):
            raise ValueError("PostgreSQL is required outside isolated tests")
        for value in (self.origin, self.issuer):
            p = urlsplit(value)
            if p.scheme != "https" or not p.hostname or p.username or p.query or p.fragment:
                raise ValueError("Explicit HTTPS origin/issuer required")
        if urlsplit(self.origin).path or self.origin.endswith("/"):
            raise ValueError("Origin must contain only scheme and authority")
        if len(self.encryption_key) != 32 or len(self.lookup_key) != 32:
            raise ValueError("Separate 256-bit encryption and lookup keys required")
        if self.encryption_key == self.lookup_key:
            raise ValueError("Purpose-separated keys required")
        if any(domain not in {"BPI", "FINCOIN"} or len(key) < 32 for domain, key in self.internal_keys.items()):
            raise ValueError("Internal domain credentials require at least 32 characters")
        if len(set(self.internal_keys.values())) != len(self.internal_keys):
            raise ValueError("Each domain requires a separate internal credential")
        if not 30 <= self.access_seconds <= 300 or not 300 <= self.idle_seconds <= self.session_seconds <= 86400:
            raise ValueError("Invalid token lifetime policy")

    @classmethod
    def from_env(cls):
        return cls(
            database_url=os.environ["IDENTITY_DATABASE_URL"],
            private_key=Path(os.environ["IDENTITY_SIGNING_KEY_FILE"]).read_bytes(),
            encryption_key=base64.b64decode(Path(os.environ["IDENTITY_ENCRYPTION_KEY_FILE"]).read_text().strip(), validate=True),
            lookup_key=base64.b64decode(Path(os.environ["IDENTITY_LOOKUP_KEY_FILE"]).read_text().strip(), validate=True),
            origin=os.environ["IDENTITY_ORIGIN"], issuer=os.environ["IDENTITY_ISSUER"],
            key_id=os.environ.get("IDENTITY_KEY_ID", "identity-sandbox-1"),
            internal_keys={domain: Path(os.environ[f"IDENTITY_{domain}_SERVICE_KEY_FILE"]).read_text().strip() for domain in ("BPI", "FINCOIN") if f"IDENTITY_{domain}_SERVICE_KEY_FILE" in os.environ},
        )
