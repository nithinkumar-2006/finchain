import base64
import hashlib
import hmac
import json
import secrets
import struct
import time
import uuid
import jwt
from argon2 import PasswordHasher
from argon2.exceptions import VerificationError, InvalidHashError
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM


def token():
    return secrets.token_urlsafe(32)


def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()


class Crypto:
    def __init__(self, settings):
        self.settings = settings
        self.passwords = PasswordHasher(time_cost=3, memory_cost=65536, parallelism=1)
        self.dummy = self.passwords.hash(token())
        self.private_key = serialization.load_pem_private_key(settings.private_key, password=None)
        if not isinstance(self.private_key, rsa.RSAPrivateKey) or self.private_key.key_size < 3072:
            raise ValueError("JWT signing requires RSA >=3072 bits")
        self.public_key = self.private_key.public_key()

    def lookup(self, purpose, value):
        return hmac.new(self.settings.lookup_key, (purpose + "\0" + value).encode(), hashlib.sha256).hexdigest()

    def encrypt(self, context, value):
        nonce = secrets.token_bytes(12)
        return b"\x01" + nonce + AESGCM(self.settings.encryption_key).encrypt(nonce, value.encode(), context.encode())

    def decrypt(self, context, value):
        if value[:1] != b"\x01":
            raise ValueError("Unknown encryption version")
        return AESGCM(self.settings.encryption_key).decrypt(value[1:13], value[13:], context.encode()).decode()

    def verify_password(self, encoded, password):
        try:
            return self.passwords.verify(encoded, password)
        except (VerificationError, InvalidHashError):
            return False

    def issue(self, user, session):
        ts = int(time.time())
        return jwt.encode({"iss": self.settings.issuer, "aud": "finchain:identity:sandbox", "sub": str(user.id),
                           "sid": str(session.id), "jti": str(uuid.uuid4()), "iat": ts, "nbf": ts, "exp": ts + self.settings.access_seconds,
                           "auth_time": int(session.authenticated_at.timestamp()), "amr": session.assurance_level,
                           "cv": user.credentials_version, "scope": "identity:self"},
                          self.private_key, algorithm="RS256", headers={"kid": self.settings.key_id, "typ": "at+jwt"})

    def decode(self, encoded):
        head = jwt.get_unverified_header(encoded)
        if head.get("kid") != self.settings.key_id or head.get("typ") != "at+jwt" or set(head) - {"kid", "typ", "alg"}:
            raise jwt.InvalidTokenError("Untrusted header")
        claims = jwt.decode(encoded, self.public_key, algorithms=["RS256"], audience="finchain:identity:sandbox", issuer=self.settings.issuer,
                            options={"require": ["iss", "aud", "sub", "sid", "jti", "iat", "nbf", "exp", "auth_time", "amr", "cv", "scope"], "strict_aud": True})
        for name in ("sub", "sid", "jti"):
            uuid.UUID(claims[name])
        if any(type(claims[name]) is not int for name in ("iat", "nbf", "exp", "auth_time", "cv")):
            raise jwt.InvalidTokenError("Integer claims required")
        if not 0 < claims["exp"] - claims["iat"] <= 300 or claims["auth_time"] > claims["iat"] or claims["nbf"] > claims["iat"] or claims["cv"] < 1 or claims["scope"] != "identity:self" or claims["amr"] not in {"PASSWORD", "MFA"}:
            raise jwt.InvalidTokenError("Invalid claims")
        return claims


def totp_code(secret, counter):
    raw = hmac.new(base64.b32decode(secret), struct.pack(">Q", counter), hashlib.sha1).digest()
    offset = raw[-1] & 15
    return f"{(struct.unpack('>I', raw[offset:offset+4])[0] & 0x7fffffff) % 1000000:06d}"


def match_totp(secret, code, last_counter, timestamp):
    counter = int(timestamp) // 30
    for candidate in (counter, counter - 1, counter + 1):
        if candidate > last_counter and hmac.compare_digest(totp_code(secret, candidate), code):
            return candidate
    return None


def audit_hash(event):
    return hashlib.sha256(json.dumps(event, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
