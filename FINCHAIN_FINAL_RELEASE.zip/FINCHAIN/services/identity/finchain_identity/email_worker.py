"""Local sandbox inbox delivery only; no real email transport."""
import json
import os
import smtplib
import time
from email.message import EmailMessage
from sqlalchemy import select
from .config import Settings
from .models import EmailOutbox
from .service import Identity


def deliver_one(identity, smtp_host="mailpit", smtp_port=1025):
    # Explicit allowlist keeps this demonstration from accidentally sending real mail.
    if smtp_host not in {"mailpit", "127.0.0.1", "localhost"}:
        raise ValueError("Sandbox mail sink required")
    with identity.transaction() as db:
        row = db.scalar(select(EmailOutbox).where(EmailOutbox.state == "SANDBOX_QUEUED").order_by(EmailOutbox.created_at).with_for_update(skip_locked=True).limit(1))
        if row is None:
            return False
        payload = json.loads(identity.crypto.decrypt(f"email_outbox:{row.id}:payload", row.payload_ciphertext))
        route = "/verify-email" if payload["purpose"] == "VERIFY_EMAIL" else "/reset-password"
        message = EmailMessage()
        message["From"] = "FINCHAIN Sandbox <sandbox@finchain.invalid>"
        message["To"] = payload["recipient"]
        message["Subject"] = "FINCHAIN sandbox: " + ("verify your email" if route == "/verify-email" else "reset your password")
        message["Message-ID"] = f"<{row.id}@finchain.invalid>"
        message.set_content("This message is captured in a local test inbox. No real email was sent.\n\nOpen the one-time link:\n" + identity.settings.origin + route + "#" + payload["token"] + "\n\nIf you did not request this, ignore it.\n")
        with smtplib.SMTP(smtp_host, smtp_port, timeout=5) as smtp:
            smtp.send_message(message)
        row.state = "SANDBOX_DELIVERED"
        identity.audit(db, "email.sandbox_delivery", "ACCEPTED", actor=row.user_id)
        return True


def main():
    if os.environ.get("FINCHAIN_MODE") != "sandbox":
        raise ValueError("Sandbox delivery only")
    identity = Identity(Settings.from_env())
    while True:
        try:
            deliver_one(identity, os.environ.get("SANDBOX_SMTP_HOST", "mailpit"), int(os.environ.get("SANDBOX_SMTP_PORT", "1025")))
        except Exception:
            # Do not emit exception text, message bodies, tokens or recipients.
            print("sandbox_email_delivery_retry", flush=True)
        time.sleep(2)


if __name__ == "__main__":
    main()
