"""FINCHAIN sandbox identity. No wallet keys or financial authority."""
