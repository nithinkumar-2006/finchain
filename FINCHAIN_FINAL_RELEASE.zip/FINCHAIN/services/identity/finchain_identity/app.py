import secrets
import uuid
from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, Response
from starlette.middleware.cors import CORSMiddleware
from starlette.middleware.trustedhost import TrustedHostMiddleware
from sqlalchemy.exc import SQLAlchemyError
from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator
from urllib.parse import urlsplit
from .config import Settings
from .crypto import token
from .service import Identity, Denied

PREFIX = "/v1/identity"
COOKIE = "__Host-finchain-session"
CSRF = "__Host-finchain-csrf"


class StrictBody(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True, hide_input_in_errors=True)


class EmailBody(StrictBody):
    email: EmailStr = Field(max_length=254)

    @field_validator("email")
    @classmethod
    def normalize(cls, value):
        # Product policy: case-insensitive accounts, no provider dot/plus rewriting.
        return str(value).casefold()


class Registration(EmailBody):
    password: str = Field(min_length=15, max_length=128, repr=False)


class Login(EmailBody):
    password: str = Field(min_length=1, max_length=128, repr=False)
    totp_code: str | None = Field(default=None, pattern=r"^[0-9]{6}$", repr=False)


class ChallengeBody(StrictBody):
    token: str = Field(min_length=43, max_length=43, pattern=r"^[A-Za-z0-9_-]+$", repr=False)


class Reset(ChallengeBody):
    password: str = Field(min_length=15, max_length=128, repr=False)


class PasswordBody(StrictBody):
    password: str = Field(min_length=1, max_length=128, repr=False)


class OTPBody(StrictBody):
    code: str = Field(pattern=r"^[0-9]{6}$", repr=False)


class InternalValidation(StrictBody):
    browser_cookie: str | None = Field(default=None, max_length=43, repr=False)
    csrf_token: str | None = Field(default=None, max_length=43, repr=False)
    mutation: bool = False
    subject_id: str | None = None
    session_id: str | None = None
    credentials_version: int | None = None


def error(code, status):
    return JSONResponse({"type": "about:blank", "title": "Request could not be completed", "status": status,
                         "code": code, "request_id": str(uuid.uuid4())}, status_code=status, media_type="application/problem+json",
                        headers={"Retry-After": "60"} if status == 429 else None)


def cookie(response, name, value, max_age, http_only=True):
    response.set_cookie(name, value, secure=True, httponly=http_only, samesite="lax", path="/", max_age=max_age)


def clear_session(response):
    response.delete_cookie(COOKIE, path="/", secure=True, httponly=True, samesite="lax")


def create_app(settings=None):
    settings = settings or Settings.from_env()
    identity = Identity(settings)
    app = FastAPI(title="FINCHAIN Sandbox Identity", docs_url=None, redoc_url=None, openapi_url=None)
    app.state.identity = identity
    app.add_middleware(CORSMiddleware, allow_origins=[settings.origin], allow_credentials=True,
                       allow_methods=["GET", "POST", "DELETE"], allow_headers=["Content-Type", "X-CSRF-Token"])
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=[urlsplit(settings.origin).hostname])

    @app.middleware("http")
    async def boundary(request: Request, call_next):
        response = None
        if request.url.path.startswith("/internal/"):
            domain = request.headers.get("x-service-domain", "")
            expected = settings.internal_keys.get(domain, "")
            if not expected or not secrets.compare_digest(request.headers.get("x-service-key", ""), expected):
                response = error("FORBIDDEN", 403)
        elif request.method in {"POST", "PUT", "PATCH", "DELETE"}:
            supplied, stored = request.headers.get("x-csrf-token", ""), request.cookies.get(CSRF, "")
            if request.headers.get("origin") != settings.origin or not supplied or len(supplied) != 43 or not secrets.compare_digest(supplied, stored):
                response = error("CSRF_FAILED", 403)
            elif request.method == "POST" and request.headers.get("content-type", "").split(";")[0] != "application/json":
                response = error("JSON_REQUIRED", 415)
        if response is None:
            body = bytearray()
            async for chunk in request.stream():
                body.extend(chunk)
                if len(body) > 8192:
                    response = error("REQUEST_TOO_LARGE", 413)
                    break
            if response is None:
                request._body = bytes(body)
                response = await call_next(request)
        response.headers.update({"Cache-Control": "no-store", "Pragma": "no-cache", "X-Content-Type-Options": "nosniff",
                                 "Content-Security-Policy": "default-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'",
                                 "X-Frame-Options": "DENY", "Referrer-Policy": "no-referrer", "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
                                 "Strict-Transport-Security": "max-age=31536000"})
        return response

    @app.exception_handler(Denied)
    async def denied(_, exc):
        return error(exc.code, exc.status)

    @app.exception_handler(RequestValidationError)
    async def validation(_, exc):
        # Pydantic errors can contain submitted secrets: never echo errors/body.
        return error("INVALID_INPUT", 422)

    @app.exception_handler(SQLAlchemyError)
    async def unavailable(_, exc):
        return error("IDENTITY_UNAVAILABLE", 503)

    def limited(request, route):
        # X-Forwarded-For is intentionally ignored. Configure one trusted proxy at deployment.
        identity.rate(request.client.host if request.client else "unknown", route)

    def browser(request):
        value = request.cookies.get(COOKIE, "")
        if len(value) != 43:
            raise Denied("INVALID_SESSION")
        return value

    def csrf(request):
        return request.headers.get("x-csrf-token", "")

    @app.get("/health/live")
    def live():
        return {"status": "alive", "environment": "sandbox"}

    @app.post("/internal/v1/validate")
    def internal_validate(body: InternalValidation):
        from .models import User, LoginSession, now
        from datetime import timedelta
        with identity.transaction() as db:
            if body.browser_cookie:
                user, session, _ = identity.authenticate(db, body.browser_cookie, (body.csrf_token or "") if body.mutation else None)
            else:
                try:
                    user_id = uuid.UUID(body.subject_id or "")
                    session_id = uuid.UUID(body.session_id) if body.session_id else None
                except ValueError:
                    raise Denied("INVALID_PRINCIPAL") from None
                user = identity.lock_user(db, user_id)
                if not user or user.status != "ACTIVE" or not user.email_verified_at:
                    raise Denied("INVALID_PRINCIPAL")
                session = db.get(LoginSession, session_id) if session_id else None
                if session_id and (not session or session.user_id != user.id or session.revoked_at or session.expires_at <= now() or session.last_seen_at+timedelta(seconds=settings.idle_seconds) <= now() or session.credentials_version != user.credentials_version or body.credentials_version != user.credentials_version):
                    raise Denied("INVALID_SESSION")
            return {"id": str(user.id), "credentials_version": user.credentials_version, "session_id": str(session.id) if session else None,
                    "assurance": session.assurance_level if session else "NONE", "auth_time": int(session.authenticated_at.timestamp()) if session else 0}

    @app.get(PREFIX + "/csrf")
    def csrf_bootstrap(request: Request):
        limited(request, "csrf")
        # Reuse existing value so another tab cannot invalidate an active session binding.
        value = request.cookies.get(CSRF)
        if value is None or len(value) != 43:
            value = token()
        response = JSONResponse({"csrf_token": value})
        cookie(response, CSRF, value, settings.session_seconds, http_only=False)
        return response

    @app.post(PREFIX + "/registrations", status_code=202)
    def register(body: Registration, request: Request):
        limited(request, "register")
        identity.register(body.email, body.password)
        return {"status": "accepted", "delivery": "sandbox_queue"}

    @app.post(PREFIX + "/sessions")
    def login(body: Login, request: Request):
        limited(request, "login")
        fingerprint = (request.client.host if request.client else "unknown") + "|" + request.headers.get("user-agent", "")[:512]
        session_cookie, csrf_value = identity.login(body.email, body.password, body.totp_code, fingerprint)
        response = JSONResponse({"status": "authenticated", "csrf_token": csrf_value})
        cookie(response, COOKIE, session_cookie, settings.session_seconds)
        cookie(response, CSRF, csrf_value, settings.session_seconds, http_only=False)
        return response

    @app.post(PREFIX + "/sessions/refresh", status_code=204)
    def refresh(request: Request):
        limited(request, "refresh")
        identity.refresh(browser(request), csrf(request))
        return Response(status_code=204)

    @app.post(PREFIX + "/logout", status_code=204)
    def logout(request: Request):
        limited(request, "logout")
        identity.logout(browser(request), csrf(request))
        response = Response(status_code=204)
        clear_session(response)
        return response

    @app.delete(PREFIX + "/sessions/{session_id}", status_code=204)
    def revoke(session_id: uuid.UUID, request: Request):
        limited(request, "revoke")
        identity.logout(browser(request), csrf(request), session_id)
        return Response(status_code=204)

    @app.get(PREFIX + "/sessions")
    def sessions(request: Request):
        limited(request, "sessions")
        return {"items": identity.list_sessions(browser(request))}

    @app.get(PREFIX + "/me")
    def me(request: Request):
        limited(request, "me")
        return identity.me(browser(request))

    @app.post(PREFIX + "/forgot-password", status_code=202)
    @app.post(PREFIX + "/recovery", status_code=202)
    def forgot(body: EmailBody, request: Request):
        limited(request, "recovery")
        identity.request_challenge(body.email, "RESET_PASSWORD")
        return {"status": "accepted", "delivery": "sandbox_queue"}

    @app.post(PREFIX + "/reset-password", status_code=204)
    def reset(body: Reset, request: Request):
        limited(request, "challenge")
        identity.consume_challenge(body.token, "RESET_PASSWORD", body.password)
        return Response(status_code=204)

    @app.post(PREFIX + "/email-verification/requests", status_code=202)
    def email_request(body: EmailBody, request: Request):
        limited(request, "recovery")
        identity.request_challenge(body.email, "VERIFY_EMAIL")
        return {"status": "accepted", "delivery": "sandbox_queue"}

    @app.post(PREFIX + "/email-verification/confirm", status_code=204)
    def verify(body: ChallengeBody, request: Request):
        limited(request, "challenge")
        identity.consume_challenge(body.token, "VERIFY_EMAIL")
        return Response(status_code=204)

    @app.post(PREFIX + "/mfa/enrollments")
    def enroll(body: PasswordBody, request: Request):
        limited(request, "mfa")
        identity.rate(browser(request), "mfa-account")
        return identity.enroll_mfa(browser(request), csrf(request), body.password)

    @app.post(PREFIX + "/mfa/verifications", status_code=204)
    def confirm(body: OTPBody, request: Request):
        limited(request, "mfa")
        identity.rate(browser(request), "mfa-account")
        identity.confirm_mfa(browser(request), csrf(request), body.code)
        response = Response(status_code=204)
        clear_session(response)
        return response

    @app.get(PREFIX + "/audit-logs")
    def audit_logs(request: Request):
        limited(request, "audit-read")
        return {"items": identity.audit_view(browser(request))}

    return app
