"""Offline role provisioning. Run only with separately controlled operator DB credentials."""
import argparse
import uuid
from .config import Settings
from .service import Identity


def main():
    parser = argparse.ArgumentParser(description="Grant one audited identity role; no financial scope")
    parser.add_argument("--user-id", type=uuid.UUID, required=True)
    parser.add_argument("--operator-id", type=uuid.UUID, required=True)
    parser.add_argument("--role", choices=["consumer", "merchant", "admin", "compliance", "support"], required=True)
    args = parser.parse_args()
    Identity(Settings.from_env()).provision_role(args.user_id, args.role, args.operator_id)
    print("Role grant committed; existing user sessions revoked.")


if __name__ == "__main__":
    main()
