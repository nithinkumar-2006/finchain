BEGIN;

CREATE TABLE alembic_version (
    version_num VARCHAR(32) NOT NULL, 
    CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num)
);

-- Running upgrade  -> 0001_identity

CREATE SCHEMA auth;

CREATE TABLE auth.users (
    email_ciphertext BYTEA NOT NULL, 
    email_lookup_digest VARCHAR(64) NOT NULL, 
    lookup_key_version INTEGER NOT NULL, 
    status VARCHAR(16) NOT NULL, 
    email_verified_at TIMESTAMP WITH TIME ZONE, 
    credentials_version INTEGER NOT NULL, 
    failures INTEGER NOT NULL, 
    locked_until TIMESTAMP WITH TIME ZONE, 
    last_authenticated_at TIMESTAMP WITH TIME ZONE, 
    last_login_digest VARCHAR(64), 
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    deleted_at TIMESTAMP WITH TIME ZONE, 
    id UUID NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    CONSTRAINT user_status CHECK (status IN ('ACTIVE','DISABLED','DELETED')), 
    CONSTRAINT user_counters CHECK (credentials_version > 0 AND failures >= 0), 
    UNIQUE (email_lookup_digest)
);

CREATE TABLE auth.rate_buckets (
    bucket_key VARCHAR(64) NOT NULL, 
    "window" INTEGER NOT NULL, 
    hits INTEGER NOT NULL, 
    id UUID NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    UNIQUE (bucket_key)
);

CREATE TABLE auth.audit_streams (
    name VARCHAR(16) NOT NULL, 
    sequence INTEGER NOT NULL, 
    head VARCHAR(64) NOT NULL, 
    id UUID NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    UNIQUE (name)
);

CREATE TABLE auth.password_credentials (
    user_id UUID NOT NULL, 
    password_hash VARCHAR(512) NOT NULL, 
    changed_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    id UUID NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    UNIQUE (user_id), 
    FOREIGN KEY(user_id) REFERENCES auth.users (id)
);

CREATE TABLE auth.role_grants (
    user_id UUID NOT NULL, 
    role VARCHAR(16) NOT NULL, 
    id UUID NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    UNIQUE (user_id, role), 
    CONSTRAINT role_allowlist CHECK (role IN ('consumer','merchant','admin','compliance','support')), 
    FOREIGN KEY(user_id) REFERENCES auth.users (id)
);

CREATE INDEX ix_auth_role_grants_user_id ON auth.role_grants (user_id);

CREATE TABLE auth.sessions (
    user_id UUID NOT NULL, 
    authenticated_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    last_seen_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    revoked_at TIMESTAMP WITH TIME ZONE, 
    revocation_reason VARCHAR(32), 
    assurance_level VARCHAR(8) NOT NULL, 
    credentials_version INTEGER NOT NULL, 
    id UUID NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    CONSTRAINT session_expiry CHECK (expires_at > authenticated_at), 
    CONSTRAINT session_assurance CHECK (assurance_level IN ('PASSWORD','MFA')), 
    FOREIGN KEY(user_id) REFERENCES auth.users (id)
);

CREATE INDEX ix_auth_sessions_user_id ON auth.sessions (user_id);

CREATE TABLE auth.identity_challenges (
    user_id UUID NOT NULL, 
    purpose VARCHAR(16) NOT NULL, 
    token_digest VARCHAR(64) NOT NULL, 
    credentials_version INTEGER NOT NULL, 
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    used_at TIMESTAMP WITH TIME ZONE, 
    id UUID NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    CONSTRAINT challenge_purpose CHECK (purpose IN ('VERIFY_EMAIL','RESET_PASSWORD')), 
    FOREIGN KEY(user_id) REFERENCES auth.users (id), 
    UNIQUE (token_digest)
);

CREATE INDEX ix_auth_identity_challenges_user_id ON auth.identity_challenges (user_id);

CREATE TABLE auth.mfa_factors (
    user_id UUID NOT NULL, 
    factor_type VARCHAR(8) NOT NULL, 
    totp_secret_ciphertext BYTEA NOT NULL, 
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    verified_at TIMESTAMP WITH TIME ZONE, 
    last_counter INTEGER NOT NULL, 
    id UUID NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    CONSTRAINT mfa_type CHECK (factor_type = 'TOTP'), 
    UNIQUE (user_id), 
    FOREIGN KEY(user_id) REFERENCES auth.users (id)
);

CREATE TABLE auth.audit_logs (
    sequence INTEGER NOT NULL, 
    actor_user_id UUID, 
    operator_id UUID, 
    action VARCHAR(40) NOT NULL, 
    result VARCHAR(32) NOT NULL, 
    correlation_id UUID NOT NULL, 
    previous_hash VARCHAR(64) NOT NULL, 
    event_hash VARCHAR(64) NOT NULL, 
    id UUID NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    UNIQUE (sequence), 
    FOREIGN KEY(actor_user_id) REFERENCES auth.users (id)
);

CREATE INDEX audit_actor_time ON auth.audit_logs (actor_user_id, created_at);

CREATE TABLE auth.refresh_tokens (
    session_id UUID NOT NULL, 
    parent_token_id UUID, 
    token_digest VARCHAR(64) NOT NULL, 
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    used_at TIMESTAMP WITH TIME ZONE, 
    id UUID NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    UNIQUE (id, session_id), 
    FOREIGN KEY(session_id) REFERENCES auth.sessions (id), 
    UNIQUE (parent_token_id), 
    UNIQUE (token_digest), 
    FOREIGN KEY(parent_token_id, session_id) REFERENCES auth.refresh_tokens (id, session_id)
);

CREATE INDEX ix_auth_refresh_tokens_session_id ON auth.refresh_tokens (session_id);

CREATE UNIQUE INDEX one_refresh_root ON auth.refresh_tokens (session_id) WHERE parent_token_id IS NULL;

CREATE TABLE auth.web_sessions (
    session_id UUID NOT NULL, 
    browser_cookie_digest VARCHAR(64) NOT NULL, 
    csrf_digest VARCHAR(64) NOT NULL, 
    refresh_token_ciphertext BYTEA NOT NULL, 
    access_token_ciphertext BYTEA NOT NULL, 
    id UUID NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    UNIQUE (session_id), 
    FOREIGN KEY(session_id) REFERENCES auth.sessions (id), 
    UNIQUE (browser_cookie_digest)
);

CREATE TABLE auth.email_outbox (
    user_id UUID NOT NULL, 
    challenge_id UUID NOT NULL, 
    payload_ciphertext BYTEA NOT NULL, 
    state VARCHAR(16) NOT NULL, 
    id UUID NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(user_id) REFERENCES auth.users (id), 
    UNIQUE (challenge_id), 
    FOREIGN KEY(challenge_id) REFERENCES auth.identity_challenges (id)
);

CREATE INDEX ix_auth_email_outbox_user_id ON auth.email_outbox (user_id);

INSERT INTO auth.audit_streams (name, sequence, head, id, created_at) VALUES ('identity', 0, '0000000000000000000000000000000000000000000000000000000000000000', '00000000-0000-4000-8000-000000000001', '2026-09-14 10:05:52.428257+00:00');

CREATE FUNCTION auth.reject_audit_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
    BEGIN RAISE EXCEPTION 'Audit events are append-only'; END $$;

CREATE TRIGGER audit_append_only BEFORE UPDATE OR DELETE ON auth.audit_logs FOR EACH ROW EXECUTE FUNCTION auth.reject_audit_mutation();

INSERT INTO alembic_version (version_num) VALUES ('0001_identity') RETURNING alembic_version.version_num;

COMMIT;

