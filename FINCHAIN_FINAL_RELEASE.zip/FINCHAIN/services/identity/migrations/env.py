import os
from alembic import context
from sqlalchemy import create_engine, pool
from finchain_identity.models import Base

url = os.environ["IDENTITY_DATABASE_URL"]
if not url.startswith("postgresql+psycopg://"):
    raise RuntimeError("Migrations require a dedicated PostgreSQL identity database")
if context.is_offline_mode():
    context.configure(url=url, target_metadata=Base.metadata, literal_binds=True, include_schemas=True)
    with context.begin_transaction():
        context.run_migrations()
else:
    engine = create_engine(url, poolclass=pool.NullPool, hide_parameters=True)
    with engine.connect() as connection:
        context.configure(connection=connection, target_metadata=Base.metadata, include_schemas=True)
        with context.begin_transaction():
            context.run_migrations()
