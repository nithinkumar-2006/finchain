"""Identity foundation; frozen schema snapshot, no dependency on future live models."""
import importlib.util
from pathlib import Path
from uuid import UUID
from alembic import op

revision = "0001_identity"
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    op.execute("CREATE SCHEMA auth")
    snapshot_path = Path(__file__).parents[1] / "schema_v0001.py"
    spec = importlib.util.spec_from_file_location("identity_schema_v0001", snapshot_path)
    snapshot = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(snapshot)
    snapshot.Base.metadata.create_all(op.get_bind(), checkfirst=False)
    op.bulk_insert(snapshot.AuditStream.__table__, [{"id": UUID("00000000-0000-4000-8000-000000000001"), "name": "identity", "sequence": 0, "head": "0" * 64, "created_at": snapshot.now()}])
    op.execute("""CREATE FUNCTION auth.reject_audit_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
    BEGIN RAISE EXCEPTION 'Audit events are append-only'; END $$""")
    op.execute("CREATE TRIGGER audit_append_only BEFORE UPDATE OR DELETE ON auth.audit_logs FOR EACH ROW EXECUTE FUNCTION auth.reject_audit_mutation()")


def downgrade():
    raise RuntimeError("Destructive identity downgrade disabled; restore an isolated backup or forward-fix")
