# Implemented architecture

The Roles 1–3 documents remain the design baseline. This implementation uses a modular Python service package instantiated with one financial domain and one database per process. Sharing source primitives does not share balances, grants, signing masters or chain heads.

```mermaid
flowchart LR
  Browser --> Edge[Nginx HTTPS]
  Edge --> Web[Next.js]
  Edge --> Identity[Identity API]
  Edge --> BPI[BPI API]
  Edge --> FNC[FINCOIN API]
  BPI --> BDB[(BPI PostgreSQL)]
  FNC --> FDB[(FINCOIN PostgreSQL)]
  BW[BPI worker] --> BDB
  FW[FINCOIN worker] --> FDB
  BW --> BS[Private BPI signer]
  FW --> FS[Private FINCOIN signer]
  BW --> Gateway[Sandbox gateway]
  BDB --> BP[Proof projector]
  FDB --> FP[Proof projector]
  BP --> Public[(Public projections)]
  FP --> Public
  Edge --> Explorer
  Explorer --> Public
```

Identity keeps private account information and validates opaque browser sessions through a per-domain authenticated internal endpoint. Financial databases store pseudonymous subject IDs, wallet ownership and financial records. APIs enqueue intent; restricted worker accounts post journals and chain events. PostgreSQL serializable transactions, a head lock, advisory leadership lock and writer epoch control posting.

Design refinements: reservation and inclusion happen in one atomic worker transaction; QR URLs are high-entropy opaque server-resolved references, not self-authenticating signed documents; the public chain is a readable proof projection of a centrally sequenced sandbox, not a permissionless consensus network. Unknown settlement never becomes spendable value. Fixed FINCOIN issuance has no normal admin mint control.
