# FINCHAIN — Design System

Role 2 · Version 1.0 · Dark-mode-first visual baseline. Companion: [component contracts](COMPONENT_LIBRARY.md).

## 1. Visual direction

Use deep navy surfaces, warm-white typography, subtle borders, generous whitespace and two restrained product accents. The application should resemble a professional payment workspace, with charts subordinate to decisions. Avoid neon glow, glass behind forms, coin imagery, gradients behind small text, animated earnings and decorative background motion in authenticated screens.

## 2. Color tokens

| Token | Hex | Usage |
|---|---|---|
| `canvas` | `#0B1018` | Main background, button text on bright fills |
| `surface` | `#121B27` | Cards, sidebar |
| `surface-raised` | `#182332` | Menus, dialogs, selected neutral panels |
| `text-primary` | `#F2F5FA` | Headings and values |
| `text-secondary` | `#B6C2D2` | Body/supporting text |
| `text-muted` | `#95A6BC` | Captions and metadata, not opacity-faded |
| `border-subtle` | `#2A394B` | Decorative separators only |
| `border-control` | `#6B809A` | Input/control boundaries that convey affordance |
| `accent-bpi` | `#69DDC3` | BPI action fill, product marker, selected navigation |
| `accent-fincoin` | `#B6AAFF` | FINCOIN action fill and product marker |
| `status-success` | `#75D7A2` | Completed outcomes, with label/icon |
| `status-warning` | `#F4C778` | Review, pending attention, stale data |
| `status-danger` | `#FF9B9B` | Denial, errors, destructive actions |
| `status-info` | `#8FBEFF` | Progress and neutral notices |

Calculated opaque sRGB contrast against the lightest normal dark surface `#182332`: primary text 14.50:1; secondary 8.78:1; muted 6.38:1; control border 3.91:1; BPI 9.61:1; FINCOIN 7.68:1; success 9.05:1; warning 10.03:1; danger 7.86:1; info 8.28:1. Canvas text on BPI fill is 11.56:1; on FINCOIN fill 9.24:1. These are token-pair calculations, not a rendered-application audit. Subtle border is never the sole outline of an input, focus state or selected control.

Badges use semantic text on solid raised surface with semantic icon; do not lower text opacity to create tint. Selected navigation uses product accent text plus a leading 3 px indicator and `current page` semantics. Success uses a check icon; positive P&L also includes `+`, negative includes `−`. Color never alone communicates a domain, risk level or state.

Dark is the authored v1 theme. Settings can expose “Dark” as current theme; do not present a working Light toggle until a separately validated palette exists. Forced-colors/high-contrast user modes must remain usable. Print receipts use black text on white with all sandbox and status labels retained.

## 3. Typography

Primary family: system sans-serif stack, resolving to Segoe UI on Windows and the native system sans elsewhere. This avoids an external font dependency in the baseline. A later Inter brand font can replace it after licensing, loading and layout review. Mono: system monospace for addresses/hashes only. Use tabular numerals for amounts, metric comparisons and table values.

| Style | Desktop size / line height | Mobile size / line height | Weight / use |
|---|---|---|---|
| Display | 56 / 64 px | 36 / 44 px | 650–700; public hero only |
| H1 | 32 / 40 | 28 / 36 | 600–700; screen heading |
| H2 | 24 / 32 | 22 / 30 | 600; section heading |
| H3 | 18 / 26 | 18 / 26 | 600; card heading |
| Balance | 40 / 48 | 32 / 40 | 600; primary available value |
| Metric | 28 / 36 | 24 / 32 | 600; supporting metric |
| Body | 16 / 24 | 16 / 24 | 400; readable prose/forms |
| Compact | 14 / 20 | 14 / 20 | 400–500; tables/metadata |
| Caption | 12 / 18 | 12 / 18 | 500; noncritical timestamp/labels |

No critical disclosure, fee, error or action instruction below 14 px. Keep explanatory prose under roughly 70 characters per line. Do not uppercase whole paragraphs; uppercase is reserved for short domain/risk labels. Headings follow semantic order regardless of visual size. Use `FNC` and `SIM_INR` consistently, and INR formatting with two decimal places on review/receipts.

## 4. Spacing, grid and surfaces

Spacing scale: 4, 8, 12, 16, 24, 32, 40, 48, 64, 80, 96 px. Base dashboard gap 24 px, compact internal gap 12–16 px, section gap 32–40 px. Public section padding 80 px desktop / 48 px mobile.

Desktop shell: 240 px sidebar, 64 px header, 32 px horizontal main inset; max dashboard content width 1,440 px. Public content max 1,200 px with 32 px gutters. 12-column desktop grid with 24 px gaps; tablet 8 columns/20 px gaps; mobile 4 columns/16 px gaps and 16 px edge inset. Detailed breakpoints are in RESPONSIVE_SPEC.

Cards: 16 px radius, 24 px desktop/16 px mobile padding, solid surface, 1 px decorative border. Dense tables use 12 px container radius; controls 10 px; status badges 6 px. No border radius should imply an interactive card if only an inner action is clickable. Shadows only for raised overlays: soft black with clear border, never the sole boundary. No glowing financial totals.

## 5. Buttons, links and form inputs

Button sizes: large 48 px height; standard 44 px; compact visible 36 px with at least 44 px interactive area. Primary fill uses current domain accent and canvas text. Secondary uses raised surface/control border, tertiary is text with visible hover/focus treatment, destructive uses explicit verb and danger treatment. Only one main filled action per local decision group. Loading retains button width, changes label to an accurate verb and announces busy state.

Inputs: 48 px high, 16 px input text, visible 14 px label above, optional 14 px helper below, solid surface and control border. Placeholders are examples, never labels. Error adds icon, text and danger boundary while preserving value. Required fields are stated before the form; optional fields labeled. Amount field displays a persistent currency/asset suffix outside the editable value; use decimal keyboard without blocking paste or assistive input. Reject excess precision with a specific explanation, not silent rounding.

Focus: 2 px info-colored ring with 2 px dark offset around interactive elements, visible on all supported surfaces. Keep active focus clear of sticky bars. Hover must not change layout. Disabled controls expose a nearby explanation and retain readable labels; do not make an entire form faint. Read-only payment type/currency use a value field, not a disabled dropdown with nonexistent choices.

Form review is a page or full-screen mobile step, not a tiny confirmation toast. Error summary at top links to invalid fields after submission; inline errors appear on blur/submit, not while the user has typed only one character. Password fields allow reveal, paste and password-manager autofill.

## 6. Tables, navigation and badges

Tables have a 48 px header and 56 px normal rows; 48 px dense admin rows with adequate targets. Right-align amounts, left-align names/references, keep status widths stable. Sorting buttons name the field and current order. Row navigation is an explicit link; row hover may assist but does not replace keyboard links. No nested row click that steals Copy or Refund clicks. Row selection exists only for real batch actions with a visible selection count.

Badge families are separate: Domain, Environment, BusinessStatus, ChainStatus, SettlementStatus, RiskSeverity and Availability. Do not reuse a green “Confirmed” badge to mean settled, authenticated, safe and executed. Canonical labels are defined by domain specs. Risk is always text plus icon; severity is distinct from permission to continue.

Sidebar items are 44 px minimum height with 20 px line icons. Active page has text, marker and accessible current-page state. Tooltips are supplementary in compact navigation. Mobile uses text labels below bottom-bar icons and a labeled More menu. Breadcrumb truncation never hides the selected organization/domain.

## 7. Charts

Use restrained lines, light gridlines, visible axis units, proper legends and consistent time ranges. Price charts do not start arbitrarily at zero if that conceals variation, but the visible range must be clear; bar charts use a zero baseline. Missing data produces gaps, not interpolation masquerading as observed values. Do not smooth through unobserved trades or fabricate uptrends.

BPI charts use the BPI accent for settled activity, neutral/hatched pending series if shown. FINCOIN price uses violet, P&L uses sign plus labeled series; negative periods must be as legible as gains. Tooltips support keyboard/focus and touch, show exact value/time/source, and are not the only way to read the dataset. Every chart has a text summary and an accessible table/download of the same authorized data. Synthetic prices and simulator-only volume are stated next to charts.

## 8. Overlays, feedback, motion and icons

Use modal dialogs for bounded confirmation, drawers for filters/details that do not contain a primary financial review, and full pages for payment/trade authorization. Desktop dialog width 480–640 px; mobile full-height sheet/page when content requires scrolling. Dialogs have a visible title, close action, contained keyboard focus and focus restoration, following the [WAI modal dialog pattern](https://www.w3.org/WAI/ARIA/apg/patterns/dialog-modal/). Closing a submitted-operation overlay does not cancel its command.

Tabs group peer data views; keyboard arrows navigate tabs and panels are properly associated, following the [WAI tabs pattern](https://www.w3.org/WAI/ARIA/apg/patterns/tabs/). Do not use tabs to conceal mandatory fee or settlement information. Toasts are for low-risk feedback such as Copied; financial outcomes remain in page content. Errors requiring action stay until resolved/dismissed appropriately.

Motion duration 120–180 ms for hover/menu transitions, up to 240 ms for page-level panel changes; no parallax or autoplay decorative motion. Reduced-motion setting removes shimmer, chart entrance animation and positional transitions. Use a single 20/24 px outline icon family with consistent stroke. Icon-only actions need accessible names and visible tooltips; status icons always have text. No decorative shield icon is evidence of certification.

## 9. Accessibility target and verification

Target WCAG 2.2 AA: text contrast at least 4.5:1 for normal text and 3:1 for large text; essential control graphics at least 3:1. Support keyboard operation, visible focus, zoom/reflow, non-color status cues and accessible authentication. These requirements are grounded in [WCAG 2.2](https://www.w3.org/TR/WCAG22/); this is a target, not a conformance claim. FINCHAIN additionally chooses 44 px minimum primary touch targets.

Future UI QA must test full journeys with keyboard and screen reader, 200% text scaling, 400% browser zoom at 1,280 px width, 320 px narrow view, forced colors and reduced motion. Announce meaningful status transitions politely once; do not announce every price tick or countdown second. Fraud denial remains descriptive, and MFA has a usable recovery route. Automated contrast checks alone do not verify the full experience.
