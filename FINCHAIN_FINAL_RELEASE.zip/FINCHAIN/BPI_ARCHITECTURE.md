# FINCHAIN — BPI Architecture

Status: sandbox architecture v1.0. Authorities: [database](DATABASE_ARCHITECTURE.md) for journals; this document for payment lifecycle.

## 1. Value model

BPI records **simulated INR obligations**, with no FINCOIN dependency, conversion, gas, or investment feature. The gateway is a simulated settlement interface. An initial sandbox funding operation creates test value using a balanced journal against a synthetic gateway asset account. A wallet balance is not proof of money deposited with a bank.

Supported denomination: INR, two decimal places. `amount_minor: "50000"` means a simulated ₹500. Initial fee is zero. Multi-currency and FX require separate accounts and new contracts; do not infer conversion from a currency field.

For each wallet:

* `settled_minor`: credit balance of its settled liability account.
* `held_minor`: active reservations against that settled balance.
* `available_minor = settled_minor - held_minor`.
* `pending_incoming_minor`: credit balance of its separate pending liability account.

Nonnegative available funds are required for ordinary wallets. Pending credits cannot fund another payment. Holds are reservations, not journal transfers; every hold change is audited. Actual postings are immutable double-entry journals anchored by blocks.

## 2. Payment types and actors

| Type | Sender | Recipient | Required policy |
|---|---|---|---|
| P2P | Consumer wallet | Consumer wallet | Ownership, recipient confirmation, risk and limits |
| P2B | Consumer wallet | Merchant wallet | Valid merchant/request, immutable checkout amount |
| B2P | Merchant wallet | Consumer wallet | Authorized payout role; maker/checker above threshold |
| B2B | Merchant wallet | Merchant wallet | Payout permission, invoice/reference, approval policy |

The server derives payment type from the verified owners of both wallets. The client cannot self-classify to bypass rules. A business may have outlet wallets but cannot spend another organization's funds. Bulk payouts create independent child payments with their own authorization and idempotency; the batch can partially succeed and is not advertised as atomic.

## 3. Lifecycle and distinct status axes

```mermaid
stateDiagram-v2
    [*] --> DRAFT
    DRAFT --> AUTHORIZED: payload confirmed and signed
    AUTHORIZED --> RISK_REVIEW: review required
    AUTHORIZED --> RESERVED: risk allow and funds held
    RISK_REVIEW --> RESERVED: fresh authorization and risk allow
    DRAFT --> CANCELED
    DRAFT --> EXPIRED
    AUTHORIZED --> REJECTED
    AUTHORIZED --> EXPIRED
    RISK_REVIEW --> REJECTED
    RISK_REVIEW --> EXPIRED
    RESERVED --> INCLUDED: journal and block commit
    RESERVED --> REJECTED: pre-inclusion validation failure
    RESERVED --> EXPIRED: inclusion deadline elapsed
    RESERVED --> CANCELED: cancellation wins before inclusion
    INCLUDED --> SETTLEMENT_PENDING
    SETTLEMENT_PENDING --> SETTLEMENT_UNKNOWN: timeout or ambiguity
    SETTLEMENT_UNKNOWN --> COMPLETED: verified success applied
    SETTLEMENT_PENDING --> COMPLETED: verified success applied
    SETTLEMENT_PENDING --> RETURNED: definitive failure and compensation
    SETTLEMENT_UNKNOWN --> RETURNED: verified failure and compensation
```

`INCLUDED` and `SETTLEMENT_PENDING` may be observed together: the inclusion transaction sets business state to `SETTLEMENT_PENDING` and chain state to `CONFIRMED`; `INCLUDED` names the emitted transition event. It is not a second database commit before pending state.

| Axis | Values | Authority |
|---|---|---|
| Payment business state | States above, with `SETTLEMENT_PENDING` persisted at inclusion | BPI ledger after reservation; API owns draft/authorization progression |
| Chain status | `NOT_SUBMITTED`, `QUEUED`, `CONFIRMED`, `REJECTED` | Ledger inclusion |
| Settlement status | `NOT_STARTED`, `PENDING`, `UNKNOWN`, `SUCCEEDED`, `FAILED` | Verified gateway outcome applied by ledger |
| Refund aggregate | `NONE`, `PARTIAL`, `FULL` | Sum of completed linked refund operations |

`COMPLETED` is permitted only after success settlement evidence and the recipient balance release journal commit together. A failed included transfer remains chain-confirmed with settlement failed and business state returned. A refund does not rewrite the original completed payment; it is a new transaction.

Persist the following combinations; prohibit other combinations at the application/posting boundary:

| Business state | Chain status | Settlement status |
|---|---|---|
| `DRAFT`, `AUTHORIZED`, `RISK_REVIEW` | `NOT_SUBMITTED` | `NOT_STARTED` |
| `RESERVED` | `QUEUED` | `NOT_STARTED` |
| `REJECTED`, `EXPIRED`, `CANCELED` before inclusion | `REJECTED` | `NOT_STARTED` |
| `SETTLEMENT_PENDING` | `CONFIRMED` | `PENDING` |
| `SETTLEMENT_UNKNOWN` | `CONFIRMED` | `UNKNOWN` |
| `COMPLETED` | `CONFIRMED` | `SUCCEEDED` |
| `RETURNED` | `CONFIRMED` | `FAILED` |

Here chain status `REJECTED` means the intent will never be included, including user cancellation or expiry; the business state and reason distinguish why. Commands waiting for reservation can remain `AUTHORIZED` while their separate command status is queued. Do not invent an intermediate spendable state merely because a command was accepted.

## 4. Authorization, reservation, and nonce

The API creates a draft with resolved recipient, exact amount, zero fee, currency, network, expiry, payment type and request/order references. It provides a canonical payload digest. The user confirms these details with recent authentication; step-up is required by policy. The sandbox signer signs only that digest against a short-lived, one-use authorization grant. The service holds the signing key; the UI must describe this honestly.

Risk checks run after signing and before reservation. The decision is tied to the payload digest, policy version and expiry. A reviewed draft must be reauthorized if its authorization or signature deadline has expired; reviewers cannot approve stale signatures into spendability. Ledger validation rechecks wallet status, permissions version and current holds under locks. A risk allow decision is valid for at most 60 seconds; if it expires, recompute before inclusion.

Reauthorization creates a new authorization version and signed digest for the same still-open intent, invalidating previous versions. Commands and grants bind that version; the ledger rejects superseded commands. Once an intent reaches a terminal pre-inclusion state, create a new intent instead of reopening it. The payment request may be reused under its own claim/expiry rules.

Only one active outgoing nonce claim per wallet is allowed initially. `next_nonce` starts at 0. Draft signing does not increment it; reservation atomically claims the expected nonce and holds funds. Competing signed drafts with that nonce cannot both reserve. Inclusion consumes the nonce by incrementing `next_nonce`; pre-inclusion rejection, expiry, or cancellation releases its claim and hold without increment. Old signatures remain unusable because their payment IDs are terminal and grants cannot be replayed. A client with a competing rejected draft must create and authorize a new one.

Reservation and inclusion are separate durable steps, both owned by the ledger worker. A reserved hold expires after two minutes or the signed payload expiry, whichever is earlier. The expiration worker and inclusion worker lock the same payment/wallet rows; exactly one terminal transition wins. Payment draft validity defaults to five minutes. Requests may live longer and generate fresh drafts.

## 5. Inclusion and settlement posting

At inclusion, the ledger worker validates the signed transaction and reservation, debits the sender's settled liability account, credits the receiver's pending liability account, removes the hold, consumes the nonce, records a signed block and journal, advances payment state and writes the settlement outbox event in one PostgreSQL transaction.

The gateway worker then submits `operation_type: TRANSFER_SETTLEMENT` with stable `operation_id` derived from the payment. This models settlement of an internally recorded obligation, not a fresh independent debit on each retry. The simulator may return success, definitive failure, or an uncertain result.

* **Success:** ledger records a second system transaction and journal: debit receiver pending liability, credit receiver settled liability. The payment becomes completed. This settlement event has its own block inclusion and links the original transfer hash.
* **Definitive failure:** ledger records a compensation: debit receiver pending liability, credit sender settled liability. The payment becomes returned. The original chain event remains.
* **Unknown:** no release or compensation. Reconcile by querying the same operation and independent simulator statement. Escalate after the configured age threshold; age alone never justifies refunding.

Callbacks only create durable inbox evidence. A verified, unique result command is applied by the ledger worker. A conflicting terminal result triggers a case and pauses affected operations; it does not overwrite a previous terminal posting. The simulator contract guarantees stable terminal outcomes, so conflict signals corruption or contract violation.

## 6. Funding, redemption, and gateway abstraction

The adapter contract includes `create_funding`, `submit_transfer_settlement`, `create_redemption`, `get_operation`, and `list_statement_entries`. Each takes a stable operation ID, amount, currency, network/environment and correlation ID. Responses include status, provider reference, observed time, and authenticated evidence digest. Simulator results and statements are stored independently of BPI journals so reconciliation can detect omissions and duplicates.

Sandbox funding: after verified simulator success, post debit synthetic gateway asset / credit user settled liability, with a system-signed chain event. Duplicate evidence cannot mint again. Funding failure has no wallet effect. Unknown funding has no spendable credit.

Sandbox redemption: reserve funds, then post debit user settled liability / credit redemption pending liability on inclusion. On simulator success, debit redemption pending liability / credit synthetic gateway asset. On definitive failure, debit redemption pending liability / credit user settled liability. Unknown remains pending. This is a test workflow, not a withdrawal of real money.

The synthetic gateway asset must reconcile to issued value net of successful redemptions. Internal transfers and their settlement change only liability ownership. No actual bank account details are needed; use generated sandbox participant references.

## 7. Requests, QR, and refunds

Payment requests contain payee wallet, immutable amount/currency, request ID, allowed payer if any, expiry and optional order/invoice. State: `OPEN → CLAIMED → PAID`, with `EXPIRED` and `CANCELED` alternatives. Claiming and linking a payment are atomic. A claim can reopen only after a pre-inclusion failure and before request expiry. An included/unknown attempt keeps the claim; it cannot allow a second payment. Definitively returned attempts may reopen if the request is still valid, with the previous attempt retained.

Dynamic QR encodes a same-origin sandbox URL with an opaque request token and server signature. It contains no credentials, private keys, or profile data. Scan resolves the request on the server and displays verified recipient and amount before authorization. Static merchant QR resolves only a merchant profile; the payer enters an amount and a new single-use request/draft is created. Never execute arbitrary QR URLs or imply interoperability with UPI.

Refunds reference a completed original transaction. Refund amount plus active refund reservations plus completed refunds cannot exceed the original settled amount. Lock the original refund aggregate when reserving. A refund is funded by the original recipient's available balance, follows the same risk/signature/settlement engine, and cannot overdraw them. Insufficient funds creates a pending business case, not invented credit. Release the refund aggregate reservation only on definitive failure/pre-inclusion cancellation; unknown settlement keeps it reserved. Multiple partial refunds are allowed with exact linkage and distinct idempotency keys.

## 8. Fraud and limits

Initial deterministic rules cover account/device velocity, amount thresholds, new recipient, repeated failures, unusual merchant payout patterns, and account freeze flags. Decisions are `ALLOW`, `REVIEW`, `DENY`; risk score is an internal 0–100 diagnostic with rule reasons and version, never a guarantee of safety. Store sensitive signals off-chain with restricted access.

Configure sandbox per-transfer, daily, and merchant payout limits; reserve rolling-limit capacity with funds to prevent parallel requests bypassing limits. Release capacity for failures before inclusion; completed/included activity remains in the historical velocity window even if later returned. Risk downtime fails closed for new inclusion but does not block returning or settling previously included obligations.

## 9. Acceptance criteria

Verify all four payment types with FINCOIN stopped and no FINCOIN wallet. Test duplicate clicks, exhausted balance, simultaneous payments, altered QR amounts, foreign merchant IDs, expired signatures, freeze during reservation, signer failure, worker crash after inclusion, repeated gateway callbacks, settlement unknown, definitive return, partial refunds, and concurrent order claims. Expected accounting for the ₹500 path is specified in [DATA_FLOW.md](DATA_FLOW.md).
