# FINCHAIN — Deployment Architecture

Status: cloud-ready sandbox design v1.0. No infrastructure or application has been deployed by this deliverable.

## 1. Environments and topology

Use isolated `local`, `test`, and `cloud-sandbox` environments, each with separate databases, networks, identities, keys, genesis/epoch identifiers and synthetic data. There is no production/live-money environment in the baseline. Builds assert `environment=sandbox`; domain adapters and asset registries reject anything else.

```mermaid
flowchart TB
    C[Browser] --> TLS[HTTPS edge / Nginx]
    TLS --> W[Next.js web replicas]
    W --> I[Identity API]
    W --> B[BPI API replicas]
    W --> F[FINCOIN API replicas]
    I --> IDB[(Identity PostgreSQL)]
    B --> BDB[(BPI PostgreSQL)]
    BL[BPI single ledger writer] --> BDB
    BL --> BS[BPI signer]
    BG[BPI gateway worker] --> BDB
    BG --> SIM[Private simulator]
    SIM --> GDB[(Simulator PostgreSQL)]
    B --> BR[(BPI Redis)]
    F --> FDB[(FINCOIN PostgreSQL)]
    FL[FINCOIN single ledger writer] --> FDB
    FL --> FS[FINCOIN signer]
    F --> FR[(FINCOIN Redis)]
    BP[BPI projection worker] --> BDB
    FP[FINCOIN projection worker] --> FDB
    BP --> EP[(BPI public projection)]
    FP --> EF[(FINCOIN public projection)]
    TLS --> EX[Read-only explorer API]
    EX --> EP
    EX --> EF
```

Worker arrows indicate private access; only TLS edge is public. API, signer, gateway and data subnets use deny-by-default ingress/egress. BPI cannot reach FINCOIN signers/data and vice versa. Identity shares login capabilities without carrying domain financial credentials. Observability agents use redacted telemetry and separate write-only export credentials.

## 2. Local Docker Compose profile

Plan containers for Nginx, web, identity API, BPI API/ledger/signer/gateway/projection, FINCOIN API/ledger/signer/feed/projection, explorer API and simulator. PostgreSQL may run one local server with distinct databases/roles; use separate Redis containers per domain and dedicated named volumes. Give services only their own secrets and database grants. Local delivery sinks replace real email/SMS.

Use Docker networks for edge, identity, BPI, FINCOIN, public projection and operations. Signers and databases expose no host ports by default. Bind development access only to loopback when needed. Mount test secrets read-only. Configure non-root users, read-only root filesystems where practical, resource limits, health checks and restart policies. Do not store chain data solely inside a disposable container layer.

Docker Compose is a development/small sandbox option with a host-level failure domain, not high availability. Do not describe multiple containers on the same host as independent validator decentralization.

## 3. Cloud sandbox profile

Use a managed container platform with at least two stateless API/web replicas across availability zones, managed PostgreSQL with encrypted backups and private connectivity, managed Redis, key vault, object storage and centralized observability. Nginx may sit behind a managed TLS load balancer; maintain equivalent headers, body limits, timeouts and forwarding trust settings. Use a selected region after privacy/residency review; no region is assumed legally sufficient by this document.

Deploy each domain into separate service identities, database instances and network policies when moving beyond a small developer sandbox. Keep one active ledger writer per chain plus a standby with database-backed fencing. Stateless APIs/projection consumers may scale horizontally; additional producers cannot write the same chain concurrently.

Build custom pinned images and run one Uvicorn process per replicated API container initially. Container-level replication and one-off migration jobs follow the deployment pattern described in [FastAPI container guidance](https://fastapi.tiangolo.com/deployment/docker/). Keep migrations outside application startup to avoid replicas racing schema changes.

## 4. Configuration and secrets

| Configuration class | Examples | Handling |
|---|---|---|
| Immutable environment | Domain, sandbox flag, network ID, genesis hash | Verify at startup against DB genesis |
| Financial policy | Limits, fee schedule, quote expiry, approvals, risk policy | Versioned domain config; audit changes; bind version into authorizations |
| Operational settings | Worker batch size, retry intervals, resource caps | Deploy config with measured tuning |
| Secrets | DB credentials, JWT keys, signer wrapping keys, callback keys | Vault/file injection, scoped rotation, no image/commit/log exposure |
| Simulator scenarios | Success, failure, delay, conflicting callback fixtures | Test/admin-only, synthetic operations, audit scenario changes |

`GATEWAY_MODE=simulated` and `TRADING_MODE=simulation` are startup requirements. Reject missing/mismatched flags rather than falling back. Egress allowlists contain only sandbox simulator/approved infrastructure addresses. There are no production credentials or live gateway adapters in the image. Adding a live adapter requires a new reviewed build and the gate in [REGULATORY_BOUNDARIES.md](REGULATORY_BOUNDARIES.md).

## 5. Reliability targets and sizing hypotheses

These are acceptance targets to measure, not established capabilities or guarantees:

| Measure | Initial cloud-sandbox target |
|---|---|
| Monthly web/API availability | 99.5% during declared sandbox operation |
| Authenticated read latency | p95 under 300 ms server-side under target load |
| Durable command acknowledgment | p95 under 500 ms, excluding user MFA/signing interaction |
| BPI chain inclusion | p95 under 3 seconds after eligible reservation |
| Simulated settlement | p95 under 10 seconds in normal success scenario |
| Read-model lag | p95 under 5 seconds; expose actual freshness |
| Trial load | 50 BPI transfers/second plus 20 FINCOIN fills/second for 30 minutes |
| Cloud backup recovery target | RPO no more than 5 minutes; RTO no more than 60 minutes, subject to exercises |

One BPI transfer creates at least two chain events, so the load target implies at least 100 BPI events/second plus funding/returns. Benchmark batching and per-block database/signing costs; tune batch size/interval or lower the demonstrated capacity openly if targets are not met. Bound API queue admission based on backlog and expiry so overload does not produce masses of stale signed payments.

Scale stateless reads, cache immutable content, use scoped read replicas for reporting, and partition only after profiling. The domain sequencer/database writer is an intentional throughput limit. Scale by optimizing batching/queries first. Sharding wallets or multiple writers changes atomicity and consensus and requires a new architecture decision. Never split a transfer across two databases without specifying a safe replacement protocol.

RPO is backup granularity, not permission to silently lose acknowledged financial history. After a restore behind published blocks or external gateway outcomes, keep writes paused and reconcile/recover the missing interval before declaring service restored. If recovery cannot retain continuity, retire the sandbox epoch explicitly; do not claim successful transparent recovery.

## 6. Health, telemetry and alerts

Liveness checks show process health; readiness verifies essential dependencies and correct genesis/environment without making a new financial operation. API command readiness may fail closed while read-only routes remain available. Signer readiness checks key access with a safe diagnostic, not a user payment. Clock synchronization is monitored for signature/quote expiry.

Track request/error/latency metrics, rejected authorization, database locks/serialization retries, command/outbox age, active expired holds, chain head age, writer fencing errors, block validation failures, settlement unknown count/age, gateway mismatches, journal balance checks, negative-balance attempts, projection lag, synthetic-feed age, exhausted inventory, refresh reuse and privileged actions.

Immediate page: journal invariant violation, signature/head divergence, impossible negative balance, conflicting terminal gateway outcome, or suspected key compromise. Investigate unknown settlement after five minutes, outbox lag over 30 seconds and unavailable feed; tune alert severity to sandbox impact. Logs/traces carry correlation and operation IDs without tokens, private keys or personal/raw financial payloads. Trace both inclusion and later settlement under the same payment correlation.

## 7. Backup and restore runbook

1. Maintain encrypted PostgreSQL base backups plus WAL/PITR per database; replicate protected backups and signed checkpoints to a separate failure/access boundary.
2. Save backup manifests with network ID, schema version, chain height/hash, accounting totals, unresolved-operation count and timestamp. Include commitment salts/key metadata in protected backups; private signing keys follow separate key recovery procedures.
3. On incident, stop new financial authorizations and fence writers. Restore the complete domain database, never blocks and journals from mismatched points.
4. Verify genesis, hash/signature chain, remote checkpoints, journal balancing, supplies, balance replay and command/outbox uniqueness. Rebuild read models.
5. Reconcile every pending/unknown gateway operation against simulator status/statements. A restored local row must not cause a new external operation ID. Recover missing acknowledged operations before reopening.
6. Rotate exposed credentials if needed, obtain the new writer epoch, run smoke checks and resume scoped traffic. Record recovered head, known gaps and approvals in audit.

Exercise restore monthly and after major schema/key changes. A simulated region outage and worker crash drill must demonstrate measured RPO/RTO. Preserve independent simulator statements during domain restore; restoring all evidence to the same earlier state would hide lost-operation bugs.

## 8. CI/CD and rollback

Pipeline: format/lint/type checks → unit and property tests → API/protocol contract tests → isolated PostgreSQL integration/fault tests → Playwright product flows → image/dependency/secret scan → reproducible signed image → sandbox smoke deployment. Schedule load/restore tests for material financial/operational changes rather than repeating them for trivial UI edits.

Use expand/migrate/contract schema changes with backward-compatible readers during rollout. Run migration once with a dedicated role and backup checkpoint. Roll stateless services gradually; stop/fence/restart the writer with explicit head verification. Application rollback may reuse a compatible schema, but must not undo posted journals or downgrade protocol history. An incompatible signed-schema change needs new version handling; a reset needs a new sandbox network epoch.

## 9. Operational ownership

Assign named maintainers before shared deployment for identity/security, BPI accounting/settlement, FINCOIN simulator/analytics, and infrastructure/recovery. Maintain domain-specific pause controls, incident contacts and rotation schedules. Document service dependencies so FINCOIN maintenance does not trigger a platform-wide BPI outage. No live launch is authorized by meeting sandbox deployment targets.
