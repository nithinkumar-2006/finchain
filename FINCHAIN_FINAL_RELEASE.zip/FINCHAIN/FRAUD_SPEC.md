# Fraud and review specification

Risk uses deterministic, explainable rules, not machine learning. Signals include a new recipient, large instruction, short-window activity, recent failures and restricted wallets. Scores are capped at 100 and stored with policy version, exact payload digest, reasons and assessment expiry.

Scores through 60 allow, 61–80 enter RISK_REVIEW, and above 80 reject. Assessment occurs after authorization/signing and before posting. Review/rejection creates no financial journal and consumes no wallet nonce. A restricted recipient/sender is blocked through risk/validation. Limits and signals are simulator engineering choices, not regulatory decisions.

Domain admin/compliance users need a recent MFA sign-in to inspect the queue. They can cancel or reject a review case. There is intentionally no button that turns a stale signature into an approved transfer. Resubmission requires a new draft, fresh user authorization and current risk assessment. Every administrative decision is queued, rechecked by the worker and audited.

Identity also records changed sign-in fingerprints, login failures and lockouts. These records stay in the identity domain. Payment risk does not publish IPs, device identifiers or identity details into public blocks. Model tuning, labelled fraud datasets, sanctions screening, investigation tooling and production false-positive evaluation remain separate work.
