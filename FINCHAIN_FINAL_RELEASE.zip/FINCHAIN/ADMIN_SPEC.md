# Administrative operations

Identity roles do not automatically grant financial database authority. Domain staff grants are independently provisioned and checked at request time. Admin/compliance views require a recent MFA session. Support has no implied access to financial controls.

Each domain exposes network status, chain height, active configured producer count, wallet/transaction/block counts and audit history. BPI additionally exposes a private risk-review queue. Network pause/resume requires domain admin; wallet restriction and risk cancellation/rejection allow admin/compliance. Actions are queued and the worker rechecks the live identity session, credential version and domain grant.

Administrative commands take queue priority so a paused network can be resumed even while ordinary payment commands are waiting. Pause prevents new financial processing, while reconciliation of existing BPI settlements continues. No control rewrites a balance, edits a block, changes fixed supply, exposes a wallet key or approves a stale risk signature.

The optional demo provisioner creates a sandbox admin with separate domain grants. That account must enroll MFA before using protected controls. Production operator provisioning must be separately authenticated, reviewed, audited and protected with hardware-backed access; no public self-service administrator registration endpoint exists.
