# FINCOIN market and P&L

The worker emits a deterministic synthetic series around 100.00 SIM_INR per FNC. The API labels source and observation time; feed age over ten seconds blocks new quotes. Charts use observed ticks, not fabricated historical candles. Displayed 24-hour volume sums recorded sandbox fills.

For quantity q atoms and price p minor units, gross BUY is ceil(q×p/10^8), gross SELL is floor(q×p/10^8). Fee is ceil(gross×10/10000). Buy total is gross+fee; sell proceeds are gross−fee. Dust producing a zero/negative valid total is rejected. Quotes expire after 15 seconds and require current nonce and explicit authorization.

Every fill posts FNC inventory/user movements plus SIM_INR inventory/user/fee movements in one database transaction and chain event. FIFO acquisition cost includes purchase fees. Partial lot cost uses integer floor allocation and the last portion takes the remainder. Transfer carries cost; grants have separate provenance. Realized purchased return uses disposed purchased cost as denominator; zero/absent denominator is unavailable, not infinity.

Regression example: buy 2 FNC at 100.00 costs 200.20 including fee; sell 1 at 120.00 receives 119.88, allocates 100.10 cost, and realizes 19.78. Remaining purchased cost is 100.10. This example is a test vector, not a promised return.
