# FINCHAIN — Regulatory and Product Boundaries

Status: mandatory sandbox constraints v1.0. Reviewed for architecture drafting on 2026-09-13; this document is not a legal opinion or evidence of authorization.

## 1. Current permitted product posture

FINCHAIN is a software prototype using synthetic value and simulated settlement. BPI demonstrates INR-denominated payment instructions through a simulated gateway abstraction. FINCOIN demonstrates a separate test asset and simulated trading ecosystem. Neither domain accepts, holds, transfers or redeems real public money in this baseline.

The name “Blockchain Payment Infrastructure” and an interface shaped for a future regulated gateway do not make FINCHAIN, its developer, or the simulator regulated. A “sandbox” label does not mean admission to a regulator's official sandbox. No official sandbox participation is claimed.

## 2. Claims and interface rules

| Do not claim or imply | Required prototype wording/behavior |
|---|---|
| RBI authorization or approval | “Prototype / sandbox. No RBI authorization is claimed.” |
| Bank status or deposit account | “BPI simulated balance”; no bank account branding |
| Legal tender or redeemable INR instrument | “INR-denominated simulated units; no cash value or redemption right.” |
| Real public-money custody | No real deposits, withdrawals, bank credentials or live payment acceptance |
| Guaranteed investment returns | “Simulated P&L based on synthetic data; no guaranteed returns.” |
| Actual FINCOIN exchange execution | “Simulated trade on FINCHAIN test ledger.” |
| Real securities issuance/operations | No securities offering, brokerage, exchange or depository claims |
| Public/permissionless consensus in the prototype | “Single-writer sandbox ledger with verifying followers.” |
| Official regulatory sandbox enrollment | Use “software sandbox” unless separately evidenced and approved |
| UPI-compatible or bank-settled QR | Use FINCHAIN sandbox request links only |

Display relevant labels at onboarding, wallet balances, authorization, receipts, merchant checkout, funding/redemption simulation, FINCOIN quotes/fills, portfolio charts and exports. Metadata must also carry sandbox/simulated markers so integrations cannot drop context. Avoid realistic “bank transfer successful” language for simulator responses; say “Simulated settlement completed.”

## 3. Mandatory domain separation

The future conceptual BPI route is:

```text
Regulated money
  → regulated gateway / settlement interface
  → BPI payment record and settlement workflow
  → user / merchant
```

The current implementation substitutes synthetic value and a gateway simulator at that boundary. Normal BPI payments cannot buy/sell FINCOIN, consume FINCOIN gas, use FINCOIN as collateral, or require an investment account. FINCOIN quote credits cannot be redeemed into BPI, and BPI balances cannot fund simulated FINCOIN buys. There is no bridge or conversion endpoint.

Marketing pages, UI labels, API contracts and database architecture must preserve this boundary. Combined portfolio views must not sum BPI simulated INR and FINCOIN market values into a spendable balance. Shared identity and web navigation are allowed; shared financial custody or settlement is not.

## 4. Legal context to revisit before any live proposal

India is the initial denomination/context assumption because the requested payment example uses INR. The operating jurisdiction, user locations and legal entity are not specified. Do not infer that an INR example decides all applicable law.

The RBI's explanation of the Payment and Settlement Systems Act states that operating a payment system requires authorization under the Act, subject to the actual statutory framework and applicable role. This is a reason to assess the proposed live operating model before launch, not a conclusion that this prototype has approval or that a partner automatically supplies all required permissions. See [RBI payment-system FAQs](https://www.rbi.org.in/CommonPerson/english/scripts/FAQs.aspx?Id=420) and the [Payment and Settlement Systems Act text hosted by India's Department of Financial Services](https://financialservices.gov.in/sites/default/files/Act-Policies/2026-01/Payment-and-Settlement-Systems-Act_2007.pdf).

Before a live design, qualified legal/compliance review must determine applicable payment-system/operator or intermediary roles, instrument classification, gateway/partner responsibilities, customer due diligence, AML controls, safeguarding/custody, complaints/refunds, privacy, record retention, security reporting, taxation, advertising and any cross-border restrictions. FINCOIN requires its own analysis of asset classification, issuance, custody and trading permissions. This list is an architectural review agenda, not a finding that each regime applies or a statement of current tax/licensing rules.

No opinion is made here that FINCOIN is or is not a security, that a testnet exemption exists, or that connecting a licensed gateway makes every FINCHAIN activity permissible. Legal status depends on actual features, parties and jurisdictions. The source check in this document does not replace launch-time verification of amendments and partner conditions.

## 5. Technical enforcement of the sandbox

* Only simulator adapters are shipped. Startup validates sandbox mode, network ID and genesis. Configuration cannot switch an existing build into real-money mode.
* No production bank, UPI, card, exchange, broker or wallet credentials exist in the deployment. Egress is restricted to sandbox endpoints and approved infrastructure.
* Test funding is capped, separately authorized and auditable. It issues simulated units only; its API cannot accept card numbers, live bank tokens or mainnet deposit addresses.
* FINCOIN uses synthetic quotes and internal simulator inventory. No order routing to an exchange or cash payout is implemented.
* Sandbox network IDs, assets, keys and user-facing markers are required in signatures and resources. Reject mismatched environment events, even if their signatures otherwise validate.
* QR requests point to FINCHAIN sandbox origins and show simulated context before user authorization.
* Admin controls cannot turn off sandbox labels, add a live adapter dynamically, or move balances across domains.

Collect minimal account data for a prototype. Prefer fictitious merchant/customer profiles in shared demos. Do not collect official identity documents or real banking details just to imitate KYC. Mock onboarding review must be labeled as simulated verification; a successful mock check does not establish legal eligibility.

## 6. Live-integration change gate

Any later proposal to process actual value must be a separate scoped project decision. Required evidence includes:

1. Defined legal entity, jurisdictions, operating roles, user eligibility, asset/instrument characterization and qualified legal assessment.
2. Verified partner permissions and contracts; responsibilities for money handling, settlement finality, safeguarding, reconciliation, disputes, refunds, failures and data processing.
3. Written custody and accounting design identifying who holds actual money/assets, where obligations arise, and how gateway reports reconcile to financial books. BPI chain inclusion remains distinct from legal settlement.
4. FINCOIN-specific issuance/trading/custody permission review, separately from BPI. BPI approval is not transferable to FINCOIN.
5. Production identity/fraud/compliance controls, privacy/retention decisions, independent security review, incident response and tested recovery/capacity.
6. New infrastructure, network/genesis, production secrets and reviewed adapters; no promotion of test balances into real obligations.
7. Accurate terms, disclosures, consent, complaints process and user-facing product descriptions supported by actual operating arrangements.
8. Formal release authorization by accountable project owners after the evidence is reviewable.

This gate does not require stopping ordinary sandbox implementation to seek live-launch approval. It prevents future agents from treating a prototype flag, test balance or partner URL as permission to operate a real financial product.

## 7. Boundary acceptance checklist

Verify a user can create and complete a BPI payment with FINCOIN disabled. Verify no balance/fee/route converts between domains. Scan UI, receipts, exports, API examples and marketing content for unsupported approval/bank/legal-tender/return claims. Confirm no real-money input rails or production secrets exist. Attempt wrong-network and wrong-environment callbacks and signatures and require rejection. Confirm sandbox resets create a new epoch and cannot mint real entitlements.

Maintain this document when scope changes; cite fresh primary regulatory sources for specific legal claims. Preserve these initial constraints until a separately authorized live-system design replaces the relevant sections with evidence-backed requirements.
