# FINCHAIN — Admin Interface Specification

Role 2 · Version 1.0 · Operations design for the software sandbox; no direct balance editor.

## 1. Trust, shell and navigation

Admin is a separate authenticated workspace with staff MFA and explicit domain permissions. Header shows “BPI Admin · Sandbox” or “FINCOIN Admin · Test network”, selected domain/epoch, operator role and incident state. Organization/customer context is secondary and cannot replace the domain label. No combined spendable/asset balance is ever shown.

Navigation order: Overview, Users, Merchants, Payments, Fraud, Settlements, Blockchain, Validators, FINCOIN, Audit Logs, System Health. These correspond to A-01–A-11; A-12 is a shared correction/approval detail subview. BPI-only sections are unavailable in FINCOIN scope; FINCOIN operations require a deliberate authorized domain switch. Hidden navigation is not the access control: backend scope checks apply to every list/detail/action/export.

Staff sees only required data. Support gets masked records; risk reviewers get permitted evidence; settlement operators get operation/reconciliation evidence; domain security operators get configuration and key proposals; auditors get read-only evidence. No universal role grants both domains' secrets. Signing keys, JWTs, raw MFA factors and credentials are never displayed.

## 2. Overview A-01

Desktop 12-column layout: domain/period heading → four main KPI cards → next metric row → 8-column priority work queues and 4-column system status → chain/settlement activity. Main action is Open pending reviews, not Add funds. Domain outages appear above KPIs; stale metric values retain timestamps and never become zeros.

| Requested metric | Definition and limits |
|---|---|
| Total Users | Unique enrolled subjects in selected domain; not automatically total identity registrations |
| Active Users | Unique enrolled subjects with authenticated successful domain activity within selected interval; exclude health checks/bot/service events |
| Merchants | BPI sandbox organizations by status; unavailable/not applicable in FINCOIN scope |
| Payment Volume | BPI completed ordinary payment principal in selected completion-time interval; fees, grants, funding/redemption/refunds separate |
| Transactions | Distinguish submitted payment attempts and included chain events as separate labeled metrics; never equate them |
| Fraud Alerts | Open domain cases by severity, not a count of proven fraud |
| Pending Reviews | Open review/approval tasks awaiting staff action, deduplicated by case/proposal |
| Blocks | Current height and included-block count, explicitly distinguished because genesis is height 0 |
| Validators | Authorized producer count and health; verifying followers separate |
| System Health | Domain service readiness/latency/queue freshness from actual telemetry, with as-of time |

FINCOIN overview uses active users, filled simulated orders, FNC volume, simulator inventory, synthetic-feed freshness and chain events instead of BPI payment/settlement metrics. UX-E09 supplies these complete aggregates; do not calculate totals from first-page rows. No platform revenue, real assets under custody or guaranteed returns metric.

## 3. Users A-02 and Merchants A-03

User list: opaque subject reference, permitted display alias, domain enrollment/status, MFA status if authorized, creation time and scoped activity summary. Filters use allowed status/date fields. Detail separates account access, domain wallet references, security events and cases. Reveal of otherwise masked fields requires a valid support/investigation reason where policy specifies and is audited. No lookup by arbitrary sensitive field for every staff role.

Account freeze/restrict action shows domain, subject, reason, affected capabilities and confirmation. Describe precisely whether new authorization is paused while already included settlements can still complete. Reauthentication/MFA applies; success only after recorded action. No user impersonation, private-key export or balance overwrite. Role 1 account recovery/key binding process appears as a proposal/evidence workflow, never “Reset private key” with an instant toast.

Merchant list: organization/outlet references, display name, sandbox review status, owner reference (masked as needed), operational restrictions and pending cases. Detail contains review evidence, role history and organization-scoped payment summaries. Review choices allow sandbox access, request corrections or reject with reason; “Approved” is visibly qualified “Sandbox onboarding approved”. There is no RBI/bank verification badge.

## 4. Payments A-04

List filter by scoped reference, type, business/chain/settlement status, safe risk severity, amount range and time. Table shows each status axis independently. Detail contains private receipt, authorization/version timestamps, risk decision reference, journal/chain references, gateway operation, associated order/invoice, returns/refunds and audit timeline, limited by role.

Use exact minor-unit amounts with formatted currency; never editable balance cells. Any correction is a linked proposal with balanced impact preview, reason and two independent approvals. A correction cannot convert between BPI and FINCOIN or mutate an original block. Support actions include Copy reference and Open case; not Force successful, Reverse blockchain or Resend payment automatically.

Unknown status highlights reconciliation work and the existing operation ID. A frontend timeout opens status retrieval for the original case/action. If state changes while staff reviews, show version conflict and require a refreshed review before action.

## 5. Fraud A-05

Queue columns: case ID, created/age, scope/reference, LOW/MEDIUM/HIGH/CRITICAL severity, decision type, owner and review status. Default order: required action severity then age, with explicit sorting. Empty queue means no cases in the requested scope; unavailable detection service must not appear as zero alerts.

Case detail: summary, timeline, permitted reason categories, evidence provenance, policy version, amount/recipient context, past relevant domain activity and decision composer. Internal score may appear only for authorized risk staff with “Diagnostic score, not a safety guarantee”. Severity, model/rule decision and user-permitted action are separate fields. Never calculate enforcement from UI badge color.

Decisions: request verification, approve review subject to fresh authorization, reject, escalate or close with reason where backend policy permits. No “Continue anyway” for a consumer-denied payment and no automatic signing on behalf of the user. Approval after expiry instructs user to review a fresh authorization; superseded intent versions cannot be revived. User-visible messages are separately previewed and limited to approved safe reasons.

High/critical visual treatment: text label plus icon, calm explanation, specific next task. No siren, flashing banner or claim that the subject is a criminal. Record reviewer identity/reason and show immutable decision history. Another reviewer changing the case creates a visible version conflict instead of silently overwriting it.

## 6. Settlements A-06

Two tabs: Operations and Reconciliation cases. Operations show funding/transfer/redemption/refund type, exact amount/currency, gateway simulator reference, business/chain/settlement state, age, last status query and evidence status. Cases classify matched, missing, duplicate, orphan, amount mismatch and terminal conflict.

Detail uses side-by-side Expected BPI operation and Observed simulator evidence, with differences highlighted in text. Actions: query existing operation, record investigation note, assign/escalate, attach permitted evidence, propose a correction/return only through validated ledger commands. Do not expose an editable “succeeded” dropdown. Conflicting terminal evidence preserves existing postings and opens an incident; the UI cannot select a preferred outcome to force through.

Unknown duration appears as elapsed time, not a countdown promising automatic refund. Refresh queries the same operation; retry delivery uses stable IDs only when authorized. Do not bulk-resubmit unknown payouts as new operations. Already included obligations should continue safe resolution during a pause of new payments.

## 7. Blockchain A-07 and Validators A-08

Blockchain view: head height/hash, epoch, block verification/checkpoint status, writer fencing state, replay/reconciliation health and links to authorized private detail. Distinguish public explorer proof from internal operational evidence. Verification/invariant failures are actionable alerts; no Delete block, Edit hash, Roll back payment or Reset chain action in routine UI.

Validators view titles its main card “Authorized block producer”. Show configured key ID/public key, valid-from height, current heartbeat/status, rotation proposal/history, and optional verifying followers separately. No staking, rewards, voting weight, decentralization score or fabricated validator map.

Normal key rotation proposal: new public key reference and proof of possession → impact and activation-height review → first/second independent approvals → authorized system event → next-height activation → evidence in history. Private key import/creation belongs to secure operational tooling, not a browser text field. If the backend proposal contract is absent, the UI is read-only with procedure guidance. Key compromise uses incident/recovery procedure; it cannot be “fixed” by a routine rotate confirmation that ignores broken trust.

## 8. FINCOIN A-09

Accessible only within FINCOIN scope. Display test supply, simulator inventory per asset, fee treasury, faucet grant usage, open/rejected/filled orders, synthetic feed status and portfolio projection lag. FNC and SIM_INR remain separate quantities; BPI is not a replenishment source. A dry simulator inventory should be visible as limited availability, not hidden by arbitrary minting.

Permitted controls: pause new simulated quotes/orders, inspect failed commands, review capped test-grant policy through approved configuration and monitor feed scenarios in sandbox. FINCOIN supply is fixed after genesis under Role 1; no unrestricted Mint FNC button. Corrections are linked reviewed transactions; fills, prices and user P&L cannot be edited retrospectively. User-view examples in this panel are explicitly synthetic and separate from real account projections.

## 9. Audit Logs A-10 and System Health A-11

Audit logs: time (with zone), domain, actor/service, action, scoped resource, result, reason and correlation ID. Filter by bounded period/action/result and permitted reference; detail shows immutable event linkage, evidence and safe before/after differences. Raw secrets/request bodies never appear. Export requires audit permission, scope and durable job; access to export itself is audited. Log gaps or unverifiable chains are an alert, not a silently shortened list.

System Health: per-domain service readiness, API latency/error rate, command/outbox age, expired holds, head/follower/checkpoint status, settlement unknown age, ledger invariant alarms, feed freshness, projection lag and backup/recovery exercise status. Distinguish measured performance from architectural targets. “Not measured” is not “Healthy”. Restricted infrastructure details stay out of public pages.

Pause workflow: choose permitted new-operation scope, mandatory reason, duration/review time and impact preview → MFA/approval where policy requires → server acknowledgment → persistent banner and audit event. Pausing new BPI payments does not imply canceling included obligations or FINCOIN operations. Resume requires fresh health/status review and authorization. No destructive database recovery/reset controls are exposed as casual dashboard buttons.

## 10. New backend contracts and availability

UX-E09 requires domain-scoped aggregate read models, users/merchant oversight queries, explicit allowed-actions, risk evidence views, audit search, measured health and governed operational proposals. Existing Role 1 admin families provide the direction; exact schemas/permissions/versioning are required before UI wiring. Every mutation supplies idempotency and expected version where appropriate and returns a durable action/proposal ID.

Correction A-12 detail must expose proposed balanced impact, original linked operation, reason/evidence, maker and required checker, status and resulting transaction if executed. No arbitrary cross-domain account selector. Reviewer cannot approve their own correction where independence is required. Submitted-but-unknown proposal state reopens the same action ID.

## 11. State, mobile and acceptance

All lists distinguish empty scope, no filter matches, unavailable source and denied permission. Polling live queues must not steal keyboard focus or reorder the record being reviewed; indicate new items and let staff refresh deliberately. Use persistent labels on urgent cases and keyboard-accessible detail links.

Mobile supports triage, evidence reading, and approved actions with a full-screen exact-impact review. Dense evidence becomes sections; no hidden decision rationale. Particularly complex recovery stays procedural/read-only, without pretending that a mobile confirmation operates infrastructure. Test two reviewers racing, stale proposal, wrong domain, unauthorized export, unknown settlement, invariant alert, producer outage and failure of an action acknowledgment.
