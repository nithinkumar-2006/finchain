# FINCHAIN QA report

Executed on 18 September 2026. This is a sandbox implementation report, not a production certification.

| Check | Actual result |
|---|---|
| Complete Python regression with all three PostgreSQL test URLs configured | 95 passed, zero skipped, 115.06 seconds |
| PostgreSQL subset | 20 checks included: identity 4, platform 16; PostgreSQL 17.11 |
| Next.js production build and TypeScript validation | Passed |
| Chromium against latest production build | 9 passed, 14.8 seconds |
| Python dependency consistency and compilation | Passed |
| Generated configuration isolation/refusal-to-overwrite tests | Passed within regression |
| Release CRC and per-file SHA-256 verification | Performed by scripts/package_release.py |

Backend coverage includes authentication, refresh replay/revocation, recovery, TOTP, permission boundaries, real identity-to-domain HTTP validation, double-entry posting, constrained database roles, append-only records, all four BPI payment types, concurrent duplicate nonce spending, settlement success/failure/unknown, refunds, redemptions, durable signer recovery, fixed FINCOIN supply, order/fill accounting, FIFO cost basis, commerce, API keys and local webhook acknowledgments. Application tests use isolated databases; concurrency and database privilege checks use real PostgreSQL.

Browser coverage: responsive layouts at 320/390/768/1440 pixels, navigation, password input behavior, explicit service-unavailable errors, keyboard skip link and per-request production CSP nonce. These checks do not constitute a complete browser-to-database financial journey.

Resolved issues include private-service Host validation, PostgreSQL migration percent handling, runtime worker database grants, deterministic signing retries after rollback, duplicate wallet nonce races, inaccessible form labels, HTML responses incorrectly appearing successful, merchant wallet selection, premature webhook delivery status, and missing production script nonces. Regression tests cover the affected boundaries where applicable.

Three Python warnings remain: two dependency deprecations in the test client and a deliberately short HMAC key in a negative JWT algorithm test. Browser tooling emits a color-environment warning. The host web server also warns about using `next start` with standalone output; the supplied container uses the standalone server entry point.

## Not executed

Docker image builds, Compose startup/networking, optional demo provisioning, complete HTTPS browser payment journeys across all services, physical camera scanning, production load/failover, disaster recovery, external gateway/email/exchange integrations and independent penetration testing. Docker is unavailable on this machine. No production deployment, real-money movement or public release occurred.

Repeat instructions are in LOCAL_DEVELOPMENT.md and QA_TEST_PLAN.md. Workspace test XML is not packaged because it contains machine-specific paths. Do not infer readiness for public funds from these results.
