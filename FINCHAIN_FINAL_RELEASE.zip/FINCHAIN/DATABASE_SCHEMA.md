# FINCHAIN — PostgreSQL Database Schema

Role 3 · Version 1.0 · 2026-09-14 · Design only; no database or migration has been deployed.

## 1. Scope, inputs and authority

This specification makes the Role 1 logical architecture concrete and incorporates the data requirements of Role 2. Read it with [DATA_DICTIONARY.md](DATA_DICTIONARY.md), which owns columns and table constraints, and [ER_DIAGRAM.md](ER_DIAGRAM.md), which owns relationship diagrams. Existing documents remain reference material; naming refinements below replace conceptual names for future migration work, not historical records.

Reviewed inputs: [MASTER_ARCHITECTURE.md](MASTER_ARCHITECTURE.md), [SYSTEM_CONTEXT.md](SYSTEM_CONTEXT.md), [COMPONENT_MAP.md](COMPONENT_MAP.md), [DATA_FLOW.md](DATA_FLOW.md), [DATABASE_ARCHITECTURE.md](DATABASE_ARCHITECTURE.md), [API_ARCHITECTURE.md](API_ARCHITECTURE.md), [BLOCKCHAIN_ARCHITECTURE.md](BLOCKCHAIN_ARCHITECTURE.md), [BPI_ARCHITECTURE.md](BPI_ARCHITECTURE.md), [FINCOIN_ARCHITECTURE.md](FINCOIN_ARCHITECTURE.md), [SECURITY_ARCHITECTURE.md](SECURITY_ARCHITECTURE.md), [DEPLOYMENT_ARCHITECTURE.md](DEPLOYMENT_ARCHITECTURE.md), [REGULATORY_BOUNDARIES.md](REGULATORY_BOUNDARIES.md), and all eleven UI/UX documents indexed by [UI_UX_SPEC.md](UI_UX_SPEC.md), including its page, journey, component, dashboard, merchant, FINCOIN, explorer, admin, design-system and responsive specifications.

PostgreSQL is the durable accounting, workflow and chain store. Redis is never authoritative for amounts, nonce consumption, idempotency, approvals or settlement. All value is synthetic. BPI supports simulated INR only; FINCOIN supports `FINCOIN` and `SIM_INR` in a different database/network. No bridge, shared financial wallet, conversion journal or cross-domain transaction exists.

Use PostgreSQL 18-compatible features for this design and select a supported patched release when implementing. Do not require UUIDv7 availability: all primary identifiers use native `uuid` with `gen_random_uuid()` as the default, or a server-generated UUID provided for an idempotent operation. Hashes/heights/provider IDs are alternate keys, never replacements for UUID primary keys.

## 2. Physical boundaries and schemas

| Database | Schemas / responsibility | Runtime writers |
|---|---|---|
| `identity_db` | `auth`: users, profile PII, password verifiers, sessions/devices/MFA; `audit` and `ops` identity event transport | Identity service only |
| `bpi_db` | `core`, `app`, `ledger`, `risk`, `commerce`, `integration`, `ops`, `audit`, `readmodel` | Separate BPI API, ledger, risk, gateway, integration and projection roles |
| `fincoin_db` | Independent `core`, `app`, `ledger`, `market`, `ops`, `audit`, `readmodel` | Separate FINCOIN API, ledger, market and projection roles |
| `gateway_sim_db` | `sim`: independent synthetic provider operations/statements | Simulator only |
| `explorer_bpi_db` | `public_data`: redacted BPI headers and proofs | BPI projection exporter; explorer read only |
| `explorer_fincoin_db` | Separate `public_data`: redacted FINCOIN headers and proofs | FINCOIN exporter; explorer read only |

The shared table templates in the dictionary are physically instantiated separately in BPI and FINCOIN. A shared name is not a shared table, connection, credential or transaction. Identity uses only its explicitly identified audit/outbox subset and has no financial network, ledger or asset registry.

Foreign keys cannot span these databases. Each domain has a minimal `core.subjects` projection of authorized identity events, and all local user relations reference it. The projection's UUID equals the source `auth.users.id`; this equality is a replication contract, not a PostgreSQL FK. Apply identity events with version checks and durable deduplication. Unknown subjects are not invented by a payment request; wallet enrollment waits for trusted projection creation. Revoked/deleted subjects retain tombstone IDs for historical integrity. Fresh financial authorization checks identity/session and current domain membership as Role 1 requires; replicated status alone is not immediate revocation proof.

No cross-database foreign data wrapper, `dblink`, financial join or distributed two-phase commit is part of the design. Gateway/public copies use authenticated events and source IDs with local deduplication. An explorer cannot acquire private data merely by joining a shared UUID.

## 3. Required-entity coverage and canonical naming

| Requested entity | Canonical location | Meaning |
|---|---|---|
| users / profiles | `identity_db.auth.users`, `auth.profiles` | Identity lifecycle and encrypted personal profile |
| wallets / wallet_addresses / balances | `bpi_db.ledger.wallets`, `wallet_addresses`, `balances` | BPI wallets, versioned addresses and exact balance projection |
| merchant_accounts | `bpi_db.app.merchant_accounts` | Sandbox merchant organization, not a bank account |
| payments | `bpi_db.app.payments` plus `ledger.payment_states` | Payment intent and restricted mutable lifecycle |
| transactions | Each domain's `ledger.transactions` | Immutable balanced accounting transaction/journal header |
| blockchain_transactions / blocks | Each domain's `ledger.blockchain_transactions`, `ledger.blocks` | Signed inclusion record and ordered block header |
| payment_requests / qr_payments | `bpi_db.app.payment_requests`, `app.qr_payments` | Payee request and QR initiation configuration; QR is not a second payment |
| settlements / gateway_transactions | `bpi_db.integration.settlements`, `gateway_transactions` | One settlement obligation and stable provider operation |
| fraud_scores / fraud_events | `bpi_db.risk.fraud_scores`, `fraud_events` | Versioned assessments and evidence; private |
| devices / sessions | `identity_db.auth.devices`, `auth.sessions` | Authentication device/session records, not public chain data |
| audit_logs / notifications | Private per-domain `audit.audit_logs`, `app.notifications`; identity audit copy | Append-only evidence and private notification delivery state |
| commerce_orders / merchant_products / invoices | `bpi_db.commerce.commerce_orders`, `merchant_products`, `invoices` | Server-priced sample commerce and issued invoice snapshots |
| refunds | `bpi_db.app.refunds` | Linked reverse payment, never editing original accounting |
| fincoin_wallets / fincoin_transactions | `fincoin_db.ledger.fincoin_wallets`, `fincoin_transactions` | Independent asset wallet and typed receipt linked to accounting transaction |
| fincoin_orders / fincoin_portfolios / fincoin_price_history | `fincoin_db.app.fincoin_orders`, `readmodel.fincoin_portfolios`, `market.fincoin_price_history` | Simulated orders, rebuildable analytics and synthetic ticks |
| api_keys / webhooks | `bpi_db.integration.api_keys`, `webhooks` | Scoped merchant sandbox credentials and verified callback endpoints |
| system_settings | Each financial domain's `app.system_settings` | Versioned nonsecret policy/configuration |

Role 1 `journals` becomes `ledger.transactions`; `journal_lines` stays separate. `payment_drafts` becomes `app.payments` with immutable business terms and append-only authorization versions. `chain_transactions` becomes `blockchain_transactions`; `organizations` becomes `merchant_accounts`. FINCOIN's typed transaction table is a 1:1 extension of its own accounting header, not a second posting. Do not create duplicate authoritative tables under old aliases; compatibility views may be added only if actual legacy consumers later require them.

## 4. Column and key conventions

Every persistent table, including joins, journal lines, outbox, balances, network heads and public projections, has `id uuid PRIMARY KEY`. Composite business keys use separate UNIQUE constraints. Every table has `created_at timestamptz NOT NULL DEFAULT transaction_timestamp()`. Mutable operational rows additionally have `updated_at` and `row_version bigint NOT NULL DEFAULT 1`; update through controlled code/trigger increments the version. Append-only facts have business `occurred_at`/`posted_at` timestamps where needed and no fake mutable `updated_at`.

Network-scoped tables include `network_id uuid NOT NULL`, FK to their local `core.networks`, and `UNIQUE(id,network_id)` for composite references. Assets are UUID registry rows with an asset code and decimals, not arbitrary currency strings. A relationship between two network-scoped financial objects must reference `(parent_id,network_id)`, not `parent_id` alone. Where wallet/asset/merchant identity must agree, add the declared longer alternate key and reference all required columns. All such constraint targets are actual UNIQUE constraints, not partial indexes.

Use `ON DELETE RESTRICT` and noncascading identity for financial/history relations. Deferrable `NO ACTION` is used for explicitly documented intra-transaction cycles and terminal commit assertions. Never cascade-delete payments, blocks, journal lines, settlement evidence, refunds or audit records. Foreign-key nullability expresses actual optionality; a nullable column is not permission for an orphan UUID.

Use bounded `text` values with named CHECK constraints for states and code sets, rather than hard-to-evolve PostgreSQL enums. Use `jsonb` only for versioned nonrelational metadata, safe reason codes, configuration and bounded event payloads; primary financial amounts, links and status are typed columns. Generic audit resource snapshots and remote source identifiers are explicitly not local FK relations.

## 5. Exact accounting and atomic unit types

BPI business amounts are `bigint` minor units; INR scale is 2. FINCOIN and shared journal quantities use `numeric(38,0)` atomic units; FINCOIN scale is 8 and SIM_INR scale is 2. Never use `money`, float/double, binary floating-point conversions or locale-formatted text for authoritative amounts. Reject noninteger input before storing `numeric(38,0)` because PostgreSQL coercion may round rather than reject excess fractional precision. Signed/wire integers remain canonical decimal strings.

All monetary quantities have explicit finite/range checks, including rejection of numeric NaN/infinity where applicable. BPI adapter postings must additionally fit BPI bigint bounds; business policy limits are much lower. Compute products and aggregated sums with arbitrary precision, check range before narrowing, and carry no mixed-asset totals.

The canonical ledger is `transactions` + `journal_lines`; account totals and wallet balances are synchronous projections. One accounting transaction balances independently per asset, contains at least two positive lines, and has exactly one blockchain transaction and one membership in a committed block. Ordinary wallet balances cannot be negative; issuance/contra accounts have their declared normal side and must not be subjected to the wrong wallet-only constraint.

| BPI event | Debit | Credit |
|---|---|---|
| Funding success | Synthetic gateway asset | User settled liability |
| Transfer inclusion | Sender settled liability | Receiver pending liability |
| Settlement success | Receiver pending liability | Receiver settled liability |
| Definitive transfer failure | Receiver pending liability | Sender settled liability |
| Redemption inclusion | User settled liability | Redemption pending liability |
| Redemption success / failure | Redemption pending liability | Synthetic gateway asset / original user settled liability |

Holds reserve spendable value without journal ownership movement. At inclusion they are consumed together with the sender debit. BPI `available_minor` is a stored generated expression `settled_minor - held_minor`. Recipient `pending_minor` is never added. FINCOIN `available_atomic = settled_atomic - reserved_atomic`; asset legs of a fill and its immutable fill record commit together. Refunds are fresh signed payments linked to a completed original, with cumulative reservations preventing over-refund.

## 6. Enforced transaction boundaries

### 6.1 Drafts and authorization

The BPI API may create immutable payment terms, root operation and initial DRAFT state through a narrow initializer that can only initialize state, never set arbitrary financial statuses. Later state updates belong to the ledger workflow. Revised authorizations are new `ops.authorizations` rows bound to the current intent revision and exact signed digest; consumed/superseded grants cannot be reused. Do not overwrite previously signed bytes. Merchant maker/checker approvals bind the same digest and distinct human principals.

### 6.2 Reservation

In a serializable transaction, lock the root operation, payment/state, wallet, relevant request/refund/limit rows in a documented stable order; verify current grant/permissions/risk/expiry; claim the wallet nonce; reserve funds and limit capacity; claim payment request if relevant; write audit and outbox. Only one active outgoing claim per wallet. Expiry/cancel and inclusion lock the same rows. Only inclusion increments `next_nonce`; rejection before inclusion releases the claim/hold, with the old intent terminal.

### 6.3 Inclusion and settlement application

Obtain the database writer fence/head lock; lock candidates and affected accounts deterministically; revalidate; create accounting transaction, journal lines, balance updates, nonce/hold consumption, signed chain transaction, block membership, block/head advance, state changes, audit and outbox in one commit. No public block is published before commit. Provider HTTP is outside this transaction. A block proposal may be signed before commit; failed transactions discard that unpublished proposal.

Callbacks only append authenticated gateway evidence and queue a result command. The ledger locks the settlement, deduplicates its terminal application, and posts either success or definitive return once. UNKNOWN retains pending value. Terminal conflicts create reconciliation cases, not replacement postings. A single terminal child operation `(parent_operation_id = settlement.operation_id, slot_key = 'APPLY_TERMINAL')` prevents both success and failure from independently crediting wallets; conflicting evidence is still retained.

For FINCOIN, quote expiry/ownership, user funds, simulator inventory, both asset legs, fees, fill, nonce, chain and outbox commit together. Grants and issuance are explicit system transactions; genesis FINCOIN supply cannot be increased by a routine admin setting. Read-only portfolio updates may lag and cannot authorize a sale.

Stable operation slots make retry semantics concrete:

| Root/resource | Child slots and effects |
|---|---|
| BPI payment root | INCLUDE for initial transfer journal; SETTLEMENT for the provider obligation; its APPLY_TERMINAL child for success or return journal |
| BPI funding/redemption root | SETTLEMENT/provider obligation and APPLY_TERMINAL result; redemption additionally has INCLUDE for the pending debit |
| FINCOIN quote/trade root | Quote and eventual order share root; FILL child is the only execution journal |
| Refund | New payment root linked to original payment, following normal INCLUDE/SETTLEMENT slots |
| Network initialization | One INITIALIZE_NETWORK root per network; one INITIAL_ISSUANCE child with registry-defined quantities, permitted only during initialization |

Use database-allocated/persisted UUIDs plus unique parent/slot keys, not a newly generated operation on every retry. Reservation and delivery command stages may reuse the root with distinct command_kind; they are not additional journal postings.

### 6.4 Constraint enforcement

Use CHECK for row-local invariants, UNIQUE/partial UNIQUE for identities/active claims, and composite FKs for relational scope. Cross-row accounting sums require a deferred constraint trigger plus restricted posting routines; CHECK cannot reliably validate other rows. This distinction follows [PostgreSQL constraint documentation](https://www.postgresql.org/docs/current/ddl-constraints.html). At deferred commit, assert balanced nonempty journals, matching asset/network/account ownership, exactly one chain attachment, valid block roots/head, and terminal-state/journal agreement. No financial transaction may survive as an incomplete draft journal.

At the access boundary, revoke direct journal/chain/balance DML from API/projection/gateway roles. Ledger role executes audited posting routines, with fixed schema-qualified references and a safe `search_path`; SECURITY DEFINER owners are nonlogin roles. Immutable facts reject UPDATE/DELETE for ordinary runtime roles. A superuser can bypass these protections; external signed checkpoints and restricted administration detect/limit that trust, not remove it.

Retry complete serializable transactions on `40001` and bounded deadlock retries on `40P01`, keeping the same operation IDs, with jitter and initial maximum five immediate attempts. Thereafter retain retryable commands. Serializable execution may abort transactions; applications must retry the whole transaction, consistent with [PostgreSQL isolation guidance](https://www.postgresql.org/docs/current/transaction-iso.html). External provider calls are never repeated with fresh logical IDs just because a local retry occurs.

## 7. Uniqueness, indexing and query design

| Workload / invariant | Index or constraint |
|---|---|
| User login | Unique normalized-email blind index; verification hash, never plaintext email index |
| Session/refresh/API-key replay | Unique token hash; active session user/expiry indexes; family chain retained |
| Wallet/account/address | Unique local network/address; wallet owner/asset keys; one preferred active address per wallet |
| User transaction nonce | Partial UNIQUE `(network_id,sender_wallet_id,nonce)` on included user chain records |
| Active reservation | Partial UNIQUE wallet claim where state ACTIVE; payment/root operation hold uniqueness |
| Journal dedupe | UNIQUE accounting transaction `operation_id` |
| Chain order | UNIQUE `(network_id,height)`; `(block_id,tx_index)`; one membership per chain transaction |
| BPI history | `(sender_wallet_id,created_at DESC,id DESC)` and matching receiver index; private read model for combined feed |
| Merchant reporting | `(merchant_account_id,status,created_at DESC,id DESC)` and completed-time aggregate indexes |
| Requests/refunds | Unique request token lookup digest; original payment index; unique reverse-payment link |
| Gateway | Unique `(provider_code,provider_operation_ref)` and `(provider_code,event_id)`; pending/unknown next-check partial index |
| Workers | `(state,next_attempt_at,created_at,id)` partial queued/retry index; leases indexed for expiry |
| FINCOIN | Unique filled order/quote; `(wallet_id,created_at DESC,id DESC)` order index; `(feed_id,sequence)` tick uniqueness; price time index |
| Audit | `(actor_principal_id,occurred_at DESC,id DESC)`, `(action,occurred_at,id)`, scoped resource/reference index |
| Webhooks | Unique endpoint/event delivery; `(state,next_attempt_at)` delivery queue; endpoint history index |

PostgreSQL does not automatically add every useful index on referencing FK columns. Add a leading-column index for each high-use FK, avoiding duplicates already covered by another index. Low-cardinality status alone is usually not selective. Avoid indexing ciphertext and indiscriminate GIN indexes on every JSONB field. Use B-tree for exact/cursor lookups; consider BRIN on large time-correlated append-only history only after measurements.

Use keyset pagination with `(timestamp,id)` or `(height,tx_index)`; scope/time range first, then bounded page size. Money authorization reads the primary within its transaction; replicas are for nonauthoritative reporting. Read models include source block/event checkpoints and as-of times. A dashboard total is a full scoped aggregate, not a sum of visible page rows.

Start unpartitioned to preserve UUID PK/global uniqueness simply. Later partitioning of history/audit/ticks requires a separate design: a PostgreSQL partitioned unique key normally must include partition columns, so retain an unpartitioned UUID/key registry and a constrained partitioned payload design, or explicitly redesign key requirements. Never casually replace a required `id` uniqueness guarantee with `(id,date)` and call it equivalent. Do not partition balances, chain head, nonce claims or dedupe registries.

## 8. Identity, encryption and public/private separation

Passwords are Argon2id PHC verifiers with per-password salt/parameters; no plaintext or reversible password column. Optional pepper lives in a key vault. Random refresh/session/API tokens use cryptographic verifier hashes; HMAC-based lookup may use a vault-held key. Password hashing and high-entropy token verification are distinct policies.

Encrypt profile names/contact, sensitive device metadata, private notes, raw risk/gateway evidence and webhook signing secrets with application-level authenticated envelope encryption. Dictionary `ENC` fields are versioned envelopes containing algorithm/key version, ciphertext, nonce and authentication tag; key material is external. Bind associated data to database, table, row ID and column to prevent ciphertext swapping. TLS, encrypted disks and encrypted backups remain required; disk encryption alone does not limit database-reader exposure.

Email/alias exact lookup uses normalized text and purpose-specific HMAC blind indexes with key version, not an unsalted hash. During rotation maintain both old/new lookup indexes until backfill and dual lookup are verified; enforce no duplicate normalization identities through the controlled identity writer. Do not normalize email local parts using provider-specific dot/plus rewriting. Deleted accounts cannot be reactivated or reassigned accidentally through blind-index reuse; subject UUID is never reused.

Private signing keys are not stored as raw database columns. `core.signing_keys` stores public key and vault handle/metadata. Webhook HMAC secrets must be decryptable by the scoped delivery service to sign; API-key secrets need only verification hashes and are shown once at issuance. Refresh tokens held by a server-side web bridge are stored encrypted in restricted web-session storage; the auth verifier still stores only hashes. No secret appears in logs, public explorer, URLs or system settings JSON.

Public export explicitly copies allowlisted block headers/hashes/commitments/proofs to separate databases. No wallet addresses, user UUIDs, amounts, risk scores, notes, legal names, phone/email or private FK joins are exported. Transaction hashes and salted journal commitments follow the existing protocol; an unsalted low-entropy amount/contact hash is not anonymization. Public block counts/timestamps remain limited to declared synthetic networks. Full private accounting replay requires private journal evidence and salts, not only a public proof.

## 9. Deletion, audit and retention

Soft deletion (`deleted_at`, `deleted_by`, reason) applies to mutable profile, merchant/catalog and optional integration configuration where named in the dictionary. Wallets are closed, sessions/keys revoked, payment intents expired/canceled; they are not deleted to erase activity. Journals, blocks, included transactions, fills, gateway evidence and audit facts are append-only for the epoch's retention lifecycle, without soft-delete filters that conceal financial history.

Deleting a user disables authentication, revokes sessions, emits domain tombstones, and removes/encrypts-away eligible PII after the retention/privacy process. Keep surrogate IDs and required historical relationships. Deleting a product does not delete issued order/invoice line snapshots. API keys/webhooks are revoked/disabled with audit history retained. Purging encrypted payloads must not break required accounting replay/commitment evidence; distinguish purgeable PII from retained financial evidence and salt keys.

Use inherited sandbox defaults as planning values: debug logs 30 days, raw risk signals 90 days, audit exports 180 days, archived epochs 90 days, subject to an explicit retention matrix and holds before collecting real personal data. Do not delete live-epoch dedupe keys, journals or refresh-token family evidence merely because a cache TTL expired. Store retention/legal-hold metadata privately; no claim that these defaults satisfy any legal retention obligation.

Audit events include actor, time, action, scope, safe before/after digest, reason, correlation, previous hash and record hash. Financial audit/outbox entries commit with the posting; identity/admin actions have their own durable audit path. Export signed checkpoints to independently controlled append-only storage. No single-row mutable JSON audit array is acceptable history.

## 10. Roles and tenant isolation

Identity, BPI and FINCOIN each have separate connection roles. BPI API can manage app/commerce proposals and command ingress but not financial DML. Risk writes risk facts; gateway writes provider evidence; ledger alone posts finance; projections read minimal source data and write read models; explorer reads only public databases. Integrations manage their own scoped credentials/deliveries, not balances. Migration owner is offline/nonruntime.

Use row-level security for tenant/subject tables as defense in depth. Validate JWT/service credentials before establishing transaction-local scope; never trust a caller-provided organization ID. A pooled connection must set and clear trusted scope per transaction and fail closed if absent. Generic custom settings are not themselves an unforgeable authorization boundary against a fully compromised database role. Protect scope-setting access through trusted API/routines and enforce ownership again in posting operations. Audit bypass roles and prohibit `BYPASSRLS` for ordinary services.

Table owners and privileged roles can bypass policies in relevant circumstances; use FORCE ROW LEVEL SECURITY where appropriate and test actual role behavior. See [PostgreSQL row security](https://www.postgresql.org/docs/current/ddl-rowsecurity.html). Cross-tenant composite FKs prevent incorrect relationships independently of UI filters/RLS. Read models contain only fields allowed for their audience.

## 11. Migration plan

Use Alembic with separate version histories/connection targets per database and a release manifest listing compatible revisions. Shared templates are generated consistently but applied independently; no migration assumes a cross-database transaction. Migrations are reviewed source artifacts, executed once by a dedicated job, never by every API replica.

| Phase | Migration group | Verification gate |
|---|---|---|
| 0001 | Roles, schemas, UUID/default conventions, audit and deployment metadata | Runtime cannot acquire owner/other-domain permissions |
| 0002 | Identity tables, encrypted envelopes/verifiers, sessions and trusted subject-event transport | Credential secrecy, refresh reuse and tombstone/revocation tests |
| 0003 | Domain registries/subjects/principals/settings/operations and merchant membership | All scope FKs and allowed assets enforced |
| 0004 | Wallets/addresses/keys, accounts/balances, journals/chain/heads | Balanced posting, replay, nonce, fencing and immutability tests |
| 0005 | BPI intents/requests/QR/holds/limits/approvals/risk | Double-spend, expiry, competing request and approval tests |
| 0006 | Gateway simulator/settlement/evidence/reconciliation | Lost response, duplicate callback, terminal conflict and return tests |
| 0007 | Commerce/invoices/refunds/merchant integrations | Immutable issued totals, refund bound, secret/delivery tests |
| 0008 | FINCOIN quote/order/fill/grant/price/lot/portfolio | Atomic two-asset fill, supply, FIFO and metric tests |
| 0009 | Private reporting and isolated public projection | No private public-data fields; scope/freshness verified |

These phases group revisions; tables may be created first with cyclic FKs added in later revisions before writes are enabled. For example requests/payments and settlement/evidence terminal pointers need their target tables first. Seed only explicit sandbox network/asset registries and service principals. FINCOIN initial issuance is an auditable financial command/block, never a migration UPDATE that invents balances. No demo user passwords/secrets are committed in seeds.

**Genesis clarification:** Role 1 describes both an empty genesis proof root and fixed FINCOIN genesis supply. The concrete boot sequence keeps block 0 as the empty parameter/checkpoint block and posts the registry-pinned initial quantities in a single controlled initialization block 1, while the network is INITIALIZING. The event is named GENESIS_ISSUANCE because it implements the genesis allocation; it is not discretionary minting. It issues exactly 1,000,000 FINCOIN and 1,000,000.00 SIM_INR to the configured simulator inventory, with balanced issuance contra accounts. Unique initialization operation/asset rules prevent repetition; activate the network only after amounts, supply and chain are verified. After activation, FINCOIN minting is disabled; SIM_INR test-credit issuance follows capped grant policy. This resolves the two conceptual descriptions without changing the empty-root protocol or the intended initial quantities.

For schema changes use expand → backfill → validate → switch readers/writers → contract. Backfill in bounded, restartable batches with checkpoints and counts/digests; do not rewrite signed historical payloads. New nullable columns precede required constraints. For existing data add CHECK/FK `NOT VALID` where supported, clean/validate, then tighten nullability. Build large indexes with `CREATE INDEX CONCURRENTLY` in an explicitly nontransactional migration step, monitor failed/invalid indexes and recover before proceeding. Concurrent index builds cannot run inside a transaction block; see [PostgreSQL CREATE INDEX](https://www.postgresql.org/docs/current/sql-createindex.html).

Use lock/statement timeouts and measure lock impact on realistic sandbox datasets. For each release store old/new revisions, data counts, chain heads and backup references. Protocol/state changes need readers able to understand old versions. Roll back application code only while schema/protocol compatible; repair committed financial data with linked forward transactions, never destructive down-migrations. If a data migration fails, resume/checkpoint or forward-fix; do not drop ledger columns to make a rollback pass.

## 12. Restore and acceptance

Back up each entire domain DB with encrypted base backup plus WAL/PITR, retaining journal commitment salts and required key metadata under separate access control. Restore block/journal/balance state from the same point, fence writers, verify genesis/hash chain/remote checkpoints, replay journals, reconcile unresolved provider operations using the same IDs, rebuild projections and only then reopen writes. A restored database behind published history cannot silently discard acknowledged events. Simulator statements must remain an independent evidence source during a BPI restore exercise.

Required future tests: FK network/tenant mismatch; UUID/alternate-key uniqueness; duplicate operations/webhooks/callbacks; concurrent spend/refund/faucet limits; serialization retries; expiry/inclusion race; exact amount overflow/NaN/fraction rejection; journal balance and chain attachment; terminal status consistency; key rotation; no plaintext passwords/secrets; RLS under real roles; tombstone/retention behavior; fill/FIFO/grant return metrics; public-field allowlist; backup replay. This documentation deliverable validates design completeness and references only; it does not claim that executable migrations or PostgreSQL integration tests have run.
