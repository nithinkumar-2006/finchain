# FINCHAIN — Data Flows

Status: sandbox architecture v1.0. All amounts below are simulated. Lifecycle authority: [BPI](BPI_ARCHITECTURE.md).

## 1. Login and product access

Browser → Next.js same-origin session bridge → Identity API → credential/MFA verification → short-lived domain JWT and rotating refresh session. Tokens stay server-side behind an opaque Secure/HttpOnly browser cookie. Next.js forwards the correct audience token to BPI or FINCOIN. Each API rechecks ownership/organization membership; UI visibility is not authorization.

Creating a BPI wallet sends a BPI command and establishes only an INR sandbox wallet. FINCOIN wallet creation is independent and optional. Subject identifiers may match across products but financial account IDs and addresses cannot.

## 2. Alice sends Bob ₹500

Precondition: Alice has `100000` minor units settled, Bob `0`, no holds, and neither has a FINCOIN wallet. Alice's balance was created by a verified sandbox funding operation. The synthetic gateway asset holds `100000`; total wallet liabilities equal it.

```mermaid
sequenceDiagram
    actor Alice
    participant Web
    participant API as BPI API
    participant Signer as BPI sandbox signer
    participant Ledger as BPI ledger worker
    participant DB as BPI PostgreSQL
    participant GW as Gateway adapter/simulator
    participant Read as History / merchant projections
    Alice->>Web: Confirm Bob and simulated INR 500
    Web->>API: Create draft with idempotency key
    API-->>Web: Immutable payload digest and authorization challenge
    Alice->>Web: Authorize payload
    Web->>API: Confirm authorization / step-up
    API->>Signer: One-use grant bound to payload
    Signer-->>API: Signed transaction
    API->>DB: Risk decision and durable command
    API-->>Web: 202, payment ID and status URL
    Ledger->>DB: Lock, validate, reserve amount and nonce
    Ledger->>DB: Atomic journal + block + hold consumption + outbox
    DB-->>Ledger: Committed; chain confirmed, settlement pending
    GW->>DB: Claim committed settlement outbox operation
    GW->>GW: Submit stable operation ID to simulator
    GW->>DB: Persist verified success evidence / result command
    Ledger->>DB: Atomic settlement journal + system block + completed status
    Read->>DB: Consume outbox idempotently
    Web->>API: Read receipt / receive SSE hint then fetch
    API-->>Web: Completed; Bob available 50000
```

### Balance checkpoints (minor units)

| Step | Alice settled | Alice held | Alice available | Bob pending | Bob settled / available |
|---|---:|---:|---:|---:|---:|
| Initial | 100000 | 0 | 100000 | 0 | 0 |
| Reserved | 100000 | 50000 | 50000 | 0 | 0 |
| Included | 50000 | 0 | 50000 | 50000 | 0 |
| Settlement succeeded | 50000 | 0 | 50000 | 0 | 50000 |

No FINCOIN transaction occurs. Inclusion and settlement produce separate immutable chain events. Synthetic gateway asset remains `100000` because this is an internal transfer, not funding or redemption.

If risk denies before inclusion, no journal posts and any hold is released. If settlement definitively fails after inclusion, debit Bob pending / credit Alice settled: Alice returns to `100000`, Bob stays `0`, and the original transaction remains chain-confirmed with a linked return. If settlement is unknown, Alice remains `50000` available and Bob retains `50000` pending until a verified resolution.

## 3. Gateway failure and crash handling

| Failure point | Durable evidence | Recovery |
|---|---|---|
| Browser retries draft/authorize | Scoped idempotency row and stable payment ID | Same payload returns same resource; changed payload conflicts |
| Signer fails | Draft/grant state, no financial commit | Retry same grant/payload idempotently or reauthorize after expiry |
| Worker dies after reserve | Hold, nonce claim, command state | Lease retry includes if still valid; expiry worker releases under same locks |
| Block commit fails | No journal/block changes committed | Retry complete DB transaction under same operation ID |
| Worker dies after inclusion commit | Block, journal, settlement outbox | Resume delivery; never debit Alice again |
| Gateway accepts but reply lost | Stable operation ID, local pending operation | Query same ID; mark unknown; retry only with same ID |
| Callback duplicated | Unique provider/event ID and unique terminal posting | Return acknowledgment with no second credit |
| Callback arrives before submit response | Durable inbox with operation ID | Apply valid known-operation result; later response cannot regress state |
| Callback references unknown operation | Quarantined evidence | Investigate; never create a funded payment from a callback |
| Terminal statuses conflict | Prior terminal result and new evidence | Quarantine and alert; preserve original posting |
| Projection worker dies | Outbox and consumer cursor | Replay idempotently; UI shows freshness |

After an unknown result, periodically query operation status and statement entries. Match domain, environment, operation ID, participant references, currency and amount. Reconciliation classifies matched, missing, duplicate, amount mismatch, status conflict and orphan evidence. Only an authenticated conclusive result produces a ledger command; human reviews never directly edit balances.

## 4. QR and commerce checkout

Merchant creates an order with server-calculated amount and reserves inventory → BPI creates a single-use payment request → QR encodes an opaque signed request link → customer resolves request and verifies merchant/amount → authorizes BPI draft → payment atomically claims request → normal BPI flow.

The order waits in `PAYMENT_PENDING` while settlement is pending or unknown. A `PaymentCompleted` event marks the order `PAID`, request `PAID`, and releases fulfillment once, using event deduplication and the order's expected payment ID. A browser redirect or screenshot is never proof of payment. A late settled event after inventory expiry produces `PAID_REVIEW` and a normal linked refund or explicit fulfillment review.

## 5. Merchant payout and refunds

Maker prepares a B2P/B2B payout → server verifies merchant membership, source wallet and receiver type → checker independently authorizes the exact payload where policy requires → signer grant → risk → reserve → include → settle. Any amount/payee change invalidates prior approvals. A bulk batch aggregates independent child statuses and exposes partial success.

Refund request locks original refund totals and merchant available funds → creates linked reverse-direction payment → normal authorization/settlement path. Completed refunds update original refund totals; an unknown refund keeps its reservation. Merchant reports show gross settled sales, completed refunds, net settled sales, pending receipts and payouts separately, never treating chain inclusion as revenue settlement.

## 6. FINCOIN simulated buy and sell

```mermaid
sequenceDiagram
    actor User
    participant API as FINCOIN API
    participant Feed as Synthetic feed
    participant Ledger as FINCOIN ledger
    participant DB as FINCOIN PostgreSQL
    participant P as Portfolio projection
    User->>API: Request buy quote, quantity in FINCOIN atoms
    API->>Feed: Read fresh synthetic reference tick
    API-->>User: Price, total SIM_INR, fee, expiry, simulator label
    User->>API: Authorize exact quote and quantity
    API->>DB: Signed order command
    Ledger->>DB: Lock user and simulator inventory, validate quote/nonce
    Ledger->>DB: Atomic two-asset journal, fill, block, balances, outbox
    P->>DB: Consume fill; create FIFO lot and snapshot
    User->>API: Fetch order / portfolio
    API-->>User: Simulated fill, balances, P&L as-of time
```

Sell reverses the asset directions, with fees and exact rounding defined in [FINCOIN_ARCHITECTURE.md](FINCOIN_ARCHITECTURE.md). There is no gateway request or BPI mutation. Quote expiry or insufficient simulator inventory rejects the entire fill; no partial asset leg posts. A stale portfolio projection may lag a fill, but order detail and current ledger balance remain authoritative.

## 7. Audit and public explorer

Every sensitive request writes a domain audit record including actor, action, scope, correlation and result. Financial state transitions append audit plus outbox inside the posting transaction. Audit exporter periodically seals records into restricted append-only object storage.

Projection workers export an allowlisted set of committed block headers and salted commitments to public explorer databases. Private history joins ownership only within its domain. Explorer visitors cannot query the original private tables. A verified public inclusion proof says nothing about bank settlement; the authorized receipt carries separately labeled simulated settlement evidence.

## 8. Cross-flow acceptance scenario

Seed Alice once; repeat each command/callback ten times and crash workers at every boundary. Assert exactly one transfer debit, one recipient settlement release, balanced journals, valid chain linkage and reproducible balances. Repeat with definitive failure and unknown settlement. Then stop all FINCOIN processes and repeat the successful BPI path. Stop all BPI processes and execute a FINCOIN simulated fill. These are required future acceptance tests, not tests run as part of this documentation deliverable.
