# FINCHAIN — API Architecture

Status: sandbox contract baseline v1.0. Implement OpenAPI from these contracts before application handlers.

## 1. Routing and trust

Nginx exposes one HTTPS origin. Next.js serves pages and a same-origin session bridge. Internal routes are `/v1/identity`, `/v1/bpi`, `/v1/fincoin`, and `/v1/explorer/{domain}`. Browser session credentials are exchanged by the web bridge for audience-specific JWTs; private APIs never accept a browser-supplied owner/role as authority. Service routes such as `/internal/v1/...` are private-network only and require service identity plus scoped authorization.

Use REST/JSON for commands/queries and SSE for authenticated status hints. On reconnect, resume by bounded event cursor or refetch state; an SSE message is not financial authority. No client submits blocks, gateway success results, prices or balances as trusted facts. Generate separate TypeScript clients for BPI and FINCOIN to avoid a generic interchangeable wallet API.

## 2. Common contract

Every money-bearing resource includes `domain`, `environment: "sandbox"`, `value_kind: "simulated"`, `network_id`, and explicit asset/currency. Financial integer values are strings. Times are UTC RFC 3339 with milliseconds. IDs are opaque, not authorization secrets. Paginated lists use `items`, `next_cursor`, and `as_of_time`; page size defaults to 25 and caps at 100. History sorts by time plus ID; chain lists sort by height/index.

All resource reads check subject/organization membership. Enforce field-level permissions on support/admin responses. Reject unknown mutation fields. Frontend server actions and direct API calls are both authenticated; route hiding alone is insufficient, as described in [Next.js authentication guidance](https://nextjs.org/docs/app/guides/authentication).

Mutations that can create a financial effect require `Idempotency-Key` (128-bit random or equivalent), including draft creation, authorization, payments, refunds, faucet operations, quote execution and payouts. Store `(principal, domain, route, key)` with canonical request hash, resource ID and result. Same key/payload returns the same resource; different payload returns `409 IDEMPOTENCY_CONFLICT`. Concurrent retries use a unique insert/lock. Cache exact HTTP results for 24 hours; retain operation uniqueness for the epoch so expiry cannot permit a second posting. Returning the same mutable resource may show a newer status, never a new ID/effect.

Use `201 Created` for synchronous resource creation, `202 Accepted` for durable queued commands (with `Location` status URL), `200` for reads/completed retry responses, and `204` for successful session revocation. A `202` is not settlement or inclusion. For state-sensitive edits, require `If-Match` resource version and return `409 STATE_CONFLICT` on a stale version.

Errors use `application/problem+json` with `type`, `title`, HTTP `status`, stable `code`, `detail`, `request_id`, optional field errors and `retryable`. Use 400 malformed syntax, 401 missing/invalid authentication, 403 unauthorized action, 404 absent or inaccessible resource, 409 state/nonce/idempotency conflict, 422 invalid amount/unsupported asset, 429 limits, 503 unavailable required dependency. Never leak internal risk rules, signatures' secret material or another tenant's existence.

## 3. Identity and account endpoints

| Method / route | Input / result | Access |
|---|---|---|
| `POST /v1/identity/registrations` | Credentials and minimal profile → subject | Rate-limited public |
| `POST /v1/identity/sessions` | Credential proof → session/MFA challenge | Rate-limited public |
| `POST /v1/identity/sessions/refresh` | Rotating refresh credential → scoped tokens | Session bridge |
| `DELETE /v1/identity/sessions/{id}` | Revoke session family | Self or security role |
| `GET /v1/identity/me` | Profile and sessions summary | Self |
| `POST /v1/identity/mfa/enrollments` | WebAuthn/TOTP enrollment challenge | Recent authentication |
| `POST /v1/identity/mfa/verifications` | Enrollment/step-up proof | Bound challenge owner |
| `POST /v1/identity/recovery` | Begin controlled recovery | Enumeration-resistant |
| `POST /v1/bpi/wallets` | Owner context → BPI wallet creation command | Self / merchant owner |
| `GET /v1/bpi/wallets/{id}` | Settled, held, available, pending and version | Wallet owner/member |
| `POST /v1/bpi/merchants` | Organization registration | Authenticated applicant |
| `GET/PATCH /v1/bpi/merchants/{id}` | Profile/configuration | Scoped merchant permissions |
| `POST/DELETE /v1/bpi/merchants/{id}/memberships` | Grant/revoke role | Merchant owner, audited |

Merchant verification status is a sandbox review label, not regulatory KYC approval. Deleting a membership endpoint identifies the membership in its request contract and cannot revoke the last owner without an approved replacement.

## 4. BPI payment endpoints

| Method / route | Contract |
|---|---|
| `POST /v1/bpi/payment-drafts` | Source wallet, recipient/request, amount, currency → immutable draft, digest, nonce candidate, expiry |
| `POST /v1/bpi/payment-drafts/{id}/authorizations` | Digest, confirmation/step-up reference, version → signed submission command and payment ID |
| `GET /v1/bpi/payments/{id}` | Authorized receipt with all three status axes, amount, timestamps, proof references |
| `GET /v1/bpi/payments` | Owner-scoped history; type/status/time filters and cursor |
| `POST /v1/bpi/payments/{id}/cancellations` | Pre-inclusion cancellation command; conflict if inclusion already won |
| `POST /v1/bpi/payment-requests` | Immutable amount/currency/payee/expiry and optional order → request and QR payload |
| `GET /v1/bpi/payment-requests/{token}` | Resolve signed opaque request; limited recipient display, expiry and amount |
| `POST /v1/bpi/payment-requests/{id}/cancellations` | Payee authorized cancel, subject to active attempt state |
| `POST /v1/bpi/payments/{id}/refund-drafts` | Amount/reason → linked reverse payment draft; later normal authorization |
| `POST /v1/bpi/payout-batches` | Merchant child payouts → batch/draft IDs, no all-or-nothing promise |
| `POST /v1/bpi/payouts/{id}/approvals` | Checker approval of immutable digest; final approval triggers authorized command |
| `GET /v1/bpi/events` | Subject/merchant scoped SSE hints |
| `POST /v1/bpi/sandbox/funding` | Capped test amount/wallet → gateway funding operation |
| `POST /v1/bpi/sandbox/redemption-drafts` | Test redemption amount → draft for explicit authorization |
| `POST /v1/bpi/sandbox/redemption-drafts/{id}/authorizations` | Confirm digest → signed redemption command |
| `GET /v1/bpi/sandbox/operations/{id}` | Owner-scoped simulator operation status |

Payout approvals are independent actor grants, not reusable signatures. Only the final authorized payload is signed. Requests permit bounded anonymous resolution via opaque tokens; creating or paying them requires authentication. Resolution must not expose wallet history or arbitrary address lookup.

Illustrative create-draft body:

```json
{
  "sender_wallet_id": "wallet-alice",
  "receiver_address": "bpi_sbx_bob",
  "amount_minor": "50000",
  "currency": "INR"
}
```

Payment status response after inclusion (identifiers abbreviated):

```json
{
  "payment_id": "payment-1",
  "domain": "BPI",
  "environment": "sandbox",
  "value_kind": "simulated",
  "network_id": "finchain-bpi-sandbox-1",
  "amount_minor": "50000",
  "currency": "INR",
  "payment_type": "P2P",
  "business_status": "SETTLEMENT_PENDING",
  "chain_status": "CONFIRMED",
  "settlement_status": "PENDING",
  "transaction_hash": "abbreviated-example-only",
  "block_height": "42",
  "recipient_spendable": false,
  "version": 4
}
```

Clients poll the same resource until terminal or use SSE hints. HTTP timeout must prompt status lookup with the original ID/key, not a freshly created payment.

## 5. Merchant, commerce, reporting and explorer

| Route family | Capabilities |
|---|---|
| `/v1/bpi/merchants/{id}/dashboard` | Settled sales/refunds/net, pending amounts, payout totals; bounded date range |
| `/v1/bpi/merchants/{id}/products` | Authorized product create/edit/list; inventory version checks |
| `/v1/bpi/orders` and `/{id}` | Create server-priced order and inspect own order |
| `/v1/bpi/orders/{id}/checkout` | Create/reuse single active request for fixed total |
| `/v1/bpi/orders/{id}/fulfillments` | Merchant action only after verified paid state |
| `/v1/bpi/disputes` | Open/view scoped case; resolution creates commands, not balance edits |
| `/v1/bpi/reports/exports` | Async export job; scoped signed download link and expiry |
| `/v1/explorer/{domain}/blocks` and `/{height}` | Public redacted headers, pagination |
| `/v1/explorer/{domain}/transactions/{hash}/proof` | Public commitment/inclusion proof only |

For route families, use GET for reads, POST for resource/actions, PATCH with version checks for mutable catalog data. Never offer PATCH for journal lines or committed transactions. Export text fields must neutralize spreadsheet formula injection, and download authorization must be rechecked before issuing a short-lived link.

## 6. FINCOIN endpoints

| Method / route | Contract |
|---|---|
| `POST/GET /v1/fincoin/wallets` | Independent creation/list, no BPI owner substitution |
| `GET /v1/fincoin/wallets/{id}` | FINCOIN/SIM_INR balances, precision, test network |
| `POST /v1/fincoin/transfer-drafts` | Exact atom quantity and recipient → signed-payload draft |
| `POST /v1/fincoin/transfer-drafts/{id}/authorizations` | Bound confirmation → queued transfer |
| `GET /v1/fincoin/transactions/{id}` | Scoped test transfer/fill receipt |
| `POST /v1/fincoin/quotes` | Side, quantity atoms → fixed synthetic price/fees/expiry |
| `POST /v1/fincoin/orders` | Quote ID and explicit authorization reference → queued simulated order |
| `POST /v1/fincoin/quotes/{id}/authorizations` | Confirm quoted digest / step-up → short-lived order grant |
| `GET /v1/fincoin/orders/{id}` | Order state, immutable fill if any |
| `POST /v1/fincoin/orders/{id}/cancellations` | Pre-fill cancellation command |
| `GET /v1/fincoin/portfolio` and `/pnl` | Subject-scoped holdings and FIFO analytics with freshness |
| `GET /v1/fincoin/market/candles` | Bounded interval/range, synthetic source and gaps |
| `POST /v1/fincoin/sandbox/grants` | Capped SIM_INR issuance or inventory FINCOIN test grant |

FINCOIN requests cannot name BPI wallet IDs or use `currency: INR` as a quote asset. APIs reject cross-domain identifiers even when the subject owns both accounts.

## 7. Internal gateway and admin contracts

`POST /internal/v1/bpi/gateway/events` accepts authenticated raw callback bytes, provider event/operation IDs, amount/currency, status, environment, timestamp and signature metadata. Verify signature before parsing into trusted evidence; deduplicate by provider/event and check body hash. Return 202 only after durable inbox insertion. Unknown or conflicting events are quarantined. The callback handler has no journal write credentials. Simulator responses cannot redirect the adapter to arbitrary URLs.

Domain admin families `/v1/{domain}/admin/risk-cases`, `/pauses`, `/audit-events`, `/reconciliation-cases`, `/correction-proposals` require explicit scopes and MFA. Approving a correction requires a different actor and a reason; execution submits a domain ledger command. BPI risk review endpoints do not approve FINCOIN trades. There is no admin “set balance” endpoint.

## 8. Limits, versioning and verification

Default edge body cap 256 KiB; signed transaction payload cap 16 KiB. Bulk payouts cap at 100 items and receive child-level validation. Apply rate limits by IP, subject, wallet and merchant; expensive export/chart queries have time-window caps and asynchronous jobs. Treat limits as tunable sandbox defaults and instrument rejections.

Version APIs by major path; version commands, events and signed schemas independently. Additive optional response fields are compatible; signed-payload changes require a protocol version. Publish OpenAPI, error catalog, role matrix and canonical fixtures in the future contracts package. Contract tests must cover authorization, string amounts, idempotency conflicts, all status combinations and no cross-domain asset routes.
