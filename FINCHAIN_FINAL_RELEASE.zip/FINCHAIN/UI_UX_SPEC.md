# FINCHAIN — UI/UX Specification

Role 2 · Version 1.0 · Completed 2026-09-14 · Status: interface design baseline, not an implemented application.

## 1. Purpose and reading order

Design a premium, dark-mode-first web product for demonstrations, client review, merchant onboarding and future engineering. The product is a software sandbox. Usability, accurate status and calm presentation take priority over promotional effects.

All twelve Role 1 documents were reviewed: [master](MASTER_ARCHITECTURE.md), [context](SYSTEM_CONTEXT.md), [components](COMPONENT_MAP.md), [flows](DATA_FLOW.md), [security](SECURITY_ARCHITECTURE.md), [database](DATABASE_ARCHITECTURE.md), [API](API_ARCHITECTURE.md), [blockchain](BLOCKCHAIN_ARCHITECTURE.md), [BPI](BPI_ARCHITECTURE.md), [FINCOIN](FINCOIN_ARCHITECTURE.md), [deployment](DEPLOYMENT_ARCHITECTURE.md) and [regulatory boundaries](REGULATORY_BOUNDARIES.md). Role 2 adds interface contracts where the new brief requires capabilities not yet defined by Role 1; it does not silently modify those documents.

| Deliverable | Authority |
|---|---|
| [PAGE_MAP.md](PAGE_MAP.md) | Complete page hierarchy, routes, access and navigation |
| [USER_FLOWS.md](USER_FLOWS.md) | Journeys, payment lifecycle, recovery and warning copy |
| [DESIGN_SYSTEM.md](DESIGN_SYSTEM.md) | Visual tokens, typography, controls and accessibility |
| [COMPONENT_LIBRARY.md](COMPONENT_LIBRARY.md) | Component contracts, variants and reuse |
| [DASHBOARD_SPEC.md](DASHBOARD_SPEC.md) | Consumer dashboard, pay, receive, history, wallet, commerce and settings |
| [MERCHANT_UI_SPEC.md](MERCHANT_UI_SPEC.md) | Merchant onboarding, operations, refunds and integrations |
| [FINCOIN_UI_SPEC.md](FINCOIN_UI_SPEC.md) | FNC simulator, charts, portfolio and metric definitions |
| [EXPLORER_UI_SPEC.md](EXPLORER_UI_SPEC.md) | Public proof explorer and private address view |
| [ADMIN_UI_SPEC.md](ADMIN_UI_SPEC.md) | Domain-scoped operations, fraud and audit |
| [RESPONSIVE_SPEC.md](RESPONSIVE_SPEC.md) | Desktop, tablet, mobile and interaction adaptation |

This file owns product principles, public pages and cross-cutting scope decisions. Screen IDs in PAGE_MAP are the handoff identifiers. Domain specifications own behavior; DESIGN_SYSTEM owns presentation. A visual component cannot override authorization or financial lifecycle rules.

## 2. Product principles

1. **Two clearly named products.** BPI Payments uses a restrained mint accent; FINCOIN Simulator uses muted violet. Text labels and persistent context carry meaning even without color. Never combine balances, charts, funding sources or checkout choices across them.
2. **Trust through evidence.** Show the real sandbox state, data source and freshness. No invented customers, partner logos, throughput counters, security certifications or positive-only charts.
3. **Financial clarity.** BPI available, reserved and incoming-pending values are separate. A block confirmation cannot trigger a successful-payment screen. FINCOIN trading uses SIM_INR, never a BPI funding selector.
4. **Progressive detail.** Prioritize recipient, amount, business outcome and next action. Put hashes, signatures and block proof details in expandable sections or the explorer.
5. **Calm security.** Explain relevant safe reasons and actions. Do not shame users, use alarmist imagery, or present an internal risk score as a guarantee.
6. **Responsive without losing evidence.** Mobile changes layout, not settlement meaning, fees, disclosure, permissions or required review.

## 3. Decisions reconciling the new brief

| Brief item | Final design decision | Implementation implication |
|---|---|---|
| Risk check before Confirm | Before Confirm, show recipient/amount review and any safe preliminary context. The authoritative risk check runs after authorization/signing, as Role 1 requires | No premature “risk passed”; review/denial can occur after confirmation |
| “Transaction Successful” | Use “Transaction successful” only with subtitle “Simulated settlement completed” after `COMPLETED` | Chain-only confirmation uses “Recorded on BPI — settlement pending” |
| P2P/P2B/B2P/B2B field | Show read-only server-derived type; consumer/merchant source context determines allowed types | Do not let a type dropdown bypass business permissions |
| BPI address / username | Address is baseline; exact opt-in username lookup is extension UX-E01 | Never expose a searchable global customer directory |
| Payment note | Optional private off-chain note via UX-E02; never changes signed amount or appears publicly | Hide note input until private metadata contract exists |
| Deposit / Withdraw | Labels “Deposit — sandbox” and “Withdraw — sandbox”; helpers explain test funding/redemption | No real account/card form or live payout promise |
| FNC ticker | Display ticker `FNC`; asset identifier remains `FINCOIN` | UI mapping only; signatures/API assets are not renamed |
| Market cap, volume, Return % | Explicitly labeled simulation metrics, with precise definitions in FINCOIN_UI_SPEC | Read-only metric extensions; unknown/unsupported values show a reason, not zero |
| Public address details | The architecture exposes no customer addresses publicly. Provide a private, owner-authorized address details screen and a public privacy explanation | Do not add public wallet/address search or history |
| Active validators | Show “Authorized block producer: 1” per configured network, with honest activity status; followers separate | No invented decentralization or staking |
| Recharge/utilities/travel/subscriptions | Category pages exist. Only clearly described one-time sample catalog items are purchasable where available | No actual biller, booking, recharge or recurring mandate action |
| API credentials and webhooks | Fully specified sandbox-only extension workflow in MERCHANT_UI_SPEC | No fake keys, local-only “saved” settings or fabricated delivery results |

Existing architecture behavior remains the baseline. New read-only metrics and integration contracts below are design requirements for the future backend. Until a required contract is implemented, show an honest unavailable state or explanatory preview; never simulate a successful backend operation just to make a demo clickable.

## 4. Shared shells and branding

Public shell: 72 px header, FINCHAIN wordmark, Products menu (BPI / FINCOIN), Merchants, Developers, Explorer, Security; About and Contact remain in footer and mobile menu. Login is tertiary; Launch FINCHAIN is primary. Hero includes the exact descriptor “Public Payment Blockchain + Digital Asset Ecosystem” with nearby “Software sandbox · Simulated value”.

Consumer shell: 240 px sidebar, 64 px top bar, 32 px content inset on desktop. Persistent “BPI Payments · Sandbox” context. FINCOIN navigation opens its independent sub-shell with a visible “Back to BPI” link; there is no combined financial overview. Merchant shell displays selected organization, outlet and role. Admin shell displays selected domain and staff role, visually separated from consumer/merchant context.

Brand treatment: typographic FINCHAIN wordmark with a simple linked-node geometric mark, pending final brand asset approval. No coin mascot, metallic token spin or animated profit counters. Network lines may decorate public illustrations at low contrast and must not look like actual telemetry. User data and action cards remain static except for meaningful state updates.

## 5. Landing page — PUB-01

Desktop hero uses a 7/5 split: heading and actions left, a labeled conceptual two-domain diagram right. Mobile stacks copy, CTAs, then the diagram. Suggested hero H1: “Blockchain-native financial infrastructure for payments, commerce and digital assets.” FINCHAIN wordmark/descriptor appears above it. Supporting copy: “Explore BPI payment workflows and an independent FINCOIN simulator in one clearly separated ecosystem.”

CTA routing: **Launch FINCHAIN** → consumer dashboard if signed in, otherwise login with safe return path; **Explore BPI** → `/bpi-network`; **Explore FINCOIN** → `/fincoin`. Primary button is filled; the two exploration actions are secondary links/buttons, not three competing filled buttons.

| Order / section | Content and composition | Interaction and truth rule |
|---|---|---|
| 1 Hero | Wordmark, exact descriptor, primary message, three CTAs, conceptual two-domain diagram | Label diagram “Conceptual architecture”; no fake live balances |
| 2 What is FINCHAIN? | Short definition plus two equal product panels | Each panel names independent purpose; no “all assets” wallet graphic |
| 3 BPI Overview | Simulated INR payments, requests, merchant acceptance | “No FINCOIN purchase required”; link BPI details |
| 4 FINCOIN Overview | Test wallet, synthetic chart, simulated trading | Chart is labeled illustrative if no feed; link simulator overview |
| 5 How BPI Payments Work | Authorize → risk/validation → chain record → simulated settlement → recipient available | Desktop step row/mobile ordered list; settlement is visible |
| 6 Security & Fraud Prevention | Authentication, transaction authorization, risk review, audit trails | Describe designed controls; no claim of audited/certified protection |
| 7 Merchant Infrastructure | QR requests, invoices, payouts, settlement visibility | Annotated merchant wireframe illustration; merchant CTA |
| 8 Blockchain Transparency | Signed blocks and privacy-preserving public proofs | Link public explorer, explain private payment details remain private |
| 9 Commerce Ecosystem | Sample catalog and BPI checkout | No real biller/airline/subscription logo unless integration exists |
| 10 Developer APIs | Versioned sandbox APIs, idempotency and asynchronous statuses | Link documented contract; examples labeled example, not executable API console |
| 11 FINCOIN Investment Layer | Heading “Explore the FINCOIN investment simulator”; holdings and P&L education | State synthetic prices, no guaranteed returns, separate SIM_INR credits |
| 12 Regulatory / Prototype Disclaimer | Short readable panel, not tiny footnote | Exact sandbox copy below; link full disclosure |
| 13 Footer | Products, company, developer/security/explorer, contact and disclosures | Real destinations only; no invented legal entity/address/social links |

Disclosure copy: “FINCHAIN is a software prototype. BPI balances and settlement are simulated. FINCOIN trades use test assets and synthetic prices. No real-money custody, RBI authorization, bank status or guaranteed returns are claimed.”

Landing has no request-time dependency on financial APIs for its static sections. If an optional explorer snippet cannot load, show “Network data unavailable” within that section; the rest of the page remains usable. Omit promotional counters entirely unless backed by a defined, timestamped source.

## 6. Other public pages

All pages share header, footer, sandbox context, one H1 and a clear primary next step. Informational sections are readable without login.

| ID / page | Detailed screen composition | Primary interaction / exceptional states |
|---|---|---|
| PUB-02 About | Mission, two-domain diagram, prototype scope, current capabilities and future decisions | Explore BPI; do not invent team biographies, dates, traction or partners |
| PUB-03 BPI Network | BPI definition, simulated fiat gateway diagram, four payment types, explicit no-FINCOIN rule, chain-vs-settlement comparison | Launch payments; conceptual regulated route clearly separated from currently simulated route |
| PUB-04 FINCOIN | FNC identity, simulation explanation, wallet/trade/portfolio preview, separate-value notice and risk notice | Open FINCOIN Simulator, which may require optional enrollment; no BPI funding CTA |
| PUB-05 Security | Account security, signing custody explanation, privacy/explorer boundaries, risk review and reporting guidance | Open account Security or Contact; control status says “Design requirement” until implementation evidence exists |
| PUB-06 Merchant Solutions | Accept requests, reconcile settlements, refund, inspect invoices; small cashier/finance/owner comparison | Start merchant onboarding; no promise of live acquiring or bank settlement |
| PUB-07 Developers | Left contents rail: overview, auth, BPI, FINCOIN, idempotency, statuses, errors, webhooks readiness, sandbox limits | Download/read actual contract; sample snippets labeled; “Try API” only when connected endpoint exists |
| PUB-08 Explorer | Domain selector, search hashes/heights, blocks/transactions and honest network stats | See EXPLORER_UI_SPEC; private data never leaks into public shell |
| PUB-09 Contact | Topic, reply address, message, purpose/retention notice; no bank or identity document upload | Submit only via durable UX-E03 contract; success after acknowledgment; validation preserves entered message |
| PUB-10 Login | Narrow form, email/username credential identifier, password reveal, recovery, MFA challenge, register link | Support paste/autofill; generic invalid-login error; validated internal return URL |
| PUB-11 Register | Display name, email, password, truthful sandbox/terms acknowledgment; optional merchant onboarding next | No FINCOIN requirement; policy links must resolve before registration acceptance is enabled |
| PUB-12 Disclosures | Full prototype and financial-boundary explanation, data use and custody explanation | Link related architecture-informed explanations; distinguish draft policies from approved published terms |
| PUB-13 Recovery | Credential recovery form, generic confirmation, challenge/new password, completion | Expired link offers fresh request; no account enumeration or fake email delivery |

Contact form fields: topic (Product / Merchant / Developer / Security), reply email, message capped at 2,000 characters, optional organization display name. Warn against entering passwords, keys or banking details. No marketing subscription preselection. Submission means FINCHAIN recorded a request, not that a human has replied. In a demo without delivery, use “Contact form unavailable in this demonstration”; do not show a pretend Sent state.

Login/register layout: max 440 px form width, centered on mobile; desktop optionally uses a calm product explainer side panel. MFA methods have labels, recovery alternatives and visible error descriptions. TOTP supports paste of the full code and mobile OTP autofill. Recovery codes are shown once after successful generation with copy/download and acknowledgment; no seed phrase screen because signing is custodial in this sandbox.

## 7. Global interaction and copy rules

Primary commands name their financial intent: “Confirm simulated ₹500.00 payment”, “Buy 2 FNC — simulation”, “Approve payout”, “Submit sandbox refund”. Review includes source account, recipient, amount, asset, fee, total and simulation context before authorization. Escape/back never undoes a submitted payment. Post-submit close text says “You can leave this page. Track this payment in Transactions.”

Loading is a real unresolved request, not a fake progress percentage. Render shape-matched skeletons for reads; submit button shows a busy label and blocks repeat click but the backend still requires idempotency. Network timeouts show an uncertain state and retrieve the original operation. Do not optimistically debit/credit wallets, issue keys, acknowledge webhooks or show trade fills.

Zero, unknown, empty and unavailable are distinct: `₹0.00` for an authoritative zero, “No activity yet” for an empty history, “—” plus reason for unavailable values, and “Updated at …” for retained stale data. Required actions get a durable banner or inline message, not only a disappearing toast. Dates use the selected display zone with a visible zone label; explorer defaults to UTC. Amounts retain full precision on review/receipts even if overview cards abbreviate.

Payment notes, usernames and recipient display names are private scoped metadata. Risk reasons shown to users must be explicitly approved safe categories. Tooltips add explanation, never hide mandatory fees, blocked-action reasons or disclosure.

## 8. Contract readiness and extensions

`A` means architecture-defined contract, not implemented functionality. `E` means Role 2 extension requiring backend contract/schema agreement before wiring. `D` means excluded capability with an explanation-only screen. No screen may manufacture success when an A or E endpoint is absent.

| ID | Required extension | Contract and safety requirement |
|---|---|---|
| UX-E01 | Exact opt-in BPI username resolution | Authenticated exact match → permitted display name, recipient type, address and opaque confirmation token; throttled, no prefix enumeration or contact disclosure; consent/revocation settings required |
| UX-E02 | Private payment note | Private draft metadata, 140 characters, access scoped to participants; sanitized text, excluded from public chain/QR; attached to stable payment ID |
| UX-E03 | Contact intake and published policy content | Durable idempotent request acknowledgment; restricted message storage, actual configured delivery; versioned policy URLs/content rather than fabricated terms acceptance |
| UX-E04 | FINCOIN derived metrics | Timestamped market simulation stats, remaining purchased basis and explicitly defined realized-return metric; see FINCOIN_UI_SPEC |
| UX-E05 | Merchant API credentials/webhooks | Scoped credentials, one-time secret, rotation/revocation; verified destinations and signed delivery/test evidence; see MERCHANT_UI_SPEC |
| UX-E06 | Aggregate dashboards and explorer stats | Domain-scoped count/sum/window definitions, source freshness, denominators; no client-inferred totals from a paginated page |
| UX-E07 | Private wallet details / profile preferences / customer/invoice lists | Object-level access, opt-in aliases, minimal customer relationship projection, invoice state/details and server persistence; see domain screens |
| UX-E08 | Safe preliminary payment context | Optional nonsensitive recipient/device prompts before confirmation; cannot replace the authoritative post-signature risk decision |
| UX-E09 | Admin operational read models and actions | Domain-scoped counts, review/audit queries, pauses and governed validator/key-change proposals; see ADMIN_UI_SPEC |

The engineer must reconcile E contracts into Role 1 API/data documentation before implementing dependent interactions. Baseline address-only payments, existing receipts and synthetic fills remain fully specified without username, note, contact or webhook extensions. Store mock datasets only in an explicitly labeled isolated preview/test mode; never fall back to them after a live sandbox API error.

## 9. Handoff acceptance

Every page in PAGE_MAP must have its content, permissions, action outcomes and loading/empty/error behavior specified here or in its owning document. Validate BPI with FINCOIN disabled, chain-confirmed-but-unsettled receipts, new users with zero funds, simulated losses, rejected/expired trades, merchant partial payouts, failed webhooks, unknown explorer hashes and admin access denial.

Before frontend acceptance: compare desktop/tablet/mobile against layout rules; test keyboard/screen reader flow, accessible labels and contrast; confirm all primary actions invoke real authorized contracts or show explicit unavailability; verify sandbox markers survive receipts/exports; inspect that no backend error is presented as a financial failure or success without authoritative evidence. This documentation has no frontend code, rendered screen implementation or claim of passed application usability testing.
