# FINCHAIN — Security Architecture

Status: sandbox architecture v1.0. Controls are requirements for implementation, not a security certification.

## 1. Threat model

Assets: credentials/MFA secrets, user/merchant permissions, signing keys, simulated balances, immutable journals/blocks, gateway evidence, portfolio basis, private metadata and audit trails. Adversaries include malicious users/merchants, stolen sessions, compromised browser scripts, replaying network clients, compromised services, and privileged insiders. Sandbox value does not remove the need to protect actual user credentials and personal data.

| Threat | Required controls | Verification |
|---|---|---|
| Cross-user or cross-merchant access | Object ownership and organization scope on every read/write, explicit response fields | Swap IDs and organization contexts across all endpoints |
| BPI/FINCOIN crossover | Separate DB roles, keys, service audiences, networks and financial schemas | Attempt every cross-domain credential/ID combination |
| Account/session takeover | Strong password hashing, MFA/step-up, session rotation/revocation, rate limits | Credential stuffing and session replay tests |
| Transaction tampering/replay | Canonical signed payload, domain/network binding, expiry, one-use grant, nonce and idempotency | Alter every signed field and replay across epochs |
| Double spend/race | Ledger-only writes, serializable transactions, locks, holds, unique operations | Concurrent spend/refund/nonce tests |
| Gateway spoof or duplicate credit | Raw-body signature, timestamp window, operation binding, inbox dedupe, reconciliation | Duplicate, reordered, conflicting, wrong-amount callbacks |
| Insider history/balance change | No balance editor; maker/checker corrections, append-only DB roles, remote checkpoints | Privilege tests and tamper detection exercises |
| Public data leakage | Separate allowlisted explorer projection and masked support views | Schema allowlist and low-entropy commitment review |
| Queue/cache loss | PostgreSQL durability and replay; Redis not authoritative | Flush cache, kill workers, restore and replay |

Object-level authorization is essential even when IDs are unguessable; this risk is described in [OWASP API1:2023](https://api-security.owasp.org/editions/2023/en/0xa1-broken-object-level-authorization/).

## 2. Authentication and session handling

Hash passwords using Argon2id with parameters benchmarked on the deployed hardware. Use generic login/recovery responses, rate limiting, breached-password screening where appropriately configured, and no secrets in logs. Identity data belongs only in the identity database.

Access JWTs expire after five minutes by default. Use an asymmetric allowlisted algorithm and verify signature, issuer, audience, expiry, issued-at and not-before. Include `sub`, `sid`, `jti`, resource audience, scoped permissions and authentication time/assurance. Never accept algorithm downgrades or trust JWT-supplied key URLs. Signing-key IDs resolve only through configured issuer keys.

Refresh tokens are high-entropy opaque values stored as hashes, rotated on each use with a family chain. Atomic reuse detection revokes the family. The web bridge serializes concurrent refreshes per session; a reused old token is not silently accepted as a grace mechanism. Password reset, suspected compromise and logout revoke applicable sessions. Refresh rotation and replay detection follow the approach described in [OAuth security best current practice, RFC 9700](https://www.rfc-editor.org/rfc/rfc9700.html).

The browser receives an opaque session cookie only: Secure, HttpOnly, SameSite=Lax, narrow scope, bounded lifetime. Access/refresh tokens are held in encrypted server-side identity session storage, never localStorage. Cookie-authenticated mutations require CSRF tokens plus Origin validation; SameSite alone is not the complete control. Apply strict CORS allowlists. Personalized pages/API responses use private/no-store caching to prevent one user's history being served to another.

MFA architecture supports WebAuthn first, TOTP fallback and hashed single-use recovery codes. Require MFA for staff and merchant payout approvers before enabling those actions. Step-up binds a challenge to the exact transaction digest; recent login alone does not authorize an altered amount. WebAuthn offers phishing resistance through origin binding, as discussed in [NIST authentication guidance](https://pages.nist.gov/800-63-4/sp800-63b/authenticators/). Do not claim a particular assurance certification from the presence of MFA alone.

Check live session/account revocation and current membership for new financial grants. Cached JWT roles are insufficient after merchant-role removal. Low-risk reads may accept an unexpired token per policy; no new financial authorization during unavailable revocation/permission checks. Authentication/authorization outages do not stop securely verified settlement completion of previously included obligations.

## 3. Authorization and privileged access

Use RBAC for action classes and attribute checks for ownership, merchant/outlet, domain, transaction limits, authentication freshness and account state. Service identity is additional to end-user authorization. Database row security can add tenant protection, but APIs still enforce checks and workers use explicit scopes.

| Role | Allowed | Forbidden |
|---|---|---|
| Consumer | Own wallets, requests, authorized payments, optional own FINCOIN | Merchant payouts, another user's receipt |
| Merchant cashier | Outlet requests and receipts | Role grants, refunds/payouts unless explicitly assigned |
| Merchant maker | Prepare immutable payout/refund proposal | Approve own proposal when checker required |
| Merchant checker | Approve exact proposal within limits | Change payload during approval |
| Risk reviewer | Read scoped signals, decide case | Sign as user or change funds |
| Support | Masked troubleshooting views | Keys, raw MFA data, money mutation |
| Domain operator | Pause, monitor, approved configuration | Cross-domain authority or direct balance update |
| Auditor | Read protected evidence | Mutation |

Privileged correction proposals specify domain, affected operation/accounts, balanced entries, reason, evidence and expected result. Require two independent authorized identities and produce a new system transaction. Separate service code path validates all accounting invariants even after approval. Emergency controls pause new commands, not erase history. Record reason, actor and expiry of pauses; recovery from pause is audited.

## 4. Signing and key lifecycle

Initial signing is **custodial sandbox signing**. The user authorizes; a private signer service holds the transaction key. It must not be described as noncustodial or proof that a user's private key stayed on their device. A future client-held wallet changes recovery, UX and threat assumptions and needs a separate decision.

Use distinct keys for identity JWTs, each domain's wallet signing, validator blocks, gateway callbacks, audit checkpoints and encryption. Signer requests contain a one-use grant ID, payload hash, subject, network, key ID and expiry. The signer validates trusted issuer/audience, grant scope and exact hash, records grant consumption durably, and returns the same signature for an identical retry. Reject attempts to use a consumed grant for another payload.

Use a managed secret/key service with envelope encryption. For local development only, mount encrypted test keys as secret files; never commit plaintext keys or use production credentials. A managed vault holding encrypted Ed25519 keys does not necessarily perform Ed25519 signing inside an HSM; verify provider capability and document where plaintext key material exists in process memory. A dedicated private signer confines that exposure.

Rotation records new key bindings with effective block height and old/new approval evidence. Keep historical public keys for verification. Lost/compromised wallet-key recovery freezes new signing, performs account recovery and independent approval, and publishes a recovery binding event. Validator compromise pauses new blocks, checks independent checkpoints and follows an incident recovery decision; do not hide it by silently rotating and resuming.

## 5. Application, gateway and data defenses

Enforce CSP, output escaping, safe rich-text policies, parameterized SQL and request size/schema limits. Validate upload MIME/content and isolate uploaded objects if uploads are later enabled. Restrict server outbound destinations to prevent SSRF. Merchant notification webhooks, if added, require destination verification, SSRF-safe resolution, signed events and retry limits. They cannot become a money movement trigger from arbitrary responses.

Gateway callbacks use authenticated service transport plus HMAC or asymmetric raw-body signature, provider key ID, timestamp (five-minute ingress window) and event ID. Reconciliation queries can recover older legitimate outcomes outside that callback window. Always bind evidence to an existing operation, exact amount/currency/network and expected participants. Store minimal encrypted evidence and body digest; never trust a browser's gateway redirect.

Encrypt transport and storage, including backups. Keep names, phone/email, addresses, devices, risk signals and invoices off-chain. Use per-record/envelope encryption where appropriate and a retention/deletion workflow for private data. Salt low-entropy audit/journal commitments; unsalted hashes of phone numbers or amounts are not anonymization. Pseudonymous wallet metadata can still be personal data.

## 6. Fraud operations and audit

Risk rules are deterministic and versioned initially. Store input snapshot references, rule outcomes, decision, score, expiry, reviewer and correlation. No ML model is necessary for v1. Later models require evaluation of false positives, drift, bias, explainability and fallback. Public APIs return safe reason categories, not a map of evasion thresholds.

Audit login/recovery, membership and policy changes, signing grants, key lifecycle, risk decisions, financial transitions, gateway evidence, reconciliation, privileged reads/exports and administrative actions. Audit events include event ID, UTC time, actor/service, subject/scope, resource, action, result, reason, request/correlation ID, before/after digests where safe, and previous-event hash. Never log passwords, tokens, private keys, raw MFA factors or unrestricted request bodies.

Financial audit events commit with the financial transition. Security failures use a separate durable append-only path; if audit durability is unavailable, privileged/new financial actions fail closed. Export signed audit batches to separately controlled append-only storage and alert on gaps. Hash chaining detects tampering only relative to a trusted checkpoint; it does not make a compromised host inherently immutable.

## 7. Delivery and incident gates

CI must check secrets, dependency vulnerabilities, container contents, authorization contracts, canonical signature vectors, accounting properties and known web attack surfaces. Use locked dependencies and review migrations. Before exposing a cloud sandbox: enforce staff MFA, TLS, private databases, sandbox egress restrictions, redacted explorer, backup restore exercise, least-privilege credentials and incident contacts.

Incident sequence: contain affected domain/credential; preserve evidence; pause new authorization where needed; keep reconciliation and safe terminal processing running where possible; rotate/revoke compromised material; verify journals/chain/checkpoints; reconcile uncertain operations; restore scoped service; document impact and follow-up. Notification and legal obligations must be assessed for the actual deployment, not invented by the prototype.
