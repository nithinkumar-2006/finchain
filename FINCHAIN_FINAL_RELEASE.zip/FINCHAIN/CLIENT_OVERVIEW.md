# Client overview

The sandbox implements account registration, email verification, login/logout, refresh rotation, password recovery, TOTP enrollment and session revocation. Consumer, merchant, admin, compliance and support roles exist; financial domain grants are separate from identity roles. Support does not receive a broad financial administrator permission.

| Area | Implemented behavior |
|---|---|
| BPI | Independent simulated INR wallets; P2P/P2B/B2P/B2B; signed instructions; history; QR requests; reviewed redemption; definitive and unknown settlement outcomes |
| Merchant | Onboarding; scoped team roles; independent payout approval; invoices; refunds; stock/catalog; reports; API credentials; signed local webhooks |
| Commerce | Sample categories, one-merchant checkout, stock reservation, payment request, settlement-linked order status |
| FINCOIN | Separate wallet, fixed test issuance, test grants, transfer, synthetic quotes, buy/sell, FIFO portfolio and P&L |
| Operations | Per-domain metrics, audit trail, network pause/resume, wallet restriction, risk-case cancellation/rejection |
| Explorer | Public block headers, hashes, signatures, commitments and Merkle inclusion proofs |
| Security | Password hashing, encrypted identity fields, opaque secure cookies, MFA, CSRF checks, strict input schemas, database privileges and append-only records |

Use BPI first without opening a FINCOIN wallet. Deposit a test amount, send to another test wallet, and watch pending value become available only after the simulator confirms settlement. FINCOIN balances use FNC and SIM_INR, neither of which is exchangeable with BPI INR here.

This is an engineering sandbox, not a commercially authorized payment system. Read the release limitations and test evidence before evaluating it for a pilot. Physical camera hardware, the complete Docker stack, independent penetration testing and real-provider integration have not been certified by this delivery.
