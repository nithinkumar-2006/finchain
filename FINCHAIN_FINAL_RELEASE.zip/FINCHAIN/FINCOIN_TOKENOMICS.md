# FINCOIN test-asset policy

Asset identifier FINCOIN; display ticker FNC; precision eight decimal places. Separate quote asset SIM_INR has two decimal places and no redemption into BPI INR or cash.

Network initialization records 1,000,000 FNC (100,000,000,000,000 atoms) and 1,000,000 SIM_INR (100,000,000 minor units) in simulator inventory through a balanced genesis-issuance journal. Normal operations have no FNC mint endpoint. An already initialized network rejects a changed genesis policy.

Test grants debit inventory rather than inventing user balances. Per-wallet daily grants are capped at 10 FNC or 10,000 SIM_INR equivalent. Supply and inventory can be replayed from committed journals. Insufficient inventory fails atomically. This is a test distribution policy, not an economic valuation or investment proposition.

Trade fees are 10 basis points of gross quote value, rounded upward to an integer minor unit. Fees remain in a separate SIM_INR ledger account. There is no staking return, yield, interest, guaranteed price, public sale or production token allocation in this implementation.
