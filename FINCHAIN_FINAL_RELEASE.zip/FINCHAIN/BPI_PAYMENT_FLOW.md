# BPI payment flow

1. Resolve a wallet or unexpired request. Validate domain, recipient, ownership, amount and exact minor units.
2. Create an immutable draft with nonce, expiry, payment type, authorization reference and canonical payload digest. Return a review screen.
3. The user confirms that digest. Merchant spending also needs recent MFA and an independent eligible checker.
4. The worker revalidates the live identity session/credential epoch, current ownership, nonce and expiry, then obtains an Ed25519 signature. Deterministic risk rules allow, review or reject.
5. Under a single PostgreSQL transaction, reserve available value, post sender-settled debit and receiver-pending credit, consume nonce, create journal commitment, append signed block and update head. The temporary hold is consumed in that transaction.
6. The independent gateway simulator receives a durable operation reference. Repeating the same request retrieves the same outcome; conflicting payloads fail.
7. UNKNOWN keeps value pending and schedules reconciliation. SUCCEEDED posts pending→settled. FAILED posts pending→original sender. Exactly one terminal application commits.
8. Receipt, history, notifications, order/invoice state and local webhook evidence reflect committed data. The public projector publishes only permitted proof fields.

Do not resend a payment merely because a network response was lost. Reuse its idempotency key and query the existing reference. The same key with altered terms returns conflict. A fresh draft after expiry/nonce changes requires a new review and authorization.
