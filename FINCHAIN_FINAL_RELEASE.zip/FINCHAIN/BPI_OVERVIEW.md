# BPI overview

BPI models regulated-money integration behind an explicit sandbox gateway boundary. There is no FINCOIN conversion, fee balance or token purchase in a BPI payment. Currency is simulated INR, represented as integer minor units in PostgreSQL and decimal strings in JSON.

A user or merchant owns a wallet and public address. Ownership is enforced on the server. Merchant cashier, maker, checker, integration and analyst permissions are separately scoped. Organization spending requires recent MFA and an independent checker approval of the exact digest. The worker rechecks the maker's active membership and checker eligibility before posting.

Payments support P2P, P2B, B2P and B2B. Refunds refer to a completed original payment, reverse the original parties and enforce the remaining refundable amount under a lock. Redemptions first move value to pending, then reduce simulated gateway-backed outstanding value only after the simulator reports success; failure returns it.

Deposits are capped at ₹10,000 equivalent per subject per rolling day. Individual payment/request instructions are bounded at ₹100,000 equivalent. These are engineering sandbox controls, not regulatory limits. BPI transaction fees are zero in the current policy. A transaction included in a block can still be awaiting settlement.
