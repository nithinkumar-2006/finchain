# FINCHAIN — Component Library Specification

Role 2 · Version 1.0 · Behavior contracts, not frontend code. Visual authority: [DESIGN_SYSTEM.md](DESIGN_SYSTEM.md).

## 1. Composition rules

Separate visual primitives, layout components and domain components. Shared appearance does not imply shared financial state. BPI and FINCOIN use different typed money, balance, status and authorization contracts. A generic Card can render either; a generic mutable Wallet that accepts either asset is prohibited. Public explorer components accept only public projection fields.

Every asynchronous component explicitly models loading, ready, empty, stale, unavailable and forbidden where applicable. Never use a missing numeric property as zero. Domain amounts arrive as exact strings, formatted without floating-point accounting. Callbacks request actions; they do not calculate balances or invent backend results.

## 2. Primitives

| Component | Required contract / variants | Interaction and state rules |
|---|---|---|
| Text / Heading | Semantic level, style token, content | Preserve heading hierarchy; no truncation of required disclosure |
| Button / Link | Visible label, intent, destination/action, busy/disabled reason | Keyboard, focus, minimum target; links navigate, buttons act |
| Icon | Name, size; decorative or accessible label | One consistent outline family; no unlabeled icon-only actions |
| InputField | Label, value, helper, error, required/read-only | Associated error, paste/autofill, no placeholder-only label |
| AmountField | Domain, asset, exact decimal text, supported precision | No asset mixing or silent rounding; server final validation |
| Select / Combobox | Named choices, current value, loading/no-match | Exact recipient lookup only; no global personal-data suggestions |
| Checkbox / Radio | Group label, option label, checked state | Terms/marketing not preselected; full label target |
| Card / Divider | Heading slot, content, optional real action | Decorative borders cannot impersonate input boundaries |
| Badge | Family and enum value plus text | Business/chain/settlement/risk families cannot substitute for each other |
| Tooltip / Popover | Trigger, short explanation | Keyboard/touch access; mandatory information remains inline |
| Skeleton | Shape/size, busy semantics | No fake amounts or scannable placeholder QR |
| InlineAlert / Banner | Tone, headline, explanation, permitted action | Persistent for consequential issues; reason independent of color |
| Toast | Low-risk event text | Copied/saved only after actual confirmation; not sole financial outcome |
| Dialog / Drawer | Title, content, close and focus origin | Focus containment/restoration; close never undoes committed work |
| Tabs | Items, selected panel and accessible names | Keyboard support; no hidden mandatory review data |

## 3. Shared layouts and data views

| Component | Inputs / responsibilities | Reuse |
|---|---|---|
| PublicShell | Public navigation, footer, sandbox context | All PUB pages and public explorer |
| WorkspaceShell | Product/domain, role, organization/outlet, menu | Consumer, FINCOIN, merchant, admin with scoped variants |
| DomainSwitcher | Allowed domains, active scope, unsaved draft guard | Merchant/admin; consumer FINCOIN transition |
| PageHeader | H1, contextual subtitle, optional primary action | All authenticated pages |
| EnvironmentNotice | Sandbox/test-network context and accessible explanation | Public finance content, wallets, reviews, receipts, exports |
| MetricCard | Label, exact value/unit or unknown reason, period, freshness, definition | Dashboard/merchant/admin; domain-specific datasets only |
| DataTable / MobileRecordList | Column schema, row ID/link, rows, cursor, filters | Transactions, merchant queues, explorer, admin |
| FilterBar / FilterDrawer | Applied filters, options, reset, result scope | History, analytics, explorer, audit |
| ChartPanel | Dataset, units, source, time zone/range, text summary, table alternative | Spend, merchant analytics, FINCOIN market/P&L |
| EmptyState | Cause-specific title, explanation, authorized next action | New account, no results, no items, no matches |
| UnavailableState | Safe reason, last known timestamp, read retry | Every remote panel |
| HashReference | Full reference, short display, copy, permitted destination | Receipts and explorer; never exposes private payload |
| FreshnessLabel | Server as-of time/sequence, stale threshold | Balances, analytics, health, charts |
| ExportJob | Scope/filter, requested/processing/ready/failed, actual link expiry | Merchant reports and authorized histories |

Domain switch clears data before new content renders. Table implementations choose explicit row link and individual action targets. Do not mount an admin table with hidden sensitive columns into a public page: data must be absent from its response, not hidden by CSS.

## 4. Domain components

| Component | Required data | Permitted behavior |
|---|---|---|
| BpiBalanceCard | Available, settled, reserved, pending, INR, environment, freshness | Open wallet/pay/receive; no FINCOIN valuation or conversion |
| RecipientResolver | Candidate address/opt-in alias, resolved public-to-payer fields, result version | Confirm exact recipient; do not infer identity from user input alone |
| PaymentReview | Immutable draft, exact source/payee/amount/fee/total, expiry, permitted actions | Authorize once; edit invalidates draft authorization |
| RiskNotice | Safe severity/reasons, decision summary, allowed actions | Verification/review/cancel/report; no client-side override |
| PaymentProgress | Authoritative business, chain, settlement state and timestamps | Display genuine milestones, track same operation on timeout |
| PaymentReceipt | Participant-scoped payment fields, linked returns/refunds, proof URL | Print/copy/refund if authorized; success only when completed |
| RequestQrCard | Actual server request/address, QR payload type, expiry/status | Copy/share only valid payload; no synthetic QR placeholder |
| GatewayOperation | Funding/redemption ID, simulator state, amount, receipt | Await authoritative result; no optimistic funding |
| CommerceCheckout | Immutable order lines/total, BPI request/source, order state | Reuse PaymentReview; fulfillment after settlement only |
| FincoinBalanceCard | FNC atoms, SIM_INR credits, reserved quantities, environment | Separate asset rows; no BPI balance or combined spendable figure |
| QuoteReview | Quote ID/side/quantity/price/fee/total/expiry/source | Confirm simulation; expiry disables confirm, never reprices silently |
| SimulatedOrderStatus | Order ID, filled/rejected/expired/canceled or pending state | Track same order, no partial fill display in v1 |
| PortfolioSummary | Holdings, known basis, market value/P&L/return definition, freshness | Mark grants/unknown basis; no invented market gain |
| MerchantApproval | Proposal digest, maker/checker, source/recipient/amount, role eligibility | Independent checker only; edits reset approvals |
| RefundComposer | Original settled amount, completed/reserved refunds, available funds | Enforce server remaining allowance; linked new operation |
| PublicProofView | Allowlisted hashes/headers/commitments/signatures/proof | Never names, addresses, amount, private risk or settlement evidence |
| AdminCasePanel | Domain, evidence permissions, audit/case state, allowed actions | Record decisions/proposals, never mutate balances directly |

## 5. Reuse map

| Screen family | Shared composition |
|---|---|
| Public information | PublicShell + PageHeader + content cards + EnvironmentNotice |
| Consumer dashboard | WorkspaceShell + BpiBalanceCard + MetricCard + DataTable + RequestQrCard + FreshnessLabel |
| P2P/P2B/B2P/B2B | RecipientResolver + PaymentReview + RiskNotice + PaymentProgress + PaymentReceipt; source/approval policy differs |
| QR / invoice payment link | RequestQrCard + request state + shared payment review |
| Wallet funding/redemption | BpiBalanceCard + AmountField + GatewayOperation |
| Commerce checkout | OrderSummary + CommerceCheckout + shared payment components |
| Merchant overview/analytics | MetricCard + DataTable + ChartPanel + ExportJob, merchant scope |
| Merchant payouts/refunds | MerchantApproval / RefundComposer + shared payment progress/receipt |
| FINCOIN | FincoinBalanceCard + ChartPanel + QuoteReview + SimulatedOrderStatus + PortfolioSummary |
| Public explorer | PublicShell + FilterBar + PublicProofView + HashReference, public-only DTO |
| Admin | WorkspaceShell + scoped DataTable + AdminCasePanel + audit timeline |

## 6. State contract and accessibility

Read states: loading → ready(data) / empty(no rows) / unavailable(error). Ready may transition to stale while retaining authorized data; label its timestamp and disable actions needing fresh inputs. Permission loss transitions to forbidden and clears private data. A filter mismatch is a distinct empty cause, with Clear filters instead of onboarding CTA.

Command states: editing → reviewing → authorizing → submitted(operation ID) → authoritative result. Transport uncertainty is a separate flag on submitted, not a new financial terminal state. Button disabling prevents accidental repeat interaction; durable idempotency remains a backend guarantee. An action that submits successfully but cannot refresh the list remains “Submitted — refreshing status” until reconciled.

Provide state fixtures for every public component variant with long labels, zero values, unavailable values, negative P&L, 8-decimal FNC, very long hashes, no permissions, pending and unknown settlement, declined camera/clipboard, reduced motion and high contrast. Fixture data lives only in an explicit isolated preview/test environment. Future component tests must verify that amount precision, accessible labels, focus and status distinctions survive reuse.

## 7. Engineer handoff boundaries

Use Next.js/TypeScript/Tailwind and Recharts-compatible interfaces per Role 1; this document does not prescribe unverified library-specific APIs. Generate domain clients from agreed OpenAPI. Do not log sensitive props in browser analytics, persist tokens locally, cache another scope's DTO or calculate authoritative financial state in a chart component. Add new variants through these semantic contracts rather than duplicating visually similar but inconsistent payment screens.
