# FINCHAIN — Master Architecture

Status: implementation baseline for a prototype/sandbox. Version: 1.0. Date: 2026-09-13.

## 1. Purpose and boundary

FINCHAIN combines two independent products in one web experience:

* **BPI — Blockchain Payment Infrastructure:** INR-denominated simulated payment obligations recorded on a private, blockchain-style ledger, with a sandbox gateway modeling settlement.
* **FINCOIN:** a separate digital-asset test ledger, wallet, trading simulator, and portfolio product.

The intended future BPI integration boundary is **regulated money → regulated gateway / settlement interface → BPI → user or merchant**. In this release, the money, gateway responses, and settlement are simulated. `INR` identifies a denomination, never proof of actual INR custody or redeemability. Every money-bearing API response includes `environment: "sandbox"` and `value_kind: "simulated"`.

Normal payments MUST NOT acquire, sell, bridge, spend, stake, or pay network fees in FINCOIN. There is no INR → FINCOIN → payment → INR path. FINCOIN has its own nonredeemable simulated quote balance, named `SIM_INR`; it cannot be funded from a BPI wallet. Sharing login does not imply shared financial authority.

“Public Payment Blockchain” is the project vision, not a description of the prototype's consensus or permissions. The initial chain has one authorized writer per domain and optional verifying followers; it is neither permissionless nor Byzantine fault tolerant. A public explorer exposes only redacted verification data. See [regulatory boundaries](REGULATORY_BOUNDARIES.md) and [blockchain design](BLOCKCHAIN_ARCHITECTURE.md).

## 2. Architecture decisions

| ID | Decision | Reason / constraint |
|---|---|---|
| ADR-001 | Separate BPI and FINCOIN deployments, databases, chains, keys, queues, and service identities | Prevent accidental value conversion and shared ledger privileges |
| ADR-002 | Modular FastAPI application inside each domain; private ledger worker and gateway adapter as separate processes | Small initial operational footprint with enforceable financial write ownership |
| ADR-003 | PostgreSQL is the durable store; chain records, journal entries, and financial state commit atomically in each domain | Avoid a database/chain dual-write failure window |
| ADR-004 | Double-entry journals are the accounting source; signed blocks are the ordered integrity record | Neither Redis nor explorer projections determine balances |
| ADR-005 | Distinct chain, settlement, and business statuses | Blockchain inclusion is not fiat settlement |
| ADR-006 | Durable command inbox and transactional outbox, at-least-once delivery with idempotent consumers | Recover safely after process or network failures |
| ADR-007 | No user-paid chain token or gas in BPI; sandbox fee is zero | BPI remains usable without FINCOIN |
| ADR-008 | Custodial sandbox transaction signing after explicit user authorization | Practical web prototype; do not claim user-held keys or self-custody |
| ADR-009 | Synthetic market data and fully collateralized simulator inventory | Deterministic FINCOIN demonstrations without external execution |
| ADR-010 | No application implementation in this deliverable | Contracts and acceptance criteria precede code |

These are design decisions, not claims that any component has been implemented or verified. Changes require a written decision update, migration impact, security review, and updated cross-document contracts. The domain separation and sandbox-only rules are fixed requirements.

## 3. Recommended stack

| Layer | Choice | Intended use |
|---|---|---|
| Web | Next.js App Router, TypeScript, Tailwind CSS | Responsive consumer, merchant, commerce, FINCOIN, and admin interfaces |
| Charts | Recharts | Price candles via a suitable custom chart if needed; portfolio, volume, P&L charts |
| API | Python FastAPI, Pydantic, Uvicorn | Separate identity/control, BPI, and FINCOIN APIs; versioned OpenAPI |
| Data | PostgreSQL, SQLAlchemy, Alembic | Exact amounts, journal integrity, commands, outbox, migrations |
| Cache | Redis | Short-lived rate limits, cache, wakeup hints; never financial truth |
| Async execution | Python workers polling PostgreSQL inbox/outbox | Durable workflow without needing a broker initially |
| Blockchain | Custom Python ordered ledger service | SHA-256 commitments, Ed25519 signatures, deterministic validation |
| Cryptography | Maintained cryptographic library and managed key vault interface | No custom cryptographic primitives |
| Auth | Short-lived JWT access tokens, rotating opaque refresh tokens | Separate token audiences; WebAuthn/TOTP enrollment and step-up hooks |
| Infrastructure | Docker Compose locally; managed containers, Nginx, managed PostgreSQL/Redis in cloud | Private networks and explicit persistence |
| Observability | OpenTelemetry, Prometheus-compatible metrics, Grafana, structured logs | Tracing, alerts, settlement and accounting health |
| Testing | pytest, property-based tests, Playwright, contract tests, k6 or equivalent | Accounting, replay, access isolation, recovery, and load |

Choose supported stable releases at implementation kickoff; pin exact versions and container digests in lockfiles and record a compatibility matrix. Do not equate this design with a dependency lockfile or promise of compatibility with future releases. Build an application-specific Python container rather than a deprecated FastAPI base image, consistent with [FastAPI container guidance](https://fastapi.tiangolo.com/deployment/docker/).

## 4. Product coverage and ownership

| Requested capability | Component / contract owner | Primary document |
|---|---|---|
| Consumer and merchant accounts | Identity plus BPI organization membership | [System context](SYSTEM_CONTEXT.md) |
| BPI wallets; payment requests; QR; P2P/P2B/B2P/B2B | BPI payment module | [BPI](BPI_ARCHITECTURE.md) |
| Blockchain transaction engine and explorer | Domain ledger workers and explorer projection | [Blockchain](BLOCKCHAIN_ARCHITECTURE.md) |
| Payment history, merchant dashboard, commerce | BPI reporting and commerce modules | [Component map](COMPONENT_MAP.md) |
| Fraud detection | BPI risk module and review queue | [Security](SECURITY_ARCHITECTURE.md) |
| FINCOIN wallet, simulated buy/sell, portfolio, P&L, market charts | FINCOIN modules | [FINCOIN](FINCOIN_ARCHITECTURE.md) |
| Admin, security controls, audit logs | Domain-scoped admin and audit exporters | [Security](SECURITY_ARCHITECTURE.md) |
| API layer | Each domain's FastAPI application | [API](API_ARCHITECTURE.md) |
| Deployment | Container infrastructure and operations | [Deployment](DEPLOYMENT_ARCHITECTURE.md) |

## 5. Source-of-truth and failure invariants

1. All amounts use integer minor units / atomic units, serialized as decimal strings. No floating-point accounting. INR has two decimal places; FINCOIN has eight.
2. Every posted journal balances per asset. Wallet balances can be rebuilt from immutable journal lines; synchronous balance rows are checked projections used for locking and authorization.
3. Spendable BPI balance equals settled wallet liability credit balance minus active holds. Pending recipient credits are not spendable.
4. A financial block and its journal changes either both commit or neither commits. No distributed database transaction spans domains or the gateway.
5. A repeated command, block transaction, settlement callback, or order cannot create a second financial effect.
6. Expired or canceled instructions cannot be included. An included transfer cannot be deleted or silently rolled back; a compensating operation records any return.
7. A settlement timeout means unknown, not failed. Uncertain value remains blocked until reconciled.
8. A user, merchant operator, or administrator cannot update balances directly. Account corrections use approved, balanced, linked journal commands.
9. Ledger services independently validate authorization grants, signed payloads, balances, nonces, and risk validity.
10. FINCOIN outage, missing wallet, or zero holdings cannot block an otherwise valid BPI payment.

## 6. Suggested future repository structure

```text
apps/web/                       # shared shell, independent product routes
services/identity/              # auth and sessions
services/bpi-api/               # payment, merchant, commerce, risk modules
services/bpi-ledger/            # sole BPI financial writer
services/bpi-gateway/           # simulator and reconciliation
services/fincoin-api/           # wallet, quotes, orders, analytics
services/fincoin-ledger/        # sole FINCOIN financial writer
services/projections/           # separate domain deployments/credentials
packages/contracts/            # OpenAPI snapshots and generated clients
packages/crypto-spec/           # public protocol schemas and test vectors
infra/                         # containers, networking, monitoring
tests/                         # cross-service acceptance and fault tests
docs/adr/                      # subsequent decisions
```

Do not create these application components until implementation begins. Do not modify synced `sources/` material. Shared packages may contain types and transport utilities; they must not contain shared financial tables or logic that converts between products.

## 7. Delivery sequence and acceptance gates

1. **Foundation:** identity, organization roles, environment assertions, schema migrations, exact money types, audit interface. Gate: cross-tenant and cross-domain authorization tests pass.
2. **BPI accounting and chain:** seeded simulated funding, holds, deterministic signatures, journal posting, block verification. Gate: concurrency, restart, duplicate-command, and replay tests preserve invariants.
3. **Payments and settlement:** all four payment types, gateway uncertainty, refunds, reconciliation, QR, history. Gate: Alice's ₹500 scenario and fault variants in [data flows](DATA_FLOW.md) pass.
4. **Merchant and security:** commerce checkout, maker/checker payouts, fraud review, redacted explorer, admin. Gate: no order fulfillment on mere inclusion; no sensitive explorer leakage.
5. **Independent FINCOIN:** test funding, transfers, buy/sell, chart feed, FIFO P&L. Gate: supply, inventory, rounding, and domain isolation tests pass with either domain stopped.
6. **Operational hardening:** load, recovery, key rotation, restore and incident exercises. Gate: measured results against [deployment targets](DEPLOYMENT_ARCHITECTURE.md), not assumed performance.

No stage enables live funds. A later live-money proposal requires the separate gate in [REGULATORY_BOUNDARIES.md](REGULATORY_BOUNDARIES.md).

## 8. Document authority

Read this file first, then [SYSTEM_CONTEXT.md](SYSTEM_CONTEXT.md), [COMPONENT_MAP.md](COMPONENT_MAP.md), and [DATA_FLOW.md](DATA_FLOW.md). Detailed authorities: [DATABASE_ARCHITECTURE.md](DATABASE_ARCHITECTURE.md) owns accounting/storage invariants; [BLOCKCHAIN_ARCHITECTURE.md](BLOCKCHAIN_ARCHITECTURE.md) owns protocol encoding; [BPI_ARCHITECTURE.md](BPI_ARCHITECTURE.md) owns payment states; [FINCOIN_ARCHITECTURE.md](FINCOIN_ARCHITECTURE.md) owns simulated trading; [API_ARCHITECTURE.md](API_ARCHITECTURE.md) owns transport; [SECURITY_ARCHITECTURE.md](SECURITY_ARCHITECTURE.md) owns trust and access; [DEPLOYMENT_ARCHITECTURE.md](DEPLOYMENT_ARCHITECTURE.md) owns operations. Regulatory and separation rules override implementation convenience.

Open decisions before a live-system redesign: legal operating model and geography, permitted partner responsibilities, custody structure, privacy and retention policy, public-chain consensus/governance, real asset issuance and classification, and audited capacity requirements. None prevents implementing this explicitly simulated baseline.
