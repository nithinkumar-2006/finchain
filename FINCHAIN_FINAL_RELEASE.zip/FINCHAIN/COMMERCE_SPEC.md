# Commerce implementation

The catalog supports sample Mobile Recharge, Utilities, Shopping, Travel, Subscriptions and Services categories. These labels do not connect to actual operators, booking systems or recurring services. A sample purchase is a one-time sandbox order.

Checkout accepts 1–20 unique items from one merchant, validates bounded integer quantities, locks stock rows in stable order, calculates totals on the server and snapshots product name/price into order items. No client-supplied total is trusted. The idempotency record, stock reservation, order and payment request commit together.

Stock is reserved for 15 minutes. The worker returns stock once when an unpaid reservation expires. Payment inclusion leaves the order PAYMENT_PENDING. Successful simulated settlement makes it PAID while the reservation remains valid; a late success becomes PAID_REVIEW rather than silently claiming fulfillment. Failed or unknown settlement never marks an order paid.

The consumer UI supports selecting a sample item, reviewing checkout and following the generated BPI request. The API supports multiple same-merchant items. The merchant can inspect its scoped orders. Shipping, real service fulfillment, multi-merchant cart splitting, tax computation, recurring billing and automatic compensation for PAID_REVIEW are not implemented.
