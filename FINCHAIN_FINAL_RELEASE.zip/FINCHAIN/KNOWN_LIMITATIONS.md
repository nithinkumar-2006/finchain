# Known limitations and acceptance gates

This is source for a sandbox, not approval for public-money operation.

- Docker was not installed on the implementation host. Full Compose image build/start, local Mailpit delivery over a running container network, and optional demo provisioning were not executed end to end. Configuration isolation and email retry behavior were tested separately.
- Browser tests cover public rendering, navigation, responsive widths, security headers and disconnected-service behavior. Identity→payment integration was tested through real in-process HTTP contracts; full browser→Nginx→all-service journeys remain an acceptance gate.
- A single producer and PostgreSQL are trusted infrastructure. There is no permissionless consensus, BFT quorum, peer discovery or independent public finality. External checkpoints and disaster recovery drills are still needed.
- Gateway, prices, balances, assets, catalog and webhooks are sandbox-only. External bank/exchange/mail/webhook/fulfillment integrations are absent. Webhook destinations are limited to a local signed HTTP inbox.
- MFA supports TOTP; WebAuthn, recovery codes, lost-factor recovery and managed HSM signing adapters remain future work. Private keys are not exposed through the UI, but the sandbox master-key custody must be replaced before production.
- Merchant reports use bounded lists and a rolling 30-day incoming-payment window. The UI checkout is single-item; the API accepts a bounded same-merchant cart. Product editing/deletion UI, multi-merchant carts, taxes and fulfillment are not implemented.
- Risk is deterministic rules, not a trained fraud model or compliance screening service. Review can cancel/reject; resubmission always needs fresh authorization. Late paid orders need manual review.
- Profile editing and additional appearance preferences are explicitly unavailable. Camera scanning depends on browser BarcodeDetector support and permission; manual request-link/address input remains available. Physical camera operation has not been tested.
- Infrastructure image tags must be pinned and scanned before shared deployment. Performance, accessibility certification, backup restore, independent penetration testing, KMS interoperability and regulatory/provider approval have not been completed.

No unexecuted check is described as passed. See QA_REPORT for actual evidence.
