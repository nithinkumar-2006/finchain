# FINCHAIN — sandbox implementation

FINCHAIN contains two independent financial domains: BPI simulated INR payments and FINCOIN test assets. BPI never buys, sells, holds or spends FINCOIN to make a payment. This repository does not provide banking, real-money custody, securities operations, regulatory approval or investment guarantees.

## Start here

1. Read [INSTALLATION_GUIDE.md](INSTALLATION_GUIDE.md).
2. Generate local credentials with `python scripts/configure_sandbox.py` after installing the Python dependencies.
3. Start the local stack with `docker compose -f compose.json up --build -d`.
4. Open `https://localhost:8443`. Verification mail is captured at `http://localhost:8025`.
5. Optionally run `docker compose -f compose.json --profile demo run --rm seed-demo`. Generated credentials stay in `.secrets/demo/credentials.json`; they are not in the download.

The certificate is self-signed for localhost. Never reuse this configuration for a public financial service. Docker startup and the optional demo provisioner require verification on a Docker-enabled machine; Docker was unavailable on the implementation machine. See [QA_REPORT.md](QA_REPORT.md) for executed checks rather than assuming every deployment path was tested.

## Repository

| Path | Responsibility |
|---|---|
| `apps/web` | Next.js, TypeScript, Tailwind, Recharts, responsive public and private interfaces |
| `services/identity` | FastAPI identity, sessions, JWT bridge, MFA, recovery, email queue, Alembic |
| `services/platform` | Independent BPI/FINCOIN APIs, ledgers, workers, signers, gateway, explorer |
| `deploy` | Nginx, one-shot migrations, genesis initialization, optional demo provisioning |
| `scripts` | Configuration, verification, API export and release packaging |
| Root architecture documents | Preserved Roles 1–3 design baseline plus implementation handoff |

Use [CLIENT_OVERVIEW.md](CLIENT_OVERVIEW.md) for capabilities, [API_REFERENCE.md](API_REFERENCE.md) for interfaces, [KNOWN_LIMITATIONS.md](KNOWN_LIMITATIONS.md) for scope, and [FINAL_DELIVERY_MANIFEST.md](FINAL_DELIVERY_MANIFEST.md) for package contents. Nothing in the public explorer reveals private payment addresses, amounts, risk records or identity-service data.
