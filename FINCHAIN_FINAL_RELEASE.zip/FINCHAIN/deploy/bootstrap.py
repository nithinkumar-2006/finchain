import os
from pathlib import Path
from finchain_platform.config import DomainSettings
from finchain_platform.signing import RemoteSigner
from finchain_platform.bpi import BPI, BPI_POLICY
from finchain_platform.fincoin import FINCOIN

settings = DomainSettings.from_env()
signer = RemoteSigner(settings.signer_url, Path(os.environ["SIGNER_SERVICE_KEY_FILE"]).read_text().strip())
store = (BPI if settings.domain == "BPI" else FINCOIN)(settings, signer)
store.initialize(BPI_POLICY) if settings.domain == "BPI" else store.initialize_fincoin()
print(settings.domain, "sandbox initialized", store.validate_chain()["head"])
