"""Opt-in sandbox fixtures. All financial value goes through normal queued commands."""
import json
import os
import secrets
import time
import uuid
from pathlib import Path
from sqlalchemy import select
from finchain_identity.config import Settings
from finchain_identity.service import Identity
from finchain_identity.models import EmailOutbox, User
from finchain_platform.config import DomainSettings
from finchain_platform.bpi import BPI
from finchain_platform.fincoin import FINCOIN
from finchain_platform.commerce import Commerce, CATEGORIES
from finchain_platform.storage import DomainGrant


def read_env(name):
    return dict(line.split("=",1) for line in (Path("/run/config")/(name+".env")).read_text().splitlines() if line and not line.startswith("#"))


def stable(value): return uuid.uuid5(uuid.NAMESPACE_URL,"finchain-sandbox-demo:"+value)


def main():
    migrations=json.loads(Path("/run/secrets/migrations.json").read_text())
    owner_urls={item["kind"]:item["url"] for item in migrations if item["kind"] in {"identity","bpi","fincoin"}}
    os.environ.update(read_env("identity"))
    os.environ["IDENTITY_DATABASE_URL"]=owner_urls["identity"]
    identity=Identity(Settings.from_env())
    stores={}
    for domain,cls in (("bpi",BPI),("fincoin",FINCOIN)):
        os.environ.update(read_env(domain+"-api"))
        # Trusted one-shot provisioning needs staff-grant authority; it never posts journals.
        os.environ["DOMAIN_DATABASE_URL"]=owner_urls[domain]
        stores[domain]=cls(DomainSettings.from_env())
    output=Path("/demo/credentials.json")
    records=json.loads(output.read_text()) if output.exists() else {name:{"email":name+"@example.com","password":secrets.token_urlsafe(24)} for name in ("alice","bob","merchant","admin")}
    output.write_text(json.dumps(records,indent=2));output.chmod(0o600)
    for name,record in records.items():
        identity.register(record["email"],record["password"])
        with identity.transaction() as db:
            user=identity.user_by_email(db,record["email"])
            user_id=user.id
            verified=user.email_verified_at is not None
            queued=db.scalars(select(EmailOutbox).where(EmailOutbox.user_id==user.id).order_by(EmailOutbox.created_at.desc())).all()
            token=None
            if not verified:
                for message in queued:
                    payload=json.loads(identity.crypto.decrypt(f"email_outbox:{message.id}:payload",message.payload_ciphertext))
                    if payload["purpose"]=="VERIFY_EMAIL": token=payload["token"];break
        if token: identity.consume_challenge(token,"VERIFY_EMAIL")
        if name in {"merchant","admin"}: identity.provision_role(user_id,name,stable("seed-operator"))
        with identity.transaction() as db:
            user=db.get(User,user_id)
            principal={"id":str(user.id),"credentials_version":user.credentials_version,"session_id":str(stable(name+"-seed-session")),"assurance":"NONE","auth_time":0}
        record["subject_id"]=str(user_id)
        for domain,store in stores.items():
            store.request_wallet(principal,stable(name+"-"+domain+"-wallet"))
            for _ in range(60):
                wallets=store.wallets(principal)
                if wallets: break
                time.sleep(1)
            if not wallets: raise RuntimeError("Domain worker did not create a demo wallet")
            record[domain+"_address"]=wallets[0]["address"]
            if domain=="bpi": store.funding(principal,stable(name+"-funding"),wallets[0]["id"],"100000")
            else: store.request_grant(principal,stable(name+"-quote-credit"),"SIM_INR","100000")
            if name=="admin":
                with store.transaction() as db:
                    subject,_=store.sync_subject(db,principal)
                    if not db.scalar(select(DomainGrant).where(DomainGrant.subject_id==subject.id,DomainGrant.role=="admin")):
                        db.add(DomainGrant(subject_id=subject.id,role="admin"))
                        store.audit(db,"demo.staff.provision","ADMIN_GRANTED",subject.id)
        if name=="merchant":
            store=stores["bpi"]
            merchant=store.merchant_onboard(principal,stable("sample-merchant"),"FINCHAIN Demo Store","Services")
            record["merchant_id"]=merchant["merchant_id"]
            commerce=Commerce(store)
            for category in sorted(CATEGORIES):
                commerce.create_product(principal,stable("product-"+category),merchant["merchant_id"],category+" sample","Simulated purchase only. No external service is fulfilled.",category,"25000",100)
    output.write_text(json.dumps(records,indent=2))
    print("Demo provisioning complete. Credentials are in .secrets/demo/credentials.json. Merchant and admin users must enroll MFA before protected actions. No real money or external services were used.")


if __name__=="__main__": main()
