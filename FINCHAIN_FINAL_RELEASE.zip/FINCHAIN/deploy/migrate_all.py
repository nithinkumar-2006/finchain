"""One-shot deployment owner. Its credentials are never mounted in runtime APIs."""
import json
import os
import subprocess
import sys
from pathlib import Path
from sqlalchemy import create_engine

sys.path.insert(0, "/srv/platform")
from migrate import migrate
from deploy_roles import install

config = json.loads(Path("/run/secrets/migrations.json").read_text())
for item in config:
    url, kind = item["url"], item["kind"]
    if kind == "identity":
        subprocess.run([sys.executable, "-m", "alembic", "upgrade", "head"], cwd="/srv/identity", env={**os.environ,"IDENTITY_DATABASE_URL":url}, check=True)
    else:
        migrate(url, kind)
    engine = create_engine(url, hide_parameters=True)
    if kind in {"bpi", "fincoin"}:
        install(url, kind)
    with engine.begin() as c:
        if kind == "identity":
            with c.connection.driver_connection.cursor() as cursor:
                cursor.execute(Path("/srv/identity/deploy/roles.sql").read_text())
        for user, role in item["users"].items():
            if role == "owner":
                c.exec_driver_sql(f"GRANT USAGE ON SCHEMA public TO {user}")
                c.exec_driver_sql(f"GRANT SELECT,INSERT,UPDATE ON ALL TABLES IN SCHEMA public TO {user}")
            elif role == "reader":
                c.exec_driver_sql(f"GRANT USAGE ON SCHEMA public TO {user}")
                c.exec_driver_sql(f"GRANT SELECT ON public.public_blocks,public.public_transactions TO {user}")
            else:
                c.exec_driver_sql(f"GRANT {role} TO {user}")
    engine.dispose()
