# FINCHAIN — Component Map

Status: sandbox architecture v1.0. Parent: [Master architecture](MASTER_ARCHITECTURE.md).

## Deployment units and ownership

| Component | Responsibilities | Authoritative data / allowed writes | Interfaces |
|---|---|---|---|
| Next.js web | Consumer, merchant, commerce, FINCOIN and admin pages; server-side session bridge | Web sessions in identity-controlled storage; no financial writes | Domain REST, SSE, identity API |
| Identity API | Login, registration, password/MFA, refresh rotation, subjects | `identity_db` only | Resource-specific JWT issuance and revocation events |
| BPI API | Wallet requests, payment drafts, authorization, merchant membership, risk and commerce | BPI application tables and durable command inbox | Private ledger commands, scoped signer, domain reads |
| BPI ledger worker | Validate commands; reserve funds; enforce nonce; post journal/block; apply gateway results | Exclusive writer of BPI ledger schema | Commands in, transactionally emitted events out |
| BPI sandbox signer | Sign authorized immutable BPI payload hashes | BPI key handles, grant consumption evidence | Private authenticated signing requests only |
| Gateway adapter worker | Submit settlement operations, query unknown outcomes, ingest callbacks | Gateway operation and inbox records, never balances | Contract to simulator; result commands to ledger |
| Gateway simulator | Deterministic success/failure/timeout scenarios, independent statements | `gateway_sim_db` synthetic operation log | Authenticated submit/status/statement API |
| BPI projection worker | History, merchant summaries, commerce payment events, explorer export | Rebuildable BPI read models, public redacted store | BPI outbox; tenant and public read APIs |
| FINCOIN API | Independent wallets, quotes, order requests, portfolio, prices | FINCOIN application tables and command inbox | FINCOIN signer and ledger; synthetic feed |
| FINCOIN ledger worker | Transfers, test issuance, inventory checks, atomic simulated fills | Exclusive writer of FINCOIN ledger schema | Domain commands and outbox |
| FINCOIN sandbox signer | FINCOIN-only signing grants and keys | FINCOIN key handles | No BPI token audience or key access |
| FINCOIN projection worker | FIFO lots, P&L, candles, portfolio snapshots, redacted explorer | Rebuildable FINCOIN read models | FINCOIN outbox and feed |
| Admin module per domain | Pauses, role administration, reviews, configuration, evidence exports | Domain configuration/audit, approved command requests | Same validated domain APIs; no ledger SQL console |
| Audit exporter per domain | Export append-only audit chain to protected storage | Domain audit exports and checkpoints | No business mutation |

Several modules may share a codebase inside a domain API. Financial writer credentials are available only to that domain's ledger process. Reporting workers are deployed separately per domain, even if they share projection code. Do not deploy a universal worker holding both domains' financial credentials.

## Internal module boundaries

```mermaid
flowchart LR
    R[HTTP routes / schemas] --> A[Application use cases]
    A --> D[Domain rules and state machines]
    A --> P[Ports: repositories, signer, clock, events]
    X[Adapters: PostgreSQL, keys, simulator] --> P
    W[Durable workers] --> A
```

Domain rules should be deterministic and independent of HTTP, UI, Redis, and a live clock. Inject a clock for expiry checks and a repository transaction for atomic changes. FastAPI routes validate transport, then invoke application use cases. Adapters do not decide accounting semantics. Public DTOs explicitly allow fields rather than serializing database rows.

The custom ledger is a service boundary but shares its own domain database with the domain application under different roles. This deliberate choice allows atomic journal/block/state commits without distributed transactions. API handlers submit commands; they do not update money and then call a separate blockchain store.

## Screen-to-component map

| Web route concept | Data owner | Behavior |
|---|---|---|
| Account/security | Identity | Sessions, MFA, recovery, domain enrollment |
| BPI home/wallet | BPI ledger query | Spendable/pending/held, currency, sandbox label |
| Pay/request/scan | BPI payments | Recipient confirmation, request expiry, signature authorization |
| BPI history/receipt | BPI history projection plus authoritative status | Filters, cursor pagination, refund linkage |
| Merchant dashboard | BPI reporting | Settled sales, pending payments, refunds, payout state, exports |
| Commerce catalog/cart/checkout | BPI commerce | Inventory reservation, immutable order total, payment request |
| FINCOIN wallet/trade | FINCOIN | Independent balances, test transfers, time-limited quotes |
| Portfolio/P&L/market | FINCOIN reporting | Synthetic prices, FIFO cost, realized/unrealized P&L, stale-data warnings |
| Explorer | Redacted projection | Domain/network selector, commitments, signed block headers |
| Admin | Domain admin modules | Separate roles and pauses; audit every privileged action |

## Commerce scope

Initial commerce supports merchants, outlets, products, inventory, carts, orders, invoices, fulfillment states, and refunds. It does not implement lending, escrow, marketplace split settlement, subscriptions, FX, or a universal asset checkout. FINCOIN cannot appear as a checkout funding source.

Each order stores an immutable server-calculated total and a single active payment attempt. Inventory reservations have expiries. A successful payment event transitions the order to paid exactly once. If stock expires before late settlement, move to `PAID_REVIEW` and issue a linked refund through the normal BPI flow; do not silently fulfill or discard the payment. Disputes are off-chain cases linked to immutable transactions, with outcome operations recorded separately.

## Contracts and extraction rules

Every command has `command_id`, `domain`, `schema_version`, `subject_id`, `organization_id` where relevant, `authorization_ref`, `correlation_id`, `submitted_at`, and an immutable payload hash. Events add `event_id`, `aggregate_id`, `aggregate_version`, and `occurred_at`. No service treats event delivery as a new authorization to spend funds.

Shared infrastructure is permitted for observability and identity. Shared financial repositories, cross-domain SQL joins, chain bridges, and generic `wallet.balance += amount` helpers are prohibited. New services may be extracted only after specifying ownership, failure/retry behavior, and replacement for any lost atomic transaction. Measured pressure, independent scaling, or security isolation must justify added infrastructure.

## Dependency degradation

* FINCOIN feed or service failure leaves BPI functional.
* Gateway outage pauses completion but preserves included payments and pending value.
* Risk outage stops new payment authorization/inclusion; already accepted settlement results still apply.
* Ledger outage leaves accepted commands pending; the API does not fabricate receipts.
* Projection lag displays freshness and uses authoritative status for decisions.
* Redis loss may reduce rate-limit availability but cannot reset balances, commands, or nonces. Sensitive endpoints fail closed if no safe rate-limit fallback exists.
* Identity outage allows locally verifiable, unexpired tokens for low-risk reads under policy; new login, refresh, and fresh financial authorization fail closed.
