# FINCOIN overview

FINCOIN is an independent test-asset ecosystem with its own PostgreSQL database, network, signer master, wallet addresses, chain, worker and public proof projection. BPI accounts are neither funded by nor dependent on FINCOIN. No bridge, swap or transfer between BPI INR and SIM_INR exists.

Users may create a FINCOIN wallet, request bounded test assets/credits, transfer FNC and simulate buys/sells. Quote prices are explicitly synthetic. A 15-second quote binds side, quantity, price, fee, total, nonce, feed sequence and authorization reference. The user reviews the quote and confirms its digest. A stale feed stops quote creation.

The ledger atomically posts both asset legs and fees. FIFO lots track purchased, granted and carried basis separately. Transferred basis moves with the units; grant proceeds are not presented as purchased investment returns. History and portfolio values come from stored fills and lots rather than decorative sample balances.

There is no real exchange, market-data subscription, bank withdrawal, investment advice or guaranteed return. This service is simulation functionality; any permitted live integration requires a new legal, custody, execution and security design.
