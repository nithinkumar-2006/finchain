# FINCHAIN Authentication Specification

Status: implemented sandbox foundation v0.1, 2026-09-14. Source: [identity service](services/identity/finchain_identity/app.py). This document specifies the executable identity slice and its deliberate extensions to the earlier architecture; earlier financial architecture remains unchanged.

## Scope and trust boundary

The service implements registration, verified-email login, logout, session listing/revocation, server-side refresh rotation, password recovery/reset, email-verification requests/confirmation, TOTP enrollment/confirmation, and identity role checks. It uses only its dedicated PostgreSQL database. BPI and FINCOIN databases, wallets, keys, asset conversions and financial grants are outside this service. Its JWT has only `identity:self` scope and the exact audience `finchain:identity:sandbox`. It must never authorize a BPI payment or FINCOIN trade.

This release is a sandbox. It provides no bank, RBI, custody, securities, legal-tender, regulatory-approval or investment-return claims. Login identity and simulated financial authority are separate concerns.

## Browser/session protocol

The existing architecture calls for a Next.js session bridge. For this backend foundation, the bridge runs inside FastAPI: the browser gets only an opaque session cookie; the bridge encrypts access and refresh tokens in `auth.web_sessions`. A future Next.js application can call these same-origin endpoints without handling JWTs. Moving bridge ownership later requires an explicit service-authenticated interface and restricted token storage; do not expose the internal rotation function as a public token-exchange endpoint.

1. Browser calls `GET /v1/identity/csrf`, keeps the returned CSRF token in memory and the CSRF cookie set by the server.
2. All mutation requests send the exact configured `Origin`, `X-CSRF-Token`, matching CSRF cookie and JSON content type for POST. This includes login, registration and recovery, preventing login CSRF.
3. Successful login replaces any supplied browser-session identifier with a fresh 256-bit opaque value and rotates the CSRF token. The response contains status and CSRF only.
4. Session cookie `__Host-finchain-session` is Secure, HttpOnly, SameSite=Lax, Path=/, without Domain. The `__Host-finchain-csrf` cookie is Secure/SameSite=Lax and intentionally readable by the frontend. Session-authenticated mutations also compare a server-stored CSRF digest; a forged double-submit pair is insufficient.
5. `GET /me` checks the encrypted access JWT, live session, current user status and credential epoch. An expired access JWT returns `401 ACCESS_EXPIRED`; call refresh once, then retry the read. Refresh itself checks the live opaque session and CSRF without requiring a still-valid access JWT.
6. Access tokens last five minutes. Sessions expire after 24 hours absolutely and after 30 minutes without authenticated activity. Refresh cannot extend the absolute expiry. A maximum of ten nonrevoked, unexpired sessions per user is retained; older sessions are revoked on new login.
7. Logout revokes the current family and clears the browser cookie. Explicit session revocation requires ownership. If a logout response is lost, client may clear its local state and repeat; an already-revoked cookie returns 401, with no restored authority.

There are no tokens in localStorage, browser URLs or response fields. Theft of an opaque session cookie still permits impersonation until expiry/revocation; HttpOnly does not stop malicious same-origin code from issuing requests.

## Endpoint contract

All paths below begin `/v1/identity`. Success/error bodies use explicit allowlists. Error responses use `application/problem+json`, stable code, HTTP status and generated request ID; validation errors do not echo submitted values. POST endpoints with no fields accept an empty JSON object.

| Method / path | Input | Success and authorization |
|---|---|---|
| GET `/csrf` | None | 200: pre-auth CSRF bootstrap; rate limited |
| POST `/registrations` | email, password | 202 generic acceptance, encrypted verification queued; consumer role only |
| POST `/sessions` | email, password, optional totp_code | 200 opaque session cookie; requires verified email and active account; enrolled MFA is mandatory |
| GET `/me` | Session cookie | 200 own subject UUID, current roles, session UUID, assurance, sandbox label |
| GET `/sessions` | Session cookie | 200 up to ten own unexpired nonrevoked sessions; no tokens |
| POST `/sessions/refresh` | Cookie + CSRF | 204; atomic server-side refresh rotation |
| POST `/logout` | Cookie + CSRF | 204; revoke current session and clear cookie |
| DELETE `/sessions/{UUID}` | Cookie + CSRF | 204; own session only, inaccessible sessions return 404 |
| POST `/forgot-password` | email | 202 generic acceptance; `/recovery` is a compatibility alias |
| POST `/reset-password` | token, password | 204; single-use challenge; revokes every session; no automatic login |
| POST `/email-verification/requests` | email | 202 generic acceptance |
| POST `/email-verification/confirm` | token | 204; single-use email proof |
| POST `/mfa/enrollments` | password | 200 pending factor ID and one-time provisioning secret; recent session plus password proof |
| POST `/mfa/verifications` | six-digit code | 204; activate pending factor; revoke all sessions and clear cookie |
| GET `/audit-logs` | Session cookie | 200 latest 50 safe event summaries; admin/compliance and recent MFA only |

Common failures: 400 invalid/expired/consumed challenge; 401 generic invalid credentials/session or expired access; 403 CSRF, role or MFA requirement; 404 inaccessible session; 409 already enrolled MFA; 413 request too large; 415 wrong content type; 422 invalid schema; 429 throttled with Retry-After; 503 database unavailable. Health liveness at `/health/live` does not certify database readiness. Interactive API docs are disabled; OpenAPI can be generated offline from `create_app(settings).openapi()`.

## Credentials, JWT and refresh rules

Passwords are 15–128 Unicode characters at registration/reset, without silent trimming or composition rules. Login permits existing passwords up to 128 characters. Argon2id uses 64 MiB memory, three iterations and one lane, with random salts and PHC verifiers; successful login upgrades outdated parameters. Benchmark under realistic concurrent load before changing costs. No plaintext or reversible password is stored. An absent account uses a dummy Argon2 verifier. Breached-password screening is not integrated.

Email account lookup is case-insensitive after email validation, without provider-specific dot/plus rewriting. Canonical email is AES-GCM encrypted with row/column-bound associated data; a purpose-specific HMAC-SHA256 blind index supports exact lookup and uniqueness. A duplicate registration has the same accepted response and does not replace credentials.

JWT signing uses RS256 with RSA keys of at least 3072 bits. Verification pins algorithm, issuer, audience, type and configured key ID. Required claims: `sub`, `sid`, `jti`, `iat`, `nbf`, `exp`, `auth_time`, `amr`, `cv`, `scope`, `iss`, `aud`. UUID and integer claims are checked, lifetime is bounded, and arbitrary key URL headers are rejected. Role claims are deliberately absent: the database is checked for current authorization. Fixed algorithm selection and mandatory claim validation follow the [PyJWT verification contract](https://pyjwt.readthedocs.io/en/stable/api.html).

Refresh tokens contain 256 random bits. Verifier rows store SHA-256 digests, one root per session and at most one child per parent, with a composite FK that forbids cross-session lineage. Session UUID is the refresh-family identity. On rotation the user and session are locked, the old verifier is marked used, one child is inserted, encrypted bridge credentials are updated and audit commits in the same transaction. Reuse revokes the entire session family and commits even though the request is rejected. The bridge locks and reloads its current encrypted token, so two concurrent browser refresh requests serialize rather than accidentally replaying a stale token. Direct reuse tests exercise the internal verifier boundary. Lost HTTP responses do not lose the new refresh token: it is already in the bridge store.

## Recovery and email delivery

Recovery returns the same status/body whether the address exists, is disabled or is unverified. Response timing is not claimed to be constant; deployment timing analysis remains required. Challenge tokens have 256 bits of entropy, purpose binding, credential epoch, expiry and one-use timestamps. A new challenge invalidates earlier unused challenges of the same purpose. Email-verification challenges last one hour; password-reset challenges last 15 minutes.

Password reset updates the verifier, advances credentials_version, clears lockout, consumes outstanding challenges and revokes all sessions atomically. It does not erase or bypass an existing MFA factor. These choices follow the single-use recovery and session-revocation principles in [OWASP password recovery guidance](https://cheatsheetseries.owasp.org/cheatsheets/Forgot_Password_Cheat_Sheet.html).

Email delivery uses an **encrypted sandbox outbox**, initially `SANDBOX_QUEUED`. The local email worker decrypts queued delivery fields and sends only to the allowlisted Mailpit/loopback SMTP sink. It records `SANDBOX_DELIVERED` after SMTP acceptance, uses a stable Message-ID, and rolls back on failure. A retry after an uncertain SMTP acknowledgment can duplicate a local message; the challenge remains single-use. No external email provider is integrated, and no public debug-token endpoint or console token dump exists. Recovery links use the configured frontend origin and a URL fragment removed from browser history before token submission. Production needs a separately restricted delivery identity, bounded/dead-letter retries, provider integration and operational monitoring. Local SMTP behavior was unit-tested; container-network delivery remains a Docker acceptance gate.

## Role policy and MFA

| Identity role | Foundation rights | Later domain rights require separate grants |
|---|---|---|
| consumer | Own profile/session security | Own BPI/FINCOIN actions after domain enrollment and authorization |
| merchant | Own identity security | Merchant/outlet membership, maker/checker and payout limits |
| admin | Safe identity audit read with recent MFA | No automatic BPI/FINCOIN administration or balance changes |
| compliance | Safe identity audit read with recent MFA | Scoped risk cases/evidence under domain policy |
| support | Own identity security; no audit/global identity access | Explicit masked support views, no impersonation or secret access |

Public registration cannot choose roles. The offline operator command grants a named role using separate operator database credentials and an operator UUID, audits the grant, advances the credential epoch and revokes sessions. The operator UUID is an external change-control reference; its truth depends on operator access controls. There is no public role-grant endpoint. Database RLS restricts runtime registration to consumer grants. Role revocation/admin lifecycle APIs are future work; current roles are nevertheless read live on every protected operation.

Implemented MFA is TOTP: a pending 160-bit secret, five-minute enrollment window, password recheck and recent authentication, six digits, 30-second steps, ±1-step clock tolerance and a monotonically consumed counter. The RFC-defined HMAC/offset encoding is implemented with standard-library primitives and a known-answer test; no novel crypto is introduced. Activation revokes all sessions; next login must provide password plus a fresh TOTP. Admin/compliance reads require MFA authentication within five minutes. A password-only staff account can enroll but cannot use protected staff routes. Enrollment replacement of an active factor is denied.

WebAuthn, multiple factors, recovery-code generation/consumption and factor-loss recovery are architecture extension points, **not implemented features**. Add audited, challenge-bound verification with RP ID/origin checks before enabling WebAuthn; no client-supplied `mfa_verified` flag may upgrade assurance. Lost-factor recovery must be a separate reviewed process and must not use email reset as an MFA bypass. Merchant payout step-up must additionally bind domain, exact payload digest, operation, expiry and current membership. This identity session alone is not such a grant.
