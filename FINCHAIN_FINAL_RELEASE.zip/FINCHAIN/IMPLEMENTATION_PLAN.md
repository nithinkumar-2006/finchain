# FINCHAIN Implementation Plan and Decision Record

Updated 2026-09-18 for the master implementation/integration brief. This is a work tracker, not a completion claim.

## Inspected baseline

The workspace contains the Role 1 architecture, Role 2 UI/UX and Role 3 database documents, plus the new identity service. Synced `sources/` are read-only. No pre-existing BPI, FINCOIN or frontend application was found. Preserve the existing documents as design baselines and document implementation refinements separately.

## Decisions resolving the expanded brief

1. Keep the existing canonical BPI business/chain/settlement states. Map the brief's simplified lifecycle to those states in UI copy; confirmation alone never means settlement.
2. Keep one authorized sequencer per domain and threshold one. Followers verify, never vote. Do not invent PoA/BFT guarantees or extra active validators.
3. Keep the privacy-preserving public explorer. Public addresses/amounts in the new illustrative brief conflict with the stricter baseline; provide authorized receipt/address detail privately.
4. FINCOIN supply policy is configured only when initializing a new network epoch. Active-network FNC supply cannot be edited or minted by a routine setting.
5. Keep `/v1/identity`, `/v1/bpi`, `/v1/fincoin` and `/v1/explorer` namespaces. The new `/api/v1/*` list is illustrative, not a reason to break validated contracts.
6. Keep authoritative risk after exact user authorization/signing. Preliminary UI review is not a fraud clearance.
7. Commerce categories are sandbox catalog categories, with one-time sample purchases. No actual recharge, travel booking or recurring mandate is implied.
8. Existing identity implementation includes an in-service opaque-cookie bridge. Extend it through authenticated internal principal validation; never expose its encrypted tokens to browser code.

## Delivery status

Architecture, identity, domain ledgers, payment and settlement workflows, FINCOIN simulation, merchant/commerce/admin interfaces, public explorer, security controls, migrations and source packaging are implemented for sandbox use. The complete regression passed: 95 backend tests with PostgreSQL checks enabled, nine Chromium browser checks, and the production web build.

The following gates remain open: Docker image/Compose execution, optional demo provisioning, complete integrated HTTPS browser journeys, physical camera testing, load and disaster-recovery exercises, and independent security review. See QA_REPORT.md and KNOWN_LIMITATIONS.md for precise coverage and scope. Supplied deployment configuration is not proof that a deployment was exercised.

## Environment and delivery

A disposable PostgreSQL 17.11 cluster was installed and tested locally; no database data or credentials are included. Docker is unavailable. SQLite remains restricted to isolated tests. No infrastructure was published and no external mail, real payment or investment order was sent. Synced sources remain untouched.

FINCHAIN_FINAL_RELEASE.zip contains source, tests, migration files and documentation. FINAL_DELIVERY_MANIFEST.md explains its hash manifest and exclusions. INSTALLATION_GUIDE.md is the entry point after extraction.
