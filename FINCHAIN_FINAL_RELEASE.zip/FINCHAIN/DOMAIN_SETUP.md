# Domain setup

No domain has been purchased, configured or published by this project. The supplied certificate and origin are localhost-only.

For an approved shared **sandbox**, first complete container acceptance and security review. Configure a sandbox hostname and a trusted TLS certificate. Update identity origin/issuer, each financial domain's `FINCHAIN_ORIGIN`, and Nginx server name/listener together. Origins must be exact HTTPS scheme/host/port values without a trailing slash. Recreate issued request links when changing origins. Existing cookies remain bound to the old host.

Route `/v1/identity`, `/v1/bpi`, `/v1/fincoin` and `/v1/explorer` through one controlled edge. Keep `/internal`, signer, gateway, database, Redis, bootstrap and administrative deployment credentials private. Do not publish Mailpit or reuse demo accounts. Bind the edge to an approved interface only after network controls and trusted TLS are ready.

Test CORS rejection, cookie Secure/HttpOnly flags, Origin/CSRF validation, CSP nonce behavior, redirects, maximum body size and private-route blocking from outside the network. Verify mail links use the intended sandbox hostname. Changing a domain does not change the system into a legally permitted real-money service.
