# FINCHAIN — Entity Relationship Diagrams

Role 3 · Version 1.0 · 2026-09-14 · Schema: [DATABASE_SCHEMA.md](DATABASE_SCHEMA.md) · Columns: [DATA_DICTIONARY.md](DATA_DICTIONARY.md).

## 1. Reading the diagrams

All entities have a UUID `id` primary key and creation timestamp, including join tables. Diagrams show selected identifying columns rather than repeating the full dictionary. `||` means exactly one; `o|` means optional one; `o{` means zero or more; `|{` means one or more. A cardinality describes valid committed business state; deferred constraints and posting routines may build the related rows within one transaction.

Solid ER relationships are local FKs plus the stated business cardinality. Dashed arrows in the boundary flowchart are authenticated replication/export contracts, **not cross-database FKs**. Repeated entity labels in different database sections represent independent tables. Shared financial template diagrams must be instantiated once per financial database with that domain's actual wallet type.

## 2. Database boundaries

```mermaid
flowchart LR
    ID[(identity_db - private identity)]
    B[(bpi_db - simulated INR)]
    F[(fincoin_db - FINCOIN and SIM_INR)]
    G[(gateway_sim_db - independent evidence)]
    EB[(explorer_bpi_db - public proofs)]
    EF[(explorer_fincoin_db - public proofs)]
    ID -. minimal subject and device events .-> B
    ID -. minimal subject and device events .-> F
    B -. stable simulator operation .-> G
    G -. authenticated result and statements .-> B
    B -. allowlisted committed headers and proofs .-> EB
    F -. allowlisted committed headers and proofs .-> EF
```

There is no BPI–FINCOIN asset edge. A local `core.subjects.id` may equal its source `auth.users.id`, but local foreign keys terminate at core.subjects. Gateway operation IDs and public source references are deduplicated external identifiers; neither creates access to the source private database.

## 3. Identity entities — identity_db

```mermaid
erDiagram
    USERS ||--|| PROFILES : owns
    USERS ||--|| PASSWORD_CREDENTIALS : authenticates_with
    USERS ||--o{ DEVICES : registers
    USERS ||--o{ SESSIONS : opens
    SESSIONS }o--o| DEVICES : optionally_bound_to
    SESSIONS ||--|{ REFRESH_TOKENS : rotates
    SESSIONS ||--o| WEB_SESSIONS : bridges_browser
    REFRESH_TOKENS ||--o| REFRESH_TOKENS : next_rotation
    USERS ||--o{ MFA_FACTORS : enrolls
    USERS ||--o{ RECOVERY_CODES : receives
    USERS {
        uuid id PK
        bytea email_lookup_digest UK
        bytea email_ciphertext
        text status
        timestamptz created_at
    }
    PASSWORD_CREDENTIALS {
        uuid id PK
        uuid user_id FK,UK
        text password_hash
    }
    SESSIONS {
        uuid id PK
        uuid user_id FK
        uuid device_id FK
        uuid family_id UK
        timestamptz expires_at
    }
    REFRESH_TOKENS {
        uuid id PK
        uuid session_id FK
        uuid parent_token_id FK
        bytea token_digest UK
    }
```

The one-password/profile cardinality is the initial password-registration path; create them in the same registration transaction. The MFA challenge may precede issuance of the completed authenticated refresh session. Refresh-token parent is optional for the root and unique for a rotation child. Composite keys ensure device belongs to the session user and parent refresh belongs to the same session. No domain table references identity password/session rows directly.

## 4. BPI merchant, wallet, request and payment entities

```mermaid
erDiagram
    SUBJECTS ||--o| PRINCIPALS : user_principal
    SUBJECTS ||--o{ MERCHANT_ACCOUNTS : owns
    MERCHANT_ACCOUNTS ||--o{ MERCHANT_MEMBERSHIPS : authorizes
    SUBJECTS ||--o{ MERCHANT_MEMBERSHIPS : joins
    MERCHANT_ACCOUNTS ||--o{ MERCHANT_OUTLETS : operates
    SUBJECTS ||--o{ WALLETS : consumer_ownership
    MERCHANT_ACCOUNTS ||--o{ WALLETS : merchant_ownership
    WALLETS ||--|{ WALLET_ADDRESSES : registers
    WALLETS ||--|| BALANCES : has
    WALLETS ||--o{ PAYMENT_REQUESTS : receives_through
    WALLETS ||--o{ PAYMENTS : sends_or_receives
    PAYMENT_REQUESTS |o--o{ PAYMENTS : optional_request
    PAYMENT_REQUESTS ||--o| QR_PAYMENTS : dynamic_qr
    QR_PAYMENTS |o--o{ PAYMENTS : optional_initiation
    PAYMENTS ||--|| PAYMENT_STATES : authoritative_lifecycle
    PAYMENTS ||--o| PAYMENT_METADATA : private_note
    PAYMENTS ||--o{ REFUNDS : original_payment
    PAYMENTS ||--o| REFUNDS : reverse_payment
    PAYMENTS ||--o| REFUND_TOTALS : cumulative_refund_guard
    PAYMENTS {
        uuid id PK
        uuid operation_id FK,UK
        uuid sender_wallet_id FK
        uuid receiver_wallet_id FK
        uuid request_id FK
        bigint amount_minor
        uuid network_id FK
    }
    BALANCES {
        uuid id PK
        uuid wallet_id FK,UK
        bigint settled_minor
        bigint held_minor
        bigint pending_minor
        bigint available_minor
    }
    REFUNDS {
        uuid id PK
        uuid original_payment_id FK
        uuid refund_payment_id FK,UK
        bigint amount_minor
    }
```

A BPI wallet has exactly one consumer **or** merchant owner, not both relationships simultaneously; CHECK plus principal-ownership validation enforces the XOR. Each payment has two role-specific wallet/address FKs even though the diagram uses a combined relationship label. Optional request/QR links do not create a second transfer.

The request's active-payment back-pointer is an additional deferred composite FK to a payment whose request_id is that request. One active request per order/invoice and one active claimed attempt are guarded under locks. A request can have many historical failed/expired payment attempts, but cannot be paid twice. Refunds are reverse payments with their own status and accounting.

## 5. Accounting and chain — independently in each financial DB

```mermaid
erDiagram
    NETWORKS ||--|{ ASSETS : defines
    NETWORKS ||--o{ BLOCKS : orders
    NETWORKS ||--|| CHAIN_HEADS : fences_writer
    WALLETS ||--|{ ACCOUNTS : wallet_accounts
    ASSETS ||--o{ ACCOUNTS : denominates
    ACCOUNTS ||--|| ACCOUNT_BALANCES : synchronous_totals
    TRANSACTIONS ||--|{ JOURNAL_LINES : posts
    ACCOUNTS ||--o{ JOURNAL_LINES : receives_entries
    TRANSACTIONS ||--|| BLOCKCHAIN_TRANSACTIONS : commits_payload
    BLOCKCHAIN_TRANSACTIONS ||--|| BLOCK_MEMBERSHIPS : included_once
    BLOCKS ||--o{ BLOCK_MEMBERSHIPS : ordered_body
    SIGNING_KEYS ||--o{ BLOCKCHAIN_TRANSACTIONS : signs
    SIGNING_KEYS ||--o{ BLOCKS : validates
    SIGNING_KEYS ||--o{ KEY_BINDINGS : authorized_history
    WALLETS ||--o{ HOLDS : reserves
    WALLETS ||--o{ NONCE_CLAIMS : replay_guard
    PRINCIPALS ||--o{ LIMIT_BUCKETS : aggregate_caps
    LIMIT_BUCKETS ||--o{ LIMIT_RESERVATIONS : reserves_capacity
    TRANSACTIONS {
        uuid id PK
        uuid operation_id FK,UK
        uuid network_id FK
        bytea journal_commitment
        timestamptz posted_at
    }
    JOURNAL_LINES {
        uuid id PK
        uuid transaction_id FK
        uuid account_id FK
        uuid asset_id FK
        text side
        numeric amount_atomic
    }
    BLOCKS {
        uuid id PK
        uuid network_id FK
        bigint height
        bytea block_hash UK
        uuid previous_block_id FK
    }
    BLOCK_MEMBERSHIPS {
        uuid id PK
        uuid block_id FK
        uuid blockchain_transaction_id FK,UK
        int tx_index
    }
```

In FINCOIN replace WALLETS with FINCOIN_WALLETS. System-owned accounts have a principal instead of a wallet; that optional ownership branch is described in the dictionary. All account/line/asset and block/body relationships include network scope. Journal lines must number at least two and balance per asset; the `|{` connector alone cannot enforce that aggregate.

Every accounting transaction has exactly one chain transaction and committed membership at transaction end, enforced by deferred validation. Genesis may contain zero journal transactions; later financial blocks cannot be empty in v1. Chain head and previous-block consistency include hash and height, not only an existing UUID. Balance and hold rows are mutable projections/reservations; transactions, journal lines and committed blocks are immutable facts.

## 6. BPI settlement and fraud

```mermaid
erDiagram
    PAYMENTS ||--o{ TRANSACTIONS : accounting_events
    PAYMENTS ||--o| SETTLEMENTS : transfer_obligation
    WALLET_OPERATIONS ||--o| SETTLEMENTS : funding_or_redemption
    WALLET_OPERATIONS ||--o{ TRANSACTIONS : accounting_events
    SETTLEMENTS ||--o| GATEWAY_TRANSACTIONS : stable_provider_operation
    GATEWAY_TRANSACTIONS |o--o{ GATEWAY_EVENTS : mapped_evidence
    SETTLEMENTS ||--o{ RECONCILIATION_CASES : exceptions
    RECONCILIATION_RUNS |o--o{ RECONCILIATION_CASES : discovers
    PAYMENTS ||--o{ FRAUD_SCORES : assessments
    AUTHORIZATIONS ||--o{ FRAUD_SCORES : exact_signed_intent
    FRAUD_SCORES |o--o{ FRAUD_EVENTS : evidence
    SUBJECTS ||--o{ DEVICE_REFERENCES : trusted_projection
    DEVICE_REFERENCES |o--o{ FRAUD_EVENTS : device_context
    FRAUD_SCORES ||--o{ RISK_CASES : review
    SETTLEMENTS {
        uuid id PK
        uuid payment_id FK
        uuid wallet_operation_id FK
        uuid terminal_transaction_id FK
        text status
        bigint amount_minor
    }
    GATEWAY_EVENTS {
        uuid id PK
        uuid gateway_transaction_id FK
        text provider_event_id UK
        bytea body_digest
        bool signature_valid
    }
    FRAUD_SCORES {
        uuid id PK
        uuid payment_id FK
        uuid authorization_id FK
        int score
        text decision
        text display_severity
    }
```

Settlement source is payment XOR wallet operation. Draft payments may have no settlement until inclusion; submitted wallet funding/redemption creates its obligation transactionally, while an unsigned redemption draft has none. Incoming unrecognized gateway events may have no local gateway-operation parent and remain quarantined. Event provider ID uniqueness is actually `(provider_code,provider_event_id)`, not globally unique across arbitrary providers.

The terminal evidence/result pointers are additional local FKs; validators ensure source operation, network, amount and participant agreement. A verified provider message does not itself change funds. Fraud scores are append-only versions; a risk case does not grant permission to spend or revive an expired authorization.

## 7. Commerce and merchant integration

```mermaid
erDiagram
    MERCHANT_ACCOUNTS ||--o{ MERCHANT_PRODUCTS : catalogs
    MERCHANT_PRODUCTS ||--|| INVENTORY : tracks_stock
    SUBJECTS ||--o{ CARTS : owns
    CARTS ||--o{ CART_ITEMS : contains
    MERCHANT_PRODUCTS ||--o{ CART_ITEMS : selected
    MERCHANT_ACCOUNTS ||--o{ COMMERCE_ORDERS : sells
    SUBJECTS ||--o{ COMMERCE_ORDERS : buys
    COMMERCE_ORDERS ||--|{ ORDER_ITEMS : immutable_snapshot
    MERCHANT_PRODUCTS ||--o{ ORDER_ITEMS : historical_product
    ORDER_ITEMS ||--o| INVENTORY_RESERVATIONS : reserves_stock
    COMMERCE_ORDERS |o--o{ INVOICES : optional_order
    MERCHANT_ACCOUNTS ||--o{ INVOICES : issues
    INVOICES ||--|{ INVOICE_LINES : exact_total
    INVOICES |o--o{ PAYMENT_REQUESTS : optional_invoice
    MERCHANT_ACCOUNTS ||--o{ MERCHANT_CUSTOMERS : own_relationships
    MERCHANT_ACCOUNTS ||--o{ API_KEYS : sandbox_access
    MERCHANT_ACCOUNTS ||--o{ WEBHOOKS : event_destinations
    WEBHOOKS ||--o{ WEBHOOK_SECRETS : key_versions
    WEBHOOKS ||--o{ WEBHOOK_DELIVERIES : logical_delivery
    WEBHOOK_DELIVERIES ||--o{ WEBHOOK_ATTEMPTS : attempts
    OUTBOX |o--o{ WEBHOOK_DELIVERIES : event_source
```

Issued orders/invoices require nonempty valid lines; unpublished drafts may temporarily have none. Every order belongs to one merchant; line composite FKs prevent another merchant's product from being inserted. Multi-merchant cart checkout creates separate orders, each with its own payment/settlement. Subscriptions/recharge/travel are catalog categories, not implied real provider integrations.

Webhook delivery source is outbox event XOR explicit test operation. A delivery binds an actual endpoint revision and secret belonging to that endpoint. API keys have only a verifier hash; webhook signing secrets are encrypted because sender must use them. Copying a key or retrying a webhook cannot mint a payment or move money.

## 8. FINCOIN trade and wallet relationships

```mermaid
erDiagram
    SUBJECTS ||--o{ FINCOIN_WALLETS : optional_enrollment
    FINCOIN_WALLETS ||--|{ WALLET_ADDRESSES : test_addresses
    FINCOIN_WALLETS ||--|{ FINCOIN_BALANCES : per_asset
    ASSETS ||--o{ FINCOIN_BALANCES : quantity_unit
    PRICE_FEEDS ||--o{ FINCOIN_PRICE_HISTORY : synthetic_ticks
    FINCOIN_PRICE_HISTORY ||--o{ FINCOIN_QUOTES : quote_source
    FINCOIN_WALLETS ||--o{ FINCOIN_QUOTES : requests
    FINCOIN_QUOTES ||--o| FINCOIN_ORDERS : accepted_once
    FINCOIN_ORDERS ||--o| FINCOIN_FILLS : all_or_nothing
    FINCOIN_ORDERS ||--o| FINCOIN_TRANSACTIONS : fill_receipt
    FINCOIN_TRANSFER_INTENTS ||--o| FINCOIN_TRANSACTIONS : transfer_receipt
    TEST_GRANTS ||--o| FINCOIN_TRANSACTIONS : grant_receipt
    TRANSACTIONS ||--|| FINCOIN_TRANSACTIONS : typed_domain_extension
    FINCOIN_TRANSACTIONS ||--o| FINCOIN_FILLS : exact_execution
    FINCOIN_WALLETS ||--o{ FINCOIN_TRANSFER_INTENTS : sender_or_receiver
    FINCOIN_WALLETS ||--o{ TEST_GRANTS : capped_funding
    FINCOIN_ORDERS {
        uuid id PK
        uuid quote_id FK,UK
        uuid wallet_id FK
        uuid authorization_id FK
        text status
    }
    FINCOIN_TRANSACTIONS {
        uuid id PK
        uuid transaction_id FK,UK
        uuid order_id FK,UK
        uuid transfer_intent_id FK,UK
        uuid grant_id FK,UK
        text event_type
    }
```

A typed FINCOIN transaction uses one allowed source for its event kind; it does not simultaneously represent a fill, transfer and grant. GENESIS_ISSUANCE/CORRECTION follow their separate controlled source rules. A rejected order has no fill/journal. A filled order has exactly one fill and typed receipt whose journal contains both asset legs and fee entries. Quantity conservation is per asset; no relationship with a BPI wallet exists.

## 9. FINCOIN analytics and public proof copies

```mermaid
erDiagram
    FINCOIN_TRANSACTIONS ||--o{ PORTFOLIO_LOTS : acquisition_or_transfer
    FINCOIN_WALLETS ||--o{ PORTFOLIO_LOTS : holds_basis
    PORTFOLIO_LOTS ||--o{ LOT_DISPOSALS : allocated_FIFO
    FINCOIN_TRANSACTIONS ||--o{ LOT_DISPOSALS : sells_or_transfers
    FINCOIN_WALLETS ||--o| FINCOIN_PORTFOLIOS : rebuildable_summary
    FINCOIN_PRICE_HISTORY |o--o{ FINCOIN_PORTFOLIOS : marking_tick
    PRICE_FEEDS ||--o{ FINCOIN_CANDLES : price_buckets
    OUTBOX ||--o{ PROJECTION_CHECKPOINTS : progress_reference
```

Lots/portfolio/candles are projections, not balances for authorization. Carry-in basis references source lots privately; grants and unknown basis remain distinguishable. The displayed realized return is derived from eligible purchased-lot P&L/cost, never an editable source fact. Checkpoints may be absent before the first event and must reflect atomic projection application; diagram shows the populated relation.

In each public explorer DB the local ER is:

```mermaid
erDiagram
    PUBLIC_NETWORKS ||--o{ PUBLIC_BLOCKS : public_headers
    PUBLIC_BLOCKS ||--o{ PUBLIC_BLOCKCHAIN_TRANSACTIONS : proof_members
    PUBLIC_NETWORKS ||--|| PUBLIC_PROJECTION_STATE : freshness
```

PUBLIC prefixes are diagram labels for `public_data.networks`, `blocks`, `blockchain_transactions` and `projection_state`. These rows have their own local FKs. There is no ER line to private wallets/users: export is an allowlisted transport boundary. Public transaction rows deliberately lack private amount, address, identity, fraud and settlement columns.

## 10. Workflow, approvals and audit

```mermaid
erDiagram
    PRINCIPALS ||--o{ OPERATIONS : initiates
    OPERATIONS ||--o{ OPERATIONS : stable_child_slots
    OPERATIONS ||--o{ COMMANDS : durable_steps
    OPERATIONS ||--o{ AUTHORIZATIONS : signed_versions
    OPERATIONS ||--o{ APPROVAL_PROPOSALS : governed_actions
    APPROVAL_PROPOSALS ||--o{ APPROVAL_DECISIONS : independent_review
    APPROVAL_PROPOSALS ||--o{ PROPOSAL_LINES : correction_preview
    OPERATIONS ||--o{ OUTBOX : committed_events
    SUBJECTS ||--o{ NOTIFICATIONS : private_delivery
    OUTBOX ||--o{ NOTIFICATIONS : source_event
    PRINCIPALS ||--o{ SYSTEM_SETTINGS : scoped_versions
    AUDIT_STREAMS ||--o{ AUDIT_LOGS : ordered_evidence
    PRINCIPALS ||--o{ AUDIT_LOGS : actor
    OPERATIONS |o--o{ AUDIT_LOGS : optional_operation
```

Inbox source events are remote identifiers or local consumer dedupe references, not cross-database FKs. Generic audit resource snapshots and aggregate IDs are documented evidence identities, not claimed strongly typed entity relations. Typed business/financial links remain explicit in their tables. Operation idempotency, actor scope, approval distinctness and state transition authorization require constraints plus controlled routines; cardinality alone does not enforce them.

## 11. Relationship acceptance checklist

Verify each FK appears with the same concrete table/column names in DATA_DICTIONARY and migration design. Test wrong network/asset/merchant ownership even when individual UUIDs exist. Test optional-source XORs, cyclic deferred request/secret links, nonempty balanced journals, exactly-once inclusion/fill, max refundable amount, quote ownership, immutable issued snapshots and source-projection freshness. No diagram arrow grants public access or authority to spend, and no archive/soft-delete operation cascades through financial history.
