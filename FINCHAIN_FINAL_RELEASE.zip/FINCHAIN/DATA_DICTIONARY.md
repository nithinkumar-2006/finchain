# FINCHAIN — PostgreSQL Data Dictionary

Role 3 · Version 1.0 · 2026-09-14 · Companion: [DATABASE_SCHEMA.md](DATABASE_SCHEMA.md) and [ER_DIAGRAM.md](ER_DIAGRAM.md).

## 1. How to read this dictionary

This is a column-level logical-to-physical contract for future migrations, not executed DDL. Every listed relation is a table unless explicitly called a view/projection. The following bundles are part of each table definition; their columns are not omitted from implementation:

| Bundle / notation | Expanded definition |
|---|---|
| `I` | `id uuid PK DEFAULT gen_random_uuid()`; `created_at timestamptz NOT NULL DEFAULT transaction_timestamp()`; append-only business fact |
| `M` | I's identity/time columns plus `updated_at timestamptz NOT NULL DEFAULT transaction_timestamp()`, `row_version bigint NOT NULL DEFAULT 1 CHECK >= 1`; controlled mutable row |
| `S` | M plus `deleted_at timestamptz?`, `deleted_by uuid?` FK local principal (auth tables instead use `auth.users`), `deletion_reason text?`; deletion fields all present together when deleted |
| `N` | `network_id uuid NOT NULL` FK local `core.networks(id)` and `UNIQUE(id,network_id)`; included alongside I/M/S |
| `?` | Nullable. Every other listed column is NOT NULL; no implicit defaults except those explicitly specified |
| `FK X` | Local FK to X's `id`; for network-scoped parent/child, expand to `(column,network_id) → X(id,network_id)` |
| `U(a,b)` | UNIQUE constraint on listed columns, in addition to UUID PK |
| `H32` / `SIG64` | `bytea` with CHECK `octet_length=32` / `=64` |
| `ENC` | `bytea` containing authenticated versioned envelope (key ID/version, algorithm, nonce, tag, ciphertext); plaintext absent |
| `Q` | `numeric(38,0)` finite integer, bounded to `0..10^38−1`; reject NaN/nonfinite/fractional input before coercion; `Q+` is strictly positive |
| `MINOR` | `bigint` nonnegative INR minor units; `MINOR+` strictly positive; business caps below type limit |
| `W` | `bpi_db.ledger.wallets` in BPI; `fincoin_db.ledger.fincoin_wallets` in FINCOIN; not an interchangeable cross-domain FK |

Unless marked immutable, only owned columns can change, with audit and row-version checks. I is append-only to runtime roles; M does not permit arbitrary overwriting of immutable payload/terms fields. Every operational mutation records who/why in `audit.audit_logs`; actor columns are also included where semantically required.

`timestamp` is always `timestamptz`, not a timezone-free timestamp. Code sets use named CHECK constraints. Every FK target's scope key must actually exist. Default delete action is RESTRICT; explicitly deferred cycles use DEFERRABLE INITIALLY DEFERRED NO ACTION. No money/history cascade deletion.

## 2. Identity database (`identity_db.auth`)

Only Identity service owns these rows. Email/name/device data are private. Domain services receive only trusted minimal projections.

### users — S

| Column | Type / constraint | Meaning |
|---|---|---|
| email_ciphertext | ENC | Original/canonical contact email encrypted |
| email_lookup_digest | H32, U; with `lookup_key_version smallint > 0` | HMAC of documented normalized email, for exact login/uniqueness |
| status | text; ACTIVE, LOCKED, DISABLED, DELETED; default ACTIVE | Authentication lifecycle; deleted status must agree with S deletion columns |
| email_verified_at | timestamptz? | Actual successful verification, never assumed |
| credentials_version | bigint default 1, >0 | Revocation/security epoch |
| last_authenticated_at | timestamptz? | Successful authentication time |

No plaintext password column. User IDs and retained email tombstones are not silently reassigned. During lookup-key rotation add a second digest/version column or versioned lookup relation through migration; populate and enforce normalized uniqueness before retiring the old index.

### profiles — S

| Column | Type / constraint | Meaning |
|---|---|---|
| user_id | uuid FK users, U | Exactly one profile per user, including soft-deleted history row |
| display_name_ciphertext | ENC | User-selected display name |
| phone_ciphertext | ENC? | Optional contact field only when justified, not required for sandbox |
| locale / time_zone | text default `en-IN` / text default `Asia/Kolkata` | Validated locale/IANA zone, not arbitrary execution input |
| preferences | jsonb default `{}` | Versioned nonsecret UI preferences; no balances/keys |
| preferences_schema_version | smallint default 1 | Decoder version |

### password_credentials — M

`user_id uuid FK users U`; `password_hash text` (Argon2id PHC string containing salt/parameters; verifier only); `pepper_key_version text?` (external key reference); `changed_at timestamptz`; `must_reset boolean DEFAULT false`. Preserve credential-change audit, not plaintext/password-history exports. Index user_id through U. Any optional password history must store verifiers under a separately reviewed retention policy.

### devices — M

`user_id uuid FK users`; `device_token_digest H32 U` (random device binding verifier, not a raw hardware fingerprint); `label_ciphertext ENC?`; `metadata_ciphertext ENC?` (bounded user agent/network metadata); `first_seen_at timestamptz`; `last_seen_at timestamptz`; `revoked_at timestamptz?`; `risk_reference uuid U` (random pseudonymous reference exported only with trusted events). Add `U(id,user_id)` and index `(user_id,last_seen_at DESC,id)`. Device registration does not certify device trust.

### sessions — M

`user_id uuid FK users`; `device_id uuid?` composite FK `(device_id,user_id) → devices(id,user_id)`; `family_id uuid U`; `authenticated_at timestamptz`; `last_seen_at timestamptz`; `expires_at timestamptz`; `revoked_at timestamptz?`; `revocation_reason text?`; `assurance_level text` (PASSWORD, MFA); `credentials_version bigint`; `session_token_digest H32 U`. CHECK expiry > authenticated time. Index active sessions `(user_id,expires_at)` WHERE revoked_at IS NULL. A device owned by another user cannot be attached.

### refresh_tokens — M

`session_id uuid FK sessions`; `parent_token_id uuid?` self-FK; `token_digest H32 U`; `issued_at timestamptz`; `expires_at timestamptz`; `used_at timestamptz?`; `revoked_at timestamptz?`. Add `U(id,session_id)` and composite parent FK to enforce same session; U(parent_token_id) for one rotated child and partial U(session_id) WHERE parent_token_id IS NULL for one root per session. Token verifier immutable; use/revocation timestamps monotonic. Reuse detection atomically revokes the session family; expiration cleanup retains required family replay evidence.

### web_sessions — M

`session_id uuid FK sessions U`; `browser_cookie_digest H32 U`; `refresh_token_ciphertext ENC`; `access_tokens_ciphertext ENC?` (audience-keyed tokens, if cached); `expires_at timestamptz`; `revoked_at timestamptz?`. This restricted bridge store is distinct from auth's verifier-only refresh table; it needs encrypted token recovery for server-side requests. Browser sees only opaque cookie. Revoke with parent session; do not log decrypted tokens.

### mfa_factors — M

`user_id uuid FK users`; `factor_type text` (WEBAUTHN, TOTP); `credential_id bytea? U`; `public_key bytea?`; `totp_secret_ciphertext ENC?`; `sign_count bigint? CHECK >=0`; `enrolled_at timestamptz?`; `verified_at timestamptz?`; `revoked_at timestamptz?`. CHECK WEBAUTHN requires credential/public key and no TOTP secret; TOTP requires encrypted secret and no WebAuthn credential. Enrollment activates only after challenge verification. Index `(user_id,factor_type)`.

### recovery_codes — M

`user_id uuid FK users`; `generation_id uuid`; `code_digest H32 U`; `issued_at timestamptz`; `used_at timestamptz?`; `revoked_at timestamptz?`. Only hashes, one-time atomic consumption. Index `(user_id,generation_id)`. Regeneration revokes earlier unused generation; no plaintext recovery-code column.

Identity also instantiates the audit/outbox/inbox definitions from section 4 with the identity-specific actor variant and no network/financial operation FK. A minimal typed identity event includes source user UUID, source version and lifecycle status; no password/session secret/PII payload is sent to financial databases.

## 3. Domain registries (separate copies in BPI and FINCOIN)

### core.networks — M

`network_code text U` (exact signed chain ID); `domain text` fixed BPI in bpi_db and FINCOIN in fincoin_db; `environment text CHECK = 'sandbox'`; `epoch bigint >0`; `protocol_version smallint >0`; `genesis_hash H32`; `status text` (INITIALIZING, ACTIVE, PAUSED, RETIRED). U(domain,environment,epoch). Domain/network identity and genesis immutable after activation. Network row is local FK root; registry insertion precedes genesis posting.

### core.assets — I + N

`asset_code text`; `decimals smallint`; `value_kind text CHECK = 'simulated'`; `issuance_policy text`; `initial_issuance_atomic Q DEFAULT 0`; `post_init_issuance_allowed boolean`; U(network_id,asset_code); U(id,network_id,asset_code). BPI permits only INR/2 with zero initial quantity and simulated gateway issuance. FINCOIN permits FINCOIN/8 with initial 100000000000000 atoms and no later issuance, and SIM_INR/2 with initial 100000000 minor units and capped later issuance. These immutable values are pinned by genesis, not editable settings. Enforce constants through database-specific CHECKs plus validated insert routine. No FINCOIN row can enter BPI registry.

### core.subjects — M

`source_identity_version bigint >0`; `status text` (ACTIVE, FROZEN, DISABLED, DELETED); `display_label_ciphertext ENC?`; `last_synced_at timestamptz`; `source_event_id uuid U`. PK id equals the replicated identity user ID; no cross-DB FK. Version-ordered ingestion only, no arbitrary client upsert. Subject row is retained as tombstone when PII removed. No email/password fields.

### core.principals — M

`kind text` (USER, ORGANIZATION, SERVICE); `subject_id uuid? FK subjects`; `service_code text? U`; `status text` (ACTIVE, REVOKED). USER requires subject_id and no service_code; SERVICE requires service_code and no subject_id; ORGANIZATION requires neither and is attached one-to-one to a merchant account in BPI. Partial U(subject_id) WHERE kind=USER. A service cannot satisfy an independent human approval. Organization principal has no authentication secret in this table.

### core.device_references — M

`subject_id uuid FK subjects`; `source_device_ref uuid U`; `status text` (KNOWN, REVOKED); `first_seen_at timestamptz`; `last_seen_at timestamptz`; `source_version bigint >0`. Minimal identity-derived reference for risk FKs; no raw device fingerprint/IP. Add U(id,subject_id). Cross-DB equality/source reference is authenticated replication, not a fake FK to auth.devices.

### core.signing_keys — I + N

`purpose text` (WALLET, VALIDATOR, SYSTEM, CHECKPOINT); `algorithm text CHECK = 'Ed25519'`; `key_reference text U`; `public_key bytea CHECK length=32`; `vault_handle text`; `owner_principal_id uuid FK principals`; `created_by uuid FK principals`. Vault handle is private metadata, not secret material; public projection omits it. Key public bytes never change. Revocation/validity is expressed by binding records/events, not rewriting historic keys.

### ledger.key_bindings — M + N

`wallet_id uuid? FK W`; `key_id uuid FK signing_keys`; `binding_kind text` (WALLET, VALIDATOR, SYSTEM); `valid_from_height bigint >=0`; `valid_until_height bigint?`; `authorized_by_operation_id uuid FK ops.operations`; `status text` (SCHEDULED, ACTIVE, RETIRED, REVOKED). Require wallet only for WALLET kind. U(network_id,key_id,valid_from_height). CHECK end > start when set. Posting/rotation routine locks wallet/network and forbids overlapping effective bindings for a purpose. Key history and public proof-of-possession/event evidence remain verifiable.

## 4. Durable operations, settings, notifications and audit

These are independent copies per domain. Their IDs never authorize a financial action by themselves.

### ops.operations — I + N

`kind text` (versioned allowlisted action code); `parent_operation_id uuid?` same-network self-FK; `slot_key text?`; `initiator_principal_id uuid FK core.principals`; `request_digest H32`; `correlation_id uuid`; `occurred_at timestamptz`. Parent and slot are both null for a root or both present for a child. U(parent_operation_id,slot_key) for child slots; no parent=self. Partial U(network_id) WHERE kind='INITIALIZE_NETWORK' prevents a second bootstrap root. Root is the durable business operation namespace. Each financial posting uses a distinct stable child slot; retries reuse it. This row is not a journal or balance.

### ops.idempotency_keys — M + N

`principal_id uuid FK principals`; `route_code text`; `key_digest H32`; `request_digest H32`; `operation_id uuid FK operations`; `http_status smallint?`; `response_ciphertext ENC?`; `response_expires_at timestamptz?`. U(principal_id,network_id,route_code,key_digest). Same key/different digest conflicts. Expiring the response blob does not remove the key→operation tombstone for the epoch. Exact cached body encrypted if private; HTTP status is not financial status. Never cache a one-time API-key/recovery-code secret issuance body here: retain only safe resource ID/outcome, and use the documented rotate/regenerate recovery if its initial response is lost.

### ops.commands — M + N

`operation_id uuid FK operations`; `command_kind text`; `schema_version smallint >0`; `payload_canonical bytea`; `payload_digest H32`; `authorization_id uuid? FK authorizations`; `state text` (QUEUED, LEASED, RETRY, SUCCEEDED, REJECTED); `attempts integer DEFAULT 0 CHECK >=0`; `next_attempt_at timestamptz`; `lease_owner text?`; `lease_until timestamptz?`; `result_reference uuid?`; `error_code text?`. U(operation_id,command_kind). result_reference is an opaque result identifier in a versioned response, not an unenforced financial FK; concrete result tables link back to operation. Expired lease enables retry, not a new operation. Index queued/retry next_attempt_at, and leased lease_until. Canonical payload cannot change on retry; no contact data, raw private notes or secrets in generic command JSON. Pseudonymous signed financial terms remain restricted private data.

### ops.authorizations — M + N

`operation_id uuid FK operations`; `actor_principal_id uuid FK principals`; `intent_revision bigint >0`; `authorization_version bigint >0`; `payload_canonical bytea`; `payload_digest H32`; `key_id uuid FK signing_keys`; `permissions_version bigint`; `authenticated_at timestamptz`; `expires_at timestamptz`; `signature SIG64?`; `signing_consumed_at timestamptz?`; `execution_consumed_at timestamptz?`; `status text` (ISSUED, SIGNED, CONSUMED, REVOKED, EXPIRED, SUPERSEDED). U(operation_id,authorization_version). Frozen digest/bytes/actor/terms after issuance; only signature and monotonic lifecycle fields change. Signing replay returns same signature for same grant; it cannot sign another digest. Ledger independently checks the current authorization and bound entity/network/key ownership. Consumer session IDs are remote opaque evidence in private audit, not cross-DB FKs.

### ops.approval_proposals — M + N

`operation_id uuid FK operations`; `proposal_kind text` (PAYOUT, REFUND, CORRECTION, KEY_ROTATION, PAUSE, POLICY); `payload_digest H32`; `maker_principal_id uuid FK principals`; `required_approvals smallint >0`; `expires_at timestamptz`; `status text` (OPEN, APPROVED, REJECTED, EXPIRED, EXECUTED); `executed_transaction_id uuid? FK ledger.transactions`. U(operation_id,payload_digest). New terms create a new proposal; executed status requires evidence/appropriate result. Nonfinancial proposals may finish through audit operation rather than a journal, with execution kind validated by routine.

### ops.approval_decisions — I + N

`proposal_id uuid FK approval_proposals`; `approver_principal_id uuid FK principals`; `decision text` (APPROVE, REJECT); `reason_ciphertext ENC?`; `authenticated_at timestamptz`; `decided_at timestamptz`; `payload_digest H32`. U(proposal_id,approver_principal_id). Controlled routine checks same payload, current scope/MFA and distinct subject from maker/other checker; USER principals only for required human approvals. No self-approval by using a service/organization principal.

### ops.proposal_lines — I + N

`proposal_id uuid FK approval_proposals`; `line_no integer >0`; `account_id uuid FK ledger.accounts`; `asset_id uuid FK assets`; `side text` (DEBIT,CREDIT); `amount_atomic Q+`. U(proposal_id,line_no); composite account/asset/network FK. Used only for CORRECTION proposals; deferred validation requires balanced proposed totals before approval. Proposed lines have no balance effect until validated posting.

### ops.outbox — M + N

`operation_id uuid FK operations`; `aggregate_id uuid`; `aggregate_version bigint >0`; `event_type text`; `schema_version smallint >0`; `payload jsonb`; `occurred_at timestamptz`; `published_at timestamptz?`. U(network_id,aggregate_id,aggregate_version,event_type). PK id is event ID. Payload and event fields immutable; only delivery metadata changes. Aggregate_id is a versioned event-stream identity, not a generic FK claim. Payload must use permitted references/data only. Publisher crash can duplicate delivery; consumers dedupe.

### ops.inbox — M

`consumer_code text`; `source_code text`; `source_event_id uuid`; `source_version bigint?`; `payload_digest H32`; `received_at timestamptz`; `processed_at timestamptz?`; `state text` (RECEIVED, APPLIED, PARKED, REJECTED). U(consumer_code,source_code,source_event_id). External source event has no FK to another DB. Same source ID/different digest is quarantined. Local-event consumers can additionally verify source outbox references through their dedicated consumer logic.

Identity's outbox variant uses no N or operation FK: `user_id uuid FK auth.users`, `source_version bigint`, `event_type`, minimal payload, occurred/published times with U(user_id,source_version,event_type). Its inbox keeps the same local dedupe shape. No financial operation table is instantiated inside identity_db.

### app.system_settings — M

`scope_principal_id uuid FK principals`; `setting_key text`; `setting_version bigint >0`; `value jsonb`; `value_schema_version smallint >0`; `effective_from timestamptz`; `superseded_at timestamptz?`; `approved_proposal_id uuid? FK approval_proposals`. U(scope_principal_id,setting_key,setting_version); partial U(scope_principal_id,setting_key) WHERE superseded_at IS NULL. Use a domain service principal for global scope rather than nullable tenant uniqueness. Version/value immutable once effective; activation/supersession audited. No passwords, keys, live adapters, sandbox-disable or cross-domain conversion setting.

### app.notifications — M

`recipient_subject_id uuid FK subjects`; `source_event_id uuid FK ops.outbox`; `channel text` (IN_APP, EMAIL_SANDBOX, SMS_SANDBOX); `template_code text`; `content_ciphertext ENC`; `state text` (PENDING, SENT, FAILED, READ); `read_at timestamptz?`; `sent_at timestamptz?`; `next_attempt_at timestamptz?`; `attempts integer DEFAULT 0 CHECK >=0`. U(recipient_subject_id,source_event_id,channel). “Sent” means actual configured delivery acknowledgment. Subject-level in-app read marker does not change source financial state. Retention may remove private content while retaining required event/delivery references.

### audit.audit_streams — M

`stream_code text U`; `head_log_id uuid? FK audit_logs`; `next_sequence bigint DEFAULT 1 CHECK >0`; `last_exported_sequence bigint DEFAULT 0 CHECK >=0`. Lock stream when appending; separate streams avoid a single global hot row. No network in identity variant; domain scope is carried by event references/private payload. Head FK is added after audit_logs exists and deferred as required.

### audit.audit_logs — I

`stream_id uuid FK audit_streams`; `sequence bigint >0`; `actor_principal_id uuid FK principals`; `operation_id uuid? FK operations`; `action text`; `result_code text`; `resource_type text`; `resource_reference uuid?`; `reason_ciphertext ENC?`; `evidence_ciphertext ENC?`; `before_digest H32?`; `after_digest H32?`; `previous_hash H32`; `event_hash H32`; `occurred_at timestamptz`; `correlation_id uuid`. U(stream_id,sequence), U(event_hash). Resource reference is an audit snapshot identifier; financial links use operation_id or typed source rows, not this generic field. Chain hashes computed over canonical minimal evidence commitment. Identity variant replaces actor_principal_id with `actor_user_id uuid? FK auth.users` and `actor_service_code text?`, exactly one set, and omits operation FK. System bootstrap uses a service actor, not an invented user.

## 5. Shared accounting and blockchain templates (per financial DB)

### ledger.accounts — I + N

`asset_id uuid FK assets`; `wallet_id uuid? FK W`; `system_owner_principal_id uuid? FK principals`; `account_code text`; `account_class text` (ASSET, LIABILITY, ISSUANCE); `normal_side text` (DEBIT,CREDIT); `role_code text` (domain-specific controlled codes). Exactly one of wallet/system owner. U(id,network_id,asset_id). Partial U(wallet_id,asset_id,role_code) for wallet accounts; partial U(network_id,system_owner_principal_id,asset_id,account_code) for system accounts. BPI roles include SETTLED, PENDING, REDEMPTION_PENDING, GATEWAY_ASSET; FINCOIN includes HOLDER, INVENTORY, FEES, ISSUANCE. Valid role/asset/class combinations enforced by registry/posting routines.

### ledger.account_balances — M + N

`account_id uuid FK accounts U`; `debit_total_atomic Q DEFAULT 0`; `credit_total_atomic Q DEFAULT 0`; `last_transaction_id uuid? FK transactions`. Synchronous running totals; posted account balance is computed using account normal side, never guessed from sign. Shared numeric totals do not permit FINCOIN in BPI. Ledger-only writes, reconciled against all journal lines. Wallet/system inventory constraints are checked during posting; issuance contra account is not an ordinary spendable account.

### ledger.transactions — I + N

`operation_id uuid FK ops.operations U`; `event_kind text`; `posted_at timestamptz`; `original_transaction_id uuid?` same-network self-FK; `initiator_principal_id uuid FK principals`; `journal_digest H32`; `journal_commitment H32`; `commitment_salt_ciphertext ENC`; `protocol_version smallint >0`. BPI adds `payment_id uuid? FK app.payments`, `wallet_operation_id uuid? FK app.wallet_operations`; an ordinary payment event requires payment_id only, a funding/redemption event requires wallet_operation_id only, and approved correction may use original_transaction_id/proposal. FINCOIN instead uses typed fincoin_transactions below. No mutable status or soft deletion. No transaction is valid without balanced lines and a committed chain attachment.

### ledger.journal_lines — I + N

`transaction_id uuid FK transactions`; `line_no integer >0`; `account_id uuid`; `asset_id uuid`; `side text CHECK IN ('DEBIT','CREDIT')`; `amount_atomic Q+`. U(transaction_id,line_no). Composite FK `(account_id,network_id,asset_id) → accounts(id,network_id,asset_id)` and normal asset/network FKs. At deferred commit, at least two lines and balanced sums per asset. No negative/zero lines or editing historical entries; corrections are new headers/lines. Index `(account_id,created_at,id)` and transaction_id through U.

### ledger.blockchain_transactions — I + N

`transaction_id uuid FK transactions U`; `transaction_hash H32 U`; `kind text`; `payload_canonical bytea`; `payload_digest H32`; `signature SIG64`; `signing_key_id uuid FK signing_keys`; `authorization_id uuid? FK ops.authorizations`; `sender_wallet_id uuid? FK W`; `nonce bigint? CHECK >=0`; `issuer_principal_id uuid? FK principals`; `issuer_sequence bigint? CHECK >=0`. User transaction: sender/nonce/authorization present, issuer fields null; system event: issuer/sequence present, sender/nonce/authorization null. U(network_id,sender_wallet_id,nonce) for sender rows; U(network_id,issuer_principal_id,issuer_sequence) for system rows. Exact immutable signed bytes retained; status/block data not embedded in signed intent. Verify hash/signature/key binding before insertion. Values/participants remain private in payload and typed business tables.

### ledger.blocks — I + N

`height bigint >=0`; `block_hash H32 U`; `previous_block_id uuid?`; `previous_hash H32`; `merkle_root H32`; `timestamp timestamptz`; `transaction_count integer >=0`; `writer_epoch bigint >=0`; `validator_key_id uuid FK signing_keys`; `signature SIG64`; `protocol_version smallint >0`. U(network_id,height), U(id,network_id,block_hash). Composite self-FK `(previous_block_id,network_id,previous_hash)` to matching previous header. Height 0 requires null predecessor/zero hash; other heights require predecessor. Deferred validation checks previous height+1, body/root/count and authorized validator binding. Genesis is the only allowed zero-event block in this baseline. No rewriting a signed header.

### ledger.block_memberships — I + N

`block_id uuid FK blocks`; `blockchain_transaction_id uuid FK blockchain_transactions U`; `tx_index integer CHECK >=0`; `leaf_hash H32`. U(block_id,tx_index). Chain attachment count and contiguous indexes `0..transaction_count−1` checked at deferred commit; hashes/root recomputed with protocol canonicalization. Table is the only inclusion link, avoiding contradictory block IDs on multiple tables. FK chain/body cannot cross network.

### ledger.chain_heads — M + N

`last_block_id uuid? FK blocks`; `height bigint DEFAULT -1 CHECK >=-1`; `block_hash H32`; `writer_epoch bigint DEFAULT 0 CHECK >=0`; `writer_lease_owner text?`; U(network_id). Initial state -1/zero hash/no last block before genesis; otherwise pointer/hash/height match last block, checked by routine. Database advisory lock plus row lock/fencing epoch governs one writer; Redis lease is not sufficient. PK remains UUID, not network_id.

### ledger.holds — M + N

`operation_id uuid FK operations`; `wallet_id uuid FK W`; `asset_id uuid FK assets`; `amount_atomic Q+`; `expires_at timestamptz`; `state text` (ACTIVE, CONSUMED, RELEASED, EXPIRED); `resolved_at timestamptz?`. U(operation_id,wallet_id,asset_id); partial index active wallet/expiry. Exactly matched to signed intent amount/fee and root operation by reservation routine. BPI amount fits MINOR and INR; FINCOIN may hold FNC or SIM_INR in its own database. Immutable amount after creation.

### ledger.nonce_claims — M + N

`wallet_id uuid FK W`; `operation_id uuid FK operations`; `nonce bigint CHECK >=0`; `state text` (ACTIVE, CONSUMED, RELEASED); `expires_at timestamptz`; `resolved_at timestamptz?`. Partial U(wallet_id) WHERE state=ACTIVE; U(operation_id). Inclusion consumes and increments wallet next_nonce atomically. Released claims can share a nonce with a later intent, but included blockchain transactions cannot. Do not enforce uniqueness of all historical claim nonces, which would prevent safe reuse after pre-inclusion failure.

### ledger.limit_buckets — M + N

`owner_principal_id uuid FK principals`; `asset_id uuid FK assets`; `limit_code text`; `window_start timestamptz`; `window_end timestamptz`; `limit_atomic Q`; `used_atomic Q DEFAULT 0`; `reserved_atomic Q DEFAULT 0`; U(owner_principal_id,network_id,asset_id,limit_code,window_start). CHECK window_end>start and used+reserved<=limit. User/organization principals allow caps across multiple wallets. Bucket boundaries determined by versioned policy; never a client-provided bypass interval.

### ledger.issuer_sequences — M + N

`issuer_principal_id uuid FK core.principals`; `next_sequence bigint DEFAULT 0 CHECK >=0`; U(network_id,issuer_principal_id). Ledger writer locks this row and increments sequence atomically with a system transaction; uniqueness on included system events remains an independent guard. Failed/uncommitted proposal does not consume a sequence. No client or gateway may supply an arbitrary system issuer identity/sequence to obtain posting authority.

### ledger.limit_reservations — M + N

`bucket_id uuid FK limit_buckets`; `operation_id uuid FK operations`; `amount_atomic Q+`; `state text` (ACTIVE, CONSUMED, RELEASED); U(bucket_id,operation_id). Row locks and balanced bucket updates in same reservation/inclusion transaction. Included activity stays in velocity used totals even after financial return; do not reset fraud history by refunding.

## 6. BPI ownership, wallets and payments (`bpi_db`)

### app.merchant_accounts — S

`principal_id uuid FK core.principals U` (ORGANIZATION kind); `owner_subject_id uuid FK subjects`; `display_name_ciphertext ENC`; `business_category text`; `status text` (DRAFT, REVIEW_PENDING, ACTIVE, RESTRICTED, CLOSED); `sandbox_reviewed_at timestamptz?`; `time_zone text DEFAULT 'Asia/Kolkata'`; `permissions_version bigint DEFAULT 1 CHECK >0`. Review is sandbox onboarding, not regulatory verification. Principal and account must be 1:1 through the controlled registration transaction. Index owner_subject_id/status. Closure retains organization and membership/audit history.

### app.merchant_outlets — S

`merchant_account_id uuid FK merchant_accounts`; `outlet_code text`; `display_name_ciphertext ENC`; `status text` (ACTIVE, DISABLED). U(merchant_account_id,outlet_code), U(id,merchant_account_id). No reusing a deleted outlet code in a way that changes historical invoice meaning. Index merchant_account_id through U.

### app.merchant_memberships — M

`merchant_account_id uuid FK merchant_accounts`; `subject_id uuid FK subjects`; `outlet_id uuid?`; `role_code text` (OWNER, CASHIER, MAKER, CHECKER, INTEGRATION_MANAGER, ANALYST); `granted_by uuid FK principals`; `granted_at timestamptz`; `revoked_at timestamptz?`; `permissions_version bigint >0`. Composite FK `(outlet_id,merchant_account_id) → merchant_outlets(id,merchant_account_id)`. Unique active `(merchant_account_id,subject_id,role_code,outlet_id) NULLS NOT DISTINCT` via partial unique index WHERE revoked_at IS NULL. Removing last active owner is prohibited under organization lock; revocations are retained, not soft-hidden.

### ledger.wallets — M + N

`owner_principal_id uuid FK principals`; `consumer_subject_id uuid? FK subjects`; `merchant_account_id uuid? FK merchant_accounts`; `outlet_id uuid?`; `asset_id uuid FK assets`; `status text` (ACTIVE, FROZEN, CLOSED); `next_nonce bigint DEFAULT 0 CHECK >=0`; `closed_at timestamptz?`. Exactly one consumer/merchant owner; outlet permitted only for merchant and composite FK enforces same merchant. The principal must match consumer subject's USER principal or merchant's ORGANIZATION principal, checked on immutable ownership creation. Owner/network/asset immutable. U(id,network_id,asset_id); one consumer wallet per subject/network/asset; one merchant wallet per merchant/outlet/network/asset using NULLS NOT DISTINCT. Scope role requires INR asset; no FINCOIN wallet here.

### ledger.wallet_addresses — M + N (also instantiate in FINCOIN with W FK)

`wallet_id uuid FK W`; `address text`; `address_digest H32`; `registered_key_id uuid FK signing_keys`; `state text` (ACTIVE, RETIRED); `is_preferred boolean DEFAULT true`; `valid_from timestamptz`; `retired_at timestamptz?`. U(network_id,address), U(network_id,address_digest), U(id,wallet_id,network_id). Partial U(wallet_id) WHERE state=ACTIVE AND is_preferred. Address/checksum/domain validated by registration routine. Address string is immutable pseudonymous private ledger metadata, not a public projection. Signing rotation changes key binding, not this historical registration identity. Registry has no email/phone/name.

### ledger.balances — M + N

`wallet_id uuid`; `asset_id uuid`; `settled_minor MINOR DEFAULT 0`; `held_minor MINOR DEFAULT 0`; `pending_minor MINOR DEFAULT 0`; `available_minor bigint GENERATED ALWAYS AS (settled_minor-held_minor) STORED`; `last_transaction_id uuid? FK transactions`. U(wallet_id); composite FK `(wallet_id,network_id,asset_id) → wallets(id,network_id,asset_id)`. CHECK settled>=held. Trigger/posting assertions reconcile settled/pending accounts and active holds. No writable available-balance column and no FINCOIN portfolio valuation.

### app.payment_requests — M + N

`payee_wallet_id uuid FK wallets`; `asset_id uuid FK assets`; `amount_minor MINOR+`; `allowed_payer_subject_id uuid? FK subjects`; `request_token_digest H32 U`; `link_payload_ciphertext ENC`; `signing_key_id uuid FK signing_keys`; `expires_at timestamptz`; `status text` (OPEN, CLAIMED, PAID, EXPIRED, CANCELED); `active_payment_id uuid? FK payments`; `order_id uuid? FK commerce.commerce_orders`; `invoice_id uuid? FK commerce.invoices`; `created_by uuid FK principals`. Composite payee-wallet/asset/network FK. If both order/invoice exist, they must belong to the same checkout/merchant, enforced with typed composites/routine. Amount/asset/payee/expiry/token frozen after issue. Active payment link must be a payment of this request via deferred composite relationship, not an arbitrary payment UUID.

Request claiming is performed under row lock; exactly one active payment. PAID requires completed linked payment; CLAIMED holds through uncertain settlement. Dynamic token is unguessable, signature checked; store lookup digest and encrypted shareable payload, not login credentials. Request expiration checks occur at use time (do not put `now()` in a persistent partial uniqueness predicate).

### app.qr_payments — M + N

`qr_kind text` (STATIC_MERCHANT, DYNAMIC_REQUEST, ADDRESS_ONLY); `merchant_account_id uuid? FK merchant_accounts`; `outlet_id uuid?`; `request_id uuid? FK payment_requests`; `wallet_address_id uuid? FK wallet_addresses`; `payload_digest H32`; `payload_ciphertext ENC`; `status text` (ACTIVE, RETIRED); `created_by uuid FK principals`. DYNAMIC_REQUEST requires only request target; STATIC_MERCHANT requires merchant and optional its outlet; ADDRESS_ONLY requires address target. CHECK exact target combination; composite outlet/merchant FK. Partial U(request_id) for one primary generated dynamic QR per request; printed copies reuse it. This table describes initiation media, not a journal. No separate QR balance/settlement/status authority and no scan-initiated auto-payment.

### app.payments — I + N

`operation_id uuid FK ops.operations U`; `sender_wallet_id uuid FK wallets`; `receiver_wallet_id uuid FK wallets`; `sender_address_id uuid`; `receiver_address_id uuid`; `asset_id uuid FK assets`; `amount_minor MINOR+`; `fee_minor MINOR DEFAULT 0 CHECK =0`; `payment_type text` (P2P,P2B,B2P,B2B); `request_id uuid? FK payment_requests`; `qr_payment_id uuid? FK qr_payments`; `created_by uuid FK principals`; `terms_revision bigint DEFAULT 1`; `terms_digest H32`; `expires_at timestamptz`. Composite address/wallet/network FKs and both wallet/asset/network FKs. Reject self-transfer in v1; type derives from owner kinds and cannot be client-selected. U(id,request_id,network_id) supports request's active-payment back-reference (nullable request remains absent for direct pay). Financial terms are immutable; editing creates a new draft/intent, while reauthorization of unchanged terms increments grant version.

QR linkage must resolve to the same request/payee; static QR references the correct merchant. Payment-request amount/currency/payee must match at reservation. Private note is in payment_metadata rather than the signed/public record.

### app.payment_metadata — M

`payment_id uuid FK payments U`; `note_ciphertext ENC?`; `note_length smallint? CHECK BETWEEN 0 AND 140`; `metadata_version smallint DEFAULT 1`; `retention_until timestamptz?`. At least note/length present together. Note cannot change authorized financial terms; post-submit amendments are audited and never written to chain/exported publicly. Deletion of eligible note payload may null both fields without deleting payment history.

### ledger.payment_states — M + N

`payment_id uuid FK payments U`; `business_status text DEFAULT 'DRAFT'`; `chain_status text DEFAULT 'NOT_SUBMITTED'`; `settlement_status text DEFAULT 'NOT_STARTED'`; `current_authorization_id uuid? FK ops.authorizations`; `current_fraud_score_id uuid? FK risk.fraud_scores`; `included_transaction_id uuid? FK ledger.transactions`; `terminal_transaction_id uuid? FK ledger.transactions`; `completed_at timestamptz?`; `terminal_at timestamptz?`; `safe_reason_code text?`. Every pointer must match this payment/operation via routine/deferred trigger, not merely exist. Initializer permits DRAFT only; subsequent transitions ledger-owned. Allowed status tuples are enumerated in section 11 below. No `INCLUDED` persisted business state: inclusion writes SETTLEMENT_PENDING directly.

### app.wallet_operations — M + N

`operation_id uuid FK ops.operations U`; `wallet_id uuid FK wallets`; `asset_id uuid FK assets`; `kind text` (FUNDING, REDEMPTION); `amount_minor MINOR+`; `created_by uuid FK principals`; `authorization_id uuid? FK ops.authorizations`; `expires_at timestamptz?`; `state text` (DRAFT,AUTHORIZED,SUBMITTED,CANCELED,EXPIRED). Financial terms freeze on creation; only authorization/lifecycle fields change. REDEMPTION may start unsigned in DRAFT but requires bound signed authorization and valid expiry before reservation/submission. FUNDING uses capped simulator/issuer approval, never incoming arbitrary callback authority. Submitted operation outcome lives in settlements/operation events; no second editable wallet balance. Ordinary payment metric queries exclude these operations.

### app.refunds — I + N

`original_payment_id uuid FK payments`; `refund_payment_id uuid FK payments U`; `requested_by uuid FK principals`; `amount_minor MINOR+`; `reason_ciphertext ENC`; `approval_proposal_id uuid? FK ops.approval_proposals`. CHECK original != refund payment. Deferred validation enforces original completed, reversed original parties, same asset/network and amount equal to reverse payment. Original payment cannot itself be a refund in v1. Status derives from the linked reverse payment, not an independent mutable success flag. Index original_payment_id.

### ledger.refund_totals — M + N

`original_payment_id uuid FK payments U`; `original_amount_minor MINOR+`; `reserved_refund_minor MINOR DEFAULT 0`; `completed_refund_minor MINOR DEFAULT 0`. CHECK reserved+completed<=original. Copied original amount must match immutable payment. Lock this row during reserve/release/complete and reconcile totals to linked refund statuses. Unknown refund keeps reserved allowance; no over-refund through simultaneous partial requests.

### app.recipient_aliases — S

`subject_id uuid FK subjects U`; `alias_ciphertext ENC`; `alias_lookup_digest H32 U`; `lookup_key_version smallint >0`; `opted_in_at timestamptz`; `revoked_at timestamptz?`; `preferred_wallet_id uuid FK wallets`. Exact opt-in lookup only; subject/wallet ownership checked on setting. This UI extension stores no public directory/search prefix index. Revoked alias cannot resolve; retained lookup tombstone prevents immediate confusing reassignment unless a separately defined reassignment policy exists.

## 7. Settlement, fraud and risk (`bpi_db`)

### integration.settlements — M + N

`operation_id uuid FK ops.operations U`; `payment_id uuid? FK app.payments`; `wallet_operation_id uuid? FK app.wallet_operations`; `kind text` (TRANSFER_SETTLEMENT, FUNDING, REDEMPTION); `asset_id uuid FK assets`; `amount_minor MINOR+`; `status text` (PENDING, UNKNOWN, SUCCEEDED, FAILED); `next_check_at timestamptz`; `last_checked_at timestamptz?`; `terminal_evidence_id uuid? FK gateway_events`; `terminal_transaction_id uuid? FK ledger.transactions`; `resolved_at timestamptz?`. Exactly one payment/wallet-operation source. Partial U(payment_id) for transfer settlement, partial U(wallet_operation_id) for funding/redemption. Transfer/refund settlement is created with inclusion; no included payment without its settlement/outbox. FUNDING failure can have no journal; other required terminal postings are enforced by kind. Status success only after ledger applies verified evidence.

The settlement operation is the stable SETTLEMENT child of its source root operation. Verified final application uses its single APPLY_TERMINAL child. Failure without a financial effect still records the terminal command/evidence idempotently; absence of a journal for failed funding does not permit a second conflicting terminal application.

### integration.gateway_transactions — M + N

`settlement_id uuid FK settlements U`; `provider_code text CHECK = 'FINCHAIN_SIMULATOR'`; `provider_operation_ref text`; `request_digest H32`; `request_ciphertext ENC`; `observed_status text` (NOT_SUBMITTED, PENDING, UNKNOWN, SUCCEEDED, FAILED); `submitted_at timestamptz?`; `last_observed_at timestamptz?`; `attempt_count integer DEFAULT 0 CHECK >=0`; `next_attempt_at timestamptz?`. U(provider_code,provider_operation_ref). Provider reference derives from stable operation UUID and is allocated before first submission. Transport retry updates attempts but never changes operation ref/request digest. Observed status is provider evidence, not the authoritative credited balance state.

### integration.gateway_events — I

`provider_code text`; `provider_event_id text`; `provider_operation_ref text`; `gateway_transaction_id uuid? FK gateway_transactions`; `claimed_network_code text`; `body_digest H32`; `evidence_ciphertext ENC`; `signature_valid boolean`; `reported_status text`; `reported_asset_code text`; `reported_amount_text text`; `provider_occurred_at timestamptz`; `received_at timestamptz`. U(provider_code,provider_event_id). Reported amount is untrusted raw text until validation; do not cast directly into ledger. Unknown/wrong-network evidence can be retained without a local financial FK, but cannot apply. Optional local mapping cannot be reassigned once accepted; ingestion handling/case records capture quarantine. Terminal evidence same operation/amount/currency/network verified before posting. Duplicate event ID with different body is a conflict case, not overwrite.

### integration.reconciliation_runs — M + N

`started_at timestamptz`; `completed_at timestamptz?`; `provider_code text`; `cursor_before text?`; `cursor_after text?`; `status text` (RUNNING, COMPLETED, FAILED); `matched_count integer DEFAULT 0`; `exception_count integer DEFAULT 0`; `statement_digest H32?`; `initiated_by uuid FK principals`. Counts nonnegative; record actual source range. Cursor advancement only after durable processing so failures are replayable.

### integration.reconciliation_cases — M + N

`settlement_id uuid? FK settlements`; `gateway_event_id uuid? FK gateway_events`; `run_id uuid? FK reconciliation_runs`; `classification text` (MISSING,DUPLICATE,ORPHAN,AMOUNT_MISMATCH,STATUS_CONFLICT); `status text` (OPEN,INVESTIGATING,RESOLVED); `assigned_to uuid? FK principals`; `reason_ciphertext ENC`; `resolution_operation_id uuid? FK operations`; `resolved_at timestamptz?`. At least source settlement or event. An orphan has event without settlement, never newly minted credit. Index open cases `(status,created_at,id)`; immutable investigation notes go to audit, not overwriting evidence.

### risk.fraud_scores — I + N

`payment_id uuid FK app.payments`; `authorization_id uuid FK ops.authorizations`; `assessment_version bigint >0`; `score smallint CHECK BETWEEN 0 AND 100`; `decision text` (ALLOW,REVIEW,DENY); `display_severity text` (LOW,MEDIUM,HIGH,CRITICAL); `safe_reason_codes text[]`; `policy_setting_id uuid FK app.system_settings`; `input_digest H32`; `assessed_at timestamptz`; `expires_at timestamptz`. U(payment_id,assessment_version). Validate authorization belongs to payment/current terms. Score/decision/severity are server output, not frontend thresholds; allow freshness max 60 seconds per Role 1. Safe reasons drawn from allowlist; sensitive reasons remain encrypted events. Reassessment appends a new score; never edits the old one.

### risk.fraud_events — I

`subject_id uuid? FK core.subjects`; `device_reference_id uuid? FK core.device_references`; `payment_id uuid? FK app.payments`; `fraud_score_id uuid? FK fraud_scores`; `event_type text`; `evidence_ciphertext ENC`; `evidence_digest H32`; `observed_at timestamptz`; `retain_until timestamptz?`. At least one typed subject/payment/assessment context; device must belong to subject when both present. Private observed evidence may predate a payment. Raw evidence retention may crypto-erase eligible content under policy while immutable digest/reference is retained through a controlled retention mechanism; no public data export.

### risk.risk_cases — M + N

`payment_id uuid FK app.payments`; `fraud_score_id uuid FK fraud_scores`; `status text` (OPEN,VERIFYING,APPROVED,REJECTED,ESCALATED,CLOSED); `assigned_to uuid? FK principals`; `decision_operation_id uuid? FK operations`; `closed_at timestamptz?`. Partial U(payment_id) for active OPEN/VERIFYING/ESCALATED case; multiple historical cases retained. Approved review does not create a valid signature or bypass expiry. Decision/allowed-actions response is computed from policy, case state and authorization, never saved as a universal bypass flag.

## 8. Commerce and merchant integration (`bpi_db`)

### commerce.merchant_products — S

`merchant_account_id uuid FK app.merchant_accounts`; `sku text`; `category text` (MOBILE_RECHARGE,UTILITIES,SHOPPING,TRAVEL,SUBSCRIPTIONS,SERVICES); `title text`; `description text`; `asset_id uuid FK core.assets`; `network_id uuid FK core.networks`; `unit_price_minor MINOR`; `is_sample boolean CHECK =true`; `status text` (DRAFT,AVAILABLE,UNAVAILABLE,RETIRED). U(merchant_account_id,sku), U(id,merchant_account_id,network_id), U(id,network_id). Product text is intended catalog content, sanitized before rendering; never contains secret configuration. Unsupported live fulfillment remains unavailable, regardless of category.

### commerce.inventory — M

`product_id uuid FK merchant_products U`; `on_hand integer CHECK >=0`; `reserved integer DEFAULT 0 CHECK >=0`; CHECK on_hand>=reserved. Stock cannot be freed by merely losing a browser session. Product deletion is soft and retains inventory/order lineage. Stock mutations require version checks and audit.

### commerce.commerce_orders — M + N

`operation_id uuid FK operations U`; `buyer_subject_id uuid FK subjects`; `merchant_account_id uuid FK merchant_accounts`; `outlet_id uuid?`; `asset_id uuid FK assets`; `status text` (DRAFT,PAYMENT_PENDING,PAID,PAID_REVIEW,FULFILLED,CANCELED,REFUND_PENDING,REFUNDED); `subtotal_minor MINOR`; `tax_minor MINOR DEFAULT 0`; `total_minor MINOR`; `price_version bigint >0`; `submitted_at timestamptz?`; `fulfilled_at timestamptz?`. CHECK total=subtotal+tax; no invented tax defaults. Composite outlet/merchant FK; U(id,merchant_account_id,network_id). One merchant/order in v1: multi-merchant carts create separate orders/payments. Issued total frozen and checked against line snapshots; changing it creates new review/request, never alters an included payment.

### commerce.order_items — I + N

`order_id uuid`; `merchant_account_id uuid`; `product_id uuid`; `line_no integer >0`; `description_snapshot text`; `quantity integer >0`; `unit_price_minor MINOR`; `line_total_minor MINOR`. U(order_id,line_no); composite FKs order/merchant/network and product/merchant/network. CHECK exact total=quantity×unit price using wide numeric intermediate; reject overflow. Rows for a submitted order immutable; editable carts use separate cart storage below. Snapshot survives product edits/soft deletion.

### commerce.inventory_reservations — M

`order_item_id uuid FK order_items U`; `inventory_id uuid FK inventory`; `quantity integer >0`; `expires_at timestamptz`; `state text` (ACTIVE,CONSUMED,RELEASED,EXPIRED); `resolved_at timestamptz?`. Routine verifies inventory product matches item product, aggregates under inventory lock and prevents oversubscription. Paid-after-expiry produces PAID_REVIEW, not fabricated stock or paid failure.

### commerce.carts — M

`buyer_subject_id uuid FK subjects`; `status text` (OPEN,CONVERTED,ABANDONED); `expires_at timestamptz?`. Partial U(buyer_subject_id) WHERE status=OPEN for initial single-cart UX. Cart totals are estimates; no financial posting. PII-free cart state may be purged after retention if no retained order linkage depends on it.

### commerce.cart_items — M

`cart_id uuid FK carts`; `product_id uuid FK merchant_products`; `quantity integer >0`; U(cart_id,product_id). Price read from current catalog; checkout creates immutable order snapshots/server total. Hard removal from an unsubmitted cart is permitted through owner-authorized action; no impact on journal/history. Explicit exception to immutable financial-history deletion, not a general cascade rule.

### commerce.invoices — M + N

`merchant_account_id uuid FK merchant_accounts`; `outlet_id uuid?`; `order_id uuid?`; `customer_subject_id uuid? FK subjects`; `invoice_number text`; `status text` (DRAFT,ISSUED,PAID,CANCELED); `asset_id uuid FK assets`; `subtotal_minor MINOR`; `tax_minor MINOR DEFAULT 0`; `total_minor MINOR`; `issued_at timestamptz?`; `due_at timestamptz?`; `supersedes_invoice_id uuid?` self-FK. U(merchant_account_id,invoice_number), U(id,merchant_account_id,network_id). Composite outlet/order/merchant integrity. Invoice number allocated by merchant sequence under lock; UUID remains PK. Issued fields/lines frozen. Pending/partial refund presentation derives from linked payment/refund facts, not a conflicting editable invoice settlement flag.

### commerce.invoice_lines — I + N

`invoice_id uuid FK invoices`; `line_no integer >0`; `description_snapshot text`; `quantity integer >0`; `unit_price_minor MINOR`; `line_total_minor MINOR`. U(invoice_id,line_no); exact multiplication with overflow guard. Draft changes rebuild unpublished lines under controlled draft operation; issued lines cannot change/delete. Deferred issue validation checks subtotal=sum(lines), total=subtotal+tax, and supported asset. Payment_requests.invoice_id supplies request linkage; don't store a second uncoordinated invoice.payment_id pointer.

### commerce.merchant_customers — M

`merchant_account_id uuid FK merchant_accounts`; `subject_id uuid FK subjects`; `first_activity_at timestamptz`; `last_activity_at timestamptz`; `permitted_alias_ciphertext ENC?`; U(merchant_account_id,subject_id). Private relationship projection from that merchant's activity only; no foreign merchant history, phone/email by default or FINCOIN portfolio fields. Rebuildable, not a source of eligibility or balance.

### integration.api_keys — M

`merchant_account_id uuid FK merchant_accounts`; `outlet_id uuid?`; `name text`; `public_prefix text U`; `secret_digest H32 U`; `hash_key_version smallint >0`; `scopes text[]`; `created_by uuid FK principals`; `expires_at timestamptz`; `last_used_at timestamptz?`; `revoked_at timestamptz?`; `replaces_key_id uuid?` same-merchant self-FK. U(id,merchant_account_id); outlet/merchant composite FK. Scopes must be a subset of a versioned code allowlist and delegator permissions; not arbitrary JSON privileges. Never store plaintext/recoverable secret. One-time response only; on lost issuance response rotate/recreate, not retrieve stored secret. Revoke and audit, not delete to remove evidence.

### integration.webhooks — S

`merchant_account_id uuid FK merchant_accounts`; `endpoint_url_ciphertext ENC`; `endpoint_lookup_digest H32`; `destination_revision bigint DEFAULT 1 CHECK >0`; `subscribed_events text[]`; `status text` (UNVERIFIED,ACTIVE,PAUSED,REVOKED); `verified_at timestamptz?`; `verification_digest H32?`; `created_by uuid FK principals`; `current_secret_id uuid? FK webhook_secrets`. U(id,merchant_account_id), U(merchant_account_id,endpoint_lookup_digest). Server validates HTTPS, ownership and SSRF-safe destination resolution; CHECK URL prefix alone is insufficient. Event subscriptions use allowlist; no raw risk signals. Changing destination resets verification and increments destination_revision with audit; queued delivery binds that revision.

### integration.webhook_secrets — M

`webhook_id uuid FK webhooks`; `secret_version bigint >0`; `secret_ciphertext ENC`; `active_from timestamptz`; `retire_after timestamptz?`; `revoked_at timestamptz?`; U(webhook_id,secret_version), U(id,webhook_id). Current secret FK uses `(current_secret_id,id) → webhook_secrets(id,webhook_id)` on webhooks, deferred for rotation. Encryption is required because sender needs HMAC signing secret; unlike api_keys it cannot be verifier-only. Expired secrets retained encrypted only as operational/evidence policy requires.

### integration.webhook_deliveries — M

`webhook_id uuid FK webhooks`; `outbox_event_id uuid? FK ops.outbox`; `test_operation_id uuid? FK ops.operations`; `endpoint_revision bigint >0`; `destination_ciphertext ENC`; `payload_digest H32`; `payload_ciphertext ENC`; `secret_id uuid FK webhook_secrets`; `state text` (QUEUED,RETRY,DELIVERED,FAILED,PAUSED); `attempts integer DEFAULT 0`; `next_attempt_at timestamptz`; `delivered_at timestamptz?`. Exactly one source event or explicitly synthetic test operation. Partial U(webhook_id,outbox_event_id) and U(webhook_id,test_operation_id). Secret FK must match same webhook; store immutable destination snapshot so edits do not silently redirect prior events. Retries reuse logical event/delivery identity and do not cause new payments.

### integration.webhook_attempts — I

`delivery_id uuid FK webhook_deliveries`; `attempt_no integer >0`; `started_at timestamptz`; `finished_at timestamptz`; `outcome text` (SUCCESS,ERROR,UNKNOWN); `http_status smallint? CHECK BETWEEN 100 AND 599`; `error_code text?`; `response_digest H32?`; `redacted_response_ciphertext ENC?`; U(delivery_id,attempt_no). Append when an observed result or crash recovery closes an attempt; in-flight lease/counter belongs to webhook_deliveries and durable worker state. UNKNOWN preserves that no conclusive receiver result was observed. Never fabricate Delivered or store raw credential-bearing request headers. Rows remain immutable after insertion.

### readmodel.payment_history — M + N

`viewer_principal_id uuid FK principals`; `payment_id uuid FK app.payments`; `direction text` (SENT,RECEIVED); `merchant_account_id uuid? FK merchant_accounts`; `business_status text`; `amount_minor MINOR+`; `occurred_at timestamptz`; `source_event_id uuid FK ops.outbox`; `as_of_time timestamptz`; U(viewer_principal_id,payment_id,direction). Private projection; participant and membership scopes validated when building/querying. Financial authorization never uses this table. Index `(viewer_principal_id,occurred_at DESC,id DESC)`; status is display-only copy of authoritative payment_states.

## 9. FINCOIN domain (`fincoin_db` only)

Instantiate the shared registries, operation/audit, accounts/journal/chain, holds/nonce/limits and wallet_addresses templates independently. No FK in this section references bpi_db. FNC is only a display ticker; the asset registry stores FINCOIN.

### ledger.fincoin_wallets — M + N

`subject_id uuid FK core.subjects`; `owner_principal_id uuid FK principals`; `status text` (ACTIVE,FROZEN,CLOSED); `next_nonce bigint DEFAULT 0 CHECK >=0`; `enrolled_at timestamptz`; `closed_at timestamptz?`; U(subject_id,network_id). Principal must be subject's USER principal. One nonce sequence across this wallet's test-asset outgoing operations; it is unrelated to any BPI nonce. No INR currency column or BPI wallet reference. System inventory/fees use system-owned ledger accounts rather than fake human wallets.

### ledger.fincoin_balances — M + N

`wallet_id uuid FK fincoin_wallets`; `asset_id uuid FK assets`; `settled_atomic Q DEFAULT 0`; `reserved_atomic Q DEFAULT 0`; `available_atomic numeric(38,0) GENERATED ALWAYS AS (settled_atomic-reserved_atomic) STORED`; `last_transaction_id uuid? FK ledger.transactions`; U(wallet_id,asset_id). CHECK settled>=reserved and asset belongs to network. Explicit per-asset rows, no mixed FNC/SIM_INR balance. Synchronous ledger projection; analytics cannot overwrite it.

### market.price_feeds — M + N

`feed_code text`; `base_asset_id uuid FK assets`; `quote_asset_id uuid FK assets`; `source_kind text CHECK = 'SYNTHETIC'`; `scenario_seed_digest H32`; `status text` (ACTIVE,PAUSED,RETIRED); `last_sequence bigint DEFAULT 0 CHECK >=0`; U(network_id,feed_code). Base FINCOIN/quote SIM_INR enforced. Scenario changes are versioned/audited, not hidden historical tick rewrites. Source metadata makes chart simulation explicit.

### market.fincoin_price_history — I + N

`feed_id uuid FK price_feeds`; `sequence bigint >=0`; `price_minor_per_coin Q+`; `observed_at timestamptz`; U(feed_id,sequence). Price is SIM_INR minor units per full FINCOIN, not per atom. Index `(feed_id,observed_at DESC,sequence DESC)`. Multiple ticks can share a timestamp; sequence resolves order. Only synthetic ingestion role writes, not traders/browser. No historical price edit to improve portfolio results.

### market.fincoin_candles — M + N

`feed_id uuid FK price_feeds`; `interval_seconds integer >0`; `bucket_start timestamptz`; `open_minor Q+`; `high_minor Q+`; `low_minor Q+`; `close_minor Q+`; `first_sequence bigint`; `last_sequence bigint`; `is_final boolean DEFAULT false`; U(feed_id,interval_seconds,bucket_start). CHECK low<=open/close<=high, first<=last. Rebuildable from ticks; explicit missing buckets/gaps. Do not equate tick counts with trade volume; use fills for volume. Finalized source history not quietly modified.

### app.fincoin_quotes — I + N

`operation_id uuid FK ops.operations U`; `wallet_id uuid FK fincoin_wallets`; `feed_tick_id uuid FK fincoin_price_history`; `side text` (BUY,SELL); `quantity_atomic Q+`; `price_minor_per_coin Q+`; `gross_minor Q+`; `fee_minor Q`; `total_or_net_minor Q+`; `fee_policy_setting_id uuid FK app.system_settings`; `quoted_at timestamptz`; `expires_at timestamptz`; `quote_digest H32`. Fixed 15-second baseline lifetime; referenced tick/source must be correct network/asset and fresh at quote. Validate exact rounding and BUY total=gross+fee / SELL net=gross−fee before issuance. Quoted values immutable; no liquidity reservation claim. No default real-money price.

### app.fincoin_orders — M + N

`operation_id uuid FK ops.operations U`; `wallet_id uuid FK fincoin_wallets`; `quote_id uuid FK fincoin_quotes U`; `authorization_id uuid FK ops.authorizations`; `status text` (CREATED,AUTHORIZED,QUEUED,FILLED,REJECTED,EXPIRED,CANCELED); `submitted_at timestamptz?`; `resolved_at timestamptz?`; `safe_reason_code text?`. Quote belongs to this wallet; order reuses its quote's root operation_id, and current authorization binds that operation plus quote digest/exact terms. U(quote_id) intentionally allows only one order record per quote, even if rejected/canceled; request a fresh quote for another order. No editable fill-price field or partial-fill status in v1. Index wallet/time/status.

### app.fincoin_transfer_intents — M + N

`operation_id uuid FK ops.operations U`; `sender_wallet_id uuid FK fincoin_wallets`; `receiver_wallet_id uuid FK fincoin_wallets`; `sender_address_id uuid`; `receiver_address_id uuid`; `asset_id uuid FK assets`; `quantity_atomic Q+`; `fee_atomic Q DEFAULT 0 CHECK =0`; `authorization_id uuid? FK ops.authorizations`; `expires_at timestamptz`; `status text` (DRAFT,AUTHORIZED,QUEUED,CONFIRMED,REJECTED,EXPIRED,CANCELED). Composite address/wallet/network FKs; asset FINCOIN for user transfers in v1, reject self-transfer. Terms freeze at authorization; no BPI destination. Confirmed requires matching financial and chain event.

### ledger.test_grants — M + N

`operation_id uuid FK ops.operations U`; `subject_id uuid FK subjects`; `wallet_id uuid FK fincoin_wallets`; `asset_id uuid FK assets`; `quantity_atomic Q+`; `grant_kind text` (SIM_INR_ISSUANCE,FINCOIN_INVENTORY_TRANSFER); `limit_bucket_id uuid FK ledger.limit_buckets`; `status text` (QUEUED,POSTED,REJECTED); `transaction_id uuid? FK ledger.transactions U`; `posted_at timestamptz?`. Wallet subject must match; cap uses subject principal across wallets. FINCOIN grants transfer existing inventory; cannot mint after genesis. SIM_INR issuance posts against issuance contra account. Grant outcome immutable once posted; transaction link and cap usage commit together.

### ledger.fincoin_transactions — I + N

`transaction_id uuid FK ledger.transactions U`; `event_type text` (GENESIS_ISSUANCE,TRANSFER,FILL,GRANT,CORRECTION); `transfer_intent_id uuid? FK app.fincoin_transfer_intents U`; `order_id uuid? FK app.fincoin_orders U`; `grant_id uuid? FK ledger.test_grants U`; `correction_proposal_id uuid? FK ops.approval_proposals`; `executed_at timestamptz`. Event type determines exactly which typed source exists; GENESIS_ISSUANCE has none and is restricted to pinned genesis issuance operation. TRANSFER requires transfer source only, FILL order only, GRANT grant only, CORRECTION approved proposal only. No independent amount/balance posting; typed receipt wraps one journal transaction. Original transaction lineage comes from shared ledger.transactions.

### ledger.fincoin_fills — I + N

`order_id uuid FK fincoin_orders U`; `fincoin_transaction_id uuid FK fincoin_transactions U`; `wallet_id uuid FK fincoin_wallets`; `side text` (BUY,SELL); `quantity_atomic Q+`; `price_minor_per_coin Q+`; `gross_minor Q+`; `fee_minor Q`; `total_or_net_minor Q+`; `feed_tick_id uuid FK fincoin_price_history`; `filled_at timestamptz`. Every copied quote field must equal its immutable source. FILL typed receipt order must match. Both asset legs, fee allocation, balances, nonce, fill, chain and outbox commit together; no fill-only record or partial execution. Index filled_at for complete simulator volume windows.

### readmodel.portfolio_lots — M + N

`wallet_id uuid FK fincoin_wallets`; `source_fincoin_transaction_id uuid FK fincoin_transactions`; `source_lot_id uuid?` self-FK for carried-in lineage; `lot_sequence integer >=0`; `basis_kind text` (OWN_PURCHASE,CARRIED_IN,GRANT,UNKNOWN); `original_quantity_atomic Q+`; `remaining_quantity_atomic Q`; `original_cost_minor Q?`; `remaining_cost_minor Q?`; `acquired_at timestamptz`; `source_block_height bigint >=0`; `source_tx_index integer >=0`; `projection_version bigint >0`. U(wallet_id,source_fincoin_transaction_id,lot_sequence). Remaining<=original; costs nonnull for known basis, null for UNKNOWN; grants use zero known spend and separate classification. FIFO order `(source_block_height,source_tx_index,lot_sequence,id)`. Rebuildable only; does not authorize spending.

### readmodel.lot_disposals — I + N

`lot_id uuid FK portfolio_lots`; `disposing_fincoin_transaction_id uuid FK fincoin_transactions`; `quantity_atomic Q+`; `allocated_cost_minor Q?`; `allocated_net_proceeds_minor Q?`; `disposal_kind text` (SALE,TRANSFER); `basis_kind_snapshot text`; `projection_version bigint >0`; U(lot_id,disposing_fincoin_transaction_id). TRANSFER carries basis without realizing proceeds; SALE apportions exact net proceeds/cost with final remainder conservation. Cost unknown remains null, never zero by assumption. For rebuilds create a new projection generation or truncate only isolated read models under rebuild control; immutable finance unaffected.

### readmodel.fincoin_portfolios — M + N

`wallet_id uuid FK fincoin_wallets U`; `holdings_atomic Q`; `available_atomic Q`; `reserved_atomic Q`; `known_basis_minor Q?`; `marked_value_minor Q?`; `realized_purchased_pnl_minor numeric(38,0)?`; `realized_carried_pnl_minor numeric(38,0)?`; `grant_value_minor Q?`; `unrealized_known_pnl_minor numeric(38,0)?`; `disposed_purchased_cost_minor Q`; `remaining_purchased_quantity_atomic Q`; `remaining_purchased_cost_minor Q`; `has_unknown_basis boolean`; `price_tick_id uuid? FK fincoin_price_history`; `as_of_block_height bigint`; `as_of_event_id uuid FK ops.outbox`; `as_of_time timestamptz`; `projection_version bigint >0`. P&L signed finite integers; null means unavailable, not zero. Snapshot quantity is not a spending authority.

Return % from Role 2 is a derived view: `100 * realized_purchased_pnl_minor / disposed_purchased_cost_minor`, only when denominator>0 and purchased basis is complete; otherwise null with reason. Round for presentation only, never store an independently editable percentage. Average remaining purchased cost uses corresponding cost/quantity, excluding grants/carry-ins as specified in FINCOIN_UI_SPEC. Marking requires a valid synthetic tick; stale/no price is labeled and cannot generate quotes. Historical snapshots may be appended in a later versioned table if a time series is required; never infer past balances from current holdings alone.

### readmodel.projection_checkpoints — M

`projector_code text`; `network_id uuid FK networks`; `generation bigint >0`; `last_event_id uuid? FK ops.outbox`; `last_block_height bigint DEFAULT -1`; `last_tx_index integer DEFAULT -1`; `updated_as_of timestamptz`; U(projector_code,network_id,generation). Same template may be used for BPI history. Deduplicate event application and checkpoint atomically; do not advance cursor after only half a lot update. Swapping rebuild generation requires totals/replay verification first.

## 10. Independent simulator and public projection databases

### gateway_sim_db.sim.gateway_operations — M

`external_operation_id uuid U`; `network_code text`; `operation_type text` (FUNDING,TRANSFER_SETTLEMENT,REDEMPTION); `request_digest H32`; `amount_minor MINOR+`; `currency text CHECK = 'INR'`; `environment text CHECK = 'sandbox'`; `payer_reference text?`; `payee_reference text?`; `scenario_code text`; `status text` (PENDING,SUCCEEDED,FAILED); `resolved_at timestamptz?`. Same operation/different request digest rejects; terminal status stable. External ID is authenticated logical reference to BPI operation, not a cross-DB FK. UNKNOWN is the caller's observation, not proof provider failed. Generated participant references only, no real banking credentials.

### gateway_sim_db.sim.statement_entries — I

`gateway_operation_id uuid FK sim.gateway_operations U`; `provider_event_id text U`; `sequence bigint U`; `result text` (SUCCEEDED,FAILED); `amount_minor MINOR+`; `currency text CHECK = 'INR'`; `occurred_at timestamptz`; `evidence_digest H32`; `evidence_signature bytea`. Exactly one canonical terminal entry per provider operation; test duplicate callbacks resend its event ID instead of minting another statement. Callback transport delivery attempts may be operational records, not new terminal financial evidence. Independent store permits detection when BPI loses/applies an outcome twice.

### explorer_bpi_db / explorer_fincoin_db.public_data.networks — I

`network_code text U`; `domain text` fixed for this public DB; `environment text CHECK='sandbox'`; `epoch bigint`; `genesis_hash H32`; `protocol_version smallint`. Public UUID may be a copied source network UUID; it does not grant private DB access. No service endpoint credentials, operator identity or tenant metadata.

### public_data.blocks — I

`network_id uuid FK public_data.networks`; `height bigint >=0`; `block_hash H32 U`; `previous_hash H32`; `merkle_root H32`; `timestamp timestamptz`; `transaction_count integer >=0`; `writer_epoch bigint`; `validator_key_reference text`; `validator_public_key bytea`; `signature SIG64`; `protocol_version smallint`; U(network_id,height), U(id,network_id). Only signed public-header facts and verifier material. Validate key history against genesis/rotation proof, not a self-asserted supplied key. No wallet addresses/amounts.

### public_data.blockchain_transactions — I

`network_id uuid FK public_data.networks`; `block_id uuid`; `transaction_hash H32 U`; `tx_index integer >=0`; `journal_commitment H32`; `merkle_proof jsonb`; `leaf_hash H32`; U(block_id,tx_index). Composite FK block/network. Proof path is bounded, versioned, validated hashes/directions; no private signed payload, user ID, sender/receiver, amount, status/risk or settlement evidence. Public transaction count counts chain events, not paid merchants or completed payments.

### public_data.projection_state — M

`network_id uuid FK public_data.networks U`; `last_exported_height bigint DEFAULT -1`; `last_exported_block_hash H32`; `verified_as_of timestamptz`; `status text` (CURRENT,STALE,ERROR). No private outbox FK; source checkpoint is authenticated export metadata. Freshness does not prove settlement. Statistics derive from complete public records; producer activity requires a separately defined safe health signal, not head age alone.

## 11. Lifecycle and relational invariants

### BPI payment state CHECK

Only the following tuples are valid in ledger.payment_states. UI labels are a view over these, not separate stored states.

| business_status | chain_status | settlement_status |
|---|---|---|
| DRAFT / AUTHORIZED / RISK_REVIEW | NOT_SUBMITTED | NOT_STARTED |
| RESERVED | QUEUED | NOT_STARTED |
| REJECTED / EXPIRED / CANCELED | REJECTED | NOT_STARTED |
| SETTLEMENT_PENDING | CONFIRMED | PENDING |
| SETTLEMENT_UNKNOWN | CONFIRMED | UNKNOWN |
| COMPLETED | CONFIRMED | SUCCEEDED |
| RETURNED | CONFIRMED | FAILED |

The state-machine routine restricts transition edges as well as tuples; a CHECK allowing a tuple does not authorize a jump from DRAFT to COMPLETED. COMPLETED/RETURNED require matching terminal ledger evidence; a mere verified callback without ledger commit is insufficient. Completed payment refunded later remains COMPLETED with linked refund totals.

### Composite/conditional FK implementation requirements

| Relationship | Exact enforcement beyond individual UUID existence |
|---|---|
| Request active payment | `(active_payment_id,id,network_id) → payments(id,request_id,network_id)`; deferred NO ACTION; active ID/status checked together |
| Payment address ownership | `(sender_address_id,sender_wallet_id,network_id)` and receiver equivalent → wallet_addresses(id,wallet_id,network_id) |
| Wallet-asset relationship | BPI `(wallet_id,network_id,asset_id)` → wallets(id,network_id,asset_id); reject mismatched account assets in posting |
| Product/order merchant | Both order_items parent FKs include merchant_account_id and network_id; product cannot belong to another merchant |
| Outlet scope | `(outlet_id,merchant_account_id)` → merchant_outlets(id,merchant_account_id) |
| Current webhook secret | `(current_secret_id,id)` → webhook_secrets(id,webhook_id), deferred; delivery secret/webhook equivalent |
| Previous block | `(previous_block_id,network_id,previous_hash)` → blocks(id,network_id,block_hash); genesis exception plus contiguous-height validation |
| Session device / refresh parent | Same user/session composite keys prevent attaching another user's credential lineage |
| Typed FINCOIN fill | Order/quote/wallet/feed/source transaction must match through composite keys where stored; deferred event validator checks copied economics |

Optional composites use MATCH SIMPLE with row CHECKs ensuring related optional fields are all present together when required. Add referenced UNIQUE constraints before FKs. Pointers within network-scoped records never use an id-only shortcut where a mismatched network could pass.

Use partial U(order_id) on payment_requests WHERE order_id IS NOT NULL AND status IN (OPEN,CLAIMED), and equivalent U(invoice_id). Terminal paid orders/invoices cannot issue another payable request through the business routine; expired/pre-inclusion-failed attempts may create a fresh request according to lifecycle policy. Never expire/reopen a CLAIMED request while an included or unknown payment is unresolved.

### Null/default and immutability rules

Missing monetary valuation, price, risk score or timestamp is NULL with a defined unavailable/not-yet-observed meaning, not zero or empty text. Only newly initialized accounting caches default to zero. Request/quote amounts and issued order/invoice totals have no default. No balances are seeded through direct defaults beyond true zero.

Primary UUIDs, natural protocol identifiers, signed bytes, keys/public-key bytes, journal/fill economics, evidence digests and issued snapshots are immutable. State/lease/read-status fields change only through their owner. Close/revoke/tombstone does not modify historical facts. All table-specific exceptions for unsubmitted cart/draft material are excluded from financial history and audited appropriately.

## 12. Data classification and retention reference

| Class | Examples | Storage / exposure |
|---|---|---|
| Public proof | Public network/header/hash/commitment/Merkle path | Separate allowlisted public DB; no private join |
| Restricted pseudonymous finance | Wallet address, private canonical payload, journal amount, order/fill | Private DB, TLS/volume/backup encryption, strict role/RLS; never public export |
| Sensitive personal/evidence | Email, display name, notes, devices, risk/gateway payload | Application envelope ENC, scoped decryption and retention |
| Secret/verifier | Password PHC hash, refresh/API key hash, MFA TOTP secret, webhook secret | Argon2id or appropriate token verifier; recoverable secrets ENC/vault; no plaintext |
| Rebuildable projection | History, portfolio, candles, public export | Scoped source-derived data with checkpoint, never spend authority |

Retain financial/dedupe lineage for the full active sandbox epoch and approved archive period. State that soft deletion differs from physical purge and key erasure. PII retention keys must be separable from financial proof keys so deleting a note does not make journal replay impossible. Source architecture retention defaults and migration/restore requirements are in DATABASE_SCHEMA. Detailed legal retention durations require the actual deployment policy; none is asserted by this dictionary.
