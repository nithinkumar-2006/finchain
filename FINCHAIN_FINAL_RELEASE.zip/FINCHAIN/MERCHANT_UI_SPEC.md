# FINCHAIN — Merchant Interface Specification

Role 2 · Version 1.0 · Applies to authorized sandbox merchant organizations only.

## 1. Merchant shell and onboarding M-00

Desktop sidebar follows Overview, Payments, Customers, QR, Invoices, Settlement, Refunds, Analytics, API, Webhooks, Settings. Payouts is a Settlement subitem; Catalog is a commerce-management subitem. Header persistently shows organization display name, outlet, role and “BPI Merchant · Sandbox”. Changing organization clears old data and requires a new review for unfinished financial drafts.

Onboarding steps: organization display name/business category → owner contact/profile → outlet setup → team/role setup → sandbox review → create merchant BPI wallet → ready screen with Generate QR and Create invoice. Collect minimum data for a prototype, not real bank or official KYC documents. “Sandbox review complete” must not read “RBI approved” or legally verified. Owner must enroll MFA before payout/approval capabilities are enabled; a cashier can onboard to request/receipt-only access.

Onboarding states: draft with saved-step indication, submitted/review pending, correction requested with safe reason, approved for sandbox, unavailable. Save progress only after actual persistence; failure preserves fields and offers retry. A merchant pending review can inspect profile but cannot falsely appear ready to accept live money.

## 2. Roles and action visibility

| Role | Main screens | Financial actions |
|---|---|---|
| Owner | All organization management as granted | Configure team, propose payouts/refunds; cannot self-check where policy requires independence |
| Cashier | Overview limited to outlet, Payments, QR, Invoices | Generate requests/receipts; no default payout, refund or key management |
| Finance maker | Payments, Settlement, Refunds, Analytics | Prepare payout/refund proposals |
| Finance checker | Approval queue and supporting records | Approve exact proposal with MFA; cannot approve own maker action |
| Integration manager | API/Webhooks and limited event logs | Manage scoped sandbox credentials/destinations, no wallet spend unless separate permission |
| Read-only analyst | Overview/Analytics/permitted exports | No money commands or integration secret access |

A disabled action explains a relevant role/policy restriction; nonexistent permissions should normally remove the action. Direct URLs remain server-authorized. Never show an owner's full secret/settings data behind a disabled overlay for a cashier.

## 3. Overview M-01

12-column layout: heading and outlet/date filters; four metric cards; second row with remaining metrics and settlement summary; 8-column payment trend and 4-column actions; latest payments and required-approval queue. Primary action Generate QR. Other actions Create payment link, Create invoice and Request payment are grouped, with shared request engine.

| Metric | Exact definition | Presentation |
|---|---|---|
| Revenue Today | Gross completed incoming sale payments in merchant zone's current calendar day | “Settled sales today · Simulated INR”; exclude funding/payouts and pending |
| Revenue This Month | Same for current calendar month | Show completed refunds separately and net settled sales = gross minus completed refunds |
| Transactions | Number of submitted sale-payment attempts in selected creation-time window | Exclude drafts; include terminal and still-pending attempts with breakdown |
| Average Payment | Completed sale amount / count completed sale payments in completion-time window | No denominator → “No completed payments”, not 0 average |
| Successful Payments | Completed ordinary sale count | Display pending separately; refunded sale remains completed with refund annotation |
| Failed Payments | Rejected + definitively returned submitted sale attempts in selected outcome-time window | Canceled/expired shown separately; unknown is never failed |
| Settlement Status | Counts/value pending and unknown, latest reconciliation timestamp | No “All settled” if source unavailable or stale |

Every card labels its period/time basis. A success-rate chart uses a separately defined submitted cohort: completed / (completed + rejected + returned) within that cohort, pending excluded and denominator shown; do not divide cards with different time bases. Backend UX-E06 supplies all totals. Cashier totals are outlet-scoped; owner rollups name included outlets. No combined FINCOIN revenue.

## 4. Payments M-02 and customers M-03

Payments: date/type/outlet/status/direction filters, amount, customer display reference, invoice, payment ID, business/chain/settlement statuses and safe review status. Row detail reuses private PaymentReceipt with organization permissions. Actions View invoice, Print receipt, Request refund and View public proof appear only when valid. Pending/unknown is visibly separate from paid; cashiers cannot manually mark settlement success.

Customers: a merchant relationship view, not a global directory. List chosen customer display alias or opaque customer reference, completed-order count, last activity and permitted aggregate purchase total from this organization. Detail shows only the merchant's own invoices/payments and explicitly shared contact fields if a lawful, consented implementation later supports them. No full platform balances, FINCOIN holdings, private risk scores, phone/email by default, or legal-name enrichment. Customer search operates within existing scoped relationships. Empty state “Customers appear after activity with your merchant”. E07 is required for this projection.

## 5. QR M-04 and invoices M-05

QR has tabs Static merchant QR and Amount request. Static QR resolves only the merchant profile; payer enters amount and creates a fresh single-use request. Amount request requires amount, INR, outlet, optional invoice/purpose and expiry; after server creation, show exact amount and expiry alongside real QR. Print/download includes merchant display name, “FINCHAIN sandbox”, request type and URL fallback. No UPI logo, interoperability claim or unverifiable bank badge.

Create payment link and Request payment open the same builder with a different default sharing view. Do not create three disconnected request engines. Generated links show OPEN/CLAIMED/PAID/EXPIRED/CANCELED; regeneration creates a new ID. A cashier viewing a claimed QR sees “Payment in progress”, not “Ready for next customer” until the current request is resolved or a new separate request is created.

Invoice list: number, customer reference, issued/due date, server total, state, payment reference and outlet. Create form: line description, quantity, unit price, optional customer reference and due date; any configured tax must be explicit, otherwise no invented tax rate. Preview before issue, then server-assigned invoice number, immutable total and linked request. States: Draft, Issued/Unpaid, Payment pending, Paid, Partially refunded, Refunded, Canceled where permitted. Do not label an invoice overdue if settlement is simply unknown without showing that distinction.

Invoice detail: summary, items, payment timeline, linked receipts/refunds, Print and Share request. Editing after issue creates a version/replacement according to backend rules; amount change invalidates prior payment request and requires a new one, subject to no active included attempt. Empty list offers Create invoice; no matching filters offers Clear filters; failed issuance retains draft and checks original operation before retry.

## 6. Settlement M-06 and payouts M-12

Settlement screen separates available merchant BPI value, incoming pending, outgoing reserved, and unknown operations. Table: payment/operation reference, type (incoming transfer/payout/refund/redemption), amount/currency, chain status, simulated settlement status, age and last check. Detail shows time-stamped evidence summary and linked transaction; no raw gateway secrets or arbitrary provider URLs. “Linked gateway: FINCHAIN simulator” stays visible.

Uncertain operation copy: “The simulator's settlement result is being checked. Do not create a replacement payout.” Merchant may refresh the same status or open a support/reconciliation case. There is no manual Mark settled, Force credit or Retry as new button. Simulated withdrawal uses the shared redemption flow and explicitly sends no bank money.

Payout creation: authorized source wallet/outlet, recipient/address, exact amount, purpose/reference, derived B2P/B2B, fee and approval policy. Maker reviews and submits proposal. Checker view identifies maker, timestamp and exact terms; Approve with verification and Reject with reason. A stale/edited proposal requires fresh approval. A maker with checker role still cannot approve their own proposal when independence is required.

Batch builder caps at the backend limit (initially 100 children), validates each row and displays aggregate expected amount without implying atomic execution. Submitted batch table includes each child ID/status/error and overall counts. Retry actions apply only to explicitly new approved attempts after definitive child failure; pending/unknown children are never resubmitted as new.

## 7. Refunds M-07

List original payment/invoice, refund ID, amount, request time, requester/approver and refund settlement state. Start from a completed original receipt. Composer shows original settled amount, already refunded, pending refund reservations, remaining refundable and source available balance. Amount input supports partial refund and server validation; reason is required private metadata.

Review says “Submit sandbox refund” and identifies the original payer recipient; recipient is not editable. After authorization, refund has its own ID/chain/settlement, and the original sale remains completed with Partial/Full refund annotation. Insufficient funds explains that the merchant needs available simulated INR; no FINCOIN source. An over-refund conflict refreshes remaining allowance. Unknown refund stays pending and blocks a duplicate allowance.

## 8. Analytics M-08 and catalog M-13

Analytics: settled sales, completed refunds, net sales, counts, payment types and outlet comparison with explicit time basis. Use bar/line charts with text/table alternatives. Separate payment processing metrics from revenue. Export jobs retain filters, zone and data-as-of time, with Requested/Processing/Ready/Failed/Expired states; no download link before job exists.

Catalog workspace: products, stock, sample-item labels, orders and fulfillment. Create/edit product uses server persistence and version conflicts; no live biller/travel integration. Order detail allows fulfillment only for paid eligible orders. `PAID_REVIEW` highlights inventory conflict and refund/review action. Backend rejection of fulfillment preserves the actual order state.

## 9. Sandbox API credentials M-09 — UX-E05

The requested credential manager is a new backend contract, not an existing Role 1 feature. Screen displays environment, credential name, identifier/prefix, allowed scopes, created/last-used/expiry, status and Rotate/Revoke. Creation requires integration-manager permission and recent MFA; grant only merchant/outlet scopes the actor can delegate. No production environment toggle.

Create → choose name/scopes/expiry → confirm scope → server issues credential → show secret once with copy/download and “I saved it” acknowledgment → show masked list. Never create a plausible fake key. If response with a one-time secret is lost, show the known credential record and rotate/recreate safely; do not claim the secret can be recovered. Revoke confirmation names affected integrations; completion only after server acknowledgment. Rotate displays exact overlap/retirement policy returned by server, not an invented grace period.

Required contract family, proposed for implementation: `/v1/bpi/merchants/{orgId}/api-credentials` supports list/create; `/{credentialId}/rotations` and `/{credentialId}/revocations` create audited actions. Server returns permitted scopes, expiry, masked identifier and one-time secret only at issuance. Credential-to-session/token exchange, scope enforcement, hashing, revocation and merchant binding require security design before this UI becomes functional. Until then, show “Sandbox credential management is not connected” with readable integration documentation.

## 10. Webhooks M-10 — UX-E05

Webhook list: destination hostname, subscribed events, verification state, enabled/paused, last delivery status and failure count. Setup: HTTPS endpoint, event selection, explanation of signed payloads, verification challenge, saved endpoint and signing-secret issuance. Relevant events include completed/returned payments, refund outcomes and invoice changes; raw fraud signals are not merchant webhook payloads.

Required backend family: `/v1/bpi/merchants/{orgId}/webhook-endpoints` list/create; endpoint verification, update/version, pause/resume, secret rotation and revoke actions; `/{endpointId}/deliveries` and `/{endpointId}/test-deliveries`. Contracts must enforce destination ownership, SSRF-safe DNS/address checks, signed requests, body minimization, retry limits, event IDs and durable delivery evidence. Destination text alone is not verified ownership.

Test webhook action creates a clearly synthetic test event with delivery ID. Queued means queued; Delivered appears only after a documented successful receiver acknowledgment. Delivery detail shows event ID/type, timestamp, attempt count, response status, latency and redacted payload/error, never secrets. Timeout is not success. Retry delivery reuses the same logical event ID to the same verified endpoint under backend rules, not a new financial operation. Logs remain merchant-scoped.

Unconnected service shows documentation and unavailable setup action, not “Webhook saved” in local storage. Secret rotation explains compatibility impact, is audited and requires verification. No user-facing tool sends a message to a merchant endpoint during this documentation phase.

## 11. Settings M-11 and failure states

Settings sections: organization display/profile, outlets, members/roles, approval policy within server-authorized bounds, display zone, supported notifications, integration permissions and sandbox context. Role removal clears access; last owner cannot be removed without replacement. Editing display metadata does not rewrite transaction history. Sensitive changes require recent MFA and confirmation of impact.

| State | Merchant presentation |
|---|---|
| No merchant yet | Finish sandbox onboarding; no revenue widget with invented zero history |
| No payments | Create QR/invoice; explain sample acceptance |
| Analytics unavailable | Retain last known date/time if permitted; never “₹0 revenue” |
| Approval needed | Persistent task with maker/checker requirements |
| Wrong outlet/org | Clear old data, show scoped denial or choose authorized scope |
| Gateway outage | Pending/unknown operations visible; no new duplicate payouts |
| Export expired | Regenerate through scoped export job |
| Key/webhook failure | Show actual operation state and recovery; never fabricate secret/delivery |

Merchant QA must include owner/cashier/maker/checker separation, organization switching, partial refunds, unknown settlement, stale invoice totals, mixed batch results, one-time-secret loss and failed webhook verification. Mobile rules are in RESPONSIVE_SPEC.
