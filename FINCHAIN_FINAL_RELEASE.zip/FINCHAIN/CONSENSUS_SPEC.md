# Consensus and finality specification

Each domain uses one configured authorized producer, threshold one. There is no mining, staking, quorum voting, leader-election network or Byzantine fault tolerance. BPI and FINCOIN do not share a producer key, chain head or monetary ledger.

The worker acquires a PostgreSQL session advisory lock for its network, increments a persistent writer epoch and locks the chain head while posting. Financial transactions use serializable isolation. An old epoch cannot write after a new leader is installed. Multiple API replicas can enqueue operations, but deploying additional writers does not create throughput scaling or multi-validator consensus.

Ledger finality means the journal, chain record and head committed atomically to PostgreSQL. BPI business finality additionally requires a definitive simulated settlement result. A projector/follower independently verifies block hashes and signatures before adding public proofs. Followers do not vote and do not make settlement decisions.

Promotion/recovery requires stopping or fencing the previous writer, replaying records and confirming the authoritative database/key checkpoint. No automatic cross-region failover is implemented. Public decentralization, validator onboarding, partitions, Byzantine behavior and adversarial consensus are future projects requiring protocol changes and separate review.
