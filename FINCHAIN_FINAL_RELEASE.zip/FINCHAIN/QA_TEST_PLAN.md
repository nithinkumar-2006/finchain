# QA test plan

Use disposable, explicitly named `_test` PostgreSQL databases. Apply migrations and restricted roles before tests. Isolated SQLite tests verify application behavior only and must not substitute for PostgreSQL concurrency/privilege checks.

Coverage includes password/token validation, session revocation and refresh reuse, concurrent refresh/reset, CSRF/Origin checks, role escalation denial, TOTP behavior, encrypted challenge delivery, canonical transaction/signature validation, nonce/expiry/domain checks, all four BPI payment types, settlement unknown/failure/replay, refund bounds, exact fixed supply, buy/sell FIFO rounding, carried basis, idempotent checkout/stock, private receipt access, restricted database posting, append-only journals/audit/blocks, balance conservation, durable-signing crash recovery, API credential revocation, webhook signature/acknowledgment, and public projection privacy.

Run `python -m pytest services/identity/tests services/platform/tests -q` with all three test URLs configured. Run `pnpm build` and Chromium browser tests from `apps/web`. Browser assertions include responsive widths 320, 390, 768 and 1440, navigation, password input, unavailable-service behavior, skip links and per-request CSP.

Release acceptance still requires Docker build/up and optional seed on a supported host, complete browser account→merchant→payment journeys behind HTTPS, camera-device testing, rollback/restore drills, controlled concurrency/load tests and independent security review. The report must distinguish these unexecuted gates from passing automated checks.
