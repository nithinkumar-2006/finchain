# Merchant implementation

Merchant onboarding creates an organization principal, owner membership and queued BPI wallet. It is sandbox onboarding, not real KYC/KYB approval. Wallet selection uses ownership UUIDs, never display-name matching.

Owners assign existing BPI subjects to cashier, maker, checker, integration or analyst roles after recent MFA. Makers/owners prepare spending instructions; a different owner/checker reviews the actual private receipt and digest before approval. The maker then authorizes unchanged terms. The worker rechecks permissions and approval eligibility. Refunds are linked reverse-party BPI payments with the same safeguards.

Invoices contain server-validated line quantities/prices, a fixed total, unique merchant number and expiring payment request. Products have stock and soft-delete fields; the delivered UI supports creation and reporting. Reports show scoped invoices, orders, catalog stock, daily completed incoming payments and pseudonymous customer wallet totals. There is no identity-service customer export.

API keys are randomly generated, stored only as SHA-256 digests, shown once and expire after 30 days. Scopes are `payments:read` and `requests:write`; neither spends funds. Revocation, creator membership and account status are rechecked. Keys are sent as Bearer headers, never query parameters.

Webhooks support the built-in local sandbox inbox only. The worker signs payload/timestamp with a per-hook secret and records DELIVERED only after a matching HTTP acknowledgment. The receiver checks signature, time window and queued payload and deduplicates events. Delivery retries up to five attempts. No external destination URL or arbitrary outbound callback is accepted.
