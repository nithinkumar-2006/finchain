# FINCHAIN — Responsive and Interaction Specification

Role 2 · Version 1.0 · Applies to all pages in [PAGE_MAP.md](PAGE_MAP.md).

## 1. Breakpoints and layout

Breakpoints are layout decisions, not device detection. Support at least 320 px viewport width and browser zoom. Use available container space for card/table changes; a wide desktop with zoom may correctly use mobile navigation.

| Viewport width | Shell / grid | Spacing |
|---|---|---|
| 320–639 px | Mobile; 4 columns, single primary content column, bottom nav or drawer | 16 px page inset/gap; 16 px card padding |
| 640–1,023 px | Tablet; 8 columns, compact header and drawer, 2-column supporting cards where they fit | 24 px inset, 20 px gap |
| 1,024–1,439 px | Desktop; 240 px sidebar, 12 columns, measured content-area adaptations | 24 px inset/gap; avoid forcing four KPI cards into narrow remaining content |
| 1,440 px and above | Full dashboard desktop; 240 px sidebar, content max 1,440 px | 32 px inset, 24 px gap; center main content within larger area |

Public header is 72 px desktop, 64 px small-screen. Public max content width 1,200 px; authenticated header 64 px. When the full public navigation no longer fits, use a labeled menu, not clipped links. At intermediate widths, two-column sections may stack even before the shell breakpoint if content would be cramped.

## 2. Navigation adaptation

Consumer mobile bottom bar: Home, Pay, Receive, Activity, More. Each target at least 44 px with icon and text, current-page indicator and safe-area padding. More presents Wallet, Commerce, FINCOIN, Security and Settings as full labels. FINCOIN navigation clearly enters another product; no shared balance in More.

FINCOIN bottom bar: Overview, Trade, Portfolio, Wallet, More. Merchant: Overview, Payments, QR, Settlement, More. Admin uses a menu drawer with domain context; do not put destructive operations or ambiguous Confirm controls in a persistent bottom nav. Active detail pages highlight their parent and use Back to list where useful.

On 640–1,023 px tablets, use header + drawer rather than a narrow icon-only 240 px sidebar. Bottom navigation is reserved for widths below 640 px; when the on-screen keyboard opens, hide the bottom bar without obscuring the focused field or financial review action. Drawer closes after navigation, restores focus when dismissed and prevents accidental background interaction.

## 3. Screen adaptation matrix

| Screen family | Desktop | Tablet | Mobile order / behavior |
|---|---|---|---|
| Landing | 7/5 hero; three-column supporting features | Hero stacks if copy/diagram needs width | Heading, disclosure, primary CTA, secondary links, diagram; no horizontally scrolling mandatory content |
| Informational public | Content + optional contents rail | Contents collapses to select/list | Linear headings; sticky header never covers anchor target |
| Login/Register | 440 px form plus optional illustration | Centered form | Full-width form with 16 px fields, autofill/paste, no keyboard overlap |
| Consumer Dashboard | 8/4 balance/actions, 8/4 history/QR | Two KPI columns; QR below activity | Available/reserved/pending → Pay/Receive → required alerts → metrics → recent activity → QR/address → chart/network |
| Pay | Form plus contextual summary | Single form with adjacent short summary if space | Source → recipient → amount → note if supported → type/currency → Review |
| Review/Authorize | Focused page, full summary visible | Same logical order | Full page; amount/payee/fee/total/disclosure above Confirm; summary not tooltip-only |
| Receive/QR | QR and request builder split | Stack builder + QR | Amount/expiry → Generate → real QR → copy/share/manual link; prevent QR shrink beyond usable size |
| History | Table with fixed status/amount columns | Fewer visible secondary columns, full detail link | Record cards preserving recipient, direction/type, exact amount, time, status and safe risk label |
| Wallet | Balance card + gateway/activity | Two panels then activity | Balance → deposit/withdraw sandbox actions → gateway explanation → address → activity |
| Commerce | Category/product grid, 8/4 checkout | Two-column cards, stacked checkout | Single/two card columns only if readable; item/order total then BPI source/review |
| FINCOIN | Chart 8, form 4 or 7/5 trade layout | Stacked form/chart | Simulator label → price/holdings → actions/form → review → chart → portfolio/history |
| Merchant | Metrics, trends, queues | Two-card metrics; lists below | Operational notices → Generate QR → settlement/approval tasks → metrics → activity |
| Explorer | Side-by-side latest blocks/events | Stacked tables | Domain/search → stats → blocks → events; long hashes wrap in detail |
| Admin | Dense tables and side-by-side evidence | Stacked evidence sections | Domain → priority queue → detail/evidence → full review for permitted action |

Status, fee, source asset and sandbox labels never disappear at a breakpoint. Only secondary metadata moves into details. A consumer table's public counterpart cannot reuse private fields simply because mobile hides them.

## 4. Payment and keyboard behavior

Amount/quantity inputs request a decimal keyboard but still validate pasted data and accept assistive input. Phone/email keyboard is used only for those identity/contact fields, not BPI addresses. Input text is at least 16 px. Scroll focused inputs into view without detaching labels/errors from fields. Errors focus the summary after submit and provide links to fields.

Sticky primary action area may be used on mobile, with an opaque surface, top border and safe-area padding. It appears after the form in semantic order and reserves equivalent space in document layout. It must not cover totals, disclosures, error messages or keyboard focus. If usable viewport becomes too short, let the action area return to normal document flow.

Financial review is not a swipe-to-pay gesture. Confirmation remains explicit labeled action after exact terms. Back/swipe navigation from a submitted operation leaves it running and preserves its status ID. Rotation, background/resume or network recovery must refetch the same operation; no automatic reauthorization or duplicate payment.

## 5. QR, sharing and camera

Recommended rendered QR size 240 px with a four-module quiet zone and at least 4 CSS px per module where possible. Calculate required size from actual encoded module count; if the payload cannot fit legibly at 320 px width, shorten the server request URL or provide a larger dedicated view/manual link, never clip its quiet zone. Use solid white background and near-black modules, no transparent/glowing/inverted QR and no logo covering modules.

Camera request follows Scan button, never on page arrival. Handle denied permission, missing camera, competing camera use and insecure context with clear manual alternatives. On resume, stop/restart capture only when user intent permits; do not keep background capture running. Recognized QR is resolved before opening payment review; malicious/unsupported schemes are rejected safely.

Native share invokes the platform share sheet only after user action. Copy reports actual clipboard success; if unsupported, show selectable full link/address. Downloadable QR includes domain, sandbox status, request amount/expiry where relevant, and manual URL. Show a text equivalent for every QR so the task does not require vision or a second camera device.

## 6. Tables, charts and long data

Consumer/merchant transaction tables become record lists on mobile. Preserve main amount, counterparty/reference and overall status; detail exposes separate chain/settlement state. Audit/proof tables that fundamentally need comparison may use a clearly labeled horizontal region within the card, with keyboard scroll and a simple detail/text alternative. The page itself must not overflow horizontally.

Long hashes/addresses wrap or use short presentation plus full selectable detail/copy. Never truncate the copied value. Long merchant names wrap to two lines before using a detail expansion; do not truncate recipient identity during review. Large amounts may reduce numeric heading size down to body-safe scale or wrap asset labels, never clip digits or remove precision from review.

Charts resize with fixed readable minimum height (240 px on mobile, 320 px desktop as a starting point), fewer ticks and no overlapping legend. Tooltips gain tap/focus access; text/table alternative remains. Pinch zoom is not required to read exact values. Reduced motion turns off chart entrance animation; no animated price transitions that hide sign changes.

## 7. Loading, offline and viewport-specific states

Skeletons match the active layout so cards do not jump from desktop geometry on mobile. Mobile progress uses a compact current-step plus expandable completed milestones; it never drops settlement as a step. Service failures show local panel messages above retry buttons; bottom navigation remains available to unaffected areas.

Offline before submission blocks financial commands and preserves only safe draft references/fields. Offline after submit shows “Status unavailable while offline” and the payment/order reference; reconnect fetches the original status. No offline payment queue is promised. A lost camera/clipboard capability does not block manual entry. Keep successful-looking cached data labeled stale and never authorize based on it.

## 8. Accessibility and test matrix

Test representative widths 320, 390, 768, 1,024, 1,440 and 1,920 px; short 568 px mobile height; portrait/landscape; touch, mouse and keyboard; 200% text size and 400% desktop zoom; reduced motion and forced colors. Check content-order consistency and that app/browser zoom does not remove actions. Both major mobile browser families and desktop browser engines should be included during implementation QA; this document makes no compatibility claim before tests run.

Critical journeys: register/MFA, pay ₹500, review high-risk allowed/blocked variants, scan/paste a request, follow unknown settlement after resume, refund, approve payout, expire a FINCOIN quote during MFA, inspect a public proof and review an admin case. Verify focus return, clear screen-reader names, bounded announcements and absence of horizontal page scroll. Financial correctness/disclosure checks apply identically at all sizes.
