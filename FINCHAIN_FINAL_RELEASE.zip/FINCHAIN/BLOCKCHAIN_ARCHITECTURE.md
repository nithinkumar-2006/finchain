# FINCHAIN — Blockchain Architecture

Status: sandbox protocol v1.0. Companion: [database atomicity](DATABASE_ARCHITECTURE.md).

## 1. Trust and network model

Run two independent Python ledger services with separate genesis records, network IDs, signing keys, state, stores and validators:

* `finchain-bpi-sandbox-1`: simulated INR payment, funding, settlement, return and redemption events.
* `finchain-fincoin-sandbox-1`: FINCOIN issuance/transfers and SIM_INR trading simulation events.

Each initially uses one authorized block producer and optional read-only verifying followers. Followers verify signatures, hashes and authorized private state replay; they do not vote. There is no mining, staking, gas token, fork choice, public validator membership, or claim of decentralized consensus. FINCOIN is not required to secure or operate BPI.

This is an application-specific signed, hash-linked ledger backed by PostgreSQL. It demonstrates blockchain transaction ordering and integrity under trusted operation. Compromise of the producer and database can rewrite history until checked against an independently stored checkpoint. Hash linkage alone cannot stop an authorized malicious producer. A production public network needs a separately reviewed protocol, independent operators, privacy design, audited consensus, governance, economics and capacity work; do not extend this sequencer into alleged BFT by adding replicas.

## 2. Genesis and addresses

Genesis records protocol version, network ID, domain, epoch, asset definitions/decimals, initial validator public key, signing algorithm, and policy commitments. BPI begins with zero simulated value; faucet/funding operations issue through explicit journals. FINCOIN genesis issuance is defined in [FINCOIN architecture](FINCOIN_ARCHITECTURE.md). Genesis hash is pinned in clients/verifiers.

Normal validator rotation is a system event authorized by two domain administrators, signed into a block by the currently trusted validator, and accompanied by proof of possession of the new key. Its activation height is the next block; verifiers derive the new key from that trusted event. Do not accept a new validator merely because its key ID appears in a header. Compromise or loss of the current key requires the explicit incident/checkpoint recovery process; routine rotation cannot repair an already broken trust chain.

Wallet addresses use `bpi_sbx_` or `fc_sbx_` plus an encoded SHA-256 public-key digest and checksum. Address resolution checks prefix, checksum, registry and network. Rotating a signing key updates an authorized key binding event for the existing wallet; addresses remain stable identifiers of the original registration, not a promise that only the original key can ever act. Key registry history defines validity at block height.

## 3. User-signed transaction contract

Illustrative signed BPI payment payload (addresses/digests shortened, not a test vector):

```json
{
  "protocol_version": "1",
  "domain": "BPI",
  "environment": "sandbox",
  "network_id": "finchain-bpi-sandbox-1",
  "transaction_id": "019-example-payment-id",
  "kind": "PAYMENT_TRANSFER",
  "sender_address": "bpi_sbx_alice",
  "receiver_address": "bpi_sbx_bob",
  "amount_minor": "50000",
  "currency": "INR",
  "fee_minor": "0",
  "timestamp": "2026-09-13T10:00:00.000Z",
  "expires_at": "2026-09-13T10:05:00.000Z",
  "nonce": "0",
  "payment_type": "P2P",
  "request_id": null,
  "order_id": null,
  "authorization_ref": "019-example-grant-id",
  "key_id": "bpi-wallet-key-1"
}
```

Use a strictly versioned schema: unknown fields are rejected, amounts/nonces are canonical decimal strings, identifiers are ASCII, timestamps are UTC with fixed millisecond format, and optional fields are explicitly null per schema. Reject duplicate JSON keys, malformed Unicode and nonfinite values before hashing. Cryptographic schema does not contain user-entered names or descriptions. Encode using UTF-8 and [RFC 8785 JSON canonicalization](https://www.rfc-editor.org/rfc/rfc8785.html); implement published cross-language test vectors before signing real test operations.

Define:

```text
payload_digest = SHA256(UTF8("FINCHAIN:PAYLOAD:v1:") || JCS(payload))
signature = Ed25519.sign(wallet_private_key, payload_digest)
transaction_hash = SHA256(UTF8("FINCHAIN:TX:v1:") || payload_digest || signature_bytes)
```

Signatures are base64url without padding on the wire; hashes are lowercase hex, decoded to bytes for concatenation. Hash inputs have fixed-width digest/signature components, avoiding ambiguous concatenation. Server custodial signing requires a user-authorized grant for this exact payload. Ed25519 proves which key signed, not independent human ownership of a server-held key.

The signed payload excludes mutable `status`, `block_height`, and `risk_score`. `previous_hash` belongs to the block header, not the user intent. `transaction_id` is a stable business identifier; `transaction_hash` is content-derived; system settlement events use separate IDs and link the original payment. API responses may assemble these fields into a receipt, but that receipt is not itself the signed payload.

System transactions have their own schema with `kind`, network/domain, `issuer_id`, `issuer_sequence`, `operation_id`, original transaction reference where applicable, event amounts/asset, timestamp and evidence commitment. Only allowlisted system identities can sign funding/settlement/issuance/correction kinds. A client key cannot submit a system event.

## 4. Validation pipeline

1. Validate schema, domain, network, environment, positive bounded amounts and allowed assets.
2. Resolve key binding and verify canonical hash/signature; verify grant actor, permissions and payload binding.
3. Reject expired instructions, future timestamps beyond 30 seconds allowed skew, terminal/replayed IDs, revoked or frozen wallets.
4. For BPI, validate current risk allow, payment type, request/order claim, sender nonce and hold; independently lock and check available funds/limits.
5. For FINCOIN, validate nonce and available assets; fills additionally validate quote, inventory and matching signed authorization.
6. Validate proposed journals, account assets and balanced totals; verify system evidence and idempotency where relevant.
7. Order accepted events deterministically, construct block and commit it atomically with journals/state/outbox.

Maximum initial transaction payload: 16 KiB. Default candidate limit: 100 transactions or 1 MiB encoded block body, whichever is reached first. Seal at most once per second when work exists; no empty blocks initially. These are starting configurations to benchmark, not throughput claims. Process queued user commands in admission sequence order; separate system-result work gets bounded priority so backlog cannot indefinitely block settlement.

## 5. Block and private commitment format

Block header fields: `protocol_version`, `network_id`, `height` (decimal string), `previous_hash`, `timestamp`, `merkle_root`, `transaction_count`, `writer_epoch`, `validator_key_id`. Genesis uses 64 zero hex characters as previous hash and height 0.

For each transaction, compute a private journal digest as SHA-256 over JCS of ordered journal lines using stable account identifiers, sides, assets and amounts. Then:

```text
journal_commitment = SHA256(0x03 || random_32_byte_salt || journal_digest)
leaf = SHA256(0x00 || transaction_hash_bytes || journal_commitment_bytes)
parent = SHA256(0x01 || left_hash_bytes || right_hash_bytes)
block_hash = SHA256(UTF8("FINCHAIN:BLOCK:v1:") || JCS(header))
block_signature = Ed25519.sign(validator_key, block_hash_bytes)
```

Merkle leaves follow `tx_index`; duplicate the last node on an odd level. A single leaf is its root; genesis empty root is SHA-256 of byte `0x02`. Keep per-transaction salts in encrypted private evidence storage with durable reference in the domain DB. Transaction IDs and authorization references include cryptographically random identifiers so public transaction hashes are not hashes of guessable amount/address tuples alone.

Store ordered transaction hash/commitment pairs as block body and private payloads/journal detail in restricted tables. Do not put risk raw data, contact details, IP/device data, legal names, invoices, or bank details in headers or public blocks. Risk decisions and external evidence are off-chain with salted commitments when audit linkage is required.

## 6. Atomicity, finality and failover

A domain has one financial writer. On start it obtains the PostgreSQL advisory writer lock and a new durable fencing epoch under the head row lock. Every block commit checks that epoch and previous head. An old writer cannot commit against a newer head/epoch. No second active producer is started until fencing is established.

The ledger may have signed an uncommitted block before a crash. Do not publish blocks before database commit. Such proposals are discarded and have no application finality. A committed block is final within this trusted sandbox: no normal forks or rollback. Database recovery cannot silently replace a published head; reconcile checkpoints and external outcomes, then resume or create an explicitly announced new sandbox epoch if recovery cannot preserve history.

Separate `CONFIRMED` chain inclusion from gateway settlement. A return, refund or correction is a newly signed transaction referencing the original. FINCOIN atomic fills have no gateway settlement stage; their financial effect commits with their test-chain block.

## 7. Explorer and verification

Public explorer serves network ID, block height/time, header hash, previous hash, Merkle root, validator key/signature, opaque transaction hashes, journal commitments and Merkle proofs. It does not expose private amounts, addresses, balances, payment type, risk score or identity lookup. Even counts/timing leak activity; public access is opt-in for synthetic datasets and must receive privacy review before use with personal data.

Authorized receipt endpoints may show the payer/payee their full transaction, signature, private proof material when permitted, chain status, and settlement status. Public proofs establish inclusion under the known validator key, not legal settlement or correctness of hidden accounting. Full private replay checks signatures, key history, nonces, postings and balances against the pinned genesis and checkpoint.

Export signed head checkpoints to independently access-controlled append-only storage at least every minute in cloud sandbox. Monitor follower/head divergence. Restore from encrypted domain backups, replay private journals/events, verify Merkle roots and checkpoint continuity before accepting writes.

## 8. Required protocol tests

Test canonicalization across TypeScript/Python, tampered fields/signatures, wrong chain/domain, duplicate JSON keys, Unicode edge cases, decimal overflow, expired nonce reuse, system-event impersonation, duplicate leaf/order changes, odd Merkle trees, stale writer epochs, crash before/after commit, key rotation and genesis mismatch. Public projection tests must assert an explicit field allowlist. Do not claim this protocol is production-safe based solely on passing these tests.
