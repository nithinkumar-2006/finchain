# FINCHAIN delivery manifest

Release: sandbox source delivery, 18 September 2026.

`FINCHAIN_FINAL_RELEASE.zip` contains a single `FINCHAIN/` folder. `MANIFEST.json` inside the archive lists every other included file, byte length and SHA-256 digest. The sibling `FINCHAIN_FINAL_RELEASE.zip.sha256` verifies the complete archive. The manifest excludes its own hash to avoid a circular checksum.

Included: the original architecture, UX and database design documents; authentication handoff; final implementation specifications; installation and deployment guides; QA report and known limitations; Next.js frontend source and lockfile; FastAPI identity and domain source, frozen migrations and dependency locks; backend and browser tests; Dockerfiles; generated secret-free Compose template; Nginx configuration; setup, migration, bootstrap, demo and verification scripts; CI configuration; exported public OpenAPI specifications.

Excluded: synced `sources/`, generated credentials, private keys, database contents, downloaded runtimes, virtual environments, dependency folders, build output, caches, browser artifacts and older ZIPs. Dependencies must be installed after extraction. Local secrets must be freshly generated using the installation guide. This archive is source code and documentation, not a preinstalled executable.

See FINAL_REPORT.md for delivery scope, QA_REPORT.md for executed checks, and KNOWN_LIMITATIONS.md for remaining work. Docker launch and demo seeding are supplied but unverified.
