# FINCHAIN Identity Security Handoff

Identity foundation v0.1, incorporated into the full-platform implementation on 2026-09-15.

## Delivered

FastAPI source, PostgreSQL schema/migration, encrypted opaque-cookie bridge, Argon2id, JWT verification, refresh rotation/replay revocation, recovery/email challenge endpoints, TOTP enrollment/login, RBAC helper and protected audit read, offline role provisioning, rate limits, CSRF/CORS/headers, Dockerfile and tests. See [AUTH_SPEC](AUTH_SPEC.md) and [SECURITY_IMPLEMENTATION](SECURITY_IMPLEMENTATION.md).

## Run and test

From the repository root, using Python 3.12:

```text
python -m venv .venv
.venv/Scripts/python -m pip install -r services/identity/requirements.lock
.venv/Scripts/python -m pip install --no-deps -e services/identity
.venv/Scripts/python -m pytest services/identity/tests -q
```

On Unix use `.venv/bin/python`. Configure the variables in `services/identity/.env.example` through the process environment or deployment secret system; the application does not automatically load `.env`. Supply separate random encryption/lookup keys and an RSA signing key through protected files. Do not paste keys into terminal output or commit them.

Apply migration using separate owner credentials:

```text
python -m alembic -c services/identity/alembic.ini upgrade head
```

Then apply `services/identity/deploy/roles.sql` as DBA and switch the API to a nonowner login inheriting `finchain_identity_runtime`. Start behind HTTPS:

```text
python -m uvicorn finchain_identity.app:create_app --factory --host 127.0.0.1 --port 8000 --no-access-log --no-proxy-headers
```

Build from `services/identity` with `docker build -t finchain-identity:sandbox .`; mount secrets and provide environment variables at runtime. Container execution has not yet been verified locally because Docker is absent.

## Verification evidence

The first executed suite passed 30 tests in 55.30 seconds. Coverage includes registration/verification, login/logout, encrypted storage, refresh replay, reset/session revocation, challenge expiry, generic failures, lockouts, suspicious-login auditing, unknown-field escalation, CSRF, cross-user access, TOTP, live role removal, JWT tampering, expiry, headers/CORS, size/injection payloads, rate abuse and audit rollback/hash verification. Dependency consistency check passed. Offline PostgreSQL migration SQL generation passed.

The four PostgreSQL checks for concurrent refresh reuse, concurrent password reset, append-only audit and runtime role-grant denial subsequently passed locally against PostgreSQL 17.11. The combined platform regression includes real PostgreSQL checks; see QA_REPORT.md for final counts and current evidence. Tests require explicitly configured disposable `_test` databases.

## Remaining security gates

A local Mailpit-only delivery worker and public-page browser tests are now included. Complete Docker-network delivery and complete browser financial journeys on a Docker-enabled host. Add WebAuthn/recovery codes and controlled lost-factor recovery before staff-wide deployment. Complete managed key adapters, rotating key rings, lookup/encryption rotation, external audit checkpoints, retention/restore procedures, vulnerability/image scans and operational alerting. Benchmark Argon2/rate limits and configure trusted proxy behavior. Never expose test tokens publicly.

No financial authority is implemented by identity roles alone. BPI and FINCOIN must independently validate membership, exact operation terms, nonces, limits and signing grants. Domain APIs must fail closed when identity/session validation is unavailable. Wallet private keys must never enter identity or its logs.
