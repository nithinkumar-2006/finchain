# FINCHAIN — System Context

Status: sandbox architecture v1.0, 2026-09-13. Parent: [Master architecture](MASTER_ARCHITECTURE.md).

## Actors and responsibilities

| Actor | Capabilities | Boundary |
|---|---|---|
| Consumer | Profile, BPI wallet, requests, QR scan, transfers, history; optional FINCOIN enrollment | Own resources only; FINCOIN enrollment is never required for BPI |
| Merchant owner | Organization, outlets, operator roles, payout approvals, reports | Merchant-scoped permissions, no access to consumer wallets |
| Merchant cashier | Create requests, inspect receipts | No payouts or role administration by default |
| Merchant finance maker/checker | Prepare / independently approve B2P or B2B payouts | Different authenticated people above configured thresholds |
| Risk reviewer | Review risk cases, request fresh authorization | Cannot alter amount, recipient, journal, or historical risk results |
| Support | Limited, masked customer and transaction views | No signing, balance editing, or private-key retrieval |
| Domain administrator | Pause domain operations, manage approved configuration | MFA, least privilege, audit; no unrestricted money mutation |
| Auditor | Read authorized evidence and verify chain commitments | No write credentials |
| Explorer visitor | Inspect redacted blocks and transaction commitments | No address search, balances, identity mapping, or amounts |
| Gateway simulator | Model funding, transfer settlement, and redemption outcomes | Synthetic value only; not a bank or authorized payment partner |

## System boundary

```mermaid
flowchart TB
    U[Consumer / Merchant] --> W[FINCHAIN Next.js web]
    A[Staff with MFA] --> AD[Admin routes]
    W --> I[Identity API]
    W --> B[BPI API]
    W --> F[FINCOIN API]
    AD --> B
    AD --> F
    B --> BL[BPI ledger and journal]
    BL --> G[Sandbox gateway adapter]
    G --> S[Gateway simulator]
    F --> FL[FINCOIN test ledger and journal]
    F --> M[Synthetic market data]
    BL --> BP[BPI redacted projection]
    FL --> FP[FINCOIN redacted projection]
    V[Explorer visitor] --> E[Explorer API]
    E --> BP
    E --> FP
```

Arrows represent allowed interfaces or event delivery, not shared database credentials. BPI and FINCOIN have no value-transfer edge. Identity issues resource-specific tokens; downstream services validate tokens locally and check current domain permissions for sensitive actions. Gateway settlement instructions originate from durable BPI ledger outbox records, never from an untrusted browser callback.

## Trust zones

1. **Untrusted internet/browser:** all input, QR content, resource IDs, price suggestions, and role claims are untrusted. User-facing code contains no ledger or gateway secrets.
2. **Edge/web:** TLS termination, request limits, same-origin browser session handling, Nginx routing. No financial database write privileges.
3. **Identity/control plane:** credentials, MFA factors, sessions, minimal subject directory. No balances or investment positions.
4. **BPI private network:** BPI API, risk, ledger, scoped signer, gateway adapter and BPI databases. Only ledger worker can write journals, holds, chain, and balances.
5. **FINCOIN private network:** dedicated API, signer, ledger worker, synthetic market feed and data stores. Cannot query BPI financial storage or invoke its signer.
6. **Reporting/public zone:** private tenant reporting uses authorized projections; public explorer uses a physically separate redacted projection store.
7. **Operations plane:** managed secrets, observability, encrypted backup storage, restricted administration. Administrative access does not bypass business approval controls.

In a local deployment, processes can share a host and PostgreSQL server, but use separate databases, roles, Redis instances, and volume namespaces. This is logical isolation, not protection against host administrator compromise. Cloud deploys independent domain resources to limit that risk.

## Product vocabulary

| Term | Defined meaning |
|---|---|
| BPI wallet | Account tracking simulated fiat-denominated obligations; not a bank account or FINCOIN balance |
| BPI address | Domain-prefixed pseudonymous identifier linked privately to a wallet |
| Chain confirmed | Financial event committed with a signed block under the sandbox writer trust model |
| Settlement succeeded | Simulator supplied a verified successful result, applied by the ledger worker |
| Payment completed | Settlement success has been applied and recipient settled balance credited |
| Gateway regulated interface | A contract shaped for a possible future regulated partner; current adapter is simulated |
| FINCOIN | Eight-decimal test asset on an independent chain; no promised market value or returns |
| SIM_INR | Nonredeemable FINCOIN trading-simulator quote units; not BPI INR |
| Public explorer | Public visibility into redacted integrity proofs, not public access to customer financial records |

## External interfaces and exclusions

The baseline has no live bank, UPI, card, exchange, securities, mainnet, or real custody integration. QR codes use FINCHAIN sandbox request links and cannot claim UPI interoperability. No external market data is required. Email/SMS can use local delivery sinks until a messaging provider is separately configured with consent and security controls.

A future gateway implementation must satisfy the same idempotency, status-query, callback authentication, and reconciliation contract, but it cannot be activated by merely changing a URL. Architecture, legal, operational, and partner approval gates are defined in [REGULATORY_BOUNDARIES.md](REGULATORY_BOUNDARIES.md).

## User journeys and information presentation

The web shell offers separate “BPI Payments” and “FINCOIN Simulator” navigation. The BPI home shows spendable and pending simulated INR; the FINCOIN page shows FINCOIN and SIM_INR. Never combine their balances into a single spendable total. A consumer can finish onboarding and pay a merchant without creating a FINCOIN wallet.

Payment receipts show business status, chain status, and settlement status separately. A chain-confirmed/pending-settlement receipt must say that the recipient cannot yet spend the amount. Merchant revenue and order fulfillment depend on completed settlement, with refunds reflected separately. All dashboard totals identify their domain, denomination, time zone, and data freshness.

Account deletion disables access and removes or pseudonymizes eligible profile data according to the sandbox retention policy. It does not edit historical blocks; only opaque identifiers and salted commitments belong there. A new sandbox epoch is a separate network, never an unannounced history reset.
